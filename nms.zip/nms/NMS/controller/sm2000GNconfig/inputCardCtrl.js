angular.module('sm2000GNinputCardgnModule',[]).controller('inputCardgnCtrl', ['$scope', '$state', '$rootScope', '$stateParams', '$rootScope', "$translate", '$state', 'publicService', function($scope, $state, $rootScope, $rootScope, $stateParams, $translate, $state, publicService) {
	$scope.loadconfigContent = function() {
		if ($scope.mauto) {
			var obj = {};
			var configName = $scope.configName,
				configDevId = $scope.mauto.id;
			switch (configName) {
				case "gnss1":
					obj = [{
						"node": "gnss1State",
						"index": "",
						"num": ""
					}, {
						"node": "gnss1Mode",
						"index": "",
						"num": ""
					}, {
						"node": "gnss1Mask",
						"index": "",
						"num": ""
					}, {
						"node": "gnss1TrackMode",
						"index": ".0",
						"num": ""
					}, {
						"node": "gnss1CableDelay",
						"index": "",
						"num": ""
					}, {
						"node": "gnss1Priority",
						"index": "",
						"num": ""
					}, {
						"node": "gnss1PQLState",
						"index": "",
						"num": ""
					}, {
						"node": "gnss1PQL",
						"index": "",
						"num": ""
					}, {
						"node": "gnss1CurrentPosMode",
						"index": "",
						"num": ""
					}, {
						"node": "gnss1CurrentPosition",
						"index": "",
						"num": ""
					}, {
						"node": "gnss1PositionConfig",
						"index": "",
						"num": ""
					}, ]
					$scope.GNSS1Mode();
					$scope.gnss1D = true;
					break;
				case "gnss2":
					obj = [{
						"node": "gnss2State",
						"index": "",
						"num": ""
					}, {
						"node": "gnss2Mode",
						"index": "",
						"num": ""
					}, {
						"node": "gnss2Mask",
						"index": "",
						"num": ""
					}, {
						"node": "gnss2TrackMode",
						"index": ".0",
						"num": ""
					}, {
						"node": "gnss2CableDelay",
						"index": "",
						"num": ""
					}, {
						"node": "gnss2Priority",
						"index": "",
						"num": ""
					}, {
						"node": "gnss2PQLState",
						"index": "",
						"num": ""
					}, {
						"node": "gnss2PQL",
						"index": "",
						"num": ""
					}, {
						"node": "gnss2CurrentPosMode",
						"index": "",
						"num": ""
					}, {
						"node": "gnss2CurrentPosition",
						"index": "",
						"num": ""
					}, {
						"node": "gnss2PositionConfig",
						"index": "",
						"num": ""
					}, ]
					$scope.GNSS2Mode();
					$scope.gnss2D = true;
					break;
				case "ppsTod1":
					obj = [{
						"node": "ppsTODState",
						"index": ".1",
						"num": ""
					}, {
						"node": "ppsTODPriority",
						"index": ".1",
						"num": ""
					}, {
						"node": "ppsTODCableDelay",
						"index": ".1",
						"num": ""
					}, {
						"node": "ppsTODPQLState",
						"index": ".1",
						"num": ""
					}, {
						"node": "ppsTODPQL",
						"index": ".1",
						"num": ""
					}]
					break;
				case "ppsTod2":
					obj = [{
						"node": "ppsTODState",
						"index": ".2",
						"num": ""
					}, {
						"node": "ppsTODPriority",
						"index": ".2",
						"num": ""
					}, {
						"node": "ppsTODCableDelay",
						"index": ".2",
						"num": ""
					}, {
						"node": "ppsTODPQLState",
						"index": ".2",
						"num": ""
					}, {
						"node": "ppsTODPQL",
						"index": ".2",
						"num": ""
					}]
					break;
				case "e1":
					if ($scope.inputCardConfigId && $scope.inputCardConfigPortId) {
						if ($scope.inputCardConfigId == '1') {
							var index = '.' + $scope.inputCardConfigPortId;
						} else if ($scope.inputCardConfigId == '2') {
							var index = '.' + parseInt(parseInt($scope.inputCardConfigPortId) + 4);
						}
					} else {
						var index = '.1';
					}
					$scope.indexs = index;
					obj = [{
						"node": "inputCardState",
						"index": index,
						"num": ""
					}, {
						"node": "inputCardPriority",
						"index": index,
						"num": ""
					}, {
						"node": "inputCardFrameType",
						"index": index,
						"num": ""
					}, {
						"node": "inputCardCRCState",
						"index": index,
						"num": ""
					}, {
						"node": "inputCardSSMState",
						"index": index,
						"num": ""
					}, {
						"node": "inputCardSSMBit",
						"index": index,
						"num": ""
					}, {
						"node": "inputCardPQL",
						"index": index,
						"num": ""
					}, {
						"node": "inputCardCfgUsed",
						"index": index,
						"num": ""
					}]
					break;
				case "otherOutput":
					obj = [{
						"node": "refCriteriaConfig",
						"index": "",
						"num": ""
					}, {
						"node": "refModeConfig",
						"index": "",
						"num": ""
					}, {
						"node": "leapSecond",
						"index": "",
						"num": ""
					}, {
						"node": "systemTime",
						"index": "",
						"num": ""
					}]
					$scope.otherOutputDF();
					break;
				case "ntp":
					if ($scope.ntpStatePortId) {
						var index = '.' + $scope.ntpStatePortId;
					} else {
						var index = '.1';
					}
					$scope.indexs = index;
					obj = [{
						"node": "ntpState",
						"index": index,
						"num": ""
					}, {
						"node": "ntpDSCP",
						"index": index,
						"num": ""
					}, {
						"node": "ntpDSCPState",
						"index": index,
						"num": ""
					}, {
						"node": "ntpTTL",
						"index": index,
						"num": ""
					}, {
						"node": "ntpVlanID",
						"index": index,
						"num": ""
					}, {
						"node": "ntpPacketLimit",
						"index": index,
						"num": ""
					}]
					break;
				case "ntpProbe":
					if ($scope.ntpProbeStatePortId) {
						var index = '.' + $scope.ntpProbeStatePortId;
					} else {
						var index = '.1';
					}
					$scope.indexs = index;
					obj = [{
						"node": "ntpProbeServerIP",
						"index": index,
						"num": ""
					}, {
						"node": "ntpProbeInterval",
						"index": index,
						"num": ""
					}, {
						"node": "ntpProbeVlanID",
						"index": index,
						"num": ""
					}, {
						"node": "ntpProbeState",
						"index": index,
						"num": ""
					}, {
						"node": "ntpProbeDataFormat",
						"index": index,
						"num": ""
					}, {
						"node": "ttl",
						"index": index,
						"num": ""
					}, {
						"node": "dscp",
						"index": index,
						"num": ""
					}, {
						"node": "dscpState",
						"index": index,
						"num": ""
					}]
					break;
				case "ntpStatus":
					if ($scope.ntpStatusPortId) {
						var index = '.' + $scope.ntpStatusPortId;
					} else {
						var index = '.1';
					}
					$scope.indexs = index;
					obj = [{
						"node": "ntpStatusPortEnabled",
						"index": index,
						"num": ""
					}, {
						"node": "ntpStatusVersion",
						"index": index,
						"num": ""
					}, {
						"node": "ntpStatusMode",
						"index": index,
						"num": ""
					}, {
						"node": "ntpStatusLeapStatus",
						"index": index,
						"num": ""
					}, {
						"node": "ntpStatusStratumLevel",
						"index": index,
						"num": ""
					}, {
						"node": "ntpStatusRootDispersion",
						"index": index,
						"num": ""
					}]
					break;
				case "zptpCommon":
					if ($scope.ptpCommonStateId) {
						var index = '.' + $scope.ptpCommonStateId;
					} else {
						var index = '.1';
					}
					$scope.indexs = index;
					obj = [{
						"node": "ptpCommonTimescale",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonState",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonMaxClient",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonProfile",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonClockID",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonPriority1",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonPriority2",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonDomain",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonDSCP",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonDSCPState",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonSyncLimit",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonAnnounceLimit",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonDelayLimit",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonDither",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonTwoStep",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonTTL",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonMgmtAddrMode",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonAlternateMaster",
						"index": index,
						"num": ""
					}, {
						"node": "ptpUnicastNegotiate",
						"index": index,
						"num": ""
					}, {
						"node": "ptpUnicastLeaseDuration",
						"index": index,
						"num": ""
					}]
					break;
				case "zptpMulticast":
					if ($scope.ptpMulticastTableId) {
						var index = '.' + $scope.ptpMulticastTableId;
					} else {
						var index = '.1';
					}
					$scope.indexs = index;
					obj = [{
						"node": "ptpMulticastVlanID",
						"index": index,
						"num": ""
					}, {
						"node": "ptpMulticastSyncIntv",
						"index": index,
						"num": ""
					}, {
						"node": "ptpMulticastAnnounceIntv",
						"index": index,
						"num": ""
					}, {
						"node": "ptpMulticastDelayIntv",
						"index": index,
						"num": ""
					}, {
						"node": "ptpMulticastAnnounceTimeout",
						"index": index,
						"num": ""
					}, {
						"node": "ptpMulticastClientTimeout",
						"index": index,
						"num": ""
					}]
					break;
				case "zUnicastClinet":
					obj = 'ptpUnicastClientTable';
					break;
				case "zptpProbe":
					if ($scope.ptpActiveProbeTableId) {
						var index = '.' + $scope.ptpActiveProbeTableId;
					} else {
						var index = '.1';
					}
					$scope.indexs = index;
					obj = [{
						"node": "ptpActiveProbeGMIpAddr",
						"index": index,
						"num": ""
					}, {
						"node": "ptpActiveProbeVlanID",
						"index": index,
						"num": ""
					}, {
						"node": "ptpActiveProbeGMClockID",
						"index": index,
						"num": ""
					}, {
						"node": "ptpActiveProbeInterval",
						"index": index,
						"num": ""
					}, {
						"node": "ptpActiveProbeDuration",
						"index": index,
						"num": ""
					}, {
						"node": "ptpActiveProbeProfile",
						"index": index,
						"num": ""
					}]
					break;
				case "alarmModle":
					obj = 'alarmConfigTable';
					break;
				case "alarmModleSub":
					obj = 'alarmConfigTable';
					break;
				case "IPETH":
					if ($scope.ipMode) {
						var index = '.' + $scope.ipMode;
					} else {
						var index = '.1';
					}
					if ($scope.firewallType) {
						var indexs = '.' + $scope.firewallType;
					} else {
						var indexs = '.1';
					}
					obj = [{
						"node": "ipMCMode",
						"index": '.0',
						"num": ""
					}, {
						"node": "ipPortState",
						"index": index,
						"num": ""
					}, {
						"node": "ipAddress",
						"index": index,
						"num": ""
					}, {
						"node": "ethAutoNegSpeed",
						"index": '.' + parseInt($scope.ipMode - 1),
						"num": ""
					}, {
						"node": "ethAutoNegState",
						"index": '.' + parseInt($scope.ipMode - 1),
						"num": ""
					}, {
						"node": "ethLinkSpeed",
						"index": '.' + parseInt($scope.ipMode - 1),
						"num": ""
					}, {
						"node": "pktServiceCCPortA",
						"index": '.0',
						"num": ""
					}, {
						"node": "pktServiceCCPortB",
						"index": '.0',
						"num": ""
					}, {
						"node": "firewallState",
						"index": indexs,
						"num": ""
					}]
					break;
				case "vlan":
					$scope.vlanModePortLoad();
					obj = 'vlanTable';
					break;
				case "reboot":
					$scope.loadrReboot();
					obj = [{
						"node": "cc1State",
						"index": '.1',
						"num": ""
					}, {
						"node": "cc2State",
						"index": '.1',
						"num": ""
					}]
					break;
				case "zSet":
					$scope.zCardConfig();
					obj = [{
						"node": "ccState",
						"index": '.1',
						"num": ""
					}]
					break;
				case "inventoryInfo":
					obj = 'inventoryInfoTable';
					break;
				default:
					configName = 'outputCardS';
			}
			if (configName == 'outputCardS' || configName == 'outputCard') {

				if (!$scope.mauto.id || typeof $scope.mauto.id === 'undefined') {

					var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
					publicService.ngAlert(tt, "info");
					return;
				}

				if (!$scope.devExp || $scope.devExp == 'undefined' || $scope.devExp == '未选择') {
					var tt = $translate.use() === 'ch' ? 　"请选择机框" : "Please select machine frame";
					publicService.ngAlert(tt, "info");
					return;
				}
				publicService.doRequest("GET", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/getIoStatus", {
					shelfIndex: $scope.devExp
				}).success(function(r) {
					if (r.data && r.data.length > 0) {
						$scope.frameConfigList = r.data;
						if ($scope.devExp == '0') {
							$scope.inputCardConfigCard = r.data[0].ioSignal;
						} else {
							$scope.inputCardConfigCard = '4-E1';
						}
					}
				})
			} else {
				publicService.doRequest("POST", "/nms/spring/deviceConfig/" + configDevId + "/getDeviceParamColl", obj).success(function(r) {
					if (r.data && r.data.length > 0) {
						$scope.deviceContent = JSON.parse(r.data);
						if ($scope.deviceContent.gnss1PositionConfig) {
							var time = new Array();
							time = $scope.deviceContent.gnss1PositionConfig.split(",");
							$scope.deviceContent.gnss1CurrentPositionJ = time[0];
							$scope.deviceContent.gnss1CurrentPositionW = time[1];
							$scope.deviceContent.gnss1CurrentPositionH = time[2];
						}
						if ($scope.deviceContent.gnss2PositionConfig) {
							var time = new Array();
							time = $scope.deviceContent.gnss2PositionConfig.split(",");
							$scope.deviceContent.gnss2CurrentPositionJ = time[0];
							$scope.deviceContent.gnss2CurrentPositionW = time[1];
							$scope.deviceContent.gnss2CurrentPositionH = time[2];
						}
					}
				});
			}
		}
	}

	$scope.loadconfigContent();

}]);
