angular.module('sm2000GNboardConfiggnModule',[]).controller('boardConfiggnCtrl', ['$scope', '$state', '$rootScope', '$stateParams', '$rootScope', "$translate", '$state', 'publicService', function($scope, $state, $rootScope, $rootScope, $stateParams, $translate, $state, publicService) {
	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
            if (r.data !== null && r.data.content && r.data.content.length > 0) {
                var content = r.data.content;
                var deviceInfo = [];
                for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'SM2000_GN') {
					deviceInfo.push(content[i]);
				}
                }
                $scope.deviceInfo = deviceInfo;
            }
	})
	$scope.backT = true;
	$scope.configT = false;
	$scope.remoteVise = true;
	$scope.backupChange = function(m) {
		if (m.operation == '0') {
			$scope.configT = false;
			$scope.backT = true;
		} else {
			$scope.backT = false;
			$scope.configT = true;
		}
		if (m.operation == '0' && m.cardId == '0') {
			$scope.chonsePlcList = [{
				'name': 'CC',
				'value': 1
			}, {
				'name': 'Remote',
				'value': 2
			}];
		} else if (m.operation == '0' && m.cardId == '1') {
			$scope.chonsePlcList = [{
				'name': 'Remote',
				'value': 2
			}, {
				'name': 'MC',
				'value': 3
			}];
		} else if (m.operation == '0' && m.cardId == '2') {
			$scope.chonsePlcList = [{
				'name': 'Local',
				'value': 0
			}];
		} else if (m.operation == '1' && m.cardId == '0') {
			$scope.chonsePlcList = [{
				'name': 'CC',
				'value': 3
			}, {
				'name': 'Remote',
				'value': 2
			}];
		} else if (m.operation == '1' && m.cardId == '1') {
			$scope.chonsePlcList = [{
				'name': 'Remote',
				'value': 2
			}, {
				'name': 'MC',
				'value': 4
			}];
		} else if (m.operation == '1' && m.cardId == '2') {
			$scope.chonsePlcList = [{
				'name': 'DefaultConfig',
				'value': 0
			}, {
				'name': 'FactoryConfig',
				'value': 1
			}];
		}

	}
	$scope.remoteChange = function(m) {
		if (m == '2') {
			$scope.remoteVise = false;
   			$scope.deviceBackupMod.remoteIP = location.hostname;
   			$scope.deviceBackupMod.remoteName = 'saisi';
   			$scope.deviceBackupMod.remotePas = 'saisi';
		} else {
			$scope.remoteVise = true;
		}
	}

	$scope.backupSub = function(m, chonsePlc) {
		if(!m) return
		var obj = {};
		var objBack = [];
		var remoteIP = m.remoteIP,
			remoteName = m.remoteName,
			filename = m.ftpName,
			remotePas = m.remotePas;
		if (m.operation == 0) {
			if (m.cardId == 2) {
				var node = 'backupConfigLocal';
				var value = "1";
			} else if (m.cardId == 0 && chonsePlc == 1) {
				var node = 'backupConfigMCtoCC';
				var value = "1";

			} else if (m.cardId == 0 && chonsePlc == 2) {
				MCtoRemote = filename + ',' + remoteIP + ',' + remoteName + ',' + remotePas;
				var value = MCtoRemote;
				var node = 'backupConfigMCtoRemote';

			} else if (m.cardId == 1 && chonsePlc == 2) {
				CCtoRemote = filename + ',' + remoteIP + ',' + remoteName + ',' + remotePas;
				var node = 'backupConfigCCtoRemote';
				var value = CCtoRemote;

			} else if (m.cardId == 1 && chonsePlc == 3) {
				var node = 'backupConfigCCtoMC';
				var value = "1";
			}
		}
		if (m.operation == 1) {
			if (m.cardId == 0 && chonsePlc == 3) {
				var node = 'restoreConfigMCtoCC';
				var value = "1";

			} else if (m.cardId == 0 && chonsePlc == 2) {
				RemoteToMC = filename + ',' + remoteIP + ',' + remoteName + ',' + remotePas;
				var node = 'restoreConfigRemoteToMC';
				var value = RemoteToMC;

			} else if (m.cardId == 1 && chonsePlc == 4) {
				var node = 'restoreConfigCCtoMC';
				var value = "1";

			} else if (m.cardId == 1 && chonsePlc == 2) {
				RemoteToCC = filename + ',' + remoteIP + ',' + remoteName + ',' + remotePas;
				var node = 'restoreConfigRemoteToCC';
				var value = RemoteToCC;

			} else if (m.cardId == 2 && chonsePlc == 0) {
				var node = 'restoreDefaultConfig';
				var value = "1";
			} else if (m.cardId == 2 && chonsePlc == 1) {
				var node = 'restoreFactoryConfig';
				var value = "1";
			}
		}
		obj.value = value;
		obj.index = '.0';
		obj.node = node;
		objBack.push(obj);
		if ($scope.devID) {
			publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.devID.id + "/setConfigsBatch", objBack).success(function(r) {
				if (!r || !r.data || r.data.length < 0) return;
				var dataObj = r.data;
				if (dataObj[0].code === true) {
					var tt = $translate.use() === 'ch' ? 　"设置成功" : "Set success";
					publicService.ngAlert(tt, "info");
				} else if (dataObj[0].code === false) {
					var tt = $translate.use() === 'ch' ? 　"设置失败" : "Set failed";
					publicService.ngAlert(tt, "info");
				}
			})
		} else {
				var tt = $translate.use() === 'ch' ?　"请选择设备" : "Please select device";
				publicService.ngAlert(tt,"info");
			return;
		}
	}
}]);
