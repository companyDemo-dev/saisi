angular.module('sm2000GNoutputCardGNppstodConfigModule',[]).controller('outputCardGNppstodConfigCtrl', ['$scope', '$stateParams', '$http', '$state',"$translate",'publicService', function($scope, $stateParams, $http, $state,$translate,  publicService) {
	$scope.ptpData = $stateParams.mauto;
	if ($stateParams.mauto) {
		$scope.ioSignal = $stateParams.mauto.ioSignal;
		$scope.mainframeNum = $stateParams.mauto.ioStatusIndex;
		if ($stateParams.mauto.ioStatusIndex == '0') {
			$scope.mainframeNumT = 'MainShelf';
		} else if ($stateParams.mauto.ioStatusIndex == '1') {
			$scope.mainframeNumT = 'ExpShelf1';
		} else if ($stateParams.mauto.ioStatusIndex == '2') {
			$scope.mainframeNumT = 'ExpShelf2';
		} else if ($stateParams.mauto.ioStatusIndex == '3') {
			$scope.mainframeNumT = 'ExpShelf3';
		} else if ($stateParams.mauto.ioStatusIndex == '4') {
			$scope.mainframeNumT = 'ExpShelf4';
		}
		$scope.solt = $stateParams.mauto.ioStatusIndex;
		$scope.ptpDevID = $stateParams.mauto.devID;
	}

	loadPTPconfigContent();

	function loadPTPconfigContent() {
		var index =  '.' + $scope.solt;
		var obj = [{
			"node": "outputPPSTodState",
			"index": index,
			"num": ""
		}]
		$scope.indexPPS = index;
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/getDeviceParamColl", obj).success(function(r) {
			if (r.data && r.data.length > 0) {
				$scope.deviceContent = JSON.parse(r.data);
				if ($scope.deviceContent.outputPPSTodState == '1') {
					$scope.deviceContent = 'enable';
					var deviceContents = [];
					for (var i = 0; i < 8; i++) {
						var obj = {
							'content': 'enable'
						};
						deviceContents.push(obj);
					}
					$scope.ppsList = deviceContents;
				} else if ($scope.deviceContent.outputPPSTodState == '0') {
					$scope.deviceContent = 'disable';
					var deviceContents = [];
					for (var i = 0; i < 8; i++) {
						var obj = {
							'content': 'disable'
						};
						deviceContents.push(obj);
					}
					$scope.ppsList = deviceContents;
				} else if ($scope.deviceContent.outputPPSTodState == 'null') {
					loadPTPconfigContent();
				}
			}
		});
	}



	$scope.configSub = function(x, index, currentUrl, flag) {
		var configSub_obj = [];
		obj = {};
		obj.value = $scope.deviceContents.outputPPSTodState;
		obj.node = 'outputPPSTodState';
		obj.index = index;
		configSub_obj.push(obj);
		configSubmit(configSub_obj, index, currentUrl);
	}

	/**
	 * configSubmit
	 *   配置提交
	 */
	function configSubmit(configSub_obj, index, currentUrl) {
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/setConfigsBatch", configSub_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			if (r.data.length == 0) {
					var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
					publicService.ngAlert(tt, "info");
				return;
			} else {
				var dataObj = r.data;
				var div = document.createElement('p');
				for (var i = 0; i < dataObj.length; i++) {
					if (dataObj[i].code === true) {
						var node = document.createTextNode(dataObj[i].message + ' ');
						div.appendChild(node);
						
						var outputPPSTodState = $scope.deviceContents.outputPPSTodState;
						if (outputPPSTodState == '0') {
							var outputPPSTodState = 'disable';
						} else if (outputPPSTodState == '1') {
							var outputPPSTodState = 'enable';
						}
						var deviceContents = [];
						for (var i = 0; i < 8; i++) {
							var obj = {
								'content': outputPPSTodState
							};
							deviceContents.push(obj);
						}
						$scope.ppsList = deviceContents;


					} else if (dataObj[i].code === false) {
						var node = document.createTextNode(dataObj[i].message + ' ');
						div.appendChild(node);
					}
				}
				var element = document.getElementById("ngTip");
				element.appendChild(div);
				var tt = $translate.use() === 'ch' ? 　"返回状态列表" : "Return state List";
				publicService.ngAlert(tt, "info");
				setTimeout(function() {
					element.removeChild(div);
				}, 3000)
			}

		})

	}
	/**
	 * downloadConfig
	 *   导出配置
	 */
	$scope.downloadConfig = function(indexs) {
		var config_obj = [];
		var obj = {};
		obj.node = 'outputPPSTodState';
		obj.index = indexs;
		config_obj.push(obj);
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/downloadConfig/config", config_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}
}]);
