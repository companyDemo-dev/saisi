angular.module('sm2000GNOutputCardgnModule',[]).controller('OutputCardgnCtrl', ['$scope', '$state', '$rootScope', '$stateParams', '$rootScope', "$translate", '$state', 'publicService', function($scope, $state, $rootScope, $rootScope, $stateParams, $translate, $state, publicService) {
	/**
	 * downloadConfig
	 *   导出配置
	 */
	$scope.downloadConfig = function() {

		var self = this;
		if (!self.devID) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}

		var config_obj = [];
		var obj = {};
		obj.node = 'ioStatusTable';
		obj.index = '';
		config_obj.push(obj);
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/downloadConfig/config", config_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}
	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data == null) return
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'SM2000_GN') {
					deviceInfo.push(content[i]);
				}
			}
			$scope.deviceInfo = deviceInfo;
		}
	})



	$scope.seach = function() {
		var self = this;
		$scope.mauto = self.devID;
		if (!self.devID || typeof self.devID.id === 'undefined' || $scope.devIP == 'No selection device') {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}

		if (self.devID.deviceStatus == 0) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}
		publicService.loading('start');

		var devId = self.devID.id;
		$scope.mauto.devExp = self.devExp;
		publicService.doRequest("GET", "/nms/spring/deviceConfig/" + devId + "/getIoStatus", {
			shelfIndex: self.devExp
		}).success(function(r) {
			if (r.data && r.data.length > 0) {
				$scope.frameConfigList = r.data;
			}
		})
	}

	$scope.macChange = function(x) {
		var self = this;
		$scope.mauto = self.devID;
		if (self.devID && self.devID.deviceStatus != 0) {
			//子页面之间传值
			/*	$rootScope.shelfList = self.devID.shelfList;
				$rootScope.devIP = self.devID.ip;*/

			//界面显示
			$scope.shelfList = self.devID.shelfList;
		} else if (self.devID && self.devID.deviceStatus != 1) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}

	}


	$scope.outPTPconfigEnt = function(m) {
		if (m) {
			m.devID = $scope.mauto.id;
			//$rootScope.mauto = m;
		}
		if (m.ioSignal == "PPS-TOD" || m.ioSignal == "IRIG") {
			$state.go("index.sm2000GNconfig.outPPSTODconfig", {
				mauto: m
			});

		} else if (m.ioSignal == "E1/2048KHz") {
			var url;
			url = 'index.sm2000GNconfig.outE12048config';
			$state.go(url, {
				mauto: m
			});
		} else if (m.ioSignal == "E1-T1") {
			var url;
			url = 'index.sm2000GNconfig.outE1config';
			$state.go(url, {
				mauto: m
			});
		}
	}

	$scope.outPTPchange = function(m) {
		var self = this;
		var devId = self.devID.id;
		var index = '.' + m.ioStatusIndex;
		t = $translate.use() === "ch" ? "确认切换？" : "confirm change？";
		if (confirm(t)) {
			var reobj = [],
				obj = {};
			obj.value = m.ioStatusRedundancyKey;
			obj.node = 'outputRedundancyState';
			obj.index = index;
			reobj.push(obj);

			publicService.doRequest("POST", "/nms/spring/deviceConfig/" + devId + "/setConfigsBatch", reobj).success(function(r) {
				if (!r || !r.data || r.data.length < 0) return;
				if (r.data.length == 0) {
					var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
					publicService.ngAlert(tt, "info");
					return;
				} else {
					var dataObj = r.data;
					if (dataObj[0].code === true) {
						var tt = $translate.use() === 'ch' ? 　"设置成功" : "Set success";
						publicService.ngAlert(tt, "info");
						setTimeout(function() {
							publicService.doRequest("GET", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/getIoStatus", {
								shelfIndex: $scope.mauto.devExp
							}).success(function(r) {
								if (r.data && r.data.length > 0) {
									$scope.frameConfigList = r.data;
								}
							})
						}, 5000)
					} else if (dataObj[0].code === false) {
						var tt = $translate.use() === 'ch' ? 　"设置失败" : "Set failed";
						publicService.ngAlert(tt, "info");
					}
				}
			})
		}
	}

}]);
