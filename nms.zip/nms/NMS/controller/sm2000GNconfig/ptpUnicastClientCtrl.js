angular.module('sm2000GNptpUnicastClientgnModule',[]).controller('ptpUnicastClientgnCtrl', ['$scope', '$state', '$rootScope', '$stateParams', '$rootScope', "$translate", '$state', 'publicService', function($scope, $state, $rootScope, $rootScope, $stateParams, $translate, $state, publicService) {
	/**
	 * downloadConfig
	 *   导出配置
	 */
	$scope.downloadConfig = function() {
		var self = this;
		if (!self.devID) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}

		var config_obj = [];
		var obj = {};
		obj.node = 'ptpUnicastClientTable';
		obj.index = '';
		config_obj.push(obj);
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/downloadConfig/config", config_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}
	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data == null) return
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'SM2000_GN') {
					deviceInfo.push(content[i]);
				}
			}
			$scope.deviceInfo = deviceInfo;
		}
	})



	$scope.seach = function() {
		var self = this;
		$scope.mauto = self.devID;
		if (!self.devID || typeof self.devID.id === 'undefined' || $scope.devIP == 'No selection device') {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}

		if (self.devID.deviceStatus == 0) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}
		publicService.loading('start');

		var devId = self.devID.id;
		obj = 'ptpUnicastClientTable';
		publicService.doRequest("GET", "/nms/spring/deviceConfig/" + devId + "/configs/" + obj + "", {}).success(function(r) {
			var list = [];
			if ($scope.ptpUnicastClientTableId == '1') {
				for (var i = 0; i < 10; i++) {
					list.push(r.data[i]);
				}
				$scope.configList = list;
			} else if ($scope.ptpUnicastClientTableId == '2') {
				for (var i = 10; i < 20; i++) {
					list.push(r.data[i]);
				}
				$scope.configList = list;
			}
		});
	}


	$scope.listSetConfig = function(x) {
		$scope.deviceContent = x;
		if (x.destNetwork != 'n/a') {
			$scope.all = false;
		} else {
			$scope.all = true;
		}
		if (x.alarmLevel == '5') {
			$scope.alarmLevelyD = true;
			$scope.alarmDelayD = true;
		} else {
			$scope.alarmLevelyD = false;
			$scope.alarmDelayD = false;
		}
	  localStorage.setItem("valueDoms", JSON.stringify(x));
	}

	$scope.configSub = function(newData) {
		if (!verify.Unicast_clinet(newData, publicService, $translate)) return;
		var self = this;
		if (!self.devID) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}
		if ($scope.ptpCommonStateId) {
			var index = '.' + $scope.ptpCommonStateId;
		} else {
			var index = '.1';
		}
		var oldData = JSON.parse(localStorage.getItem("valueDoms")),
			arr = [];
		for (ls in oldData) {
			if (oldData[ls] !== newData[ls]) {
				arr.push({
					"node": ls,
					"index": newData.ptpUnicastClientIndex,
					"value": newData[ls]
				})
			}
		}
		if (arr.length == 0) {
			var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
			publicService.ngAlert(tt, "info");
			return;
		}
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/setConfigsBatch", arr).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var dataObj = r.data,
				str = "";
			var tt = $translate.use() === 'ch' ? 　"返回状态列表" : "Return state List";
			for (var i = 0; i < dataObj.length; i++) {
				str += dataObj[i].message + ';'
			}
			publicService.ngAlert(str + tt, "info");
			localStorage.setItem("valueDoms", JSON.stringify(newData));
		})
	}


}]);
