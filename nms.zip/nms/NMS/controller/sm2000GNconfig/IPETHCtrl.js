angular.module('sm2000GNIPETHgnModule',[]).controller('IPETHgnCtrl', ['$scope', '$state', '$rootScope', '$stateParams', '$rootScope', "$translate", '$state', 'publicService', function($scope, $state, $rootScope, $rootScope, $stateParams, $translate, $state, publicService) {

	//网络初始化
	$scope.ipMode = '1';
	$scope.MCvisible = true;
	$scope.ipModeChange = function(m) {
			if (m == 1) {
				$scope.MCvisible = true;
				$scope.CCvisible = false;
			} else if (m == 2 || m == 3) {
				$scope.MCvisible = false;
				$scope.CCvisible = true;
			}
		}
		//防火墙初始化
	$scope.firewallType = '1';
	$scope.firewallTypeChange = function() {
		$scope.seach();
	}

	/**
	 * downloadConfig
	 *   导出配置
	 */
	$scope.downloadConfig = function() {
		if (!$scope.mauto) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}
		var config_obj = [];
		var _vals = JSON.parse(localStorage.getItem('valueDoms'));
		for (var x in _vals) {
			var data = {};
			if (x == 'pktServiceCCMode'||x == 'maskAddress'||x == 'gatewayAddress') continue
			data.node = x;
		  if(x == 'ipPortState'||x == 'ipAddress'){
			data.index =  $scope.indexs;
		}else if(x == 'firewallState'){
			data.index =  $scope.indexss;
		}else if(x == 'ethAutoNegSpeed' || x == 'ethAutoNegState'|| x == 'ethLinkSpeed'){
			data.index = '.' + parseInt($scope.indexs - 1);
		}else{
			data.index = '.0';
		}
			config_obj.push(data);
		}
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/downloadConfig/config", config_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}

	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data == null) return
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'SM2000_GN') {
					deviceInfo.push(content[i]);
				}
			}
			$scope.deviceInfo = deviceInfo;
		}
	})



	$scope.seach = function() {
		var self = this;
		$scope.mauto = self.devID;
		if (!self.devID || typeof self.devID.id === 'undefined' || $scope.devIP == 'No selection device') {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}

		if (self.devID.deviceStatus == 0) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}
		publicService.loading('start');

		var devId = self.devID.id;
		if ($scope.ipMode) {
			var index = '.' + $scope.ipMode;
		} else {
			var index = '.1';
		}
		$scope.indexs = index;
		if ($scope.firewallType) {
			var indexs = '.' + $scope.firewallType;
		} else {
			var indexs = '.1';
		}
		$scope.indexss = indexs;
		obj = [{
			"node": "ipMCMode",
			"index": '.0',
			"num": ""
		}, {
			"node": "ipPortState",
			"index": index,
			"num": ""
		}, {
			"node": "ipAddress",
			"index": index,
			"num": ""
		}, {
			"node": "ethAutoNegSpeed",
			"index": '.' + parseInt($scope.ipMode - 1),
			"num": ""
		}, {
			"node": "ethAutoNegState",
			"index": '.' + parseInt($scope.ipMode - 1),
			"num": ""
		}, {
			"node": "ethLinkSpeed",
			"index": '.' + parseInt($scope.ipMode - 1),
			"num": ""
		}, {
			"node": "pktServiceCCPortA",
			"index": '.0',
			"num": ""
		}, {
			"node": "pktServiceCCPortB",
			"index": '.0',
			"num": ""
		}, {
			"node": "firewallState",
			"index": indexs,
			"num": ""
		}]
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + devId + "/getDeviceParamColl", obj).success(function(r) {
			if (r.data && r.data.length > 0) {
				$scope.deviceContent = JSON.parse(r.data);
				if ($scope.deviceContent.ipAddress) {
					var time = new Array();
					time = $scope.deviceContent.ipAddress.split(",");
					$scope.deviceContent.ipAddress = time[0];
					$scope.deviceContent.maskAddress = time[1];
					$scope.deviceContent.gatewayAddress = time[2];
				}


				if ($scope.deviceContent.pktServiceCCPortA) {
					switch ($scope.deviceContent.pktServiceCCPortA) {
						case "0":
							$scope.deviceContent.pktServiceCCPortA = 'ptp-gm';
							break;
						case "1":
							$scope.deviceContent.pktServiceCCPortA = 'ptp-probe';
							break;
						case "2":
							$scope.deviceContent.pktServiceCCPortA = 'ntp-server';
							break;
						case "3":
							$scope.deviceContent.pktServiceCCPortA = 'ntp-probe';
							break;
					}
				}
				if ($scope.deviceContent.pktServiceCCPortB) {
					switch ($scope.deviceContent.pktServiceCCPortB) {
						case "0":
							$scope.deviceContent.pktServiceCCPortB = 'ptp-gm';
							break;
						case "1":
							$scope.deviceContent.pktServiceCCPortB = 'ptp-probe';
							break;
						case "2":
							$scope.deviceContent.pktServiceCCPortB = 'ntp-server';
							break;
						case "3":
							$scope.deviceContent.pktServiceCCPortB = 'ntp-probe';
							break;
					}
				}
			}
	        var setData = JSON.parse(r.data);
			var obj = setData.ipAddress.split(',');
			   setData.ipAddress = obj[0],
				setData.maskAddress = obj[1],
				setData.gatewayAddress = obj[2],
				setData.pktServiceCCMode = '';
			localStorage.setItem("valueDoms", JSON.stringify(setData));
		});
	}

	$scope.configSub = function(newData, pktServiceCCMode) {
		if (!verify.IPETH(newData, publicService, $translate)) return;
		var self = this;
		if (!self.devID) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}
		var oldData = JSON.parse(localStorage.getItem("valueDoms")),
			arr = [];
		ip1 = true;
		for (ls in oldData) {
			obj = {};
			if (oldData[ls] !== newData[ls]) {
				switch (ls) {
					case "ipAddress":
					case "maskAddress":
					case "gatewayAddress":
						if (ip1) {
							var addr = $scope.deviceContent.ipAddress,
								mask = $scope.deviceContent.maskAddress,
								gateway = $scope.deviceContent.gatewayAddress,
								adr = new Array(addr, mask, gateway);
							var ipAddress = adr.join(',');
							obj.value = ipAddress;
							obj.node = 'ipAddress';
							obj.index = $scope.ipMode;
							ip1 = false;
							arr.push(obj);
						}
						break;
					case "ipPortState":
						t = $translate.use() === "ch" ? "确认是否操作端口状态！" : "Confirm whether operation port status!";
						if (confirm(t)) {
							var ipPortState = $scope.deviceContent.ipPortState;
							obj.value = ipPortState;
							obj.node = 'ipPortState';
							obj.index = $scope.ipMode;
							arr.push(obj);
						}
						break;
					case "ipMCMode":
						var ipMCMode = $scope.deviceContent.ipMCMode;
						obj.value = ipMCMode;
						obj.node = 'ipMCMode';
						obj.index = '.0';
						arr.push(obj);
						break;
					case "ethAutoNegState":
						var ethAutoNegState = $scope.deviceContent.ethAutoNegState;
						obj.value = ethAutoNegState;
						obj.node = 'ethAutoNegState';
						obj.index = parseInt($scope.ipMode) - 1;
						arr.push(obj);
						break;
					case "ethAutoNegSpeed":
						var ethAutoNegSpeed = $scope.deviceContent.ethAutoNegSpeed;
						obj.value = ethAutoNegSpeed;
						obj.node = 'ethAutoNegSpeed';
						obj.index = parseInt($scope.ipMode) - 1;
						arr.push(obj);
						break;
					case "pktServiceCCPortA":
					case "pktServiceCCPortB":
					case "pktServiceCCMode":
						continue
						break;
					default:
						arr.push({
							"node": ls,
							"index": $scope.indexs,
							"value": newData[ls]
						})
				}
			}
		}

		if (pktServiceCCMode) {
			var pktServiceCCMode = $scope.pktServiceCCMode,
				pktServiceCCPort = $scope.pktServiceCCPort;
			if (pktServiceCCPort == '1') {
				obj.node = 'pktServiceCCPortA';
				obj.index = '.' + 0;
			} else if (pktServiceCCPort == '2') {
				obj.node = 'pktServiceCCPortB';
				obj.index = '.' + 0;
			}
			obj.value = pktServiceCCMode;
			arr.push(obj);
		}
		if (arr.length == 0) {
			var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
			publicService.ngAlert(tt, "info");
			return;
		}
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/setConfigsBatch", arr).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var dataObj = r.data,
				str = "";
			var tt = $translate.use() === 'ch' ? 　"返回状态列表" : "Return state List";
			for (var i = 0; i < dataObj.length; i++) {
				str += dataObj[i].message + ';'
			}
			publicService.ngAlert(str + tt, "info");
			newData.pktServiceCCMode = '';
			$scope.pktServiceCCMode = null;
			localStorage.setItem("valueDoms", JSON.stringify(newData));
		})
	}
	$scope.restSub = function() {
		var self = this;
		var configSub_obj = [];
		obj = {};
		obj.value = '2';
		obj.node = 'ipPortState';
		obj.index = '.' + $scope.ipMode;
		configSub_obj.push(obj);

		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/setConfigsBatch", configSub_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var dataObj = r.data;
			var tt = $translate.use() === 'ch' ? 　"重启成功" : "Rest success";
			publicService.ngAlert(tt, "info");
		})

	}

}]);
