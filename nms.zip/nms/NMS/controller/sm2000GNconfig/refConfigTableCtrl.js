angular.module('sm2000GNrefConfigTablegnModule',[]).controller('refConfigTablegnCtrl', ['$scope', '$state', '$rootScope', '$stateParams', '$rootScope', "$translate", '$state', 'publicService', function($scope, $state, $rootScope, $rootScope, $stateParams, $translate, $state, publicService) {
	$scope.deviceContent = {};
			/**
	 * downloadConfig
	 *   导出配置
	 */
	$scope.downloadConfig = function() {

		var self = this;
		if (!self.devID) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}

		var config_obj = [];
		var obj = {};
		obj.node = 'refConfigTable';
		obj.index = '';
		config_obj.push(obj);
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/downloadConfig/config", config_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}
	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data == null) return
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'NS7200') {
					deviceInfo.push(content[i]);
				}
			}
			$scope.deviceInfo = deviceInfo;
		}
	});

	$scope.devidFun = function(m){
		if(!m){$scope.mauto ={}; return; }
		publicService.loading('start');
		publicService.doRequest("GET", "/nms/spring/deviceConfig/" + m.id + "/configs/refConfigTable", {}).success(function(r) {
			if(r && r.data){
				$scope.refConfigTable = r.data;
			}				
		});
	}

	$scope.re = "";
	$scope.refPriorityFun = function (){
		$scope.re = this.refPriority;
	}

	$scope.refConfigTableSet = function (m,x){
		var self = this;

		if (!self.devID) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return
		}
		if(verifyFun.isNull(this.re)){
			this.re = m.refPriority;
		}
		var arr = [{"node": "refPriority", "index": '.'+x ,"value" : this.re}];
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/setConfigsBatch", arr).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var dataObj = r.data, str = "";
			if(dataObj[0].code){
				var doms = angular.element(document.getElementById('imageInfoTable')).find("tr");
				var tt = $translate.use() === 'ch' ? 　"设置成功" : "Set success";
				publicService.ngAlert(tt, "info");
			}else{
				publicService.ngAlert(dataObj[0].message, "info");
			}
		})
	}
}]);
