angular.module('sm2000GNRebootgnModule',[]).controller('RebootgnCtrl', ['$scope', '$state', '$rootScope', '$stateParams', '$rootScope', "$translate", '$state', 'publicService', function($scope, $state, $rootScope, $rootScope, $stateParams, $translate, $state, publicService) {
	$scope.deviceContent = {};
	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data == null) return
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'SM2000_GN') {
					deviceInfo.push(content[i]);
				}
			}
			$scope.deviceInfo = deviceInfo;
		}
	})



	$scope.seach = function() {
		var self = this;
		$scope.mauto = self.devID;
		if (!self.devID || typeof self.devID.id === 'undefined' || $scope.devIP == 'No selection device') {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}

		if (self.devID.deviceStatus == 0) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}
		publicService.loading('start');

		var devId = self.devID.id;
		obj = [{
			"node": "cc1State",
			"index": '.1',
			"num": ""
		}, {
			"node": "cc2State",
			"index": '.1',
			"num": ""
		}]

		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + devId + "/getDeviceParamColl", obj).success(function(r) {
			if (r.data && r.data.length > 0) {
				$scope.deviceContent = JSON.parse(r.data);
				
						if ($scope.deviceContent.cc1State) {
							var sum = 0;
							if ($scope.deviceContent.cc1State != 'card not present') {
								sum = 1;
							}
							if ($scope.deviceContent.cc2State != 'card not present') {
								sum = 2;
							}
							if ($scope.deviceContent.cc2State != 'card not present' && $scope.deviceContent.cc2State != 'card not present') {
								sum = 3;
							}
							$scope.loadrReboot(sum);
						}
			}
		});
	}



	//重启设备初始化
	$scope.loadrReboot = function(x) {
		publicService.doRequest("GET", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/configs/ioStatusTable", {}).success(function(r) {
			$scope.rebootList = [{
				'name': '重启系统',
				'value': 0,
				'index': 0
			}, {
				'name': '重启管理卡',
				'value': 1,
				'index': 1
			}];

			if (x == 1) {
				obj = {
					'name': '重启钟卡1',
					'value': 4,
					'index': 4
				};
				$scope.rebootList.push(obj);
			}
			if (x == 2) {
				obj = {
					'name': '重启钟卡2',
					'value': 5,
					'index': 5
				};
				$scope.rebootList.push(obj);
			}
			if (x == 3) {
				obj = {
					'name': '重启钟卡1',
					'value': 4,
					'index': 4
				};
				obj2 = {
					'name': '重启钟卡2',
					'value': 5,
					'index': 5
				};
				$scope.rebootList.push(obj);
				$scope.rebootList.push(obj2);
			}
		})
	}


	//重启设备
	$scope.rebootSub = function(configSub_obj) {
		var reobj = [],
			obj = {};
		if (configSub_obj.reboot == 0) {
			obj.value = '1';
			obj.node = 'systemReboot';
			obj.index = '.0';
			reobj.push(obj);
		} else if (configSub_obj.reboot == 1) {
			obj.value = '1';
			obj.node = 'mcReboot';
			obj.index = '.0';
			reobj.push(obj);
		} else if (configSub_obj.reboot == 4) {
			obj.value = '1';
			obj.node = 'cc1Reboot';
			obj.index = '.0';
			reobj.push(obj);
		} else if (configSub_obj.reboot == 5) {
			obj.value = '1';
			obj.node = 'cc2Reboot';
			obj.index = '.0';
			reobj.push(obj);
		} 
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/setConfigsBatch", reobj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			if (r.data.length == 0) {
				var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
				publicService.ngAlert(tt, "info");
				return;
			} else {
				var dataObj = r.data;
				if (dataObj[0].code === true) {
					var tt = $translate.use() === 'ch' ? 　"重启成功" : "Restart success";
					publicService.ngAlert(tt, "info");
				} else if (dataObj[0].code === false) {
					var tt = $translate.use() === 'ch' ? 　"重启成功" : "Restart success";
					publicService.ngAlert(tt, "info");
				}
			}
		})
	}
}]);
