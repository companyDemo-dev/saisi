angular.module('sm2000GNvlangnModule',[]).controller('vlangnCtrl', ['$scope', '$state', '$rootScope', '$stateParams', '$rootScope', "$translate", '$state', 'publicService', function($scope, $state, $rootScope, $rootScope, $stateParams, $translate, $state, publicService) {
	/**
	 * downloadConfig
	 *   导出配置
	 */
	$scope.downloadConfig = function() {

		var self = this;
		if (!self.devID) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}

		var config_obj = [];
		var obj = {};
		obj.node = 'alarmStatusTable';
		obj.index = '';
		config_obj.push(obj);
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/downloadConfig/config", config_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}
	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data == null) return
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'SM2000_GN') {
					deviceInfo.push(content[i]);
				}
			}
			$scope.deviceInfo = deviceInfo;
		}
	})


	//VLAN使能初始化
	$scope.vlanModePortLoad = function() {
		obj = [{
			"node": "vlanModePortState",
			"index": '.' + $scope.vlanPortId,
			"num": ""
		}]
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/getDeviceParamColl", obj).success(function(r) {
			if (r.data && r.data.length > 0) {
				$scope.deviceContent = JSON.parse(r.data);
				_newVals();
			}
		});
	}
	$scope.seach = function() {
		var self = this;
		$scope.mauto = self.devID;
		if (!self.devID || typeof self.devID.id === 'undefined' || $scope.devIP == 'No selection device') {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}

		if (self.devID.deviceStatus == 0) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}
		publicService.loading('start');

		var devId = self.devID.id;
		publicService.doRequest("GET", "/nms/spring/deviceConfig/" + devId + "/configs/vlanTable", {}).success(function(r) {
			if (r.data && r.data.length > 0) {
				$scope.vlanModuleID = r.data[0].vlanCfg.vlanModuleID;
				var obj = [];
				if ($scope.vlanPortId == '1') {
					for (var i = 0; i < 16; i++) {
						var val = {};
						var vlanCfg = r.data[i].vlanCfg,
							vlan = [];
						val.vlanState = r.data[i].vlanState;
						val.vlanPortID = r.data[i].vlanPortID;
						val.vlanIndex = r.data[i].vlanIndex;
						if (vlanCfg == '') {
							val.index = 'none';
							val.id = 'none';
							val.priority = 'none';
							val.addr = 'none';
							val.netmask = 'none';
							val.gateway = 'none';
							val.destNetwork = 'none';
						} else {
							vlan = vlanCfg.split(',');
							index = vlan[0];
							val.index = index.replace(/index=/, '');

							id = vlan[1];
							val.id = id.replace(/id=/, '');

							priority = vlan[2];
							val.priority = priority.replace(/priority=/, '');

							addr = vlan[3];
							val.addr = addr.replace(/addr=/, '');

							netmask = vlan[4];
							val.netmask = netmask.replace(/netmask=/, '');

							gateway = vlan[5];
							val.gateway = gateway.replace(/\//g, '').replace(/gatewaynextHop=/, '');

							destNetwork = vlan[6];
							val.destNetwork = destNetwork.replace(/destNetwork=/, '');
						}
						obj.push(val);
					}
				} else if ($scope.vlanPortId == '2') {
					for (var i = 16; i < 32; i++) {
						var val = {};
						var vlanCfg = r.data[i].vlanCfg,
							vlan = [];
						val.vlanState = r.data[i].vlanState;
						val.vlanPortID = r.data[i].vlanPortID;
						val.vlanIndex = r.data[i].vlanIndex;
						if (vlanCfg == '') {
							val.index = 'none';
							val.id = 'none';
							val.priority = 'none';
							val.addr = 'none';
							val.netmask = 'none';
							val.gateway = 'none';
							val.destNetwork = 'none';
						} else {
							vlan = vlanCfg.split(',');
							index = vlan[0];
							val.index = index.replace(/index=/, '');

							id = vlan[1];
							val.id = id.replace(/id=/, '');

							priority = vlan[2];
							val.priority = priority.replace(/priority=/, '');

							addr = vlan[3];
							val.addr = addr.replace(/addr=/, '');

							netmask = vlan[4];
							val.netmask = netmask.replace(/netmask=/, '');

							gateway = vlan[5];
							val.gateway = gateway.replace(/\//g, '').replace(/gatewaynextHop=/, '');

							destNetwork = vlan[6];
							val.destNetwork = destNetwork.replace(/destNetwork=/, '');
						}
						obj.push(val);
					}
				}
				$scope.configList = obj;
				$scope.vlanModePortLoad();
			}
		})
	}
	$scope.listSetConfig = function(x) {
		$scope.deviceContent = x;
		if (x.destNetwork != 'n/a') {
			$scope.all = false;
		} else {
			$scope.all = true;
		}
		if (x.alarmLevel == '5') {
			$scope.alarmLevelyD = true;
			$scope.alarmDelayD = true;
		} else {
			$scope.alarmLevelyD = false;
			$scope.alarmDelayD = false;
		}
		_newVals();
	}
	function _newVals() {
		var deviceContent = $scope.deviceContent;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		localStorage.setItem('valueDoms', JSON.stringify(obj));
	}

		$scope.vlanAddEdit = function(m) {
		$state.go("index.sm2000GNconfig.vlanAddEdit", {
			mauto: m
		});
	}


		$scope.configSub = function(x) {
		if (!verify.ip_vlan(x, publicService, $translate)) return;
	
		indexObj = '.'+$scope.deviceContent.vlanIndex;
	
		ds = _changeVals(x);
		var configSub_obj = [];
		vlanF = true;
		for (var j in ds) {
			obj = {};
			switch (j) {
				case "vlanState":
					var vlanState = $scope.deviceContent.vlanState;
					obj.value = vlanState;
					obj.node = 'vlanState';
					obj.index = indexObj;
					configSub_obj.push(obj);
					break;
				case "vlanModePortState":
					var vlanModePortState = $scope.deviceContent.vlanModePortState;
					obj.value = vlanModePortState;
					obj.node = 'vlanModePortState';
					obj.index = '.' + $scope.vlanPortId;
					configSub_obj.push(obj);
					break;
				case "addr":
				case "netmask":
				case "gateway":
				case "destNetwork":
					if (vlanF) {
						var addr = $scope.deviceContent.addr,
							netmask = $scope.deviceContent.netmask,
							gateway = $scope.deviceContent.gateway,
							destNetwork = $scope.deviceContent.destNetwork;
						if (destNetwork != 'n/a') {
							var vlanCfg = new Array('addr=' + addr, 'netmask=' + netmask, 'nextHop=' + gateway);
							vlanCfg.push('destNetwork=' + destNetwork);
						} else {
							var vlanCfg = new Array('addr=' + addr, 'netmask=' + netmask, 'gateway=' + gateway);
						}
						vlanCfg = vlanCfg.join(',');
						obj.value = vlanCfg;
						obj.node = 'vlanCfg';
						obj.index = indexObj;
						configSub_obj.push(obj);
						vlanF = false;
					}
					break;
				default:
					obj.value = ds[j];
					obj.node = j;
					obj.index = indexObj;
					configSub_obj.push(obj);
			}
		}
		configSubmit(configSub_obj);
		_newVals()
	}

	/**
	 * configSubmit
	 *   配置提交
	 */
	function configSubmit(configSub_obj) {
		if (!$scope.mauto) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return
		}
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/setConfigsBatch", configSub_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var doc;
			if (r.data.length == 0) {
				var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
				publicService.ngAlert(tt, "info");
				return;
			} else {
				var dataObj = r.data;
				var div = document.createElement('p');
				for (var i = 0; i < dataObj.length; i++) {
					if (dataObj[i].code === false) {
						var node = document.createTextNode(dataObj[i].message + ' ');
						div.appendChild(node);

					} else if (dataObj[i].code === true) {
						var node = document.createTextNode(dataObj[i].message + ' ');
						div.appendChild(node);
					}
				}
				var element = document.getElementById("ngTip");
				element.appendChild(div);
				var tt = $translate.use() === 'ch' ? 　"返回状态列表" : "Return state List";
				publicService.ngAlert(tt, "info");
				setTimeout(function() {
					element.removeChild(div);
				}, 3000)
			}

		})

	}
	function _changeVals(x) {
		var deviceContent = x;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		var _vals = JSON.parse(localStorage.getItem('valueDoms')),
			changeObj = {};
		for (var i = 0; i < obj.length; i++) {
			var _id = obj[i].name,
				_val = obj[i].value;
			for (var j = 0; j < _vals.length; j++) {
				var _id2 = _vals[j].name,
					_val2 = _vals[j].value;
				if (_id === _id2) {
					if (_val != _val2) {
						changeObj[_id] = _val;
					}
				}
			}
		}
		return changeObj;
	}

}]);
