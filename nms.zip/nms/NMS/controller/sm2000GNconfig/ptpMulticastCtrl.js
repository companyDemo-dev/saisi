angular.module('sm2000GNptpMulticastgnModule',[]).controller('ptpMulticastgnCtrl', ['$scope', '$state', '$rootScope', '$stateParams', '$rootScope', "$translate", '$state', 'publicService', function($scope, $state, $rootScope, $rootScope, $stateParams, $translate, $state, publicService) {
	/**
	 * downloadConfig
	 *   导出配置
	 */
	$scope.downloadConfig = function() {
		if (!$scope.mauto) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}
		var config_obj = [];
		var _vals = JSON.parse(localStorage.getItem('valueDoms'));
		for (var x in _vals) {
			var data = {};
			data.node = x;
			data.index = $scope.indexs;
			config_obj.push(data);
		}
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/downloadConfig/config", config_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}

	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data == null) return
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'SM2000_GN') {
					deviceInfo.push(content[i]);
				}
			}
			$scope.deviceInfo = deviceInfo;
		}
	})



	$scope.seach = function() {
		var self = this;
		$scope.mauto = self.devID;
		if (!self.devID || typeof self.devID.id === 'undefined' || $scope.devIP == 'No selection device') {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}

		if (self.devID.deviceStatus == 0) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}
		publicService.loading('start');

		var devId = self.devID.id;
		if ($scope.ptpMulticastTableId) {
			var index = '.' + $scope.ptpMulticastTableId;
		} else {
			var index = '.1';
		}
		$scope.indexs = index;
		obj = [{
			"node": "ptpMulticastVlanID",
			"index": index,
			"num": ""
		}, {
			"node": "ptpMulticastSyncIntv",
			"index": index,
			"num": ""
		}, {
			"node": "ptpMulticastAnnounceIntv",
			"index": index,
			"num": ""
		}, {
			"node": "ptpMulticastDelayIntv",
			"index": index,
			"num": ""
		}, {
			"node": "ptpMulticastAnnounceTimeout",
			"index": index,
			"num": ""
		}, {
			"node": "ptpMulticastClientTimeout",
			"index": index,
			"num": ""
		}]
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + devId + "/getDeviceParamColl", obj).success(function(r) {
			if (r.data && r.data.length > 0) {
				$scope.deviceContent = JSON.parse(r.data);
				localStorage.setItem("valueDoms", r.data);
			}
		});
	}
   $scope.configSub = function(newData) {
		if (!verify.multicast(newData, publicService, $translate)) return;
		var self = this;
		if (!self.devID) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}
		var oldData = JSON.parse(localStorage.getItem("valueDoms")),
			arr = [];
		for (ls in oldData) {
			if (oldData[ls] !== newData[ls]) {
				arr.push({
					"node": ls,
					"index": $scope.indexs,
					"value": newData[ls]
				})
			}
		}
		if (arr.length == 0) {
			var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
			publicService.ngAlert(tt, "info");
			return;
		}
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/setConfigsBatch", arr).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var dataObj = r.data,
				str = "";
			var tt = $translate.use() === 'ch' ? 　"返回状态列表" : "Return state List";
			for (var i = 0; i < dataObj.length; i++) {
				str += dataObj[i].message + ';'
			}
			publicService.ngAlert(str + tt, "info");
			localStorage.setItem("valueDoms", JSON.stringify(newData));
		})
	}
}]);
