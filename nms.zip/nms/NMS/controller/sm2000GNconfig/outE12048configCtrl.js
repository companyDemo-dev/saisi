angular.module('sm2000GNoutE12048configModule',[]).controller('outE12048configCtrl', ['$scope', '$stateParams', '$http', '$state', "$translate", 'publicService', function($scope, $stateParams, $http, $state, $translate, publicService) {
	$scope.mauto = $stateParams.mauto;

	if ($stateParams.mauto) {
		$scope.ioSignal = $stateParams.mauto.ioSignal;
		$scope.solt = $stateParams.mauto.ioStatusIndex;
		$scope.ptpDevID = $stateParams.mauto.devID;
	}
	$scope.PTPport = '1';
	$scope.loadPTPconfigContent = function(x) {
		var index = '.1.' + $scope.solt;
		$scope.indexE1 = index;
		var indexs = '.1';
		$scope.indexs = indexs;
		var obj = [{
			"node": "outputE1State",
			"index": index,
			"num": ""
		}, {
			"node": "outputE1FrameType",
			"index": index,
			"num": ""
		}, {
			"node": "outputE1CRCState",
			"index": index,
			"num": ""
		}, {
			"node": "outputE1SSMState",
			"index": index,
			"num": ""
		}, {
			"node": "outputE1SSMBit",
			"index": index,
			"num": ""
		}, {
			"node": "outputE1Warmup",
			"index": indexs,
			"num": ""
		}, {
			"node": "outputE1Freerun",
			"index": indexs,
			"num": ""
		}, {
			"node": "outputE1Holdover",
			"index": indexs,
			"num": ""
		}, {
			"node": "outputE1Fasttrack",
			"index": indexs,
			"num": ""
		}]
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/getDeviceParamColl", obj).success(function(r) {
			if (r.data && r.data.length > 0) {
				$scope.deviceContent = JSON.parse(r.data);
		       _newVals();
			}
		});
	}
	$scope.loadPTPconfigContent();

	function _newVals() {
		var deviceContent = $scope.deviceContent;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		localStorage.setItem('valueDoms', JSON.stringify(obj));
	}

	function _changeVals(x) {
		var deviceContent = x;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		var _vals = JSON.parse(localStorage.getItem('valueDoms')),
			changeObj = {};
		for (var i = 0; i < obj.length; i++) {
			var _id = obj[i].name,
				_val = obj[i].value;
			for (var j = 0; j < _vals.length; j++) {
				var _id2 = _vals[j].name,
					_val2 = _vals[j].value;
				if (_id === _id2) {
					if (_val != _val2) {
						changeObj[_id] = _val;
					}
				}
			}
		}
		return changeObj;
	}

	$scope.configSub = function(x, index, currentUrl, flag) {
		var indexObj = '.1';
		ds = _changeVals(x);
		var configSub_obj = [];
		flag = true;
		ip = true;
		vlanF = true;
		for (var j in ds) {
			obj = {};
			switch (j) {
				case "outputE1Freerun":
					var outputE1Freerun = $scope.deviceContent.outputE1Freerun;
					obj.value = outputE1Freerun;
					obj.node = 'outputE1Freerun';
					obj.index = indexObj;
					configSub_obj.push(obj);
					break;
				case "outputE1Holdover":
					var outputE1Holdover = $scope.deviceContent.outputE1Holdover;
					obj.value = outputE1Holdover;
					obj.node = 'outputE1Holdover';
					obj.index = indexObj;
					configSub_obj.push(obj);
					break;
				case "outputE1Fasttrack":
					var outputE1Fasttrack = $scope.deviceContent.outputE1Fasttrack;
					obj.value = outputE1Fasttrack;
					obj.node = 'outputE1Fasttrack';
					obj.index = indexObj;
					configSub_obj.push(obj);
					break;
				case "outputE1Warmup":
					var outputE1Warmup = $scope.deviceContent.outputE1Warmup;
					obj.value = outputE1Warmup;
					obj.node = 'outputE1Warmup';
					obj.index = indexObj;
					configSub_obj.push(obj);
					break;
				default:
					obj.value = ds[j];
					obj.node = j;
					obj.index = index;
					configSub_obj.push(obj);
			}
		}
		configSubmit(configSub_obj, index, currentUrl);
		_newVals()
	}

	/**
	 * configSubmit
	 *   配置提交
	 */
	function configSubmit(configSub_obj, index, currentUrl) {
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/setConfigsBatch", configSub_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			if (r.data.length == 0) {
				var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
				publicService.ngAlert(tt, "info");
				return;
			} else {
				var dataObj = r.data;
				var div = document.createElement('p');
				for (var i = 0; i < dataObj.length; i++) {
						var node = document.createTextNode(dataObj[i].message+' ');
						div.appendChild(node);
				}
				var element = document.getElementById("ngTip");
				element.appendChild(div);
				var tt = $translate.use() === 'ch' ? 　"返回状态列表" : "Return state List";
				publicService.ngAlert(tt, "info");
				setTimeout(function() {
					element.removeChild(div);
				}, 3000)
			}

		})

	}


	/**
	 * downloadConfig
	 *   导出配置
	 */
	$scope.downloadConfig = function(indexs) {
		var config_obj = [];

		var _vals = JSON.parse(localStorage.getItem('valueDoms'));
		for (var j = 0; j < _vals.length; j++) {
			var obj = {};
			if (_vals[j].name == "outputE1Warmup" || _vals[j].name == "outputE1Freerun" || _vals[j].name == "outputE1Holdover" || _vals[j].name == "outputE1Fasttrack") {
				obj.node = _vals[j].name;
				obj.index = indexs.substring(0, indexs.length - 2);
			} else {
				obj.node = _vals[j].name;
				obj.index = indexs;
			}
			config_obj.push(obj);
		}

		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/downloadConfig/config", config_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}

}]);
