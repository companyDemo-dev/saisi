angular.module('sm2000GNvlangnAddgnModule',[]).controller('vlangnAddgnCtrl', ['$scope', '$rootScope', "$translate", "$state", "$timeout", 'publicService', function($scope, $rootScope, $translate, $state, $timeout, publicService) {
	var mauto = localStorage.getItem("mauto");
	if (mauto) {
		mauto = JSON.parse(localStorage.getItem("mauto"));
		$scope.mauto = mauto;
	}
	$scope.idvisible = false;
	$scope.ipvisible = true;

	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data == null) return
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'SM2000_GN') {
					deviceInfo.push(content[i]);
				}
			}
			$scope.deviceInfo = deviceInfo;
		}
	})
	$scope.backArea = function() {
		window.history.back();
	}
	$scope.vlanIdChange = function(m) {
			if (m == 1) {
				$scope.idvisible = true;
				$scope.ipvisible = false;
			} else if (m == 2) {
				$scope.idvisible = false;
				$scope.ipvisible = true;
			}
		}
		/**
		 * vlanAddSub
		 *   添加VLAN
		 */
	$scope.vlangnAddSub = function(x, vlanFACid) {
		var self = this;
		$scope.mauto = self.devID;
		if (!self.devID || typeof self.devID.id === 'undefined' || $scope.devIP == 'No selection device') {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}

		if (self.devID.deviceStatus == 0) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}

		var devId = self.devID.id;

		var reobj = [],
			obj = {},
			vlanCfg;
		if (vlanFACid == '1') {
			vlanCfg = new Array('index=' + x.vadd_index, 'id=' + x.vadd_id, 'priority=' + x.vadd_priority, 'addr=' + x.vadd_addr, 'netmask=' + x.vadd_netmask, 'gateway=' + x.vadd_gateway);
		} else if (vlanFACid == '2') {
			vlanCfg = new Array('id=' + x.vadd_id, 'priority=' + x.vadd_priority, 'addr=' + x.vadd_addr, 'netmask=' + x.vadd_netmask, 'nextHop=' + x.vadd_gateway, 'destNetwork=' + x.vadd_destNetwork + '/24');
		}
		vlanCfg = vlanCfg.join(',');
		obj.value = vlanCfg;
		obj.node = 'vlanCfg';
		obj.index = x.vadd_index;
		reobj.push(obj);

		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + devId + "/setConfigsBatch", reobj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			if (r.data.length == 0) {
				var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
				publicService.ngAlert(tt, "info");
				return;
			} else {
				var dataObj = r.data;
				if (dataObj[0].code === true) {
					publicService.ngAlert(r.message, "info");
				} else if (dataObj[0].code === false) {
					publicService.ngAlert(r.message, "info");
				}
			}
		})
	}
}]);
