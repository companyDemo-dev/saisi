angular.module('hp55400CModule',[]).controller('hp55400CCtrl', ['$scope','$translate', '$state', '$stateParams', 'publicService', function($scope,$translate,  $state, $stateParams,publicService) {
	var DEVICETYPE = "HP55400", _URL = "";
	$scope.DEVICE_TITLE = $state.params.title;
	if(DEVICETYPE === "HP55400"){
		_URL = 34;
	}

	publicService.doRequest("GET", 30, {
		deviceType: DEVICETYPE
	}).success(function(r) {
		if (r.errCode) {
			publicService.ngAlert(r.message, "danger");
		} else {
			$scope.ssuDeviceList = r.data;
		}
	})
	publicService.doRequest("GET", _URL, {
		deviceType: DEVICETYPE
	}).success(function(r) {
		if (r.errCode) {
			publicService.ngAlert(r.message, "danger");
		} else {
			$scope.command = r.data;
		}
	})

	$scope.seach = function(m) {
		if (!m.ssudevice) {
				var tt = $translate.use() === 'ch' ?　"请选择设备" : "Please select device";
				publicService.ngAlert(tt,"info");
			return;
		}
		if (!m.comm) {
				var tt = $translate.use() === 'ch' ?　"请选择命令" : "Please select command";
				publicService.ngAlert(tt,"info");
			return;
		}

		if (!$scope.shelf || $scope.shelf.length === 0) {
			publicService.doRequest("GET", "/nms/spring/deviceConfig/hp55400/" + m.ssudevice + "/getParamByCommand/" + m.comm, {}).success(function(r) {
				if (r.errCode) {
					publicService.ngAlert(r.message, "danger");
				} else {
					if (r.data.machineFrames.length == 0) {
						executeTL1(m, true);
					} else {
						$scope.shelf = r.data.machineFrames;
					}
					$scope.comFlag = r.data.haveSet;
				}
			})
		} else {
			if (verifyFun.isNull(m.shelfM)) {
				publicService.ngAlert("请选择板卡", "danger");
				return;
			}
			if (m.shelfM.slots != null) {
				if (verifyFun.isNull(m.slotsM)) {
					publicService.ngAlert("请选择槽位", "danger");
					return;
				}
				if (m.slotsM.ports != null) {
					if (verifyFun.isNull(m.portsM)) {
						publicService.ngAlert("请选择端口", "danger");
						return;
					}
				}
			}
			executeTL1(m);
		}
	}

	function executeTL1(m, flag) {
		publicService.doRequest("POST", "/nms/spring/deviceConfig/hp55400/" + m.ssudevice + "/executeTL1", params(m, flag)).success(function(r) {
			if (r.errCode) {
				publicService.ngAlert(r.message, "danger");
			} else {
				$scope.comList = contr(r.data);
				_newVals();
				if (r.data.length == 0) {
					$scope.comINACTIVE = 'none';
				}
				if ($scope.curLoginMsg) {
					var roleName = $scope.curLoginMsg.roleList[0].roleName;
					if (roleName == '维护级' || roleName == '监视级') {
						$scope.comFlag = false;
					}
				}

			}
		})
	}
	$scope.commandD = false;
	$scope.commc = function(s,m) {
		var self = this;
		s && ($scope.shelf = []);
		$scope.comList = [];
		$scope.comINACTIVE = '';
		if (self.ssu.shelfM) self.ssu.shelfM = '';
		if (self.ssu.slotsM) self.ssu.slotsM = '';
		if (self.ssu.portsM) self.ssu.portsM = '';
		$scope.commandD = true;
	}
	$scope.modelExp = function() {
		var self = this;
		if (self.ssu.slotsM) self.ssu.slotsM = '';
		if (self.ssu.portsM) self.ssu.portsM = '';
	}
	$scope.modelSolt = function() {
		var self = this;
		if (self.ssu.portsM) self.ssu.portsM = '';
	}
	$scope.subCom = function(m, index) {
		var oo = {};
		var self = this;
		var data = m[index];
		  var obj ={};
		for(m in data){
			obj[m] = data[m].v1;
		}
		oo.value = JSON.stringify(obj);

		oo.command = self.ssu.comm;
		if (self.ssu.shelfM) {
			if (self.ssu.slotsM) {
				if (self.ssu.portsM) {
					if (self.ssu.portsM.name.length == 1) {
						var portsM = '0' + self.ssu.portsM.name;
					} else {
						var portsM = self.ssu.portsM.name;
					}
					aidS = self.ssu.shelfM.name + self.ssu.slotsM.name + ',' + portsM;
				} else {
					aidS = self.ssu.shelfM.name + self.ssu.slotsM.name;
				}
			} else {
				aidS = self.ssu.shelfM.name;
			}
		} else {
			aidS = '';
		}
		oo.param = aidS;
		publicService.doRequest("POST", "/nms/spring/deviceConfig/hp55400/" + self.ssu.ssudevice + "/executeTL1", oo).success(function(r) {
			if (r.errCode) {
				publicService.ngAlert(r.message, "danger");
			} else {
				publicService.ngAlert("设置成功", "success");
			}
		})
	}

	function params(m, flag) {
		var o = {};
		o.command = m.comm;
		if (!flag) {
			if (m.shelfM.name !== 'ALL') {
				o.param = m.shelfM.name + (verifyFun.isNull(m.slotsM) ? "" : ("," + m.slotsM.name)) + (verifyFun.isNull(m.portsM) ? "" : ("," + m.portsM.name));
			} else {
				o.param = m.shelfM.name;
			}
		}
		return o;
	}

	function contr(jsondata) {
		var obj = [];
		for (i = 0; i < jsondata.length; i++) {
			var mydata = jsondata[i];
			for (var x in mydata) {
				//alert(x+"="+mydata[x]);
				var data = {};
				if (mydata[x] == null) continue;
				if (mydata[x].indexOf('#') > -1) {
					var ss = mydata[x].split('#');
					data.v1 = ss[0];
					data.v2 = ss[1];
					data.v3 = ss[2];
					mydata[x] = data;
				} else {
					data.v1 = mydata[x];
					mydata[x] = data;
				}
			}
			obj.push(mydata);
		}
		return obj
	}


	function _newVals() {
		var comList = $scope.comList;
		var obj = [];
		for (var x in comList) {
			var comObj = comList[x];
			for (m in comObj) {
				var data = {};
				data.name = m;
				data.value = comObj[m].v1;
				obj.push(data);
			}
		}
		localStorage.setItem('ssuvalueDoms', JSON.stringify(obj));
	}

	function _changeVals(x) {
		var comList = x;
		var obj = [];
		for (var x in comList) {
			var comObj = comList[x];
			for (m in comObj) {
				var data = {};
				data.name = m;
				data.value = comObj[m].v1;
				obj.push(data);
			}
		}
		var changeObj = {};
		for (var i = 0; i < obj.length; i++) {
			var _id = obj[i].name,
				_val = obj[i].value;
			changeObj[_id] = _val;
		}
		return changeObj;
	}

}]);


