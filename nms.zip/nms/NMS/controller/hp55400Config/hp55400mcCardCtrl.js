angular.module('hp55400mcCardModule', []).controller('hp55400mcCardCtrl', ['$scope', '$state', '$rootScope', '$stateParams', "$translate", '$state', 'publicService', function($scope, $state, $rootScope, $stateParams, $translate, $state, publicService) {
	$scope.mauto = $stateParams.mauto;
	$scope.ipMode = '1';
	$scope.deviceData = $stateParams.deviceData;
	if ($stateParams.mauto) {
		$scope.ioSignal = $stateParams.mauto.ioSignal;
		$scope.mainframeNum = $stateParams.mauto.ioStatusIndex;
		$scope.solt = $stateParams.mauto.ioStatusSlotID;
		$scope.ptpDevID = $stateParams.mauto.devID;
	}
	$scope.MCvisible = true;
	$scope.ipModeChange = function(m) {
		if (m == 1 || m == 2 || m == 3) {
			$scope.MCvisible = true;
			$scope.CCvisible = false;
		} else if (m == 4) {
			$scope.MCvisible = false;
			$scope.CCvisible = true;
		}
	}

	/**
	 * downloadConfig
	 *   导出配置
	 */
	$scope.downloadConfig = function() {

		var self = this;
		if (!self.devID) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}

		var config_obj = [];
		var _vals = JSON.parse(localStorage.getItem('valueDoms'));
		for (var j = 0; j < _vals.length; j++) {
			var obj = {};
			obj.node = _vals[j].name;
			obj.index = '';
			config_obj.push(obj);
		}
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/downloadConfig/config", config_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}
	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data == null) return
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'TP1000') {
					deviceInfo.push(content[i]);
				}
			}
			$scope.deviceInfo = deviceInfo;
		}
	})



	$scope.seach = function() {
			url = 'imc';

		publicService.doRequest("GET", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/configs/" + url, '').success(function(r) {
			if (r.data) {
				var obj = r.data;
				$scope.deviceContent = obj;
			}
			_newVals();
		});
	}
	function contr(mydata) {
		var obj = [];
			for (var x in mydata) {
				//alert(x+"="+mydata[x]);
				var data = {};
				if (mydata[x] == null) continue;
				if (mydata[x].indexOf('#') > -1) {
					var ss = mydata[x].split('#');
					data.v1 = ss[0];
					data.v2 = ss[1];
					data.v3 = ss[2];
					mydata[x] = data;
				} else {
					data.v1 = mydata[x];
					mydata[x] = data;
				}
			}
			obj.push(mydata);
		return obj
	}

$scope.seach();

	function _newVals() {
		var deviceContent = $scope.deviceContent;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		localStorage.setItem('valueDoms', JSON.stringify(obj));
	}


	function _changeVals(x) {
		var deviceContent = x;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		var _vals = JSON.parse(localStorage.getItem('valueDoms')),
			changeObj = {};
		for (var i = 0; i < obj.length; i++) {
			var _id = obj[i].name,
				_val = obj[i].value;
			for (var j = 0; j < _vals.length; j++) {
				var _id2 = _vals[j].name,
					_val2 = _vals[j].value;
				if (_id === _id2) {
					if (_val != _val2) {
						changeObj[_id] = _val;
					}
				}
			}
		}
		return changeObj;
	}

	$scope.configSub = function(x, index, z) {
		if (!verify.hp55400mcCard(x, publicService, $translate, z)) return;
		ds = _changeVals(x);
		var configSub_obj = [];
		flag = true;
		for (var j in ds) {
			obj = {};
			obj.value = ds[j];
			obj.node = j;
			obj.index = $state.params.mauto.ioType;
			configSub_obj.push(obj);
		}
		configSubmit(configSub_obj, index);
		_newVals()
	}

	/**
	 * configSubmit
	 *   配置提交
	 */
	function configSubmit(configSub_obj, index) {
		if (!$scope.mauto) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return
		}
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/setConfigsBatch", configSub_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var doc;
			if (r.data.length == 0) {
				var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
				publicService.ngAlert(tt, "info");
				return;
			} else {
				var dataObj = r.data;
				var tt = $translate.use() === 'ch' ? 　"设置成功" : "set success！";
				publicService.ngAlert(tt, "info");
				return;
			}

		})

	}
}]);