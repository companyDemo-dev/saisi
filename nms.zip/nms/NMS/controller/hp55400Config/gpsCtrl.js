angular.module('gpsModule', []).controller('gpsCtrl', ['$scope', '$state', '$stateParams', '$rootScope', "$translate", '$state', 'publicService', function($scope, $state,  $stateParams,$rootScope,  $translate, $state, publicService) {
	    $scope.mauto = $stateParams.mauto;
    $scope.deviceData = $stateParams.deviceData;
    if ($stateParams.mauto) {
        $scope.ioSignal = $stateParams.mauto.ioSignal;
        $scope.mainframeNum = $stateParams.mauto.ioStatusIndex;
        $scope.solt = $stateParams.mauto.ioStatusSlotID;
        $scope.ptpDevID = $stateParams.mauto.devID;
    }
	/**
	 * downloadConfig
	 *   导出配置
	 */
	$scope.downloadConfig = function() {

		var self = this;
		if (!self.devID) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}

		var config_obj = [];
		var _vals = JSON.parse(localStorage.getItem('valueDoms'));
		for (var j = 0; j < _vals.length; j++) {
			var obj = {};
			obj.node = _vals[j].name;
			obj.index = '';
			config_obj.push(obj);
		}
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/downloadConfig/config", config_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}
	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data == null) return
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'TP1000') {
					deviceInfo.push(content[i]);
				}
			}
			$scope.deviceInfo = deviceInfo;
		}
	})



	$scope.seach = function() {
			url = 'input';

		publicService.doRequest("GET", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/configs/" + url, '').success(function(r) {
			if (r.data) {
				if ($state.params.mauto.ioType == 'GPS') {
					var obj = r.data.gps;
				} else if ($state.params.mauto.ioType == 'INP') {
					var obj = r.data.inp;
				}else if ($state.params.mauto.ioType == 'PRS') {
					var obj = r.data.prs;
				}
				$scope.deviceContent = obj;
			}
			_newVals();
		});
	}

$scope.seach();

	function _newVals() {
		var deviceContent = $scope.deviceContent;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		localStorage.setItem('valueDoms', JSON.stringify(obj));
	}


	function _changeVals(x) {
		var deviceContent = x;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		var _vals = JSON.parse(localStorage.getItem('valueDoms')),
			changeObj = {};
		for (var i = 0; i < obj.length; i++) {
			var _id = obj[i].name,
				_val = obj[i].value;
			for (var j = 0; j < _vals.length; j++) {
				var _id2 = _vals[j].name,
					_val2 = _vals[j].value;
				if (_id === _id2) {
					if (_val != _val2) {
						changeObj[_id] = _val;
					}
				}
			}
		}
		return changeObj;
	}

	$scope.configSub = function(x, index) {
		if (!verify.tp1000gps(x, publicService, $translate, "1")) return;
		ds = _changeVals(x);
		var configSub_obj = [];
		flag = true;
		for (var j in ds) {
			obj = {};
			obj.value = ds[j];
			obj.node = j;
			obj.index = $state.params.mauto.ioType;
			configSub_obj.push(obj);
		}
		configSubmit(configSub_obj, index);
		_newVals()
	}

	/**
	 * configSubmit
	 *   配置提交
	 */
	function configSubmit(configSub_obj, index) {
		if (!$scope.mauto) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return
		}
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/setConfigsBatch", configSub_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var doc;
			if (r.data.length == 0) {
				var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
				publicService.ngAlert(tt, "info");
				return;
			} else {
				var dataObj = r.data;
				var div = document.createElement('p');
				for (var i = 0; i < dataObj.length; i++) {
					if (dataObj[i].code === false) {
						var node = document.createTextNode(dataObj[i].message + ' ');
						div.appendChild(node);

					} else if (dataObj[i].code === true) {
						var node = document.createTextNode(dataObj[i].message + ' ');
						div.appendChild(node);
					}
				}
				var element = document.getElementById("ngTip");
				element.appendChild(div);
				var tt = $translate.use() === 'ch' ? 　"返回状态列表" : "Return state List";
				publicService.ngAlert(tt, "info");
				setTimeout(function() {
					element.removeChild(div);
				}, 3000)
			}

		})

	}
}]);