angular.module('newDeviceTopuModule',[]).controller('newDeviceTopuCtrl', ['$scope',  '$http', '$rootScope', '$stateParams', "$translate", '$state', 'publicService','ngDialog', function($scope,$http, $rootScope, $stateParams, $translate, $state, publicService,ngDialog) {
	var _JTopo = {
		deviceModels : [],
		linksModel:[],
		beginNode : null,
		endNode : null,
		currentLine : null,
		currentNode : null,
		stage : null,
		scene : null,
		flagLineDrag: true,
		right_Menu : $("#right_Menu"),
		currentImg : function(){
			return $("#topo_img_z").find('.totp-active').attr("imgvalue");
		},
		newNode : function(x, y, w, h, obj){
			var node = new JTopo.Node(obj.name),
				_self = this,
				ref = $("#topo_ref"),
				alarmNum = $("#alarmNum"),
				topo_tip = $("#topo_tip"),
				topo_ref = $(".topo_ref");
				br = $("#_br");
			node.setLocation(x, y);
			node.setSize(0, 0);
			node.deviceModel = obj;
			node.setImage(_self.select_Picture(obj.img), true);
			node.fontColor = '0,0,0';
			
			if(obj.type){
				node.alarm = "";
				if(obj.type === "red"){
					node.alarmColor = "214,15,15"
				}else if(obj.type === "pink"){
					node.alarmColor = '241, 147, 30'
				}else if(obj.type === "yellow"){
					node.alarmColor ='204,218,15'
				}else if(obj.type === "gery"){
					// node.alarmColor = '25, 25, 25'
					delete node.alarm;
					node.setImage(_self.offLineImg(obj.img), true);
				}else if(obj.type === "greent"){
					node.alarmColor = '0, 0, 0'
				}
				node.("mouseover", function(e){
					var obj = e.target.deviceModel;
					if(obj.deviceStatus != 0 && obj.refInput){
						ref.text(obj.refInput);
						ref.show();
						topo_ref.show();
						br.show();
					}else{
						ref.hide();
						topo_ref.hide();
						br.hide();
					}
					alarmNum.text(obj.alarmsCount);
					topo_tip.css({
						top: event.pageY,
						left: event.pageX + 15
					}).show();
				});
				node.addEventListener("mouseout", function(e){
					topo_tip.hide()
				});
				node.addEventListener("mousedrag", function(e){
					topo_tip.hide()
				});
			}
			_self.scene.add(node);
			return node;
		},
		offLineImg : function(t){
			var str = "";
			if(t == 1){
				str = "images/tep11off.png"
			}else if(t == 2){
				str = "images/tep22off.png"
			}else if(t == 3){
				str = "images/tep33off.png"
			}else if(t == 4){
				str = "images/tep4.png"
			}
			return str
		},
		select_Picture : function(t){
			var str = "";
			if(t == 1){
				str = "images/tep11.png"
			}else if(t == 2){
				str = "images/tep22.png"
			}else if(t == 3){
				str = "images/tep33.png"
			}else if(t == 4){
				str = "images/tep4.png"
			}
			return str
		},
		topoM : function(arr,id){
        	for (var i = 0; i < arr.length; i++) {
        		if(id === arr[i].deviceModel.id){
        			return arr[i];
        		}
        	}
        },
        saveDate :function(){
			var _self = this,
				allElements = _self.scene.getDisplayedElements(),
				dataObj = {},
				linkArr = [],
				nodeObj = {};
			for (var i = 0; i < allElements.length; i++) {
				if(allElements[i].elementType === "node"){
					nodeObj[allElements[i].deviceModel.id] = {x:allElements[i].x , y:allElements[i].y,name:allElements[i].deviceModel.name,img : allElements[i].deviceModel.img}
					_self.de
				}else if(allElements[i].elementType === "link"){
					var o = {};
					o.sourceid = allElements[i].nodeA.deviceModel.id;
					o.targetid = allElements[i].nodeZ.deviceModel.id;
					o.arrowsRadius = 8;
					o.lineWidth = 1;
					o.bundleGap = allElements[i].bundleGap || 0;
					o.strokeColor = allElements[i].strokeColor || '8, 7, 7';
					if(undefined !== allElements[i].dashedPattern){
						o.dashedPattern = allElements[i].dashedPattern || 0;
					}
					o.port = allElements[i].port;
					o.slot = allElements[i].slot;
					linkArr.push(o);
				}
			}
			dataObj.linkArr = linkArr;
			dataObj.nodeObj = nodeObj;

	        $http(_self.dataParams("GET")).success(function(e){
	        	var o = _self.dataParams("POST");
	        	if(e.data.length > 0 && e.data[0].bigData !== ""){
	        		var d = e.data[0].bigData;
	        		var data = JSON.parse(d);
	        		o.data.id = e.data[0].id;
	        	}
	        	o.data.bigData = JSON.stringify(dataObj);
	        	$http(o);
	        })
        },
		dataParams :function(method){
			var obj = {
   				areaId : "china",
   				userId:"",
   				viewDataType:""
   			};
   			var o ={};
   			if(method === "GET"){
   				o["params"] = obj;
   				o.method  = "GET";
   			}else if(method === "POST"){
   				o["data"] = obj;
   				o.method  = "POST";
   			}
   			o.url = "/nms/spring/viewData?token=" + $rootScope.curLoginMsg.sessionID;
   			o.headers = {
	            'Content-Type': 'application/json;charset=UTF-8'
	        };
   			return o;
		},
		topo_id : function (){
			return String(this.scene.getDisplayedElements().length + 1);　
		},
		nameQc : function (n){
			var all = this.scene.getDisplayedElements(),
				flag = false;
        	for (var i = 0; i < all.length; i++) {
        		if(all[i].elementType === "node" && all[i].deviceModel.name === n){
        			flag = true;
        		}
        	}
        	return flag;
		},
		events :function(){
			var _self = this,
				topo_save = $("#topo_save"),	
				topo_add = $("#topo_add"),
				topo_toolbars = $("#topo_toolbars a"),
				topo_img = $("#topo_img_z").children("img"),
				topo_spa = $("#topo_img_z").children("span"),
				jpoto_fis = $("#jpoto_fis"),
		    	_deleteLine = $("#_deleteLine"),
		    	_zhuLine = $("#_zhuLine"),
		    	_beiLine = $("#_beiLine"),
		    	_setPortSlot = $("#_setPortSlot"),
		    	topo_delete = $("#topo_delete");
		    topo_delete.unbind('click').click(function(){
		    	if(_self.currentNode && _self.currentNode.deviceModel.deviceType === "new_device"){
		    		_self.scene.remove(_self.currentNode);
		    	}
		    })
		    _deleteLine.unbind('click').click(function(){
		    	_self.scene.remove(_self.currentLine);
        		var index = _self.linksModel.indexOf(_self.currentLine);
        		_self.linksModel.splice(index, 1);
        		_self.right_Menu.hide();
		    })
		    _zhuLine.unbind('click').click(function(){
		    	_self.currentLine.strokeColor = '8, 7, 7';
        		_self.currentLine.bundleGap  = -15;
        		delete _self.currentLine.dashedPattern;
        		_self.right_Menu.hide();
		    })
		    _beiLine.unbind('click').click(function(){
		    	_self.currentLine.strokeColor = '255, 0, 0';
        		_self.currentLine.dashedPattern = 5;
        		_self.currentLine.bundleGap  = 15;
        		_self.right_Menu.hide();
		    })
		    _setPortSlot.unbind('click').click(function(){
		    	ngDialog.open({
	                template: "template/dialog/tuopuDialog.html",
	                className: 'ngdialog-theme-default ngdialog-theme-custom',
	                controller: function($scope, publicService) {
	                	$scope.subPs = function(oos) {
	                		if(oos && oos.slot){
	                			_self.currentLine.slot = oos.slot
	                		}
	                		if(oos && oos.port){
	                			_self.currentLine.port = oos.port
	                		}
	                		$scope.dialogClose = true;
	                		ngDialog.close('ngdialog1');

	                	}
	                },
	                preCloseCallback: function() {
	                    if (!$scope.dialogClose) {
	                        $scope.dialogClose = false;
	                    }
	                }
	            });
	            _self.right_Menu.hide();
		    })

			topo_toolbars.unbind('click').click(function(){
     			var _this = $(this);
     			var i = _this.find("i");
     			if(i.hasClass("toolbar-drag")){
     				_self.flagLineDrag = true;
     				_this.addClass('totp-active').parent().siblings().find("a").removeClass('totp-active')
     			}else if(i.hasClass("toolbar-line")){
     				_self.flagLineDrag = false;
     				_this.addClass('totp-active').parent().siblings().find("a").removeClass('totp-active')
     			}else if(i.hasClass("toolbar-zoom")){
     				_self.stage.zoomOut();
     			}else if(i.hasClass("toolbar-narrow")){
     				_self.stage.zoomIn();
     			}
			})
			jpoto_fis.change(function(){
				_self.stage.wheelZoom = $(this)[0].checked ? 1.2 : null;
			})
			topo_save.unbind('click').click(function(){
		  		_self.saveDate();
			})
			topo_add.unbind('click').click(function(){
				var name = prompt("请输入设备名称", "");
		        if(name =="")
		        {  
		            alert("设备名称不能为空");
		            return;
		        }else if(_self.nameQc(name))
		        {  
		            alert("设备名称重复，请重新输入");
		            return;
		        }else if(name === null){
		        	return
		        }
		        _self.newNode(0, 0, 0, 0, {id : _self.topo_id(),name:name,deviceType:"new_device",img : _self.currentImg()})
			})
            topo_img.unbind('click').click(function(){
            	$(this).addClass('totp-active').siblings().removeClass("totp-active");
            })
            topo_spa.unbind('click').click(function(){
            	$(this).addClass('totp-active').siblings().removeClass("totp-active");
            })
		},
		init :function(){ 
			var _self = this,
				canvas = document.getElementById('canvas');
				textfield = $("#jtopo_textfield");
			_self.stage = new JTopo.Stage(canvas);
			_self.scene = new JTopo.Scene(_self.stage);
			_self.stage.wheelZoom = 1.2;
			canvas.height = $("#canvas_content").height()
			canvas.width = $("#canvas_content").width()

			window.onresize = function(){
				canvas.height = $("#canvas_content").height()
				canvas.width = $("#canvas_content").width()
			}
			publicService.doRequest("GET", 4, {
	            type: "all"
	        }).success(function(rr) {
				if (rr.data == null) return
            	if (rr.data && rr.data.length > 0) {
            		var devices = [],
            			rrs = rr.data;
            		for (var i = 0; i < rrs.length; i++) {
            			if(rrs[i].children && rrs[i].children.length > 0){
            				Array.prototype.push.apply(devices,rrs[i].children)
            			}
            		}
					$http(_self.dataParams("GET")).success(function(e){
			        	if(e.data.length > 0 && e.data[0].bigData !== ""){
			        		var data = JSON.parse(e.data[0].bigData),
			        			nodeObj = data.nodeObj,
			        			links = data.linkArr,
			        			nodeidkeys = Object.keys(nodeObj),
			        			deviceidkeys = devices.map(function(a){return a.id});
			        		for (var i = 0; i < nodeidkeys.length; i++) {
			        			if(deviceidkeys.indexOf(nodeidkeys[i]) === -1){
			        				_self.deviceModels.push(_self.newNode(nodeObj[nodeidkeys[i]].x, nodeObj[nodeidkeys[i]].y, 30, 30,{id : nodeidkeys[i],img:nodeObj[nodeidkeys[i]].img,name:nodeObj[nodeidkeys[i]].name,deviceType:"new_device"}));
			        			}
			        		} 
		        			for (var i = 0; i < devices.length; i++) {
		        				if(nodeObj[devices[i].id]){
		        					_self.deviceModels.push(_self.newNode(nodeObj[devices[i].id].x, nodeObj[devices[i].id].y, 30, 30, devices[i]));
		        				}else{
		        					_self.deviceModels.push(_self.newNode(0, 0, 30, 30, devices[i]));
		        				}
				            }
			        		if(links.length > 0){
			        			for (var i = 0; i < links.length; i++) {
			        				var l = new JTopo.Link(_self.topoM(_self.deviceModels,links[i].sourceid), _self.topoM(_self.deviceModels,links[i].targetid));
			                        l.arrowsRadius = links[i].arrowsRadius; 
			                        l.bundleGap = links[i].bundleGap; 
			                        l.lineWidth = links[i].lineWidth;
			                        l.sourceid = links[i].sourceid; 
			                        l.targetid = links[i].targetid;
			                        l.port = links[i].port;
			                        l.slot = links[i].slot;
			                        // l.strokeColor = '8, 7, 7';
			                        l.strokeColor = links[i].strokeColor || '8, 7, 7';
			                        if(links[i].dashedPattern){
			                        	l.dashedPattern = links[i].dashedPattern
			                        }
			                        _self.scene.add(l);
			                        _self.linksModel.push(l);
			                        l.addEventListener('mouseup', function(event){
						                _self.currentLine = this;
						                if(event.button == 2){// 右键
						                    _self.right_Menu.css({
						                        top: event.pageY,
						                        left: event.pageX
						                    }).show();    
						                }
						            });
			        			}
			        		}
			        	}else{
			        		for (var i = 0; i < devices.length; i++) {
		        				_self.newNode(0,0, 30, 30, devices[i])
				            }
			        	}
			        })
				}
			})
			var falg = true
	        _self.scene.click(function(e){
	        	if(e.target !== null && e.target.elementType === "node"){
	        		_self.currentNode = e.target;
	        	}
	        	if(e.target === null || _self.flagLineDrag){
            		_self.beginNode = null;
            		return;
            	}
	        	if(_self.beginNode !== null){
            		falg = false;
            	}
            	var ee = e.target;
            	if(e.target !== null && e.target.elementType === "node" && _self.beginNode === null ){
            		_self.beginNode = e.target;
            	}


            	if(e.target !== null && e.target.elementType === "node" && _self.beginNode !== null && !falg){
    		    	if(_self.scene){
		            	var all = _self.scene.getDisplayedElements();
		            	for (var i = 0; i < all.length; i++) {
		            		if(all[i].elementType === "link" && all[i].nodeA.deviceModel.id === _self.beginNode.deviceModel.id && all[i].nodeZ.deviceModel.id === e.target.deviceModel.id){
								return;
		            		}
		            	}
	            	}
            		_self.endNode = e.target;
            		
            		var l = new JTopo.Link(_self.beginNode, _self.endNode);
                    l.arrowsRadius = 8; 
                    l.lineWidth = 1
                    l.bundleGap = 0;
                    l.strokeColor = '8, 7, 7';
                    _self.scene.add(l);
                    _self.beginNode = null;
                    _self.endNode = null;
                    falg = true;
                	l.addEventListener('mouseup', function(event){
		                _self.currentLine = this;
		                if(event.button == 2){// 右键
		                    _self.right_Menu.css({
		                        top: event.pageY,
		                        left: event.pageX
		                    }).show();    
		                }
		            });
            	}
            });

            _self.scene.mouseup(function(e){
                if(e.button == 2){
                	_self.beginNode = null;
                    return;
                }
            });

            _self.stage.click(function(event){
                if(event.button == 0){
                    _self.right_Menu.hide();
                }
            });

			_self.scene.dbclick(function(event){
                if(event.target == null || event.target.deviceModel.deviceType !== "new_device") return;
                var e = event.target;
                textfield.css({
                    top: event.pageY,
                    left: event.pageX - e.width / 2
                }).show().attr('value', e.text).focus().select();
                e.text = "";
                textfield[0].JTopoNode = e;
            });
            textfield.blur(function(){
                textfield[0].JTopoNode.text = textfield.hide().val();
            });
             _self.events();
    	    setInterval(function(){
            	if(_self.scene){
	            	var all = _self.scene.getDisplayedElements();
	            	for (var i = 0; i < all.length; i++) {
	            		if(all[i].elementType === "node" && all[i].deviceModel.deviceType !== "new_device" && all[i].deviceModel.type !== "gery"){
							if(all[i].alarm == ''){
			                    all[i].alarm = null;
			                }else{
			                    all[i].alarm = '';
			                }
	            		}
	            	}
            	}
            }, 600);
		}
	}
	_JTopo.init();
	publicService._JTopo = _JTopo;
}]);
