angular.module('alarmTipFilterModule', []).controller('alarmTipFilterCtrl', ['$scope', '$translate', '$rootScope', '$http', '$state', 'publicService',  function($scope, $translate, $rootScope, $http, $state, publicService) {
    publicService.doRequest("GET", "/nms/spring/systemManage/getParamConfig", {
        type: 'deviceType'
    }).success(function(r) {
        if (r.data !== null && r.data && r.data.length > 0) {
            $scope.deviceType = r.data;
        }
    })

    $scope.alarmFilterEditAdd = function(m) {
        $scope.did = "";
        $state.go('index.alarm.alarmTipFilterEditAdd', {
            mauto: m
        });
    }

    $scope.seach = function(m) {
      $scope.devidFun(m);
    }

    $scope.devidFun = function(m) {
        var obj = m  || '';
            publicService.doRequest("GET", "/nms/spring/alarm/promptConfig/get", { deviceType:obj}).success(function(r) {
                if (r.data) {
                    $scope.alarmFilterList= r.data;
                }
            })
    }
    $scope.seach();
    $scope.alarmFilterDel = function(m) {
        var self = this;
        t = $translate.use() === "ch" ? "确认删除?" : "confirm delete？";
        if (confirm(t)) {
            self.alarmFilterList.splice(self.alarmFilterList.indexOf(m), 1)
            publicService.loading('start');
            publicService.doRequest("DELETE", "/nms/spring/alarm/promptConfig/"+m.id+"/delete", {}).success(function(data) {
                publicService.ngAlert('删除成功', "success");
            
            })
        }
    }
      
}]);