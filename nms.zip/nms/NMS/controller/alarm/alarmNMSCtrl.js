angular.module('alarmNMSModule', []).controller('alarmNMSCtrl', ['$scope', '$translate', 'publicService', function($scope, $translate, publicService) {

    $scope.seach = function() {

        var self = this;
        self.paginationConf.onChange()
    }
    $scope.paginationConf = {
        currentPage: 1,
        totalItems: 0,
        itemsPerPage: 10,
        pagesLength: 15,
        perPageOptions: [10, 20, 30, 40, 50],
        rememberPerPage: 'perPageItems',
        onChange: function() {
            var _self = this,
                obj = {
                    page : 1,
                    pageSize : 1000,
                    deviceId : 'NMS',
                    state : '1,2',
                    activeAlarmSource : "",
                    activeAlarmLevel :  "",
                    activeAlarmReason :"",
                    activeAlarmId :  "",
                    activeAlarmtimeBgn :  "",
                    activeAlarmtimeEnd :  "",
                    clearTimeBgn :  "",
                    clearTimeEnd :  "",
                    confirmTimeBgn :  "",
                    confirmTimeEnd :  "",
                    confirmOperator :  ""
                };
            publicService.loading('start');
            publicService.doRequest("GET", 6, obj).success(function(r) {
                $scope.alarmlogList = r.data.content;
                _self.currentPage = parseInt(r.data.number + 1);
                _self.totalItems = r.data.totalElements;
                _self.itemsPerPage = r.data.size;
            })
        }
    };
     $scope.seach()
  

    /**
     * downloadlog
     *   导出日志
     */
    $scope.downloadlog = function(m) {
        if (!$scope.did) {
            var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
            publicService.ngAlert(tt, "info");
            return;
        }
        var s = $scope;
        var obj = {
                    page : 1,
                    pageSize : 1000,
                    deviceId : 'NMS',
                    state : '1,2',
                    activeAlarmSource : "",
                    activeAlarmLevel :  "",
                    activeAlarmReason :"",
                    activeAlarmId :  "",
                    activeAlarmtimeBgn :  "",
                    activeAlarmtimeEnd :  "",
                    clearTimeBgn :  "",
                    clearTimeEnd :  "",
                    confirmTimeBgn :  "",
                    confirmTimeEnd :  "",
                    confirmOperator :  ""
        };
        publicService.doRequest("GET", "/nms/spring/alarm/activeAlarm/download", obj).success(function(r) {
            if (!r || !r.data || r.data.length < 0) return;
            window.location.href = 'http://' + location.hostname + r.data + '';
        })
    }

}]);