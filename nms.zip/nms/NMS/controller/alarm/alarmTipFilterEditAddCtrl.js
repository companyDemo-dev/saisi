angular.module('alarmTipFilterEditAddModule', []).controller('alarmTipFilterEditAddCtrl', ['$scope', '$stateParams', "$translate", '$state', 'publicService',function($scope, $stateParams, $translate, $state, publicService) {
    publicService.doRequest("GET", 112, {
        page: "",
        pageSize: 200,
        name: "",
        ip: "",
        deviceStatus: "",
        areaId: "",
        deviceType: ""
    }).success(function(r) {
        if (r.data !== null && r.data.content && r.data.content.length > 0) {
            var content = r.data.content;
            var deviceInfo = [];
            for (i = 0; i < content.length; i++) {
                if (content[i].deviceStatus == 1) {
                    deviceInfo.push(content[i]);
                }
            }
            $scope.deviceInfo = deviceInfo;
        }
    })
    if ($stateParams.mauto) {
        $scope.mauto = $stateParams.mauto;
        $scope.mauto.enable += "";
        $scope.alarmFilterTitle = "修改";
        $scope.devID = $scope.mauto.device.id;
        loadSouse($scope.devID)
            //$scope.activeAlarmModule = $scope.mauto.activeAlarmModule;
    } else {
        $scope.alarmFilterTitle = "添加";
    }


    publicService.doRequest("GET", "/nms/spring/systemManage/getParamConfig", {
        type: 'deviceType'
    }).success(function(r) {
        if (r.data !== null && r.data && r.data.length > 0) {
            $scope.deviceType = r.data;
        }
    })

    $scope.alarmFilterEditAddsub = function(m) {
        publicService.doRequest("POST",'/nms/spring/alarm/promptConfig/save', m).success(function(data) {
            publicService.loading('end');
             publicService.ngAlert('添加成功', "success");
        })
    }
    $scope.backFilter = function() {
        window.history.back();
    }



}]);