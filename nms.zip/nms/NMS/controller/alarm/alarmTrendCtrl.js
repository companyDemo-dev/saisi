angular.module('alarmTrendCtrlModule',[]).controller('alarmTrendCtrl', ['$scope','$rootScope','$translate',"$timeout",'publicService',  function($scope, $rootScope,$translate,$timeout, publicService){
	publicService.doRequest("GET", 112, {
        page: "",
        pageSize: 200,
        name: "",
        ip: "",
        deviceStatus: "",
        areaId: "",
        deviceType: ""
    }).success(function(r) {
        if (r.data !== null && r.data.content && r.data.content.length > 0) {
            var content = r.data.content;
            $scope.deviceInfo = content;
        }
    })
    $scope.seachMod = {}
    $scope.seachMod.devId = null;
    $scope.seachMod.startDate = "";
    $scope.seachMod.endDate = "";
    $scope.seachMod.type = "1";
    $scope.seach = function(mod){
    	if(mod.devId === null){
    		 publicService.ngAlert("请选择设备", "danger");
    		 return;
    	}
    	if(mod.startDate === null){
    		 publicService.ngAlert("请选择起始时间", "danger");
    		 return;
    	}
    	if(mod.endDate === null){
    		 publicService.ngAlert("请选择结束时间", "danger");
    		 return;
    	}
    	publicService.doRequest("GET", "/nms/spring/report/alarm/" + mod.devId.id, {
	        type: mod.type,
	        startDate: mod.startDate,
	        endDate: mod.endDate,
	    }).success(function(r) {
	    	if(r.data && r.data.labele.length > 0){
	    		mapDate(r.data.labele,r.data.value)
	    	}
	    })
    }
    function mapDate(a, b){
		var myChart = echarts.init(document.getElementById('alarmTrend_'));
		myChart.setOption(option = {
	        title: {
	            text: ''
	        },
	        tooltip: {
	            trigger: 'axis'
	        },
	        xAxis: {
	            data: a
	        },
	        yAxis: {
	            splitLine: {
	                show: false
	            }
	        },
	        toolbox: {
	            left: 'center',
	            feature: {
	                dataZoom: {
	                    yAxisIndex: 'none'
	                },
	                restore: {},
	                saveAsImage: {}
	            }
	        },
	        dataZoom: [{
	            startValue: '2014-06-01'
	        }, {
	            type: 'inside'
	        }],
	        series: {
	            type: 'line',
	            data: b
	        }
	    });
    }
}]);
