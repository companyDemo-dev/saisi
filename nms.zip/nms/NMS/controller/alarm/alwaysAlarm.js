angular.module('alwaysAlarmModule', []).controller('alwaysAlarm', ['$scope', '$rootScope', '$translate', '$timeout', '$stateParams', "$window", 'publicService', function($scope, $rootScope, $translate, $timeout, $stateParams, $window, publicService) {
	publicService.alwaysAlarmLoad = function(id) {
		if (id) {
			$timeout(function() {
				publicService.loading('start');
				var obj = {
					page: 1,
					pageSize: 1000,
					deviceId: id,
					state: '1,2',
					activeAlarmSource: "",
					activeAlarmLevel: "",
					activeAlarmReason: "",
					activeAlarmId: "",
					activeAlarmtimeBgn: "",
					activeAlarmtimeEnd: "",
					clearTimeBgn: "",
					clearTimeEnd: "",
					confirmTimeBgn: "",
					confirmTimeEnd: "",
					confirmOperator: ""
				}
				publicService.doRequest("GET", 6, obj).success(function(data) {
					publicService.loading('end');
					if (data.errCode) {
						publicService.ngAlert(data.message, "danger");
					} else {
						$scope.alwaysAlarmList = data.data.content;
					}
				})

			})
		}
	}
	$scope.deviceType = $stateParams.deviceType || '';
	publicService.alwaysAlarmLoad($stateParams.id)
	$scope.alwaysAlarmSub = function(m) {
		t = $translate.use() === "ch" ? "确认查看?" : "confirm check";
		if (confirm(t)) {
			if (m.state === 2) return;
			publicService.loading('start');
			m.confirmOperator = $rootScope.curLoginMsg.userName;
			m.state = 2;
			publicService.doRequest("PUT", "spring/alarm/updateActiveAlarmState", m).success(function(data) {
				publicService.alwaysAlarmLoad($stateParams.id)
			});
		}
	}
	$scope.alwaysAlarmClear = function(m) {
		t = $translate.use() === "ch" ? "确认清除?" : "confirm clear";
		if (confirm(t)) {
			m.state = 3;
			var self = this;
			self.alwaysAlarmList.splice(self.alwaysAlarmList.indexOf(m), 1);
			m.confirmOperator = ""
			publicService.doRequest("PUT", "spring/alarm/updateActiveAlarmState", m).success(function(data) {
				publicService.alwaysAlarmLoad($stateParams.id)
			});
		}

	}
	$scope.alwaysAlarmBack = function() {
		window.history.back();
	}
}]);