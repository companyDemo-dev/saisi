angular.module('alarmRuleEditAddModule', []).controller('alarmRuleEditAddCtrl', ['$scope', '$stateParams', "$translate", '$state', 'publicService', "deviceInfoData", function($scope, $stateParams, $translate, $state, publicService, deviceInfoData) {
	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1) {
					deviceInfo.push(content[i]);
				}
			}
			$scope.deviceInfo = deviceInfo;
		}
	})
	if ($stateParams.mauto) {
		$scope.mauto = $stateParams.mauto;
		$scope.mauto.sendFlag += "";
		$scope.alarmRuleTitle = "修改";
		$scope.devID = $scope.mauto.device.id;
		loadSouse($scope.devID)
			//$scope.activeAlarmModule = $scope.mauto.activeAlarmModule;
	} else {
		$scope.alarmRuleTitle = "添加";

	}
	$scope.devidFun = function(m) {
		if (m) {
			loadSouse(m);
		} else {
			$scope.activeAlarmModuleList = [];
			/*if(!$scope.seachMod) $scope.seachMod = {};
			$scope.seachMod.activeAlarmModule = "";*/
		}
	}
	$scope.alarmRuleEditAddsub = function(m) {
		if (!m) m = {};
		m.activeAlarmModule = $scope.activeAlarmModule;
		if (!$scope.devID) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return
		}
		m.device = {
			'id': $scope.devID.id || ""
		}
		m.activeAlarmSubId = '0';
		if (!verify.alarmRuleEditAdd(m, publicService, $translate)) return;
		publicService.doRequest("POST", 25, m).success(function(data) {
			publicService.loading('end');
			if (data.errCode) {
				publicService.ngAlert(data.message, "danger");
			} else {
				publicService.ngAlert(data.message, "success");
				if ($scope.alarmRuleTitle === "添加") {
					delete $scope.mauto;
				}
			}
		})
	}
	$scope.backRule = function() {
		window.history.back();
	}

	function loadSouse(m) {
		$scope.did = m.id;
		publicService.doRequest("GET", "/nms/spring/deviceConfig/" + m.id + "/configs/ioStatusTable", {}).success(function(r) {
			  $scope.activeAlarmModule(m);
			if (r.data && r.data.length > 0) {

                if (r.data && r.data.length > 0 && m.deviceType == "SM2000") {
                for (var i = 0; i < r.data.length; i++) {
                    var obj = {},
                        str = "";
                    if (r.data[i].ioStatusIndex > 0) {
                        if (r.data[i].ioStatusSlotID >= 3) {
                            str = "S";
                        } else {
                            str = "B";
                        }
                    } else {
                        str = "S";
                    }
                    obj = {
                        'name': 'E' + r.data[i].ioStatusIndex + str + r.data[i].ioStatusSlotID,
                        'index': 'E' + r.data[i].ioStatusIndex + str + r.data[i].ioStatusSlotID
                    }
                    $scope.activeAlarmModuleList.push(obj);
                }
                }
				if ($scope.mauto) {
					$scope.activeAlarmModule = $scope.mauto.activeAlarmModule;
				}
			}
		})
	}
	    $scope.activeAlarmModule = function(m) {
        if (m.deviceType == "NS7200") {
            $scope.activeAlarmModuleList = [{
                'name': 'NS7200',
                'index': 'NS7200'
            }];
            return
        }
        if (m.deviceType == "SSU2000") {
            $scope.activeAlarmModuleList = [{
                'name': 'SSU2000',
                'index': 'SSU2000'
            }];
            return
        }
        if (m.deviceType == "TS3100") {
            $scope.activeAlarmModuleList = [{
                'name': 'PWR-A',
                'index': 'PWR-A'
            }, {
                'name': 'PWR-B',
                'index': 'PWR-B'
            }, {
                'name': 'SPAN-A',
                'index': 'SPAN-A'
            }, {
                'name': 'SPAN-B',
                'index': 'SPAN-B'
            }, {
                'name': 'GPS',
                'index': 'GPS'
            }];
            return
        }

        if (m.deviceType == "HP55400") {
            $scope.activeAlarmModuleList = [{
                'name': 'IMC',
                'index': 'IMC'
            }, {
                'name': 'ITH1',
                'index': 'ITH1'
            }, {
                'name': 'ITH2',
                'index': 'ITH2'
            }, {
                'name': 'ITH1-0',
                'index': 'ITH1-0'
            }, {
                'name': 'ITH1-1',
                'index': 'ITH1-1'
            }, {
                'name': 'ITH1-2',
                'index': 'ITH1-2'
            }, {
                'name': 'ITH1-3',
                'index': 'ITH1-3'
            }, {
                'name': 'ITH1-4',
                'index': 'ITH1-4'
            }, {
                'name': 'ITH2-0',
                'index': 'ITH2-0'
            }, {
                'name': 'ITH2-1',
                'index': 'ITH2-1'
            }, {
                'name': 'ITH2-2',
                'index': 'ITH2-2'
            }, {
                'name': 'ITH2-3',
                'index': 'ITH2-3'
            }, {
                'name': 'ITH2-4',
                'index': 'ITH2-4'
            }, {
                'name': 'OUT1A',
                'index': 'OUT1A'
            }, {
                'name': 'OUT2A',
                'index': 'OUT2A'
            }, {
                'name': 'OUT3B',
                'index': 'OUT3B'
            }, {
                'name': 'TSG',
                'index': 'TSG'
            }, {
                'name': 'OUT4B',
                'index': 'OUT4B'
            }, {
                'name': 'OUT5C',
                'index': 'OUT5C'
            }, {
                'name': 'OUT6C',
                'index': 'OUT6C'
            }, {
                'name': 'OUT7D',
                'index': 'OUT7D'
            }, {
                'name': 'OUT8D',
                'index': 'OUT8D'
            }];
            return
        }
        if (m.deviceType == "SM2000_GN") {
            $scope.activeAlarmModuleList = [{
            'name': 'MC',
            'index': 'MC'
        }, {
            'name': 'CC1',
            'index': 'CC1'
        }, {
            'name': 'CC2',
            'index': 'CC2'
        }, {
            'name': 'INPUT1',
            'index': 'INPUT1'
        }, {
            'name': 'INPUT2',
            'index': 'INPUT2'
        }];
            return
        }
        $scope.activeAlarmModuleList = [{
            'name': 'MC',
            'index': 'MC'
        }, {
            'name': 'CC1',
            'index': 'CC1'
        }, {
            'name': 'CC2',
            'index': 'CC2'
        }, {
            'name': 'INPUT1',
            'index': 'INPUT1'
        }, {
            'name': 'INPUT2',
            'index': 'INPUT2'
        }];
    }
}]);