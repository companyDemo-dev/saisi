angular.module('alarmStatisticsModule',[]).controller('alarmStatisticsCtrl', ['$scope','$rootScope','$translate',"$timeout",'publicService',  function($scope, $rootScope,$translate,$timeout, publicService){
	publicService.doRequest("GET", 37, {}).success(function(r) {
		$scope.alarmStatisticsList = r.data;
	});
	$scope.alarmStatistics = [];
	$scope.deviceT = [];
	$scope.deviceT.device = [];
	$scope.dev = []
	$scope.seach =function(a,b,c){
		if(!a.company)  a.company ='all';
		if(!b.deviceType)  b.deviceType ='all';
		var obj = {
			"company" : a.company,
			"deviceType" : b.deviceType,
			"device" : c.map(function(a){return a.id}) || []
		};
		publicService.doRequest("POST", 36, obj).success(function(r) {
			var result = r.data ;
			if(result.length > 0){
				$scope.aidList = result;
			}
		});

		// var r = {"code":100000,"data":[{"alarmdata":[{"color":"#a5c2d5","name":"赛思1","value":841},{"color":"#a5c2d5","name":"赛思1","value":2441},{"color":"#a5c2d5","name":"赛思1","value":9711}],"aid":"alarm level-1"},
		// 		{"alarmdata":[{"color":"#a5c2d5","name":"赛思2","value":84},{"color":"#a5c2d5","name":"赛思2","value":244},{"color":"#a5c2d5","name":"赛思2","value":971}],"aid":"alarm level-2"}]}
		// var result = r.data ;
		// if(result.length > 0){
		// 	$scope.aidList = result;
		// }
	}
	$scope.alarmStatisticsChange = function(m){
		m ? alarmStatisticsfun(m.alarmdata, m.labels) : alarmStatisticsfun([]);
	}
	alarmStatisticsfun();
	function alarmStatisticsfun(data,labels) {
            // new iChart.Column2D({
            //     render: 'alarmStatisticsCanvas',
            //     data: data || [],
            //     title: "告警统计" ,
            //     // showpercent:true,
            //     decimalsnum: 2,
            //     width: 1080,
            //     height: 400,
            //     // column_width: 40,
            //     coordinate: {
            //         background_color: '#fefefe',
            //         scale: [{
            //             position: 'left',
            //             listeners: {
            //                 parseText: function(t, x, y) {
            //                     return {
            //                         text: t
            //                     }
            //                 }
            //             }
            //         }]
            //     }
            // }).draw();
			var chart = new iChart.ColumnMulti2D({
					render : 'alarmStatisticsCanvas',
					data: data || [],
					labels:labels || 1,
					title: "告警统计" ,
					// subtitle : ',单位:万台',
					// footnote : '数据来源：销售中心',
					width : 1080,
					height : 400,
					background_color : '#ffffff',
					legend:{
						enable:true,
						background_color : null,
						border : {
							enable : false
						}
					},
					coordinate:{
						background_color : '#f1f1f1',
						scale:[{
							 position:'left',	
							 start_scale:0
						}],
						width:900,
              			height:320
					}
			});
			chart.draw();
            var par = document.getElementById('popover');
            angular.element(par).addClass('popoverS');
    }
}]);
