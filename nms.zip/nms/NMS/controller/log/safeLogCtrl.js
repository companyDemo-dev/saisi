angular.module('safeLogModule',[]).controller('safeLogCtrl', ['$scope','$translate', '$rootScope', 'publicService', function($scope,$translate, $rootScope, publicService) {
    publicService.doRequest("GET", 112, {
        page: "",
        pageSize: 200,
        name: "",
        ip: "",
        deviceStatus: "",
        areaId: "",
        deviceType: ""
    }).success(function(r) {
        if (r.data == null) return
        if (r.data !== null && r.data.content && r.data.content.length > 0) {
            var content = r.data.content;
            var deviceInfo = [];
            for (i = 0; i < content.length; i++) {
                    deviceInfo.push(content[i]);
            }
            $scope.deviceInfo = deviceInfo;
        }
    });
     $scope.seach = function(m) {
             if (!$scope.devID) {
                var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
                publicService.ngAlert(tt, "info");
                return;
            }
        $scope.seachMod = m;
        $scope.paginationConf.onChange();
    }
    $scope.paginationConf = {
        currentPage: 1,
        totalItems: 0,
        itemsPerPage: 10,
        pagesLength: 15,
        perPageOptions: [10, 20, 30, 40, 50],
        rememberPerPage: 'perPageItems',
        onChange: function() {
            if (!$scope.devID) {
                return;
            }
            $scope.seachMod = $scope.seachMod || {}
            var _self = this,
                obj = {
                    page: _self.currentPage || 1,
                    pageSize: _self.itemsPerPage,
                    deviceIp: $scope.devID.ip,
                    secuLogUser: $scope.seachMod.secuLogUser || "",
                    secuLogTimeBgn: $scope.seachMod.secuLogTimeBgn || "",
                    secuLogTimeEnd: $scope.seachMod.secuLogTimeEnd || "",
                    description: $scope.seachMod.description || ""
                }
            publicService.loading('start');
            publicService.doRequest("GET", 3, obj).success(function(r) {
                $scope.logList = r.data.content;
                _self.currentPage = parseInt(r.data.number + 1);
                _self.totalItems = r.data.totalElements;
                _self.itemsPerPage = r.data.size;
            })
        }
    };
    /**
     * downloadlog
     *   导出日志
     */
    $scope.downloadlog = function(m) {
        var s = $scope;
        var obj = {
                    secuLogUser: $scope.seachMod.secuLogUser || "",
                    secuLogTimeBgn: $scope.seachMod.secuLogTimeBgn || "",
                    secuLogTimeEnd: $scope.seachMod.secuLogTimeEnd || "",
                    secuLogDesc: $scope.seachMod.description || ""
        };
        publicService.doRequest("GET", "/nms/spring/log/downloadSecuLogByFilter", obj).success(function(r) {
            if (!r || !r.data || r.data.length < 0) return;
            window.location.href = 'http://' + location.hostname + r.data + '';
        })
    }
}]);
