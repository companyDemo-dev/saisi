angular.module('operationLogModule',[]).controller('operationLogCtrl', ['$scope',"$translate",'publicService', "deviceInfoData", function($scope, $translate,publicService, deviceInfoData) {
    publicService.doRequest("GET", 112, {
        page: "",
        pageSize: 200,
        name: "",
        ip: "",
        deviceStatus: "",
        areaId: "",
        deviceType: ""
    }).success(function(r) {
        if (r.data == null) return
        if (r.data !== null && r.data.content && r.data.content.length > 0) {
            var content = r.data.content;
            var deviceInfo = [];
            for (i = 0; i < content.length; i++) {
                    deviceInfo.push(content[i]);
            }
            $scope.deviceInfo = deviceInfo;
        }
    });
    $scope.seach = function(m) {
        $scope.seachMod = m;
        if(!$scope.devID){
            var tt = $translate.use() === 'ch' ?　"请选择设备" : "Please select device";
            publicService.ngAlert(tt,"info");
            return;
        }
        $scope.paginationConf.onChange()
    }
    $scope.paginationConf = {
        currentPage: 1,
        totalItems: 0,
        itemsPerPage: 10,
        pagesLength: 15,
        perPageOptions: [10, 20, 30, 40, 50],
        rememberPerPage: 'perPageItems',
        onChange: function() {
            $scope.seachMod = $scope.seachMod || {};

            if(!$scope.devID) return;
            var _self = this,
                obj = {
                    page: _self.currentPage || 1,
                    pageSize: _self.itemsPerPage,
                    deviceIp: $scope.devID.ip,
                    cmdLogUser: $scope.seachMod.cmdLogUser || "",
                    cmdLogTimeBgn: $scope.seachMod.cmdLogTimeBgn || "",
                    cmdLogTimeEnd: $scope.seachMod.cmdLogTimeEnd || "",
                    cmdLogDesc: $scope.seachMod.cmdLogDesc || ""
                }
            publicService.loading('start');
            publicService.doRequest("GET", 8, obj).success(function(r) {
                $scope.operationLogList = r.data.content;
                _self.currentPage = parseInt(r.data.number + 1);
                _self.totalItems = r.data.totalElements;
                _self.itemsPerPage = r.data.size;
            })
        }
    };

    /**
     * downloadlog
     *   导出日志
     */
    $scope.downloadlog = function(m) {
        if (!$scope.devID) {
                var tt = $translate.use() === 'ch' ?　"请选择设备" : "Please select device";
                publicService.ngAlert(tt,"info");
            return;
        }
        var s = $scope;
        var obj = {
            deviceIp: $scope.devID.ip,
            cmdLogUser: $scope.seachMod.cmdLogUser || "",
            cmdLogTimeBgn: $scope.seachMod.cmdLogTimeBgn || "",
            cmdLogTimeEnd: $scope.seachMod.cmdLogTimeEnd || "",
            cmdLogDesc: $scope.seachMod.cmdLogDesc || ""
        };
        publicService.doRequest("GET", "/nms/spring/log/downloadCmdLogByFilter", obj).success(function(r) {
            if (!r || !r.data || r.data.length < 0) return;
            window.location.href = 'http://' + location.hostname + r.data + '';
        })
    }
}]);
