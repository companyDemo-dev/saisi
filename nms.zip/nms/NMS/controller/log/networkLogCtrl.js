angular.module('networkLogModule',[]).controller('networkLogCtrl', ['$scope','publicService', function($scope, publicService){
	$scope.seach = function(m){
		$scope.seachMod = m;
		$scope.paginationConf.onChange()
	}
    $scope.paginationConf = {
        currentPage: 1,
        totalItems: 0,
        itemsPerPage: 10,
        pagesLength: 15,
        perPageOptions: [10, 20, 30, 40, 50],
        rememberPerPage: 'perPageItems',
        onChange: function(){
        	$scope.seachMod = $scope.seachMod || {};
        	var _self = this,
            	obj = {
        		page : _self.currentPage || 1,
        		pageSize : _self.itemsPerPage,
        		description : $scope.seachMod.description || "",
        		bgnDate : $scope.seachMod.bgnDate || "",
        		endDate : $scope.seachMod.endDate || "",
                nmsLogUser: ""
        	}
            publicService.loading('start');
            publicService.doRequest("GET", 7, obj).success(function(r){
        		$scope.networkLogList = r.data.content;
                _self.currentPage = parseInt(r.data.number + 1);
                _self.totalItems = r.data.totalElements;
                _self.itemsPerPage = r.data.size;
        	})
        }
    };
           /**
     * downloadlog
     *   导出日志
     */
    $scope.downloadlog = function(m) {
       var  s = $scope;
        var  obj = {
                description : $scope.seachMod.description || "",
                bgnDate : $scope.seachMod.bgnDate || "",
                endDate : $scope.seachMod.endDate || "",
                nmsLogUser: ""
        };
        publicService.doRequest("GET", "/nms/spring/log/downloadNmsLogByFilter", obj).success(function(r) {
            if (!r || !r.data || r.data.length < 0) return;
            window.location.href = 'http://' + location.hostname + r.data + '';
        })
    }
}]);
