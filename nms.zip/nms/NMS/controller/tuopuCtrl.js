angular.module('tuopuModule', []).controller('tuopuCtrl', ['$scope', '$rootScope', '$state', "$timeout", '$translate', 'publicService', "ngDialog", "ngTip", function($scope, $rootScope, $state, $timeout, $translate, publicService, ngDialog, ngTip) {


    //滚动鼠标地图放大缩小
    window.zoozImg = function() {
        zoomImgObj.init(document.getElementById('canvas'));
    }
    zoomImgObj = {
        sum: 0.5,
        scale: 0.05,
        init: function(dom) {
            var x = event.clientX - dom.parentElement.offsetLeft,
                y = event.clientY - dom.parentElement.offsetTop;
            if (event.wheelDelta > 0) {
                this.sum += this.scale;
            } else {
                this.sum -= this.scale;
                if (this.sum < 0.5) this.sum = 0.5;
            }
            dom.style.transform = "scale(" + this.sum + ")";
            dom.style.transformOrigin = x + 'px ' + y + 'px';
            dom.style.transition = 'transform 0.5s';
        }
    }
    if (typeof websocket !== "undefined") {
        websocket.close()
    }

    function webSocketFun() {
        websocket = new WebSocket('ws://' + location.hostname + ':8080/nms/socket?token=' + $rootScope.curLoginMsg.sessionID + '');

        websocket.onopen = function(evt) {
            onOpen(evt)
        };

        websocket.onclose = function(evt) {
            onClose(evt)
        };
        websocket.onmessage = function(evt, num) {
            onMessage(evt)
            $scope.$apply();
        };
        websocket.onerror = function(evt) {
            onError(evt)
        };
    }
    if ($rootScope.curLoginMsg) webSocketFun();
    var devicePipei = {
        "CRITI": {
            u: "images/sound/3.mp3",
            s: 0,
            c: "red"
        },
        "MAJOR": {
            u: "images/sound/2.mp3",
            s: 3,
            c: "pink"
        },
        "MINOR": {
            u: "images/sound/1.mp3",
            s: 4,
            c: "yellow"
        },
        "onLine": {
            u: "",
            s: 6,
            c: "greent"
        },
        "offLine": {
            u: "images/sound/3.mp3",
            s: 0,
            c: "gery"
        }
    };

    function onOpen(evt) {
        //console.log("onOpene:", evt)
    }

    function onClose(evt) {
        //console.log("onClose:", evt)
    }
    $scope.onmessageSum = 0;

    function newTupoImg(t) {
        var obj = {};
        if (t == 1) {
            obj.offLine = "images/tep11off.png";
            obj.onLine = "images/tep11.png"
        } else if (t == 2) {
            obj.offLine = "images/tep22off.png";
            obj.onLine = "images/tep22.png"
        } else if (t == 3) {
            obj.offLine = "images/tep33off.png";
            obj.onLine = "images/tep33.png"
        } else if (t == 4) {
            obj.onLine = "images/tep4.png"
        }
        return obj
    }


    function onMessage(evt) {
        if (!evt || !evt.data || evt.data.length < 0) return;
        var res = evt.data,
            obj = JSON.parse(res),
            code = obj.code;
        if (code == "100000") {
            if (!obj.prompt && obj.data) {
                console.log(obj)
                var device = (obj.data.device.id).replace(/[#$%^&*!-]/g, '');
                var tipshow = $("#tip" + device);
                var desc = $("#desc" + device);
                tipshow.show();
                desc.text(obj.data.activeAlarmDesc);
                $timeout(function() {
                    tipshow.hide();
                }, 6000)
            }
            if (!obj.data) {
                return
            }
            var ooo = obj.data;
            if (ooo.activeAlarmDesc) {
                var desc_ = ooo.activeAlarmDesc;
                if (desc_.indexOf("loss of signal") > -1 || desc_.indexOf("disqualified as system reference") > -1) {

                    if (window.location.hash.indexOf("#/index/") === -1) {
                        var o = {};
                        o.areaId = $scope.tuopuAreaId || "";
                        o.userId = localStorage.getItem("curUserId") || "";
                        o.viewDataType = "";
                        publicService.doRequest("GET", 5, o).success(function(r) {
                            $scope.tuopoData = r.data.length === 0 ? {} : r.data[0];
                            $scope.tuopoData.data && ($scope.tuopoData.data = JSON.parse($scope.tuopoData.data));
                            jsPlumbas($scope, publicService, ngDialog, '', $translate, ooo);
                        })

                    }

                    /*        var sp = desc_.split(/\s/)[0],
                                slotAndport = sp.split('-'),
                                port_ = slotAndport[1],
                                slot_ = slotAndport[0],
                                slot_ = slot_.substring(slot_.indexOf('t') + 1, slot_.length),
                                it = $scope.instance,
                                tpData = $scope.tuopoData
                            if (tpData && tpData.data) {
                                var tpd = tpData.data;
                                for (var j in tpd) {
                                    if (tpd[j]["targetIds"] && tpd[j]["targetIds"].length > 0) {
                                        var oso = tpd[j]["targetIds"];
                                        for (var q = 0; q < oso.length; q++) {
                                            if (oso[q].port === port_ && oso[q].slot === slot_) {
                                                delBetweenCon(it, $scope, publicService, j, oso[q].ip);
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                            if (publicService._JTopo) {
                                var allElements = publicService._JTopo.scene.getDisplayedElements();
                                for (var i = 0; i < allElements.length; i++) {
                                    if (allElements[i].elementType === "link" && port_ == allElements[i].port && slot_ == allElements[i].slot) {
                                        publicService._JTopo.scene.remove(allElements[i]);
                                    }
                                }
                                publicService._JTopo.saveDate();
                            }*/
                }
            }

        } else if (code === "100002") { //扩展机框
            var data = obj.data;
            updataExpData(data)
        } else if (code === "100003") { //主机框
            if ($scope.flag == "shil") {
                frameListFun($scope.curDevId, $scope.shelfind, $scope.deviceType)
            }
        } else if (code === "100041") { //设备上线
            var data = obj.data;
            updataTreeData(data, code);
            if (publicService._JTopo) {
                var allElements = publicService._JTopo.scene.getDisplayedElements();
                for (var i = 0; i < allElements.length; i++) {
                    if (allElements[i].elementType === "node" && allElements[i].deviceModel.id == data.id) {
                        allElements[i].setImage(newTupoImg(allElements[i].deviceModel.img)["onLine"], true);
                        allElements[i].deviceModel.deviceStatus = 1;
                        allElements[i].deviceModel.type = "greent";
                    }
                }
                // publicService._JTopo.saveDate();
            }
        } else if (code === "100042") { //设备离线
            var data = obj.data;
            updataTreeData(data, code);
            if (publicService._JTopo) {
                var allElements = publicService._JTopo.scene.getDisplayedElements();
                for (var i = 0; i < allElements.length; i++) {
                    if (allElements[i].elementType === "node" && allElements[i].deviceModel.id == data.id) {
                        allElements[i].setImage(newTupoImg(allElements[i].deviceModel.img)["offLine"], true);
                        allElements[i].deviceModel.deviceStatus = 0;
                        delete allElements[i].alarm;
                        allElements[i].deviceModel.type = "gery";
                    }
                }
                // publicService._JTopo.saveDate();
            }
        } else if (code === "100005") { //扩展机框
            if ($scope.flag == "shil") {
                frameListFun($scope.curDevId, $scope.shelfind, $scope.deviceType)
            }
        } else if (code === "100009") {
            console.log(obj)
            var data = obj.data;
            updataTreeData(data, "100009");
            if (window.location.hash.indexOf("#/index/") === -1) {
                var o = {};
                o.areaId = $scope.tuopuAreaId || "";
                o.userId = localStorage.getItem("curUserId") || "";
                o.viewDataType = "";
                publicService.doRequest("GET", 5, o).success(function(r) {
                    $scope.tuopoData = r.data.length === 0 ? {} : r.data[0];
                    $scope.tuopoData.data && ($scope.tuopoData.data = JSON.parse($scope.tuopoData.data));
                    jsPlumbas($scope, publicService, ngDialog, '', $translate, ooo);
                })

            }
        } else if (code === "100011") {
            publicService.ngAlert(obj.msg);
        } else if (code === "100020") {
            publicService.ngAlert(obj.msg);
        } else if (code === "100008") {
            var data = obj.data;
            updataTreeData(data, '100008');
            if (publicService._JTopo) {
                var allElements = publicService._JTopo.scene.getDisplayedElements();
                for (var i = 0; i < allElements.length; i++) {
                    if (allElements[i].elementType === "node" && allElements[i].deviceModel.id == data.id) {
                        if (eveLevelColor(data.activeAlarmLevel) == "red") {
                            allElements[i].alarmColor = "214,15,15"
                        } else if (eveLevelColor(data.activeAlarmLevel) == "pink") {
                            allElements[i].alarmColor = '241, 147, 30'
                        } else if (eveLevelColor(data.activeAlarmLevel) == "yellow") {
                            allElements[i].alarmColor = '204,218,15'
                        } else if (eveLevelColor(data.activeAlarmLevel) == "gery") {
                            delete allElements[i].alarm;
                            allElements[i].setImage(_self.offLineImg(obj.img), true);
                        } else if (eveLevelColor(data.activeAlarmLevel) == "greent") {
                            allElements[i].alarmColor = '0, 0, 0'
                        }
                        allElements[i].deviceModel.type = eveLevelColor(data.activeAlarmLevel);
                        allElements[i].deviceModel.alarmsCount = data.alarmsCount;
                    }
                }
                // publicService._JTopo.saveDate();
            }
        } else if (code === "100010") {
            ngTip.tip(obj.msg, "info")
                /*                    var userAgent = navigator.userAgent;
                               if (userAgent.indexOf("Firefox") != -1 || userAgent.indexOf("Chrome") != -1) {
                                    window.open('http://' + location.hostname +'/nms/index.html');
                               } else {
                                   window.opener = null;
                                   window.open("", "_self");
                                   window.close();
                               }*/
        } else if (code === "100099" || code === "100021") {
            /*   var par = document.getElementById('popover');
               if(par){
                 angular.element(par).addClass('popoverS');
               }*/
            ngTip.tip(obj.msg, "info")
            console.log(obj);
            //7200设备升级信息返回
        } else if (code === "100015") {
            if ($scope.flag == "shil") {
                frameListFun($scope.curDevId, $scope.shelfind, $scope.deviceType)
            }
        } else if (code === "100003") {
            $state.go("index");
            ngTip.tip(obj.msg, "info", 7200000)
        } else if (code === "100030") {
            $state.go("login");
            ngTip.tip(obj.msg, "info")
        } else if (code === "100022") { //100022还原数据库
            ngTip.tip(obj.msg, "info")
        }
    }

    function updataTreeData(data, type) {
        if (data && $scope.deviceTreeData && $scope.deviceTreeData.length > 0) {
            var dList = $scope.deviceTreeData;
            for (var i = 0; i < dList.length; i++) {
                if (dList[i].children && dList[i].children.length > 0) {
                    var chil = dList[i].children;
                    for (var z = 0; z < chil.length; z++) {
                        if (chil[z].ip == data.ip) {
                            if (type == '100008') {
                                if (chil[z].type != "gery") {
                                    chil[z].type = eveLevelColor(data.activeAlarmLevel);
                                }
                                chil[z].alarmsCount = data.alarmsCount;
                                if (publicService.alwaysAlarmLoad && window.location.hash.indexOf("#/index/alwaysAlarm") !== -1 && data.id && data.id === $scope.curDeviceId) {
                                    publicService.alwaysAlarmLoad($scope.curDeviceId);
                                }
                            } else if (type == '100009') {
                                chil[z].refInput = data.refInput;
                            } else if (type == '100041') {
                                chil[z].type = "greent";
                                chil[z].deviceStatus = 1;

                                var chilk = chil[z].children;
                                for (var k = 0; k < chilk.length; k++) {
                                    chilk[k].deviceStatus = 1;
                                }
                            } else if (type == '100042') {
                                chil[z].type = "gery";
                                chil[z].deviceStatus = 0;

                                var chilk = chil[z].children;
                                for (var k = 0; k < chilk.length; k++) {
                                    chilk[k].deviceStatus = 0;
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    function updataExpData(data) {
        if (data && $scope.deviceTreeData && $scope.deviceTreeData.length > 0) {
            var dList = $scope.deviceTreeData;
            for (var i = 0; i < dList.length; i++) {
                if (dList[i].children && dList[i].children.length > 0) {
                    var chil = dList[i].children;
                    for (var z = 0; z < chil.length; z++) {
                        if (chil[z].ip == data.ip) {
                            var chil2 = chil[z].children;
                            for (var m = 0; m < chil2.length; m++) {
                                if (chil2[m] == null) continue
                                if (chil2[m].nameCn == data.nameCn) {
                                    if (data.status == 0) {
                                        console.log(chil2)
                                        chil2.splice(m, 1)
                                    }
                                } else {
                                    if (data.status == 1) {
                                        console.log(chil2);
                                        data.type = "box2";
                                        data.flag = null;
                                        data.parentId = chil[z].id;
                                        chil2[m + 1] = data;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }



    function eveLevelColor(level) {
        var ss = "";
        if (level === "none") {
            ss = "greent";
        } else if (level === "EVENT" || level === "MINOR") {
            ss = "yellow";
        } else if (level === "MAJOR") {
            ss = "pink";
        } else if (level === "CRITI") {
            ss = "red";
        }
        return ss;
    }

    //解决上报拉取多次重复请求
    // function onmessageSumFun() {
    //     if ($scope.onmessageSum !== 0) {
    //         publicService.doRequest("GET", 4, {
    //             type: "all"
    //         }).success(function(data) {
    //             if (data.data == null) return
    //             if (data.data && data.data.length > 0) {
    //                 $scope.deviceTreeData = data.data;
    //                 $scope.flag = data.data[0].flag;
    //                 for (var i = 0; i < data.data.length; i++) {
    //                     if (data.data[i].children && data.data[i].children.length > 0 && $scope.tuopuAreaId === data.data[i].id) {
    //                         $scope.tuopu = data.data[i].children;
    //                         break;
    //                     }
    //                 }
    //                 treeLoad($scope.tuopuAreaId); //加载拓扑图
    //             }
    //         });
    //         if (publicService.alwaysAlarmLoad && window.location.hash.indexOf("#/index/alwaysAlarm") !== -1 && obj.data.deviceId && obj.data.deviceId === $scope.curDeviceId) publicService.alwaysAlarmLoad($scope.curDeviceId); // 时实更新告警;
    //         $scope.onmessageSum = 0;
    //     }
    //     $timeout(onmessageSumFun, 2000);
    // }
    //onmessageSumFun();

    //过滤设备树最高级别的告警声音
    function maxAlarmSound() {
        var m = treeColor();
        if (m.length > 0) {
            var maxAlarm = Math.min.apply(null, m);
            for (var s in devicePipei) {
                if (devicePipei[s]["s"] === maxAlarm) {
                    document.getElementById("audio").src = devicePipei[s]["u"];
                }
            }
        }
    }


    $scope.but = function() {
        //treeColor("192.168.81.53", "yellow")
    }

    var treeColor = function(ip, t) {
        var treeList = $scope.deviceTreeData;
        if (treeList && treeList.length > 0) {
            $rootScope.alarmLevelArray = [];
            for (var i = 0; i < treeList.length; i++) {
                var devices = treeList[i].children;
                if (devices.length > 0) {
                    for (var y = 0; y < devices.length; y++) {
                        if (ip === devices[y].ip && devices[y].type !== t) {
                            //devices[y].type = t
                            // IP相同，但上报来的消息级别与原来设备的告警级别不同，拉取新接口换最新的颜色
                        } else {
                            $rootScope.alarmLevelArray.push(clo(devices[y].type));
                        }

                    }
                }
            }
            $rootScope.alarmLevelArray = $rootScope.alarmLevelArray.unique();
        }
        return $rootScope.alarmLevelArray;
    }

    function clo(t) {
        for (var j in devicePipei) {
            if (devicePipei[j]["c"] === t) return devicePipei[j]["s"]
        }
    }



    function delBetweenCon(instance, scope, service, sourceId, targetId) {
        var cons = instance.getConnections();
        if (cons.length > 0) {
            for (var i = 0; i < cons.length; i++) {
                if (cons[i].sourceId === sourceId && cons[i].targetId === targetId) {
                    instance.detach(cons[i]);
                    deleteLine(scope, cons[i], service);
                    break;
                }
            }
        }
    }

    function onError(evt) {
        console.log("onerror:", evt)
    }
    // $scope.opts = { // 点击节点展开树；
    //     dirSelectable: false
    // };
    $scope.sounds = function() {
        $scope.$emit("otherSoundUrlMsg", "images/sound/alarm.mp3")
    }
    $scope.sounds1 = function() {
        $scope.$emit("otherSoundUrlMsg", 12000)
    }


    $scope.showSelected = function(sel) {
        $scope.selectedNode = sel;
    };

    //地图
    publicService.doRequest("GET", 17, {}).success(function(r) {
        $scope.mapList = r.data;
    })
    $scope.checkMap = function(sel) {
        var cans = angular.element(document.getElementById("tuopu_canvas"));
        if (cans) {
            cans.css({
                "background": sel !== '' ? "url(" + 'http://' + location.host + '/mapImg/' + sel + ") no-repeat" : '#c7c1c1',
                'background-size': "100% 100%"
            });
            localStorage.setItem("mapUlr", sel);
        }
    };
    //拓扑定位
    $scope.posDinfun = function() {
        var d = document.getElementsByName($scope.posDin)[0];
        if (d) {
            //treecontrol.tree-light li .tree-selected span:last-child
            var ss = angular.element(d).parent().parent().parent();
            if (ss || 　ss[0].nodeName === "UL") {

                angular.element($q(".tree-selected")).removeClass('tree-selected');
                angular.element(d).parent().addClass('tree-selected');
                ss.removeClass('ops1');
                d.scrollIntoView(true);
                window.scrollTo(0, 0); //解决锚定向定位window滚动多出15个像素;
                $scope.treeFun(JSON.parse(angular.element(ss.parent().parent().find("span")[1]).attr("obj")));

                $timeout(function() {
                    var dd = angular.element(d).attr('treeid');
                    angular.element($q(".tuopuSpan")).removeClass('tuopuSpan');
                    angular.element(document.getElementById(dd)).find("span").eq(0).addClass("tuopuSpan");
                }, 300)

            }
        } else {
            var tt = $translate.use() === 'ch' ? 　"没有查到该设备" : "The device is not found";
            publicService.ngAlert(tt, "danger");
        }
    }

    $scope.dMouseDown = function() {
            if ($rootScope.curLoginMsg.roleList[0].roleDesc != '管理级') {
                publicService.ngAlert('没有权限', "info")
                return
            }
            this.xy = {
                x: event.pageX || window.event.pageX,
                y: event.pageY || window.event.pageX
            };
        }
        //修改添加拓扑图设备
    $scope.tuopuDigEditAdd = function(m) {
            if ($rootScope.curLoginMsg.roleList[0].roleDesc != '管理级') {
                publicService.ngAlert('没有权限', "info")
                return
            }
            var self = this;
            ngDialog.close('ngdialog1');
            $state.go("index.tuopuDeviceAddEdit", {
                mauto: $scope.fitem
            })
        }
        //实施告警
    $scope.alwaysAlarm = function(m) {
            var self = $scope.fitem;
            //$rootScope.curDeviceId =self.id;
            $scope.curDeviceId = self.id;
            ngDialog.close('ngdialog1');
            $state.go("index.alwaysAlarm", {
                id: self.id
            });
        }
        //查看参考源
    $scope.showTrimble = function(m) {
        var self = $scope.fitem;
        //$rootScope.curDeviceId =self.id;
        $scope.curDeviceId = self.id;
        ngDialog.close('ngdialog1');
        publicService.doRequest("GET", "/nms/spring/deviceConfig/" + $scope.curDeviceId + "/configs/ioStatusTable", {}).success(function(r) {
            for (var i = 0; i < r.data.length; i++) {
                if (r.data[i].ioSignal == "input-PTP") {
                    $state.go("index.showTrimbleptp", {
                        id: self.id
                    });
                    return
                } else {
                    $state.go("index.showTrimble", {
                        id: self.id
                    });
                }
            }
        })

    }


    //查看参考源
    $scope.showGnss1 = function(m) {
            var self = $scope.fitem;
            //$rootScope.curDeviceId = self.id;
            $scope.curDeviceId = self.id;
            ngDialog.close('ngdialog1');
            $state.go("index.showGnss1", {
                id: self.id
            });
        }
        //查看参考源
    $scope.showGnss2 = function(m) {
            var self = $scope.fitem;
            //$rootScope.curDeviceId = self.id;
            $scope.curDeviceId = self.id;
            ngDialog.close('ngdialog1');
            $state.go("index.showGnss2", {
                id: self.id
            });
        }
        //删除拓扑图设备
    $scope.tuopuDigDel = function(m) {
            if ($rootScope.curLoginMsg.roleList[0].roleDesc != '管理级') {
                publicService.ngAlert('没有权限', "info")
                return
            }
            var self = $scope.fitem;
            t = $translate.use() === "ch" ? "确认删除?" : "confirm delete？";
            if (confirm(t)) {
                ngDialog.close('ngdialog1');
                var ip = self.ip,
                    dom = document.getElementById(ip),
                    tup = $scope.tuopoData.data;
                $scope.tuopu.splice($scope.tuopu.indexOf(self), 1); //删除拓扑图设备;
                $scope.instance.detachAllConnections(dom); //删除拓扑连线
                $scope.instance.removeAllEndpoints(dom); //删除拓扑连线的点
                for (var j in tup) {
                    if (j === ip) {
                        delete tup[j];
                    } else if (tup[j]["targetIds"]) {
                        var tag = tup[j]["targetIds"];
                        if (tag.length > 0) {
                            for (var f = 0; f < tag.length; f++) {
                                if (tag[f].ip === ip) {
                                    tag.splice(f, 1);
                                }
                            }
                        }
                    }
                }
                $scope.tuopoData.data = tup;
                publicService.loading('start')
                publicService.doRequest("POST", 5, $scope.tuopoData.data).success(function() { //连线定位表里删除

                    publicService.doRequest("DELETE", "/nms/spring/device/" + self.id, {}); //设备表里删除
                    publicService.loading('end');
                    var tt = $translate.use() === 'ch' ? 　"删除成功！" : "Delete success！";
                    publicService.ngAlert(tt, "success");
                    var topo_tip2 = $("#topo_tip2");
                    topo_tip2.hide();
                })
            }
        }
        //同步
    $scope.syncCache = function() {
            var self = $scope.fitem;
            publicService.doRequest("GET", "/nms/spring/device/" + self.id + "/syncCache", {}).success(function(r) {
                if (r.errCode) {
                    publicService.ngAlert(r.message, "danger");
                } else {

                    var tt = $translate.use() === 'ch' ? 　"数据正在同步，请稍后..." : "Data is in sync, please...";
                    publicService.ngAlert(tt, "info");
                }
            })
        }
        //拓扑查看功能
    $scope.seachDev = function() {
        var self = $scope.fitem;
        var topo_tip2 = $("#topo_tip2");
        topo_tip2.hide();
        var topo_tip3 = $("#topo_tip3");
        topo_tip3.hide();
        $scope.treeFun(self);
    }

    //查看时差
    $scope.showoffset = function(m) {
        var self = $scope.fitem;
        //$rootScope.curDeviceId = self.id;
        $scope.curDeviceId = self.id;
        ngDialog.close('ngdialog1');
        $state.go("index.showoffset", {
            id: self.id
        });
    }

    ////拓扑图排序
    $scope.tuopuSort = function() {
        // var self =  $scope.fitem;
        // self.tuopu = [];
        // publicService.doRequest("GET", "/nms/spring/device/area/" + this.tuopuAreaId, {}).success(function(r) {
        //     self.tuopu = r.data;
        //     if (r.data && r.data.length > 0) {
        //         publicService.loads(function() {
        //             jsPlumbas($scope, publicService, ngDialog, true);
        //         })
        //     }
        // })
        if ($scope.deviceTreeData && $scope.deviceTreeData.length > 0) {
            var dList = $scope.deviceTreeData;
            for (var i = 0; i < dList.length; i++) {
                if (dList[i].children && dList[i].children.length > 0 && $scope.tuopuAreaId === dList[i].id) {
                    $scope.tuopu = dList[i];
                    console.log($scope.tuopu)
                    break;
                }
            }
        }
        $scope.treeFun($scope.tuopu, true)
    }



    //拓扑图位置
    $scope.dMouseUp = function(item) {

            if ($rootScope.curLoginMsg.roleList[0].roleDesc != '管理级') {
                publicService.ngAlert('没有权限', "info")
                return
            }
            if (this.xy && event.pageX === this.xy.x && event.pageY === this.xy.y) return;
            var areaId = $scope.tuopuAreaId,
                userid = localStorage.getItem("curUserId") || "";
            publicService.doRequest("GET", 5, {
                areaId: areaId,
                userId: userid,
                viewDataType: ""
            }).success(function(r) {
                $scope.tuopoData = r.data.length === 0 ? {} : r.data[0];
                $scope.tuopoData.data && ($scope.tuopoData.data = JSON.parse($scope.tuopoData.data));
                if ($scope.tuopoData.areaId === undefined) {
                    $scope.tuopoData.areaId = areaId;
                    $scope.tuopoData.userId = userid;
                    $scope.tuopoData.data = {};
                    $scope.tuopoData.data[item.ip] = {};
                    $scope.tuopoData.data[item.ip]["possion"] = {};
                } else {
                    if (!$scope.tuopoData.data[item.ip]) {
                        $scope.tuopoData.data[item.ip] = {}
                        $scope.tuopoData.data[item.ip]["possion"] = {};
                    } else {
                        if (!$scope.tuopoData.data[item.ip]["possion"]) {
                            $scope.tuopoData.data[item.ip]["possion"] = {};
                        }
                    }
                }
                $scope.tuopoData.data[item.ip]["possion"]["left"] = (document.getElementById(item.ip).style.left);
                $scope.tuopoData.data[item.ip]["possion"]["top"] = (document.getElementById(item.ip).style.top);
                $scope.tuopoData.data = JSON.stringify($scope.tuopoData.data);
                publicService.doRequest("POST", 5, $scope.tuopoData).success(function() {
                    $scope.tuopoData.data = JSON.parse($scope.tuopoData.data)
                })
            })
        }
        //加载拓扑与设备树
    $scope.loadLeftTree2 = function() {
        var par = document.getElementById('popover');
        angular.element(par).addClass('popoverS');
        publicService.doRequest("GET", 4, {
            type: 'all'
        }).success(function(data) {
            var par = document.getElementById('popover');
            angular.element(par).addClass('popoverS');
            if (data.data == null) return
            if (data.data && data.data.length > 0) {
                $scope.deviceTreeData = data.data;
                $scope.flag = data.data[0].flag;
                var ff = true;
                for (var i = 0; i < data.data.length; i++) {
                    // if (data.data[i].children && data.data[i].children.length > 0) {
                    //     $scope.tuopu = publicService.tuopu || data.data[i].children;
                    //     publicService.tuopu = $scope.tuopu;
                    //     $scope.tuopuAreaId = publicService.tuopu.length > 0 ?  publicService.tuopu[0].area.id : data.data[i].id;
                    //     break;
                    // }
                    if (data.data[i].children && data.data[i].children.length > 0) {
                        if (publicService.tuopu && publicService.tuopu[0].area.id === data.data[i].id) {
                            $scope.tuopu = angular.extend(publicService.tuopu, data.data[i].children);
                            publicService.tuopu = $scope.tuopu;
                            $scope.tuopuAreaId = publicService.tuopu[0].area.id;
                            ff = false;
                            break;
                        }
                    }
                }
                if (ff) {
                    for (var i = 0; i < data.data.length; i++) {
                        if (data.data[i].children && data.data[i].children.length > 0) {
                            $scope.tuopu = data.data[i].children;
                            publicService.tuopu = $scope.tuopu;
                            $scope.tuopuAreaId = data.data[i].id;
                            var obj = data.data[i].children;
                            /* $timeout(function() {tuopuTip(obj)})*/
                            break;
                        }
                    }
                }
                treeLoad($scope.tuopuAreaId); //加载拓扑图

            }
        });
    }

    //加载拓扑与设备树
    $scope.loadLeftTree1 = function() {
        var par = document.getElementById('popover');
        angular.element(par).addClass('popoverS');
        publicService.doRequest("GET", 4, {
            type: 0
        }).success(function(data) {
            publicService.loading('end');
            if (data.data == null) return
            if (data.data && data.data.length > 0) {
                $scope.deviceTreeData = data.data;
                $scope.flag = data.data[0].flag;
                var ff = true;
                for (var i = 0; i < data.data.length; i++) {
                    // if (data.data[i].children && data.data[i].children.length > 0) {
                    //     $scope.tuopu = publicService.tuopu || data.data[i].children;
                    //     publicService.tuopu = $scope.tuopu;
                    //     $scope.tuopuAreaId = publicService.tuopu.length > 0 ?  publicService.tuopu[0].area.id : data.data[i].id;
                    //     break;
                    // }
                    if (data.data[i].children && data.data[i].children.length > 0) {
                        if (publicService.tuopu && publicService.tuopu[0].area.id === data.data[i].id) {
                            $scope.tuopu = angular.extend(publicService.tuopu, data.data[i].children);
                            publicService.tuopu = $scope.tuopu;
                            $scope.tuopuAreaId = publicService.tuopu[0].area.id;
                            ff = false;
                            break;
                        }
                    }
                }
                if (ff) {
                    for (var i = 0; i < data.data.length; i++) {
                        if (data.data[i].children && data.data[i].children.length > 0) {
                            $scope.tuopu = data.data[i].children;
                            publicService.tuopu = $scope.tuopu;
                            $scope.tuopuAreaId = data.data[i].id;
                            var obj = data.data[i].children;
                            /* $timeout(function() {tuopuTip(obj)})*/
                            break;
                        }
                    }
                }

                //treeLoad($scope.tuopuAreaId); //加载拓扑图
                $scope.loadLeftTree2();
            }
        });
    }

    $scope.loadLeftTree1();

    $scope.ddbclick = function(item) {
        $scope.fitem = item;
        var topo_tip = $("#topo_tip");
        topo_tip.hide();
        var topo_tip3 = $("#topo_tip3");
        topo_tip3.hide();
        $scope.alarmsList = '';
        var topo_tip = $("#topo_tip2");

        topo_tip.css({
            top: event.pageY,
            left: event.pageX + 15
        }).show();

        if (item.deviceStatus == 0) {
            $("#tuopoCK").hide();
            $("#tuopoG1").hide();
            $("#tuopoG2").hide();
            $("#tuopoCE").hide();
            $("#tuopoED").hide();
            $("#tuopoSY").hide();
        } else {
            if (item.deviceType == 'SSU2000' || item.deviceType == 'NS7200' || item.deviceType == 'STFS1000' || item.deviceType == 'HP55400') {
                $("#tuopoCK").hide();
                $("#tuopoG1").hide();
                $("#tuopoG2").hide();
                $("#tuopoCE").show();
                $("#tuopoED").show();
                $("#tuopoSY").show();
                $("#tuopoPY").show();
            } else if (item.deviceType == 'LF7300' || item.deviceType == 'TS3000G') {
                $("#tuopoCK").hide();
                $("#tuopoG1").hide();
                $("#tuopoG2").hide();
                $("#tuopoCE").show();
                $("#tuopoED").show();
                $("#tuopoSY").show();
                $("#tuopoPY").hide();
            } else {
                $("#tuopoCK").show();
                $("#tuopoG1").show();
                $("#tuopoG2").show();
                $("#tuopoCE").show();
                $("#tuopoED").show();
                $("#tuopoSY").show();
                $("#tuopoPY").hide();
            }
        }
    }
    $scope.tuopuTip = function(obj) {
        var topo_tip = $("#topo_tip"),
            ref = $("#topo_ref"),
            tupdeviceIP = $("#tupdeviceIP"),
            deviceType = $("#deviceType"),
            alarmNum = $("#alarmNum"),
            topo_ref = $(".topo_ref"),
            br = $("#_br");
        if (obj.deviceStatus != 0 && obj.refInput) {
            ref.text('：' + obj.refInput);
            ref.show();
            topo_ref.show();
            br.show();
        } else {
            ref.hide();
            topo_ref.hide();
            br.hide();
        }
        tupdeviceIP.text(obj.ip);
        deviceType.text(obj.deviceType);
        alarmNum.text(obj.alarmsCount);
        topo_tip.css({
            top: event.pageY,
            left: event.pageX + 15
        }).show();

    }
    $scope.tuopuTipl = function(obj) {
        var topo_tip = $("#topo_tip");
        topo_tip.hide();
    }
    $scope.ddbclickL = function(obj) {
        var topo_tip2 = $("#topo_tip2");
        topo_tip2.hide();
        var topo_tip3 = $("#topo_tip3");
        topo_tip3.hide();
        $scope.alarmsList = '';
    }
    $scope.alarmsclick = function(obj) {
        loadAlarms(obj.id);
    }

    $scope.tuopuDDframe = function(obj) {
        var topo_tip = $("#topo_tip");
        topo_tip.hide()
        var topo_tip2 = $("#topo_tip2");
        topo_tip2.hide();
        var topo_tip3 = $("#topo_tip3");
        topo_tip3.hide();
        $scope.alarmsList = '';
        if (obj.deviceStatus == 0) {
            publicService.ngAlert('设备已经离线', "info")
            return
        }
        frameListFun(obj.id, 0, obj.deviceType);
    }

    $scope.tuopuDframe = function(obj) {
        var topo_tip = $("#topo_tip");
        topo_tip.hide()
        var topo_tip2 = $("#topo_tip2");
        topo_tip2.hide();
        var topo_tip3 = $("#topo_tip3");
        topo_tip3.hide();
        $scope.alarmsList = '';
        if (obj.deviceStatus == 0) {
            publicService.ngAlert('设备已经离线', "info")
            return
        }
        frameListFun(obj.id, 0, obj.deviceType);
    }
    $scope.maxAlarms = function() {
        var topo_tip3 = $("#topo_tip3");
        topo_tip3.hide();
        if (document.getElementById("alarms_canvas").style.height != "100%") {
            document.getElementById("alarms_canvas").style.height = "100%";
            document.getElementById("tuopu_canvas").style.height = "0%";
            document.getElementById("tuopu_canvasTools").style.display = "none";
        } else {
            document.getElementById("alarms_canvas").style.height = "20%";
            document.getElementById("tuopu_canvas").style.height = "80%";
            document.getElementById("tuopu_canvasTools").style.display = "block";
        }

    }


    $scope.maxTuopo = function() {
        if (document.getElementById("tuopu_canvas").style.height != "100%") {
            document.getElementById("alarms_canvas").style.height = "0%";
            document.getElementById("tuopu_canvas").style.height = "100%";
        } else {
            document.getElementById("alarms_canvas").style.height = "20%";
            document.getElementById("tuopu_canvas").style.height = "80%";
        }

    }


    function treeLoad(areaId, tuopuSort) {
        var o = {};
        o.areaId = areaId || "";
        o.userId = localStorage.getItem("curUserId") || "";
        o.viewDataType = "";
        publicService.doRequest("GET", 5, o).success(function(r) {
            var par = document.getElementById('popover');
            angular.element(par).addClass('popoverS');
            $scope.tuopoData = r.data.length === 0 ? {} : r.data[0];
            $scope.tuopoData.data && ($scope.tuopoData.data = JSON.parse($scope.tuopoData.data));
            $timeout(function() {
                //加载拓扑图
                jsPlumbas($scope, publicService, ngDialog, tuopuSort, $translate);
                //初使化声音加载
                maxAlarmSound();
            })
        })
    }


    //区域、设备、机框切换
    $scope.treeFun = function(sel, tuopuSort) {
        var self = this;
        if ($scope.mactimeF) {
            $timeout.cancel($scope.mactimeF)
            delete $scope.mactimeF
        }

        if ($scope.mactimeFBJ) {
            $timeout.cancel($scope.mactimeFBJ)
            delete $scope.mactimeFBJ
        }

        var topo_tip2 = $("#topo_tip2");
        topo_tip2.hide();
        var topo_tip3 = $("#topo_tip3");
        topo_tip3.hide();
        $scope.alarmsList = '';
        if (sel.flag && sel.flag === "area") { //第二个条件为了解决同一区域点击两次
            loadAlarms();
            document.getElementById("alarms_canvas").style.height = "20%";
            document.getElementById("alarms_canvas").style.border = "1px solid #716c6c";
            $scope.instance.unbind('dblclick'); //处理绑定事件
            $scope.tuopu = [];
            $scope.instance.deleteEveryEndpoint();
            $timeout(function() {
                $scope.tuopu = sel.children;
                publicService.tuopu = $scope.tuopu;
                $scope.tuopuAreaId = sel.id;
                treeLoad($scope.tuopuAreaId, tuopuSort);
                /*  $timeout(function() {tuopuTip($scope.tuopu);})*/

            })
            $scope.flag = sel.flag; //切换标识
        }
        if (sel.flag && sel.flag === "device") {
            if (sel.deviceStatus !== 0) {
                var par = document.getElementById('popover');
                angular.element(par).removeClass('popoverS');
                document.getElementById("alarms_canvas").style.height = "0%";
                document.getElementById("alarms_canvas").style.border = "none";

                function systemTime() {
                    publicService.doRequest("GET", "/nms/spring/deviceConfig/" + sel.id + "/configs/systemTime", {}).success(function(r) {
                        if (r.data[0]) {
                            var tt = r.data[0].systemTime.trim(),
                                t = (!!window.ActiveXObject || "ActiveXObject" in window) ? tt.replace(/-/g, "/") : tt;
                            $scope.timeInter = new Date(t).getTime();

                            function timef() {
                                $scope.timeInter += 1000;
                                $scope.systemTime = $scope.timeInter;
                                $scope.mactimeF = $timeout(timef, 1000);
                            }
                            if (!$scope.mactimeF) {
                                timef();
                            }
                            var timeInterBJ = parseInt($scope.timeInter) + 60 * 60 * 1000 * 8 - 1000;

                            function timefbj() {
                                timeInterBJ += 1000;
                                $scope.systemTimeBJ = timeInterBJ;
                                $scope.mactimeFBJ = $timeout(timefbj, 1000);
                            }
                            if (!$scope.mactimeFBJ) {
                                timefbj();
                            }

                        }
                    })
                }

                if (sel.deviceType && sel.deviceType === "NS7200" || sel.deviceType === " ") {
                    $scope.tuopuAreaId = sel.parentId;
                    var devId = sel.id;
                    systemTime()
                    publicService.doRequest("GET", "/nms/spring/deviceConfig/" + devId + "/getGeneralStatus", {}).success(function(r) {
                        if (r.data && r.data.generalStatus && r.data.gpsSatelliteStatus) {
                            par = document.getElementById('popover');
                            angular.element(par).addClass('popoverS');
                            var generalStatus = r.data.generalStatus;
                            $scope.activeAlarms = generalStatus.activeAlarms;
                            $scope.lcdTimeZone = generalStatus.lcdTimeZone;
                            $scope.ref = generalStatus.ref;
                            $scope.systemName = generalStatus.systemName;
                            $scope.systemStatus = generalStatus.systemStatus;
                            if (generalStatus.systemUptime.replace('days', '天')) {
                                var systemUptime = generalStatus.systemUptime.replace('days', '天');
                            }
                            if (generalStatus.systemUptime.replace('hrs', '小时')) {
                                systemUptime = systemUptime.replace('hrs', '小时');
                            }
                            if (generalStatus.systemUptime.replace('mins', '分钟')) {
                                $scope.systemUptime = systemUptime.replace('mins', '分钟');
                            }
                            $scope.flag = "NS7200"; //切换标识、
                            $scope.gnssMod = 'gnss1';
                            $timeout(function() {
                                var data1 = r.data.gssSatelliteStatus,
                                    data2 = r.data.gpsSatelliteStatus;
                                new iChart.Column2D({
                                    render: 'canvasNsGnss1',
                                    data: data2,
                                    title: 'GNSS1 SNR ',
                                    // showpercent:true,
                                    decimalsnum: 2,
                                    width: 920,
                                    height: 295,
                                    column_width: 40,
                                    coordinate: {
                                        background_color: '#fefefe',
                                        scale: [{
                                            position: 'left',
                                            // start_scale:0,
                                            // end_scale:40,
                                            // scale_space:8,
                                            listeners: {
                                                parseText: function(t, x, y) {
                                                    return {
                                                        text: t
                                                    }
                                                }
                                            }
                                        }]
                                    }
                                }).draw();

                                new iChart.Column2D({
                                    render: 'canvasNsGnss2',
                                    data: data1,
                                    title: 'GNSS2 SNR',
                                    // showpercent:true,
                                    decimalsnum: 2,
                                    width: 920,
                                    height: 295,
                                    column_width: 40,
                                    coordinate: {
                                        background_color: '#fefefe',
                                        scale: [{
                                            position: 'left',
                                            // start_scale:0,
                                            // end_scale:40,
                                            // scale_space:8,
                                            listeners: {
                                                parseText: function(t, x, y) {
                                                    return {
                                                        text: t
                                                    }
                                                }
                                            }
                                        }]
                                    }
                                }).draw();
                                var par = document.getElementById('popover');
                                angular.element(par).addClass('popoverS');
                            }, 1000);
                        }
                        publicService.loading('end');
                    })
                } else if (sel.deviceType && sel.deviceType === "SM2000" || sel.deviceType === "SM2000_GN" || sel.deviceType === "LF7300") {

                    if(sel.deviceType != "LF7300"){
                    $scope.tuopuAreaId = sel.parentId;
                    var r = sel.children,
                        arr = [],
                        devId = sel.id,
                        devIp = sel.ip;
                    if (r && r.length > 0) {
                        for (var i = 0; i < r.length; i++) {
                            if (r[i].name !== "MainShelf") {
                                arr.push(r[i].nameCn)
                            }
                        }
                    }
                    systemTime()

                    }else{
                     $scope.tuopuAreaId = sel.parentId;
                    var devId = sel.id;
                    }
                        /*右上角接口*/
                    publicService.doRequest("GET", "/nms/spring/deviceConfig/" + devId + "/getGeneralStatus", {}).success(function(r) {

                        if(sel.deviceType === "LF7300"){
                                $scope.flag = "LF7300"; //切换标识、
                            var m1 = r.data.generalStatus;
                            $scope.systemName = m1.systemName;
                            $scope.ref = m1.ref;
                            $scope.systemUptime = m1.systemUptime;
                            $scope.clockStatus = m1.clockStatus;
                            $scope.activeAlarms = m1.activeAlarms;
                            $scope.warmupStatus = m1.warmupStatus;
                            systemTime();
                                        $timeout(function() {
                            new iChart.Column2D({
                                render: 'canvasNsLF7300',
                                data: r.data.gssSatelliteStatus,
                                title: r.data.type+'(%)',
                                // showpercent:true,
                                decimalsnum: 2,
                                width: 1100,
                                height: 295,
                                column_width: 40,
                                coordinate: {
                                    background_color: '#fefefe',
                                    scale: [{
                                        position: 'left',
                                        listeners: {
                                            parseText: function(t, x, y) {
                                                return {
                                                    text: t
                                                }
                                            }
                                        }
                                    }]
                                }
                            }).draw();
                            var par = document.getElementById('popover');
                            angular.element(par).addClass('popoverS');
                        }, 1000);
                        }else{
                        if (r.data && r.data.ccStateTable && r.data.generalStatusNoTrap) {
                            var m1 = r.data.generalStatusNoTrap[0];
                            $scope.systemName = m1.systemName;
                            $scope.refMode = m1.refMode;
                            $scope.refInput = m1.refInput;
                            $scope.clockStatus = m1.clockStatus;
                            $scope.ccstate1 = r.data.generalStatusNoTrap && r.data.generalStatusNoTrap.length > 0 && r.data.generalStatusNoTrap[0].cc1State === 'card not present' ? "card not present" : devicecc12(r.data.ccStateTable["0"].ccState);
                            $scope.ccstate2 = r.data.generalStatusNoTrap && r.data.generalStatusNoTrap.length > 0 && r.data.generalStatusNoTrap[0].cc2State === 'card not present' ? "card not present" : devicecc12(r.data.ccStateTable["1"].ccState);
                            $scope.activeAlarms = m1.activeAlarms;

                            $scope.flag = sel.flag; //切换标识、

                            $timeout(function() { //加载拓扑机框图
                                loadTopoData(arr);
                                $scope.expS = true;
                                $scope.cpuMenS = false;
                                if (sel.deviceType == "SM2000") {
                                    loadframesParams();
                                } else  if (sel.deviceType == "SM2000_GN") {
                                    loadframesParamsgn();
                                }

                            }, 100);

                            loadframes(0); //左下角数据加载
                        }
                        }
                        publicService.loading('end');


                    })

                    function devicecc12(s) {
                        switch (s) {
                            case '0':
                                return 'active';
                            case '1':
                                return 'standby';
                            case '2':
                                return 'active-warmup';
                            case '3':
                                return 'standby-warmup';
                            case '4':
                                return 'failed';
                            case '5':
                                return 'disabled';
                            default:
                                return s;

                        }
                    }
                    /*左下角接口*/
                    $scope.framesChange = function(x) {
                        loadframes(x);
                    }

                    function loadframes(x) {
                        publicService.doRequest("GET", "/nms/spring/deviceConfig/" + devId + "/getIoStatus", {
                            shelfIndex: x
                        }).success(function(r) {
                            $scope.frameInfoList = r.data;
                        })
                    }
                    publicService.doRequest("GET", 112, {
                            page: "",
                            pageSize: 200,
                            name: "",
                            ip: devIp,
                            deviceStatus: "",
                            areaId: "",
                            deviceType: ""
                        }).success(function(r) {
                            if (r.data !== null && r.data.content && r.data.content.length > 0) {
                                var arr = [];
                                var rr = r.data.content[0].shelfList;
                                for (var i = 0; i < rr.length; i++) {
                                    if (rr[i].status === 1) {
                                        arr.push({
                                            v: rr[i].shelfIndex,
                                            t: rr[i].nameCn
                                        })
                                    }
                                }
                                $scope.macFrameList = arr;
                                $scope.actAlarmFrameM = "0";
                            }
                        })
                        /*右下角接口*/
                    $scope.resourceParamsChange = function(x) {
                        if (sel.deviceType == "SM2000" || sel.deviceType === "SM2000_GN") {
                            if (x == 0) {
                                $scope.expS = true;
                                $scope.cpuMenS = false;
                                if (sel.deviceType == "SM2000") {
                                    loadframesParams();
                                } else {
                                    loadframesParamsgn();
                                }
                            } else if (x == 1) {
                                $scope.expS = false;
                                $scope.cpuMenS = true;
                                loadResourceParams();
                            }
                        }
                    }

                    function loadResourceParams() {
                        if (sel.deviceType == "SM2000" || sel.deviceType === "SM2000_GN") {
                            $scope.expS = false;
                            $scope.cpuMenS = true;
                            var obj = 'resourceParams';
                            publicService.doRequest("GET", "/nms/spring/deviceConfig/" + devId + "/configs/" + obj + "", {}).success(function(r) {
                                if (r.data !== null && r.data && r.data.length > 0) {
                                    $scope.cpuMenList = r.data;
                                }
                                var par = document.getElementById('popover');
                                angular.element(par).addClass('popoverS');
                            })
                        } else {
                            $scope.cpuMenList = '';
                            var par = document.getElementById('popover');
                            angular.element(par).addClass('popoverS');
                        }
                    }

                    function loadframesParams() {
                        $scope.resourceParams = '0';
                        var obj = [{
                            "node": "cc1State",
                            "index": "",
                            "num": ""
                        }, {
                            "node": "cc2State",
                            "index": "",
                            "num": ""
                        }]

                        publicService.doRequest("POST", "/nms/spring/deviceConfig/" + devId + "/getDeviceParamColl", obj).success(function(r) {
                            var obj = JSON.parse(r.data);
                            var sum = 0;
                            if (obj.cc1State != "card not present") sum++;
                            if (obj.cc2State != "card not present") sum++;

                            publicService.doRequest("GET", "/nms/spring/deviceConfig/" + devId + "/configs/ioStatusTable", {}).success(function(r) {

                                var data = r.data;
                                var ma = 0,
                                    k1a = 0,
                                    k2a = 0,
                                    k3a = 0,
                                    k4a = 0;
                                for (var i = 0; i < data.length; i++) {
                                    if (data[i].ioStatusIndex == 0) {
                                        if (data[i].ioSignal != '--') ma++
                                    }
                                    if (data[i].ioStatusIndex == 1) {
                                        if (data[i].ioSignal != '--') k1a++
                                    }
                                    if (data[i].ioStatusIndex == 2) {
                                        if (data[i].ioSignal != '--') k2a++
                                    }
                                    if (data[i].ioStatusIndex == 3) {
                                        if (data[i].ioSignal != '--') k3a++
                                    }
                                    if (data[i].ioStatusIndex == 4) {
                                        if (data[i].ioSignal != '--') k4a++
                                    }
                                }
                                mper = ((ma + sum + 1) / 12).toFixed(2);
                                k1per = (k1a / 14).toFixed(2);
                                k2per = (k2a / 14).toFixed(2);
                                k3per = (k3a / 14).toFixed(2);
                                k4per = (k4a / 14).toFixed(2);
                                $scope.showMainPer = parseInt(mper * 100) + '%';
                                k1per == 0 ? $scope.showExp1Per = 'not used' : $scope.showExp1Per = parseInt(k1per * 100) + '%';
                                k2per == 0 ? $scope.showExp2Per = 'not used' : $scope.showExp2Per = parseInt(k2per * 100) + '%';
                                k3per == 0 ? $scope.showExp3Per = 'not used' : $scope.showExp3Per = parseInt(k3per * 100) + '%';
                                k4per == 0 ? $scope.showExp4Per = 'not used' : $scope.showExp4Per = parseInt(k4per * 100) + '%';

                            })
                        })
                    }

                    function loadframesParamsgn() {
                        $scope.resourceParams = '0';

                        var obj = [{
                            "node": "cc1State",
                            "index": "",
                            "num": ""
                        }, {
                            "node": "cc2State",
                            "index": "",
                            "num": ""
                        }]

                        publicService.doRequest("POST", "/nms/spring/deviceConfig/" + devId + "/getDeviceParamColl", obj).success(function(r) {
                            var obj = JSON.parse(r.data);
                            var sum = 0;
                            if (obj.cc1State != "card not present") sum++;
                            if (obj.cc2State != "card not present") sum++;

                            publicService.doRequest("GET", "/nms/spring/deviceConfig/" + devId + "/configs/ioStatusTable", {}).success(function(r) {

                                var data = r.data;
                                var ma = 0;
                                for (var i = 0; i < data.length; i++) {
                                    if (data[i].ioSignal != '--') ma++
                                }
                                mper = ((ma + sum + 1) / 12).toFixed(2);
                                $scope.showMainPer = parseInt(mper * 100) + '%';
                                $scope.EXPSHELFD = false;
                            })
                        })
                    }
                } else if (sel.deviceType && sel.deviceType === "TS3100" || sel.deviceType === "TS3000G") {
                    $scope.tuopuAreaId = sel.parentId;
                    var devId = sel.id;
                    publicService.doRequest("GET", "/nms/spring/deviceConfig/" + devId + "/getGeneralStatus", {}).success(function(r) {
                        if (r.data) {
                            var gsDate = r.data,
                                tt = gsDate.systemTime,
                                t = (!!window.ActiveXObject || "ActiveXObject" in window) ? tt.replace(/-/g, "/") : tt;
                            $scope.timeInter = new Date(t).getTime();

                            function timef() {
                                $scope.timeInter += 1000;
                                $scope.systemTime = $scope.timeInter;
                                $scope.mactimeF = $timeout(timef, 1000);
                            }
                            if (!$scope.mactimeF) {
                                timef();
                            }
                            if (sel.deviceType === "TS3100") {
                                $scope.alarmNum = gsDate.alarmNum;
                                $scope.systemName = gsDate.systemName;
                                $scope.flag = "ts3100"; //切换标识、
                                $timeout(function() {
                                    var ddd = gsDate.GPStatus;
                                    new iChart.Column2D({
                                        render: 'canvasNsts3100',
                                        data: ddd,
                                        title: 'GPS CNO',
                                        // showpercent:true,
                                        decimalsnum: 2,
                                        width: 920,
                                        height: 295,
                                        column_width: 40,
                                        coordinate: {
                                            background_color: '#fefefe',
                                            scale: [{
                                                position: 'left',
                                                // start_scale:0,
                                                // end_scale:40,
                                                // scale_space:8,
                                                listeners: {
                                                    parseText: function(t, x, y) {
                                                        return {
                                                            text: t
                                                        }
                                                    }
                                                }
                                            }]
                                        }
                                    }).draw();
                                }, 1000);
                            } else {
                                var generalStatus = r.data.generalStatus;
                            $scope.activeAlarms = generalStatus.activeAlarms;
                            $scope.lcdTimeZone = generalStatus.lcdTimeZone;
                            $scope.ref = generalStatus.ref;
                            $scope.systemName = generalStatus.systemName;
                            $scope.systemStatus = generalStatus.systemStatus;
                            if (generalStatus.systemUptime.replace('days', '天')) {
                                var systemUptime = generalStatus.systemUptime.replace('days', '天');
                            }
                            if (generalStatus.systemUptime.replace('hrs', '小时')) {
                                systemUptime = systemUptime.replace('hrs', '小时');
                            }
                            if (generalStatus.systemUptime.replace('mins', '分钟')) {
                                $scope.systemUptime = systemUptime.replace('mins', '分钟');
                            }
                           systemTime();
                                $scope.flag = "TS3000G"; //切换标识、
                                $scope.gnssMod = 'gnss1';
                                $timeout(function() {
                                    var data1 = r.data.gssSatelliteStatus,
                                        data2 = r.data.gpsSatelliteStatus;
                                    new iChart.Column2D({
                                        render: 'canvasNsGnss1',
                                        data: data2,
                                        title: 'GNSS1 SNR ',
                                        // showpercent:true,
                                        decimalsnum: 2,
                                        width: 920,
                                        height: 295,
                                        column_width: 40,
                                        coordinate: {
                                            background_color: '#fefefe',
                                            scale: [{
                                                position: 'left',
                                                // start_scale:0,
                                                // end_scale:40,
                                                // scale_space:8,
                                                listeners: {
                                                    parseText: function(t, x, y) {
                                                        return {
                                                            text: t
                                                        }
                                                    }
                                                }
                                            }]
                                        }
                                    }).draw();

                                    new iChart.Column2D({
                                        render: 'canvasNsGnss2',
                                        data: data1,
                                        title: 'GNSS2 SNR',
                                        // showpercent:true,
                                        decimalsnum: 2,
                                        width: 920,
                                        height: 295,
                                        column_width: 40,
                                        coordinate: {
                                            background_color: '#fefefe',
                                            scale: [{
                                                position: 'left',
                                                // start_scale:0,
                                                // end_scale:40,
                                                // scale_space:8,
                                                listeners: {
                                                    parseText: function(t, x, y) {
                                                        return {
                                                            text: t
                                                        }
                                                    }
                                                }
                                            }]
                                        }
                                    }).draw();
                                    var par = document.getElementById('popover');
                                    angular.element(par).addClass('popoverS');
                                }, 1000);
                            }

                        }
                        publicService.loading('end');
                    })
                } else if (sel.deviceType && sel.deviceType === "STFS1000" || sel.deviceType === "TP1000" || sel.deviceType === "SSU2000") {
                    $scope.tuopuAreaId = sel.parentId;
                    var devId = sel.id;
                    $scope.flag = sel.deviceType;
                    systemTime();


                    publicService.doRequest("GET", "/nms/spring/deviceConfig/" + devId + "/getIoStatus", {
                        shelfIndex: 0
                    }).success(function(r) {
                        $scope.frameInfoList = r.data;
                    })

                    function stfs1000GGRfun(title, data) {
                        $timeout(function() {
                            new iChart.Column2D({
                                render: 'canvas' + sel.deviceType,
                                data: data,
                                title: title + ' (%)',
                                // showpercent:true,
                                decimalsnum: 2,
                                width: 1100,
                                height: 295,
                                column_width: 40,
                                coordinate: {
                                    background_color: '#fefefe',
                                    scale: [{
                                        position: 'left',
                                        listeners: {
                                            parseText: function(t, x, y) {
                                                return {
                                                    text: t
                                                }
                                            }
                                        }
                                    }]
                                }
                            }).draw();
                            var par = document.getElementById('popover');
                            angular.element(par).addClass('popoverS');
                        }, 1000);
                    }

                    function SSU2000GGRfun(title, data) {
                        $timeout(function() {
                            new iChart.Column2D({
                                render: 'canvas' + sel.deviceType,
                                data: data,
                                title: title + ' (%)',
                                // showpercent:true,
                                decimalsnum: 2,
                                width: 597,
                                height: 262,
                                column_width: 40,
                                coordinate: {
                                    background_color: '#fefefe',
                                    scale: [{
                                        position: 'left',
                                        listeners: {
                                            parseText: function(t, x, y) {
                                                return {
                                                    text: t
                                                }
                                            }
                                        }
                                    }]
                                }
                            }).draw();
                            var par = document.getElementById('popover');
                            angular.element(par).addClass('popoverS');
                        }, 1000);
                    }
                    if (sel.deviceType === "STFS1000") {
                        $scope.stfs1000module = "GGR-1";
                        publicService.doRequest("GET", "/nms/spring/deviceConfig/" + devId + "/getGeneralStatus", {}).success(function(r) {
                            if (r.data && r.data.GPStatus) {

                                publicService.loading('end');
                                $scope.systemName = r.data.systemName;
                                $scope.alarmNum = r.data.alarmNum;
                                $scope.refInput = r.data.refInput;
                                var GGR_Aars = r.data.GPStatus;
                                for (var i = 0; i < GGR_Aars.length; i++) {
                                    if (GGR_Aars[i].aid === "GGR-1") {
                                        $scope.GGR_1_List = GGR_Aars[i].starInfo || [];
                                    } else if (GGR_Aars[i].aid === "GGR-2") {
                                        $scope.GGR_2_List = GGR_Aars[i].starInfo || [];
                                    }
                                }
                                $scope.stfs1000Change("GGR-1", $scope.GGR_1_List);
                            }
                        })
                    } else if (sel.deviceType === "TP1000") {

                        $scope.stfs1000module = "tp1000";
                        publicService.doRequest("GET", "/nms/spring/deviceConfig/" + devId + "/getGeneralStatus", {}).success(function(r) {
                            if (r.data) {
                                publicService.loading('end');
                                $scope.systemName = r.data.systemName;
                                $scope.alarmNum = r.data.alarmNum;
                                $scope.refInput = r.data.refInput;
                                $scope.refmode = r.data.refmode;
                                $scope.syncmode = r.data.syncmode;
                            }
                        })
                    } else if (sel.deviceType === "SSU2000") {

                        $scope.stfs1000module = "SSU2000";
                        publicService.doRequest("GET", "/nms/spring/deviceConfig/" + devId + "/getGeneralStatus", {}).success(function(r) {
                            if (r.data) {
                                publicService.loading('end');
                                var data = r.data.generalStatusNoTrap[0];
                                $scope.systemName = data.systemName;
                                $scope.mcTime = data.mcTime;
                                $scope.cc1State = data.cc1State;
                                $scope.cc2State = data.cc2State;
                                $scope.refInput = data.refInput;
                                $scope.clockStatus = data.clockStatus;
                                $scope.activeAlarms = data.activeAlarms;
                                var GGR_Aars = r.data.GPStatus;
                                var arr = [];
                                for (var i = 0; i < GGR_Aars.length; i++) {
                                    if (GGR_Aars[i].starInfo) {
                                        var obj = GGR_Aars[i].starInfo
                                        arr.push(obj[0])
                                    }
                                }
                                SSU2000GGRfun("GPS tatus", arr);
                            }
                        })
                    }
                    $scope.stfs1000Change = function(m) {
                        if (m === "GGR-1") {
                            stfs1000GGRfun("GGR-1", $scope.GGR_1_List);
                        } else if (m === "GGR-2") {
                            stfs1000GGRfun("GGR-2", $scope.GGR_2_List);
                        }
                    }

                } else if (sel.deviceType && sel.deviceType === "HP55400" || sel.deviceType === "SYNLOCK") {
                    $scope.tuopuAreaId = sel.parentId;
                    var devId = sel.id;
                    $scope.flag = sel.deviceType;
                    systemTime();
                    publicService.doRequest("GET", "/nms/spring/deviceConfig/" + devId + "/getGeneralStatus", {}).success(function(r) {
                        if (r.data) {
                            if (sel.deviceType == "SYNLOCK") {
                                $scope.deviceType = r.data.deviceType;
                                $scope.cc1State = r.data.cc1State;
                                $scope.cc2State = r.data.cc2State;
                                $scope.inprefState = r.data.inprefState;
                                $scope.refMode = r.data.refMode;
                                $scope.ccStatus = r.data.ccStatus;
                                $scope.systemTime = r.data.systemTime;
                                $scope.alarmNum = r.data.activeAlarms;
                            } else {
                                $scope.systemName = r.data.systemName;
                                $scope.refMode = r.data.refMode;
                                $scope.ref = r.data.ref;
                                $scope.ccState = r.data.ccState;
                                $scope.cc1State = r.data.cc1State;
                                $scope.cc2State = r.data.cc2State;
                                $scope.alarmNum = r.data.alarmNum;

                            }
                        }
                    })
                }

            } else {
                var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
                publicService.ngAlert(tt, "info");
                var par = document.getElementById('popover');
                angular.element(par).addClass('popoverS');
                return;
            }

        }
        if (sel.flag === null && sel.deviceType && sel.deviceType !== "NS7200") {

            if (sel.deviceStatus !== 0) {
                document.getElementById("alarms_canvas").style.height = "0%";
                document.getElementById("alarms_canvas").style.border = "none";
                publicService.loading('start');
                $scope.curDevId = sel.parentId,
                    $scope.deviceType = sel.deviceType,
                    $scope.shelfind = sel.shelfIndex; //上报传值
                $scope.DEVICE_CUR_TYPE = sel.deviceType;
                frameListFun($scope.curDevId, sel.shelfIndex, $scope.deviceType); //切入机框
            } else {
                var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
                publicService.ngAlert(tt, "info");
                return;
            }
        }
        //$scope.flag = sel.flag;//切换标识
    };

    function frameListFun(dev, shelfIndex, deviceType) {
        if (dev == undefined) return
        publicService.doRequest("GET", "/nms/spring/deviceConfig/" + dev + "/getCardLed", {
            shelfIndex: shelfIndex
        }).success(function(r) {
            publicService.loading('end');
            if (r.data.length > 0) {
                $scope.frameList = r.data;
                $scope.deviceType = deviceType;
                r.data.length === 12 ? $scope.deviceFrameFlag = true : $scope.deviceFrameFlag = false;
                if (deviceType == 'TP1000') {
                    $scope.deviceTypeMain = 'TP1000';
                } else if (deviceType == 'HP55400') {
                    $scope.deviceTypeMain = 'HP55400';
                } else if (deviceType == 'TS3000G') {
                    $scope.deviceTypeMain = 'TS3000G';
                } else if (deviceType == 'SSU2000') {
                    $scope.deviceTypeMain = 'SSU2000';
                } else if (deviceType == 'LF7300') {
                    $scope.deviceTypeMain = 'LF7300';
                }else {
                    $scope.deviceTypeMain = false
                }
                $scope.flag = "shil"; //切换标识
                document.getElementById("alarms_canvas").style.height = "0%";
                document.getElementById("alarms_canvas").style.border = "none"; //隐藏拓扑图的历史告警
            }

        })
    }

    function macFramefun(m) {
        var index = 0;
        if (m === "MainShelf") {
            index = 0;
        } else if (m === "ExpShelf1") {
            index = 1;
        } else if (m === "ExpShelf2") {
            index = 2;
        } else if (m === "ExpShelf3") {
            index = 3;
        } else if (m === "ExpShelf4") {
            index = 4;
        }
        return index;
    }


    function jsPlumbas(scope, service, ngDialog, flag, $translate, webTargetId) {
        var instance = window.jsp = jsPlumb.getInstance({
            DragOptions: {
                cursor: 'pointer',
                zIndex: 2000
            },
            ConnectionOverlays: [
                ["Arrow", {
                    location: 1,
                    height: 5,
                    width: 5
                }],
                ["Label", {
                    location: 0.5,
                    id: "label",
                    cssClass: "aLabel"
                }]
            ],
            Container: "canvas"
        });
        var mos = document.querySelectorAll(".jsplumb-endpoint.jsplumb-endpoint-anchor,.jsplumb-overlay,svg");
        for (var i = 0; i < mos.length; i++) {
            var _p = mos[i].parentNode;
            if (_p) {
                _p.removeChild(mos[i]);
            }
        }
        var basicType = {
            connector: "StateMachine",
            paintStyle: {
                strokeStyle: "white" /*, lineWidth: 1*/
            },
            hoverPaintStyle: {
                strokeStyle: "white"
            },
            overlays: [
                "Arrow"
            ]
        };
        instance.registerConnectionType("basic", basicType);
        var connectorPaintStyle = {
                lineWidth: 1,
                strokeStyle: "#2cd440",
                joinstyle: "round",
                outlineColor: "#2cd440",
                outlineWidth: 2
            },
            connectorPaintStyle2 = { //绿色
                lineWidth: 1,
                strokeStyle: "#2cd440", //绿色
                joinstyle: "round",
                outlineColor: "#2cd440",
                outlineWidth: 2,
                dashstyle: "3 4", //分段显示4是每段长度 1是段与段之间的长度
            },
            connectorPaintStyle3 = { //红色
                lineWidth: 1,
                strokeStyle: "#ec2525", //红色
                joinstyle: "round",
                outlineColor: "#ec2525",
                outlineWidth: 2,
                dashstyle: "3 4", //分段显示4是每段长度 1是段与段之间的长度
            },
            connectorHoverStyle = {
                lineWidth: 4,
                strokeStyle: "#2cd440",
                outlineWidth: 2,
                outlineColor: "#2cd440"
            },
            connectorHoverStyle2 = {
                lineWidth: 4,
                strokeStyle: "#ec2525",
                outlineWidth: 2,
                outlineColor: "#ec2525"
            },
            endpointHoverStyle = {
                fillStyle: "#2cd440",
                strokeStyle: "#2cd440"
            },
            endpointHoverStyle2 = {
                fillStyle: "#ec2525",
                strokeStyle: "#ec2525"
            },
            sourceEndpoint = {
                endpoint: "Dot",
                paintStyle: {
                    strokeStyle: "#fff",
                    fillStyle: "transparent",
                    radius: 3,
                    lineWidth: 1
                },
                isSource: true,
                maxConnections: 200,
                dragOptions: {},
                overlays: [
                    ["Label", {
                        location: [0.5, 1.5],
                        label: "",
                        cssClass: "endpointSourceLabel"
                    }]
                ]
            },
            targetEndpoint = { //绿色
                endpoint: "Dot",
                paintStyle: {
                    fillStyle: "#fff",
                    radius: 3 //实心圆点大小
                },
                connector: ["Flowchart", {
                    stub: [40, 60],
                    gap: 10,
                    cornerRadius: 1,
                    alwaysRespectStubs: true
                }],
                connector: ["StateMachine", {}],
                maxConnections: 200,
                dropOptions: {
                    hoverClass: "hover",
                    activeClass: "active"
                },
                isTarget: true,
                overlays: [
                    ["Label", {
                        location: [0.5, -0.5],
                        label: "",
                        cssClass: "endpointTargetLabel"
                    }]
                ]
            },
            targetEndpoint2 = { //绿色虚线
                endpoint: "Dot",
                paintStyle: {
                    fillStyle: "#fff",
                    radius: 3 //实心圆点大小
                },
                connector: ["Flowchart", {
                    stub: [40, 60],
                    gap: 10,
                    cornerRadius: 1,
                    alwaysRespectStubs: true
                }],
                connector: ["StateMachine", {}],
                connectorStyle: connectorPaintStyle2,
                hoverPaintStyle: endpointHoverStyle,
                connectorHoverStyle: connectorHoverStyle,
                maxConnections: 200,
                dropOptions: {
                    hoverClass: "hover",
                    activeClass: "active"
                },
                isTarget: true,
                overlays: [
                    ["Label", {
                        location: [0.5, -0.5],
                        label: "",
                        cssClass: "endpointTargetLabel"
                    }]
                ]
            },
            targetEndpoint3 = { //红色虚线
                endpoint: "Dot",
                paintStyle: {
                    fillStyle: "#fff",
                    radius: 3 //实心圆点大小
                },
                connector: ["Flowchart", {
                    stub: [40, 60],
                    gap: 10,
                    cornerRadius: 1,
                    alwaysRespectStubs: true
                }],
                connector: ["StateMachine", {}],
                connectorStyle: connectorPaintStyle3,
                hoverPaintStyle: endpointHoverStyle2,
                connectorHoverStyle: connectorHoverStyle2,
                maxConnections: 200,
                dropOptions: {
                    hoverClass: "hover",
                    activeClass: "active"
                },
                isTarget: true,
                overlays: [
                    ["Label", {
                        location: [0.5, -0.5],
                        label: "",
                        cssClass: "endpointTargetLabel"
                    }]
                ]
            },
            init = function(connection) {
                // connection.getOverlay("label").setLabel(connection.sourceId + "-->" + connection.targetId);
            };
        var _addEndpoints = function(toId) { //绿色
            var sourceUUID = toId + "Center";
            instance.addEndpoint(toId, {
                anchor: "Center",
                uuid: sourceUUID
            }, sourceEndpoint);


            var targetUUID = toId + "TopCenter";
            instance.addEndpoint(toId, {
                anchor: "TopCenter",
                uuid: targetUUID
            }, targetEndpoint);
        };
        var _addEndpoints2 = function(toId) { //绿色虚线
            var sourceUUID = toId + "Center";
            instance.addEndpoint(toId, {
                anchor: "Center",
                uuid: sourceUUID
            }, sourceEndpoint);


            var targetUUID = toId + "TopCenter";
            instance.addEndpoint(toId, {
                anchor: "TopCenter",
                uuid: targetUUID
            }, targetEndpoint2);
        };
        var _addEndpoints3 = function(toId) { //红色虚线
            var sourceUUID = toId + "Center";
            instance.addEndpoint(toId, {
                anchor: "Center",
                uuid: sourceUUID
            }, sourceEndpoint);


            var targetUUID = toId + "TopCenter";
            instance.addEndpoint(toId, {
                anchor: "TopCenter",
                uuid: targetUUID
            }, targetEndpoint3);
        };
        instance.batch(function() {
            if (webTargetId) { //上报
                var slotAndport = webTargetId.activeAlarmDesc.split(/\s/)[0];
                var slotAndstate = webTargetId.state;
                var _tuopoData = $scope.getTopuLineData;

                for (var j = 0; j < _tuopoData.length; j++) {
                    var ref = _tuopoData[j].ref;
                    if (_tuopoData[j].ip === webTargetId.device.ip && ref === slotAndport) {
                        if (slotAndstate == 0 || slotAndstate == 3) {
                            _tuopoData[j].value = 1;
                        } else {
                            _tuopoData[j].value = 3;
                        }
                    }
                }
                $scope.getTopuLineData = _tuopoData;

            } else {
                var _tuopoData = scope.tuopoData.data;
                var getTopuLineByRef = [];
                var getTopuLineData = '';
                for (var j = 0; j < scope.tuopu.length; j++) {
                    var ipadr = scope.tuopu[j]["ip"]; //拓扑图IP
                    if (_tuopoData == undefined || _tuopoData[ipadr] == undefined) { //VIEWDATA数据
                        continue
                    } else {
                        if (_tuopoData[ipadr]["targetIds"] && _tuopoData[ipadr]["targetIds"].length > 0) {
                            var oso = _tuopoData[ipadr]["targetIds"];

                            for (var q = 0; q < oso.length; q++) {
                                var obj = {};
                                obj.sip = ipadr;
                                obj.ip = oso[q].ip;
                                obj.ref = "Slot" + oso[q].slot + "-" + oso[q].port;
                                getTopuLineByRef.push(obj);
                            }
                        }
                    }
                }
                $.ajax({
                    method: "POST",
                    url: "/nms/spring/deviceConfig/getTopuLineByRef?token=" + $rootScope.curLoginMsg.sessionID,
                    data: JSON.stringify(getTopuLineByRef),
                    dataType: 'json',
                    contentType: "application/json;charset=UTF-8",
                    async: false,
                    success: function(r) {
                        $scope.getTopuLineData = r.data;
                    }

                });
            }

            for (var i = 0; i < scope.tuopu.length; i++) {
                var ipadr = scope.tuopu[i]["ip"];
                _addEndpoints(ipadr, ["Center"], ["TopCenter"]);
            }


            instance.bind("connection", function(connInfo, e) {
                for (var i = 0; i < $scope.getTopuLineData.length; i++) {
                    if (connInfo.targetId == $scope.getTopuLineData[i].ip && connInfo.sourceId == $scope.getTopuLineData[i].sip) {
                        if ($scope.getTopuLineData[i].value == 0) {
                            connInfo.connection.setPaintStyle({
                                lineWidth: 1,
                                strokeStyle: "#07861b", //绿色
                                joinstyle: "round",
                                outlineColor: "#07861b",
                                outlineWidth: 2,
                            });

                        } else if ($scope.getTopuLineData[i].value == 1) {

                            connInfo.connection.setPaintStyle({
                                lineWidth: 1,
                                strokeStyle: "#07861b", //绿色
                                joinstyle: "round",
                                outlineColor: "#07861b",
                                outlineWidth: 2,
                            });

                        } else if ($scope.getTopuLineData[i].value == 2) {
                            connInfo.connection.setPaintStyle({
                                lineWidth: 1,
                                strokeStyle: "#07861b", //绿色虚
                                joinstyle: "round",
                                outlineColor: "#07861b",
                                outlineWidth: 2,
                                dashstyle: "3 4",
                            });

                        } else if ($scope.getTopuLineData[i].value == 3) {
                            connInfo.connection.setPaintStyle({
                                lineWidth: 1,
                                strokeStyle: "#ec2525", //红色虚
                                joinstyle: "round",
                                outlineColor: "#ec2525",
                                outlineWidth: 2,
                                dashstyle: "3 4",
                            });
                            /* connInfo.connection.id= getTopuLineData[i].ip+getTopuLineData[i].sip;*/
                        }
                    }
                }
                /*  connInfo.connection.getOverlay("label").setLabel('输出');*/
            })



            if (scope && scope.tuopoData && scope.tuopoData.data) {
                var r = scope.tuopoData.data;
                for (var s in r) {
                    if (!flag && r[s]["possion"]) {
                        var dom = document.getElementById(s);
                        if (dom) {
                            r[s]["possion"]["left"] && (dom.style.left = r[s]["possion"]["left"]);
                            r[s]["possion"]["top"] && (dom.style.top = r[s]["possion"]["top"]);
                        }
                    }
                    if (r[s]["targetIds"]) {
                        var s = tuopoz(s, arrayObjs(r[s].targetIds));
                        line(s);
                    }
                }
            }
            if (flag) {
                if (!scope.tuopoData.data) scope.tuopoData.data = {};
                var ooj = scope.tuopoData.data,
                    tp = scope.tuopu,
                    _l = 0,
                    _h = 150;
                if (tp.length > 0) {
                    for (var i = 0; i < tp.length; i++) {
                        _l = _l + 160;
                        document.getElementById(tp[i].ip).style.left = _l + "px";
                        document.getElementById(tp[i].ip).style.top = _h + "px";

                        if (!ooj[tp[i].ip]) ooj[tp[i].ip] = {};
                        if (!ooj[tp[i].ip]["possion"]) ooj[tp[i].ip]["possion"] = {};
                        ooj[tp[i].ip]["possion"]["left"] = _l + "px";
                        ooj[tp[i].ip]["possion"]["top"] = _h + "px";
                        if ((i + 1) % 4 === 0) {
                            _l = 0;
                            _h = _h + 90;
                        }
                    }
                }
                scope.tuopoData.data = JSON.stringify(ooj);
                if (!scope.tuopoData.id) {
                    scope.tuopoData.areaId = scope.tuopuAreaId;
                    scope.tuopoData.userid = localStorage.getItem("curUserId") || "";
                }
                service.doRequest("POST", 5, scope.tuopoData).success(function() {
                    scope.tuopoData.data = JSON.parse(scope.tuopoData.data)
                })
            }

            function _ip2int(ip) {
                var num = 0;
                ip = ip.split(".");
                num = Number(ip[0]) * 256 * 256 * 256 + Number(ip[1]) * 256 * 256 + Number(ip[2]) * 256 + Number(ip[3]);
                num = num >>> 0;
                return num;
            }

            function arrayObjs(arr) {
                var _a = [];
                if (arr.length > 0) {
                    for (var i = 0; i < arr.length; i++) {
                        _a.push(arr[i].ip);
                    }
                }
                return _a.join(',');
            }

            function tuopoz(s, t) {
                var arr = [],
                    ss = t.split(",")
                for (var i = 0; i < ss.length; i++) {
                    arr.push(s + ',' + ss[i])
                }
                return arr;
            }

            function line(arr) {
                for (var i = 0; i < arr.length; i++) {
                    var j = arr[i].split(",");
                    instance.connect({
                        uuids: [j[0] + "Center", j[1] + "TopCenter"],
                        editable: true
                    });
                }
            }

            instance.bind("connection", function(connInfo, originalEvent) {
                // init(connInfo.connection);
                connInfo.connection.getOverlay("label").show();
                /*   addLineEvent(instance, scope.tuopoData)*/
            });

            instance.draggable(jsPlumb.getSelector(".flowchart-demo .window"), {
                grid: [10, 10]
            });
            instance.bind("mousedown", function(conn, originalEvent) {
                r = scope.tuopoData.data;
                var o = r[conn.sourceId].targetIds;
                console.log(o)
                if (o) {
                    for (var j = 0; j < o.length; j++) {
                        if (conn.targetId === o[j].ip) {
                            var topo_tip = $("#topo_tip3");
                            var solt = "Slot" + o[j].slot + "-" + o[j].port;
                            $("#SCslot").text(o[j]._slot);
                            $("#SCport").text(o[j]._port);
                            $("#SRslot").text(o[j].slot);
                            $("#SRport").text(o[j].port);
                            topo_tip.css({
                                top: event.pageY,
                                left: event.pageX + 15
                            }).show(function() {
                                $scope.getAlarmLineData(solt);
                            });
                        }
                    }
                }
                $scope.getAlarmLineData = function(x) {
                    var obj = {
                        ip: conn.targetId
                    };
                    var objdata = [];
                    publicService.doRequest("GET", "/nms/spring/alarm/activeAlarm/getAlarmLine", obj).success(function(r) {
                        if (r.data !== null && r.data && r.data.length > 0) {
                            var data = r.data;
                            for (var j = 0; j < data.length; j++) {
                                if (data[j].activeAlarmDesc.indexOf(x) > -1) {
                                    var obj = {};
                                    obj.activeAlarmDesc = data[j].activeAlarmDesc;
                                    objdata.push(obj);
                                }
                            }
                            $scope.alarmsList = objdata;
                            return
                        } else {
                            $scope.alarmsList = '';
                        }
                    })
                }

                $scope.delline = function(x) {
                    if ($rootScope.curLoginMsg.roleList[0].roleDesc != '管理级') {
                        publicService.ngAlert('没有权限', "info")
                        return
                    }
                    if (conn.sourceId && conn.targetId) {
                        t = $translate.use() === "ch" ? "确认删除" + conn.sourceId + "至" + conn.targetId + "的信号线?" : "confirm delete " + conn.sourceId + " to " + conn.targetId + "line?";
                        if (confirm(t)) {
                            deleteLine(scope, conn, service)
                            instance.detach(conn);
                            var topo_tip3 = $("#topo_tip3");
                            topo_tip3.hide();
                        }
                    }
                }
            });


            instance.bind("connectionDrag", function(connection) {
                if (connection.targetId.indexOf("jsPlumb") === -1) {
                    //deleteLine(connection)
                }
                console.log("connection " + connection.id + " is being dragged. suspendedElement is ", connection.suspendedElement, " of type ", connection.suspendedElementType);
            });
            instance.bind("connectionDragStop", function(connection) {
                if (connection.targetId.indexOf("jsPlumb") > -1) {
                    return;
                }
                if (connection.target === null) {
                    deleteLine(scope, connection, service);
                    return;
                }
                scope.connection = connection;
                ngDialog.open({
                    template: "template/dialog/newTuopuDialog.html",
                    className: 'ngdialog-theme-default ngdialog-theme-custom',
                    scope: scope,
                    controller: function($scope, publicService) {
                        $scope.subPs = function(oos) {
                            if (!oos || !oos.slot) {
                                var tt = $translate.use() === 'ch' ? 　"输入槽位不能为空！" : "Slot cannot be empty！";
                                publicService.ngAlert(tt, "info");
                                return;
                            }
                            if (oos.port === "") {
                                var tt = $translate.use() === 'ch' ? 　"输入端口不能为空！" : "Port cannot be empty！";
                                publicService.ngAlert(tt, "info");
                                return;
                            }
                            if (!oos || !oos._slot) {
                                var tt = $translate.use() === 'ch' ? 　"输出槽位不能为空！" : "Slot cannot be empty！";
                                publicService.ngAlert(tt, "info");
                                return;
                            }
                            if (oos._port === "") {
                                var tt = $translate.use() === 'ch' ? 　"输出端口不能为空！" : "Port cannot be empty！";
                                publicService.ngAlert(tt, "info");
                                return;
                            }
                            scope.dialogClose = true;
                            ngDialog.close('ngdialog1');

                            var areaId = $scope.tuopuAreaId,
                                userid = localStorage.getItem("curUserId") || "";
                            targetId = scope.connection.targetId,
                                sourceId = scope.connection.sourceId,
                                res = scope.tuopoData;
                            if (res) {
                                o1 = res.data;
                                if (o1[sourceId]) {
                                    if (o1[sourceId].targetIds && o1[sourceId].targetIds.length > 0) {
                                        var _ars = o1[sourceId].targetIds,
                                            ja = [];
                                        for (var i = 0; i < _ars.length; i++) {
                                            ja.push(_ars[i].ip);
                                        }
                                        if (ja.indexOf(targetId) !== -1) return;
                                        o1[sourceId].targetIds.push({
                                            port: oos.port,
                                            slot: oos.slot,
                                            _port: oos._port,
                                            _slot: oos._slot,
                                            ip: targetId
                                        });
                                    } else {
                                        var f = o1[sourceId].targetIds instanceof Array;
                                        !f && (o1[sourceId].targetIds = []);
                                        o1[sourceId].targetIds.push({
                                            port: oos.port,
                                            slot: oos.slot,
                                            _port: oos._port,
                                            _slot: oos._slot,
                                            ip: targetId
                                        });
                                    }
                                } else {
                                    o1[sourceId] = {};
                                    o1[sourceId].targetIds = [];
                                    o1[sourceId].targetIds.push({
                                        port: oos.port,
                                        slot: oos.slot,
                                        _port: oos._port,
                                        _slot: oos._slot,
                                        ip: targetId
                                    })
                                }
                            } else {
                                res.data = {};
                                res.data[sourceId] = {};
                                res.data[sourceId].targetIds = [];
                                res.data[sourceId].targetIds.push({
                                    port: oos.port,
                                    slot: oos.slot,
                                    _port: oos._port,
                                    _slot: oos._slot,
                                    ip: targetId
                                });

                            }
                            res.data = JSON.stringify(res.data);
                            publicService.doRequest("POST", 5, scope.tuopoData).success(function() {
                                scope.tuopoData.data = JSON.parse(scope.tuopoData.data)
                                $scope.loadLeftTree2();
                            })
                        }
                    },
                    preCloseCallback: function($scope) {
                        if (!scope.dialogClose) {
                            instance.detach(connection);
                            scope.dialogClose = false;
                        }
                    }
                });
            });

            instance.bind("connectionMoved", function(params) {
                console.log("connection " + params.connection.id + " was moved");
            });


            // var _t_links = instance.getConnections();
            // for (var i = 0; i < _t_links.length; i++) {
            //     _t_links[i].unbind("mouseover").bind("mouseover", function(connInfo, originalEvent) {

            //     });
            //     _t_links[i].unbind("mouseout").bind("mouseout", function(connInfo, originalEvent) {
            //           console.log(2)
            //     });
            // }
            addLineEvent(instance, scope.tuopoData)

        });
        jsPlumb.fire("jsPlumbDemoLoaded", instance);
        scope.instance = instance;
    };

    function deleteLine(scope, connection, service) {
        if ($rootScope.curLoginMsg.roleList[0].roleDesc != '管理级') {
            publicService.ngAlert('没有权限', "info")
            return
        }
        var areaId = scope.tuopuAreaId,
            userid = localStorage.getItem("curUserId") || "";
        targetId = connection.targetId,
            sourceId = connection.sourceId,
            res = scope.tuopoData;
        if (res.data[sourceId].targetIds.length > 0) {
            var t = res.data[sourceId].targetIds;
            for (var i = 0; i < t.length; i++) {
                if (connection.targetId === t[i].ip) {
                    t.splice(i, 1);
                }
            }
        }
        res.data = JSON.stringify(res.data)
        service.doRequest("POST", 5, scope.tuopoData).success(function() {
            scope.tuopoData.data = JSON.parse(scope.tuopoData.data)
        })
    }

    function addLineEvent(instance, data) {
        var _t_links = instance.getConnections(),
            r = data.data;
        for (var i = 0; i < _t_links.length; i++) {
            /*        _t_links[i].getOverlay("label").hide();
                    _t_links[i].unbind("mouseover").bind("mouseover", function(connInfo, originalEvent) {
                        var o = r[connInfo.sourceId].targetIds;
                        console.log(o)
                        if (o) {
                            for (var j = 0; j < o.length; j++) {
                                if (connInfo.targetId === o[j].ip) {
                                    connInfo.getOverlay("label").show();
                                    connInfo.getOverlay("label").setLabel('输出: slot' + o[j]._slot + "-port" + o[j]._port + '-->' + '输入: slot' + o[j].slot + "-port" + o[j].port);
                                }
                            }
                        }
                    });
                    _t_links[i].unbind("mouseout").bind("mouseout", function(connInfo, originalEvent) {
                        connInfo.getOverlay("label").hide();
                    });*/
        }
    }

    function loadAlarms(id) {
        var obj = {
            page: 1,
            pageSize: 250,
            activeAlarmSource: "",
            activeAlarmLevel: "",
            activeAlarmReason: "",
            activeAlarmId: "",
            activeAlarmtimeBgn: "",
            activeAlarmtimeEnd: "",
            state: 1,
            clearTimeBgn: "",
            clearTimeEnd: "",
            confirmTimeBgn: "",
            confirmTimeEnd: "",
            confirmOperator: "",
            deviceId: id || ""
        };
        publicService.doRequest("GET", 6, obj).success(function(r) {
            $scope.alarmlogList = r.data.content;
        })
    }
    loadAlarms();

}]).filter('replaceCode', function() {
    return function(val) {
        if (!val) val = '';
        return val.replace(/[#$%^&*!-]/g, '');
    }
});
