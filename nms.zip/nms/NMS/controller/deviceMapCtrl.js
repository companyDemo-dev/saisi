angular.module('deviceMapModule',[]).controller('deviceMapCtrl', ['$scope', '$rootScope', '$http', '$translate', '$state', "publicService","ngDialog", function($scope, $rootScope, $http, $translate, $state, publicService,ngDialog) {
    function randomData() {
        return Math.round(Math.random()*1000);
    }
    var map = echarts.init(document.getElementById('mainMap')),
    option = {
        title: {
            text: '设备区域分布',
            left: 'center'
        },
        legend: {
            orient: 'vertical',
            left: 'left',
            data:['Device']
        },
        visualMap: {
            // min: 0,
            max: 2500,
            left: 'left',
            top: 'bottom',
            text: ['top','bottom'],           
            calculable: true,
            color:["#c23531", "rgb(202, 176, 176)"]
        },
        series: [
        {
            name: 'Device',
            type: 'map',
            mapType: 'china',
            label: {
                normal: {
                    show: true,
                    color:"#fff"
                },
                emphasis: {
                    show: true,
                    textStyle: {
                        color: 'rgb(2, 74, 108)'
                    }
                }
            },
            itemStyle: {
                normal: {
                    borderColor: '#000',
                    areaColor: '#fff',
                },
                emphasis: {
                        areaColor: '#ccc',
                        borderWidth: 0
                    }
                },
                data:[
                {name: '北京',value: randomData() },
                {name: '天津',value: randomData() },
                {name: '上海',value: randomData() },
                {name: '重庆',value: randomData() },
                {name: '河北',value: randomData() },
                {name: '河南',value: randomData() },
                {name: '云南',value: randomData() },
                {name: '辽宁',value: randomData() },
                {name: '黑龙江',value: randomData() },
                {name: '湖南',value: randomData() },
                {name: '安徽',value: randomData() },
                {name: '江西',value: randomData() },
                {name: '湖北',value: randomData() },
                {name: '广西',value: randomData() }
                ]
            }
            ]
        };
    map.setOption(option);
}]);
