angular.module('userManageAddEditModule',[]).controller('userManageAddEditCtrl', ['$scope','$stateParams', '$rootScope', "$state", "$timeout", '$translate', 'publicService', function($scope, $stateParams,$rootScope, $state, $timeout, $translate, publicService) {
	$scope.userNameD = false;
	$scope.formData = {};
	$scope.formData.roleName ="";
	$timeout(function() {
		if ($stateParams.mauto) {
			$scope.userTitle = "修改";
			$scope.formData = $stateParams.mauto;
			var roleList = $stateParams.mauto.roleList;
			for (var j = 0; j < roleList.length; j++) {
				if (roleList[j].roleType == 0) {
					$scope.formData.roleName = roleList[j].id;
				} else if (roleList[j].roleType == 1) {
					$scope.formData.roleName2 = roleList[j].id;
				}
			}
			if ($scope.formData.userName) {
				if ($scope.formData.userName == 'admin') {
					$scope.userNameD = true;
				}
			}
		} else {
			$scope.userTitle = "添加";
		}
		var obj1 = {
			userName: '',
			distribution: 0,
			roleType: 0
		}
		publicService.doRequest("GET", 107, obj1).success(function(r) {
				$scope.roleNameList1 = r.data;
			}) //获取角色列表
		var obj2 = {
			userName: '',
			distribution: 0,
			roleType: 1
		}
		publicService.doRequest("GET", 107, obj2).success(function(r) {
				$scope.roleNameList2 = r.data;
			}) //获取角色列表
	}, 0)


	$scope.backArea = function() {
		window.history.back();
		delete $stateParams.mauto;
	}

	$scope.userManageSub = function(m) {
		var self = this;
		if (!verify.userManageAddEdit(m, publicService, $translate)) return;
		publicService.loading('start');

		var url, method;
		if (self.userTitle === "修改") {
			url = 104;
			method = "PUT";
		} else {
			url = 101;
			method = "POST";
		}
		var roleListSS = [],
			roleListOBJ = {};
			
		if (self.formData.roleName) {
			roleListSS.push({
				'id': self.formData.roleName
			});
		}
		if (self.formData.roleName2) {
			roleListSS.push({
				'id': self.formData.roleName2
			});
		}

		roleListOBJ = roleListSS;
		m.roleList = roleListOBJ;
		self.disabledFlag = true;
		publicService.doRequest(method, url, m, self).success(function(r) {
			if (r.errCode) {
				publicService.ngAlert(r.message, "danger");
			} else {
				if (self.userTitle === "添加") {
					self.formData = {};
				}
				publicService.ngAlert(r.message, "success");
			}
			self.disabledFlag = false;
		})
	}
}]);
