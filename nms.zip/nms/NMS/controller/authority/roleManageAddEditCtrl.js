angular.module('menuManageModule',[]).controller('roleManageAddEditCtrl', ['$scope', '$stateParams','$rootScope', "$state", "$timeout", '$translate', 'publicService', function($scope, $stateParams,$rootScope, $state, $timeout, $translate, publicService) {
	$timeout(function() {
		if ($stateParams.mauto) {
			$scope.roleTitle = "修改";
			$scope.formData = $stateParams.mauto;
			if ($rootScope.curLoginMsg.userName == 'system' && $scope.formData.roleType == '0') {
				$scope.menuShow = true;
				$scope.deviceShow = false;
			} else {
				$scope.menuShow = false;
				$scope.deviceShow = true;
			}

			var obj = {
				roleName: '',
				distribution: 0
			}
			publicService.doRequest("GET", 109, obj).success(function(r) {
					if ($stateParams.mauto) {
						var deviceList = $stateParams.mauto.deviceList;
						var n_data = r.data;
						if (deviceList) {
							for (var i = 0; i < deviceList.length; i++) {
								var _id = deviceList[i].ip;
								for (var j = 0; j < n_data.length; j++) {
									var _id2 = n_data[j].ip;
									if (_id === _id2) {
										if (_id === _id2) {
											n_data[j].ticked = true;
										} else {
											n_data[j].ticked = false;
										}
									}
								}
							}
							$scope.iDeviceData = n_data;
						}
					}

				}) //获取设备列表


		} else {
			$scope.roleTitle = "添加";
			$scope.formData = {};
			$scope.menuShow = false;
			$scope.deviceShow = true;
			var obj = {
				roleName: '',
				distribution: 0
			}
			publicService.doRequest("GET", 109, obj).success(function(r) {
					$scope.iDeviceData = r.data;
				}) //获取设备列表
		}
		var obj = {
			roleName: '',
			distribution: 0
		}
		publicService.doRequest("GET", 108, obj).success(function(r) {
				if ($stateParams.mauto) {
					var menuList = $stateParams.mauto.menuList;
					var n_data = r.data;
					if (menuList) {
						for (var i = 0; i < menuList.length; i++) {
							var _id = menuList[i].menuName;
							for (var j = 0; j < n_data.length; j++) {
								var _id2 = n_data[j].menuName;
								if (_id === _id2) {
									if (_id === _id2) {
										n_data[j].ticked = true;
									} else {
										n_data[j].ticked = false;
									}
								}
							}
						}
						$scope.iMenuData = n_data;
					}
				}
			}) //获取菜单列表
	}, 0)


	$scope.backArea = function() {
		window.history.back();
		delete $stateParams.mauto;
	}

	$scope.roleManageSub = function(m) {
		var self = this;
		if (!verify.roleManageEditAdd(m, publicService, $translate)) return;
		publicService.loading('start');

		var url, method;
		if (self.roleTitle === "修改") {
			url = 106;
			method = "PUT";
		} else {
			url = 105;
			method = "POST";
		}
		var menuListSS = [],
			menuListOBJ = {};

		if (self.oMenuData && self.oMenuData.length != 0) {
			for (var i = 0; i < self.oMenuData.length; i++) {
				menuListSS.push({
					'id': self.oMenuData[i].id
				});
			}
			menuListOBJ = menuListSS;
			m.menuList = menuListOBJ;
		}
		//获取菜单列表
		var deviceListSS = [],
			deviceListOBJ = {};
		for (var i = 0; i < self.oDeviceData.length; i++) {
			deviceListSS.push({
				'id': self.oDeviceData[i].id
			});
		}
		deviceListOBJ = deviceListSS;
		m.deviceList = deviceListOBJ;
		//获取设备列表
		publicService.doRequest(method, url, m, self).success(function(r) {
			if (r.errCode) {
				publicService.ngAlert(r.message, "danger");
			} else {
				if (self.roleTitle === "添加") {
					self.formData = {};
				}
				publicService.ngAlert(r.message, "success");
			}
			self.disabledFlag = false;
		})
	}
}]);
