angular.module('menuManageModule',[]).controller('roleManageCtrl', ['$scope','$rootScope', "$state",'$translate','publicService',  function($scope, $rootScope,$state,$translate, publicService){
	
    $scope.seach = function(m){
		$scope.seachMod = m;
		$scope.paginationConf.onChange()
	}
    $scope.paginationConf = {
        currentPage: 1,
        totalItems: 0,
        itemsPerPage: 10,
        pagesLength: 15,
        perPageOptions: [10, 20, 30, 40, 50],
        rememberPerPage: 'perPageItems',
        onChange: function(){
        	$scope.seachMod = $scope.seachMod || {};
        	var _self = this,
            	obj = {
        		page : _self.currentPage || 1,
        		pageSize : _self.itemsPerPage,
        		roleName : $scope.seachMod.rolerole || "",
        		roleDesc : $scope.seachMod.roleDesc || ""
        	}
            publicService.loading('start');
            publicService.doRequest("GET", 103, obj).success(function(r){
        		var data = r.data.content;
                    for (i = 0; i < data.length; i++) {
                    var menuObj =[];
                    var obj ={};
                         var menu = data[i].menuList;
                          for (j = 0; j < menu.length; j++) {
                            menuObj.push(menu[j].menuName);
                          }
                          var menuObj = JSON.stringify(menuObj);
                          obj ={
                            menuName : 'menuName',
                            menuC : menuObj.replace(/[\[\]\"\/\b\f\n\r\t]/g, '')
                          }
                          data[i].menuList2 = obj;  //用户集中显示
                    }
                    $scope.roleManageList = data;
        		_self.currentPage = parseInt(r.data.number + 1);
        		_self.totalItems = r.data.totalElements;
        		_self.itemsPerPage = r.data.size;
        	})
        }
    };

    $scope.roleMangeAddEdit = function(m){
        $state.go("index.authority.roleManageAddEdit", {
            mauto: m
        })
    }

	$scope.roleMangeDel = function(m){
		var self = this;
            t = $translate.use() === "ch" ? "确认删除?" : "confirm delete？";
		if(confirm(t)){
			self.roleManageList.splice(self.roleManageList.indexOf(m),1)
			publicService.loading('start');
			publicService.doRequest("DELETE", "/nms/spring/role/" + m.id, {}).success(function(r){
				publicService.loading('end');
                var tt = $translate.use() === 'ch' ?　"删除成功！" : "Delete success！";
                publicService.ngAlert(tt,"success");
			})
		}
	}
}]);
