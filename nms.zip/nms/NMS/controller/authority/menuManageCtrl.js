angular.module('menuManageModule',[]).controller('menuManageCtrl', ['$scope', '$rootScope', '$http', '$state','$translate', "ngDialog", 'publicService', function($scope, $rootScope, $http, $state,$translate, ngDialog, publicService) {
    $scope.loadMenuTreeData = function() {
        $scope.showSelected = function(sel) {
            $scope.selectedNode = sel;
        };

        publicService.doRequest("GET", 102, {
            level: "1"
        }).success(function(data) {
            if (data.data && data.data.length > 0) {
                $rootScope.menuTreeData = data.data;
            }
        });
    }
    $scope.loadMenuTreeData();
    //打开菜单
    $scope.menuFun = function(sel) {
        ngDialog.open({
            template: "template/dialog/menuDialog.html",
            className: 'ngdialog-theme-default ngdialog-theme-custom',
            width: 407,
            controller: function($scope, publicService) {
                $scope.level = sel.level;
                $scope.menuDigDel = function() {
            t = $translate.use() === "ch" ? "确认删除?" : "confirm delete？";
                    if (confirm(t)) {
                        if (sel.children.length > 0) {
                var tt = $translate.use() === 'ch' ?　"无法删除！请先清空子菜单！" : "Cannot delete! Please clear the empty menu！";
                publicService.ngAlert(tt,"info");
                            return
                        }
                        ngDialog.close('ngdialog1');
                        publicService.loading('start');

                        ngDialog.close({
                            template: "template/dialog/menuDialog.html",
                            className: 'ngdialog-theme-default ngdialog-theme-custom',
                            width: 407,
                            controller: function($scope, publicService) {},
                            preCloseCallback: function($scope) {}
                        });
                        publicService.doRequest("DELETE", "/nms/spring/menu/" + sel.id, {}).success(function() {
                            publicService.loading('end');
                            publicService.doRequest("GET", 102, {
                                level: "1"
                            }).success(function(data) {
                                if (data.data && data.data.length > 0) {
                                    $rootScope.menuTreeData = data.data;
                                }
                            });
                var tt = $translate.use() === 'ch' ?　"删除成功！" : "Delete success！";
                publicService.ngAlert(tt,"success");
                        })
                    }
                };
                //添加编辑菜单
                $scope.menuDigEditAdd = function(x) {
                    ngDialog.close({
                        template: "template/dialog/menuDialog.html",
                        className: 'ngdialog-theme-default ngdialog-theme-custom',
                        width: 407,
                        controller: function($scope, publicService) {},
                        preCloseCallback: function($scope) {}
                    });

                    ngDialog.open({
                        template: "template/dialog/menuManageAdd.html",
                        className: 'ngdialog-theme-default ngdialog-theme-custom',
                        width: 407,
                        controller: function($scope, publicService) {
                            if (x) {
                                $scope.menuDigWay = '修改菜单';
                                $scope.menuDigEditAddName = '' + sel.menuName + '';
                                $scope.item = sel;
                            } else {
                                $scope.menuDigWay = '添加下级菜单';
                                $scope.menuDigEditAddName = '';
                            }

                            function getParent() {
                                publicService.doRequest("GET", "/nms/spring/menu/getParent", {
                                    id: sel.id
                                }).success(function(r) {
                                    if (r.data) {
                                        $scope.getParentData = r.data.id;
                                    }
                                });

                            }
                            getParent();
                            $scope.menuDigSub = function(m) {
                                /*if(!verify.deviceManageEditAdd(m, publicService)) return;*/
                                publicService.loading('start');

                                var url, method;
                                if ($scope.menuDigWay === "修改菜单") {
                                    url = 110;
                                    method = "PUT";
                                    m.id = sel.id;
                                    m.level = sel.level;
                                    if (sel.level != '1') {
                                        m.parentMenu = {
                                            "id": $scope.getParentData
                                        };
                                    }
                                } else {
                                    url = 110;
                                    method = "POST";
                                    m.level = parseInt(sel.level) + 1;
                                    m.parentMenu = {
                                        "id": sel.id
                                    };
                                }
                                publicService.doRequest(method, url, m, self).success(function(r) {
                                    if (r.errCode) {
                                        publicService.ngAlert(r.message, "danger");
                                    } else {
                                        ngDialog.close({
                                            template: "template/dialog/menuManageAdd.html",
                                            className: 'ngdialog-theme-default ngdialog-theme-custom',
                                            width: 407
                                        });
                                        publicService.doRequest("GET", 102, {
                                            level: "1"
                                        }).success(function(data) {
                                            if (data.data && data.data.length > 0) {
                                                $rootScope.menuTreeData = data.data;
                                            }
                                        });
                                        publicService.ngAlert(r.message, "success");
                                    }
                                    self.disabledFlag = false;
                                })
                            }
                        }
                    });

                };
            }
        });
    };



    //添加1一级菜单
    $scope.menuAdd = function(x) {
        ngDialog.open({
            template: "template/dialog/menuManageAdd.html",
            className: 'ngdialog-theme-default ngdialog-theme-custom',
            width: 407,
            controller: function($scope, publicService) {
                $scope.menuDigWay = '添加一级菜单';
                $scope.menuDigEditAddName = '';
                $scope.menuDigSub = function(m) {
                    /*if(!verify.deviceManageEditAdd(m, publicService)) return;*/
                    publicService.loading('start');
                    var url, method;
                    url = 110;
                    method = "POST";
                    m.level = "1";
                    publicService.doRequest(method, url, m, self).success(function(r) {
                        if (r.errCode) {
                            publicService.ngAlert(r.message, "danger");
                        } else {
                            ngDialog.close({
                                template: "template/dialog/menuManageAdd.html",
                                className: 'ngdialog-theme-default ngdialog-theme-custom',
                                width: 407
                            });
                            publicService.doRequest("GET", 102, {
                                level: "1"
                            }).success(function(data) {
                                if (data.data && data.data.length > 0) {
                                    $rootScope.menuTreeData = data.data;
                                }
                            });
                            publicService.ngAlert($scope.menuDigWay + '成功！', "success");
                        }
                        self.disabledFlag = false;
                    })
                }
            }
        });

    };

}]);
