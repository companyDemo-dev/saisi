;(function(app){
	app.controller('authorityCtrl', ['$scope','$rootScope','$http','$state', 'publicService',  function($scope, $rootScope, $http, $state, publicService){

	}]);
})(routerApp)