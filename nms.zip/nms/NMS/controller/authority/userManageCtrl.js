angular.module('userManageModule',[]).controller('userManageCtrl', ['$scope','$rootScope', '$stateParams', "$state",'$translate', 'publicService', function($scope, $rootScope,$stateParams, $state,$translate, publicService) {

    $translate.use(localStorage.getItem("Language") || 'ch');

    $rootScope.LANG = localStorage.getItem("Language") || "ch";
    $scope.seach = function(m) {
        $scope.seachMod = m;
        $scope.paginationConf.onChange()
    }
    $scope.paginationConf = {
        currentPage: 1,
        totalItems: 0,
        itemsPerPage: 10,
        pagesLength: 15,
        perPageOptions: [10, 20, 30, 40, 50],
        rememberPerPage: 'perPageItems',
        onChange: function() {
            $scope.seachMod = $scope.seachMod || {};
            var _self = this,
                obj = {
                    page: _self.currentPage || 1,
                    pageSize: _self.itemsPerPage,
                    userName: $scope.seachMod.secuLogUser || ""
                }
            publicService.loading('start');
            publicService.doRequest("GET", 100, obj).success(function(r) {
                var data = r.data.content;
                for (i = 0; i < data.length; i++) {
                    var roleData = data[i].roleList;
                var menuData = [];
                var deviceData = [];
                    for (j = 0; j < roleData.length; j++) {
                        if (roleData[j].roleType == 0) {
                            var objs = {};
                            objs.menuRole = roleData[j].roleName;
                            objs.menuDesc = roleData[j].roleDesc;
                            menuData.push(objs)
                        data[i].menuData = menuData;
                        }
                        if (roleData[j].roleType == 1) {
                            var objss = {};
                            objss.deviceRole = roleData[j].roleName;
                            deviceData.push(objss)
                        data[i].deviceData = deviceData;
                        }

                    }
                }
                $scope.userManageList = data;
                _self.currentPage = parseInt(r.data.number + 1);
                _self.totalItems = r.data.totalElements;
                _self.itemsPerPage = r.data.size;
            })
        }
    };

    $scope.userMangeAddEdit = function(m) {
        $state.go("index.authority.userManageAddEdit", {
            mauto: m
        })
    }

    $scope.userMangeDel = function(m) {
        var self = this;
            t = $translate.use() === "ch" ? "确认删除?" : "confirm delete？";
        if (confirm(t)) {
            self.userManageList.splice(self.userManageList.indexOf(m), 1)
            publicService.loading('start');
            publicService.doRequest("DELETE", "/nms/spring/user/" + m.id, {}).success(function(r) {
                publicService.loading('end');
                var tt = $translate.use() === 'ch' ?　"删除成功！" : "Delete success！";
                publicService.ngAlert(tt,"success");
            })
        }
    }
        $scope.userMangeAddError = function(m,x) {
          if(x == '0'){
            m.lastLogErrorTime = null;
            m.logErrorNum = 0;
            var mes ='解锁';
            }else{
                m.logErrorNum = 3;
            var mes ='锁定';
            }
        publicService.doRequest("PUT", 104, m, self).success(function(r) {
            if (r.errCode) {
                publicService.ngAlert(r.message, "danger");
            } else {
                publicService.ngAlert('成功'+mes, "success");
                $scope.seach(m);
            }
        })
    }
}]);
