angular.module('tp1000AlarmtableModule', []).controller('tp1000AlarmtableCtrl', ['$scope', '$state', '$stateParams', '$rootScope', "$translate", '$state', 'publicService', function($scope, $state, $stateParams, $rootScope, $translate, $state, publicService) {


	/**
	 * downloadConfig
	 *   导出配置
	 */
	$scope.downloadConfig = function() {

		var self = this;
		if (!self.devID) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}

		var config_obj = [];
		var obj = {};
		obj.node = 'alarmConfigTable';
		obj.index = '';
		config_obj.push(obj);
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $rootScope.tp1000devID.id + "/downloadConfig/config", config_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}
	$scope.deviceContent = {};
	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data == null) return
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'TP1000') {
					deviceInfo.push(content[i]);
				}
			}
			$scope.deviceInfo = deviceInfo;
		}
	})


	sum = 1;
	$scope.PREVIOUSD = true;
	$scope.seach = function(x) {
		var self = this;
		$scope.mauto = self.devID;
		$scope.devExp = self.devExp;
		if ($rootScope.tp1000devID) {
			$scope.mauto = $rootScope.tp1000devID;
		} else {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}
		publicService.loading('start');

		var devId = $rootScope.tp1000devID.id;
		url = 'alarms';

		publicService.doRequest("GET", "/nms/spring/deviceConfig/" + devId + "/configs/" + url, '').success(function(r) {
			if (r.data && r.data.length > 0) {
				$scope.configList = r.data;
			}
			_newVals();
		});
	}
	if ($rootScope.tp1000devID) {
		$scope.mauto = $rootScope.tp1000devID;
		$rootScope.devIP = $rootScope.tp1000devID.name;
		$scope.shelfList = $rootScope.tp1000devID.shelfList;
		$scope.devExp = '0';
		$scope.seach()
	}
	$scope.listSetConfig = function(x) {
		$scope.deviceContent = x;
		_newVals();
	}

	$scope.macChange = function(x) {
		var self = this;
		$scope.mauto = self.devID;
		if (self.devID && self.devID.deviceStatus != 0) {
			//子页面之间传值
			/*	$rootScope.shelfList = self.devID.shelfList;
				$rootScope.devIP = self.devID.ip;*/

			//界面显示
			$rootScope.devIP = self.devID.name;
			$rootScope.tp1000devID = self.devID;
			//界面显示
			$scope.shelfList = self.devID.shelfList;
			$scope.devIP = self.devID.ip;
			$scope.devExp = '0';
		} else if (self.devID && self.devID.deviceStatus != 1) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}

	}
	$scope.configSub = function(x, index) {
		if (!verify.alarmConfig(x, publicService, $translate)) return;
		if (index) {
			indexObj = parseInt(index) + 1;
		}
		ds = _changeVals(x);
		var configSub_obj = [];
		for (var j in ds) {
			obj = {};
			obj.value = ds[j];
			obj.node = j;
			obj.index = '.' + indexObj.toString();;
			configSub_obj.push(obj);

		}
		configSubmit(configSub_obj, index);
		_newVals()
	}

	/**
	 * configSubmit
	 *   配置提交
	 */
	function configSubmit(configSub_obj, index) {
		if (!$scope.mauto) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return
		}
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/setConfigsBatch", configSub_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var doc;
			if (r.data.length == 0) {
				var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
				publicService.ngAlert(tt, "info");
				return;
			} else {
				var dataObj = r.data;
				var div = document.createElement('p');
				for (var i = 0; i < dataObj.length; i++) {
					if (dataObj[i].code === false) {
						var node = document.createTextNode(dataObj[i].message + ' ');
						div.appendChild(node);

					} else if (dataObj[i].code === true) {
						var node = document.createTextNode(dataObj[i].message + ' ');
						div.appendChild(node);
					}
				}
				var element = document.getElementById("ngTip");
				element.appendChild(div);
				var tt = $translate.use() === 'ch' ? 　"返回状态列表" : "Return state List";
				publicService.ngAlert(tt, "info");
				setTimeout(function() {
					element.removeChild(div);
					publicService.doRequest("GET", "/nms/spring/device/" + $scope.mauto.id + "/syncAlarms", {});
				}, 3000)


			}

		})

	}

	function _newVals() {
		var deviceContent = $scope.deviceContent;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		localStorage.setItem('valueDoms', JSON.stringify(obj));
	}

	function _changeVals(x) {
		var deviceContent = x;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		var _vals = JSON.parse(localStorage.getItem('valueDoms')),
			changeObj = {};
		for (var i = 0; i < obj.length; i++) {
			var _id = obj[i].name,
				_val = obj[i].value;
			for (var j = 0; j < _vals.length; j++) {
				var _id2 = _vals[j].name,
					_val2 = _vals[j].value;
				if (_id === _id2) {
					if (_val != _val2) {
						changeObj[_id] = _val;
					}
				}
			}
		}
		return changeObj;
	}
}]);