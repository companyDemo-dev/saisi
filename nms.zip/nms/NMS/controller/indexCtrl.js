angular.module('indexModule',[]).controller('indexCtrl', ['$scope', '$timeout', '$rootScope', '$http', '$state', function($scope, $timeout, $rootScope, $http, $state) {

	if ($state.params.ExpiredFlag === 0) {
		$timeout(function(){
			var par = document.getElementById('popover');
			if (par) {
				angular.element(par).removeClass('popoverS');
			}
		},2000)
	}
	if (!$rootScope.curLoginMsg) {
		$state.go('login');
		localStorage.setItem("mauto", '');
	}
	//$state.go('index');
	$scope.$on("otherSoundMsg", function(event, msg) { //声音功能;
		$scope.$broadcast("otherSoundMod", msg);
	});
	if ($rootScope.lockPb) $timeout.cancel($rootScope.lockPb)
	var windwosLock = 0;

	function test1() {
		var otherFrameObj = localStorage.getItem("otherFrame");
		if (!otherFrameObj) {
			var otherFrame = {
				"frameOffOn": "off",
				"pwOffOn": "off",
				"frameInterval": "5",
				"framePsw": 123
			};
		} else {
			var otherFrame = JSON.parse(otherFrameObj);
		}
		var frameInterval = parseInt(otherFrame.frameInterval);
		windwosLock++;
		if (windwosLock == frameInterval) {
			if (otherFrame.frameOffOn == 'on') {
				$state.go('lockFrame');
			}
		}
		$rootScope.lockPb = $timeout(test1, 60000);
	}
	test1();
	/*
			document.body.onmousemove = function() {
				
			}*/
	document.addEventListener('mousemove', function(e) {
		windwosLock = 0;
	})
	document.addEventListener('keydown', function(e) {
		windwosLock = 0;
	})

	document.addEventListener('keydown', function(e) {
		var bb = angular.element(document.getElementById("oneMenu")).find('a')
		var e = e || window.event,
			_code = e.keyCode;
		if (e.ctrlKey && _code === 49) { //ctrl + 1
			stopDefault(e, function() {
				bb[0].click()
					//$state.go("index")
			});
		} else if (e.ctrlKey && _code === 50) { //ctrl + 2  
			stopDefault(e, function() {
				bb[1].click()
			});
		} else if (e.ctrlKey && _code === 51) { //ctrl + 3
			stopDefault(e, function() {
				bb[2].click()
			});
		} else if (e.ctrlKey && _code === 52) { //ctrl + 4
			stopDefault(e, function() {
				bb[3].click()
			});
		} else if (e.ctrlKey && _code === 53) { //ctrl + 5
			stopDefault(e, function() {
				bb[4].click()
			});
		} else if (e.ctrlKey && _code === 54) { //ctrl + 6
			stopDefault(e, function() {
				bb[5].click()
			});
		} else if (e.ctrlKey && _code === 55) { //ctrl + 7
			stopDefault(e, function() {
				bb[6].click()
			});
		} else if (e.ctrlKey && _code === 56) { //ctrl + 8
			stopDefault(e, function() {
				bb[7].click()
			});
		} else if (e.ctrlKey && _code === 57) { //ctrl + 9
			stopDefault(e, function() {
				bb[8].click()
			});
		} else if (e.ctrlKey && _code === 81) { //ctrl + q
			stopDefault(e);
		}
	}, false);

	function stopDefault(e, fu) {
		if (e && e.preventDefault) {
			e.preventDefault();
		} else {
			window.event.returnValue = false;
		}
		fu();
		return false;
	}

}]);
