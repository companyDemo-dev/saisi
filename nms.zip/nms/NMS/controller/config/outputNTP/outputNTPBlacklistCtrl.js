angular.module('sm2000outputNTPBlacklistModule',[]).controller('outputNTPBlacklistCtrl', ['$scope', '$stateParams', '$state', "$translate", 'publicService', function($scope, $stateParams, $state, $translate, publicService) {
	$scope.dev_Id = $stateParams.devid;
	$scope.slot = $stateParams.slot;
	$scope.exp = $stateParams.exp;
	$scope.ntpStatePortId = '1';
	$scope.mauto = {};

	$scope.downloadConfig = function() {
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/downloadConfig/config", arr).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}


	$scope.seach = function() {
		var obj = {};
		if ($scope.ntpStatePortId) {
			var indexN = "." + $scope.exp + "." + $scope.slot + '.' + $scope.ntpStatePortId;
		} else {
			var indexN = "." + $scope.exp + "." + $scope.slot + '.1';
		}
		obj = [{
			"node": "outputNTPntpBlacklistCount",
			"index": "" + indexN + ".1",
			"num": ""
		}, {
			"node": "outputNTPntpListState",
			"index": indexN,
			"num": ""
		}]
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/getDeviceParamColl", obj).success(function(r) {
			if (r.data && r.data.length > 0) {
				$scope.mauto = JSON.parse(r.data);
				var num = JSON.parse(r.data);
				var count = num.outputNTPntpBlacklistCount;
				if (count != "null") {
					var a = {},
						obj2 = [];
					for (var i = 1; i <= count; i++) {
						a = {
							"node": 'outputNTPntpBlacklistAddr',
							"index": indexN + '.' + i,
							"num": ""
						}
						obj2.push(a);
					}
					publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/getDeviceParamTable", obj2).success(function(r) {
						if (r.data && r.data.length > 0) {
							var obj3 = r.data;
							var Whitelist = [];
							for (var i = 0; i < obj3.length; i++) {
								var listAddr = obj3[i]['outputNTPntpBlacklistAddr'].split(',');
								var WhitelistAddrlistAddr = {
									"listAddr1": listAddr[0],
									"listAddr2": listAddr[1]
								};
								Whitelist.push(WhitelistAddrlistAddr);
							}
							$scope.loadNTPWhiteList = Whitelist;
						}
					})

				} else {
					$scope.loadNTPWhiteList = '';
				}

			}
		});

	}
	$scope.seach();

	/**
	 * outputPTPntplistSub
	 *   黑白名单创建 激活
	 */



	$scope.outputNTPSub = function(x) {

		var arr = [{
			"node": x,
			"index": "." + $scope.exp + "." + $scope.slot + '.' + $scope.ntpStatePortId,
			"value": $scope.mauto.outputNTPntpListState
		}];
		publicService.loading('start');
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/setConfigsBatch", arr).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var dataObj = r.data,
				str = "";
			if (dataObj[0].code) {
				var tt = $translate.use() === 'ch' ? 　"设置成功" : "Set success";
				publicService.ngAlert(tt, "info");
				// $scope.mauto.inputPTPimageCurrentImage = _self.inputPTPimageCurrentImage;
			} else {
				publicService.ngAlert(dataObj[0].message, "info");
			}
		})
	}
	$scope.outputNTPAddrSub = function(x) {

		if (!verify.outputNTPWhitelistIP(x, publicService, $translate)) {
			return;
		}
		var obj = {};

		if ($scope.ntpStatePortId) {
			var indexN = "." + $scope.exp + "." + $scope.slot + '.' + $scope.ntpStatePortId;
		} else {
			var indexN = "." + $scope.exp + "." + $scope.slot + '.1';
		}
		obj = [{
			"node": "outputNTPntpBlacklistCount",
			"index": "" + indexN + ".1",
			"num": ""
		}]
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/getDeviceParamColl", obj).success(function(r) {
			if (r.data && r.data.length > 0) {
				var num = JSON.parse(r.data);
				var count = num.outputNTPntpBlacklistCount;
				if (count == "null" || count == "") count = '0';
				var reobj = [],
					obj = {};
				if (x.outputNTPWhitelistAddr2) {
					var value = x.outputNTPWhitelistAddr + ',' + x.outputNTPWhitelistAddr2;
				} else {
					var value = x.outputNTPWhitelistAddr;
				}
				if ($scope.ntpStatePortId) {
					var index = indexN + '.' + parseInt(parseInt(count) + 1);
				} else {
					var index = indexN + '.' + parseInt(parseInt(count) + 1);
				}
				obj.value = value;
				obj.node = 'outputNTPntpBlacklistAddr';
				obj.index = index;
				reobj.push(obj);
				publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/setConfigsBatch", reobj).success(function(r) {
					if (!r || !r.data || r.data.length < 0) return;
					if (r.data.length == 0) {
						var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
						publicService.ngAlert(tt, "info");
						return;
					} else {
						var dataObj = r.data;
						if (dataObj[0].code === true) {
							var tt = $translate.use() === 'ch' ? 　"添加IP成功" : "Add IP success";
							publicService.ngAlert(tt, "info");
							$scope.outputPTPntpActiveSub(x, index);
						} else if (dataObj[0].code === false) {
							var tt = $translate.use() === 'ch' ? 　"添加IP失败" : "Add IP failed";
							publicService.ngAlert(tt, "info");
						}
					}
				})

			}
		});
	}


	$scope.outputPTPntpActiveSub = function(x, index) {
		var reobj = [],
			obj = {};
		obj.value = '1';
		obj.node = 'outputNTPntpBlacklistRowStatus';
		obj.index = index;
		reobj.push(obj);

		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/setConfigsBatch", reobj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			if (r.data.length == 0) {
				var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
				publicService.ngAlert(tt, "info");
				return;
			} else {
				var dataObj = r.data;
				if (dataObj[0].code === true) {
					var tt = $translate.use() === 'ch' ? 　"激活成功" : "active success";
					publicService.ngAlert(tt, "info");
					$scope.seach();
				} else if (dataObj[0].code === false) {
					var tt = $translate.use() === 'ch' ? 　"激活失败" : "active failed";
					publicService.ngAlert(tt, "info");
				}
			}
		})
	}



	$scope.NTPIpListDel = function(x) {
		var t = $translate.use() === "ch" ? "确认删除?" : "confirm delete？";
		if (confirm(t)) {
			if ($scope.ntpStatePortId) {
				var index = "." + $scope.exp + "." + $scope.slot + '.' + $scope.ntpStatePortId + '.'+x;
			} else {
				var index = "." + $scope.exp + "." + $scope.slot + '.1.'+x;
			}
			var reobj = [],
				obj = {};
			obj.value = '6';
			obj.node = 'outputNTPntpBlacklistRowStatus';
			obj.index = index;
			reobj.push(obj);

			publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/setConfigsBatch", reobj).success(function(r) {
				if (!r || !r.data || r.data.length < 0) return;
				if (r.data.length == 0) {
					var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
					publicService.ngAlert(tt, "info");
					return;
				} else {
					var dataObj = r.data;
					if (dataObj[0].code === true) {
						var tt = $translate.use() === 'ch' ? 　"删除成功" : "delete success";
						publicService.ngAlert(tt, "info");
						$scope.seach();

					} else if (dataObj[0].code === false) {
						var tt = $translate.use() === 'ch' ? 　"删除失败" : "delete failed";
						publicService.ngAlert(tt, "info");
					}
				}
			})
		}
	}
}]);
