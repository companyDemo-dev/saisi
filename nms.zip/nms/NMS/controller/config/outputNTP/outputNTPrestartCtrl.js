angular.module('sm2000outputNTPrestartModule',[]).controller('outputNTPrestartCtrl', ['$scope', '$stateParams', "$timeout",'$state',"$translate",'publicService', function($scope, $stateParams, $timeout,$state,$translate,  publicService) {
	$scope.dev_Id = $stateParams.devid;
	$scope.slot = $stateParams.slot;
	$scope.exp = $stateParams.exp;
	$scope.port = '1';
	$scope.mauto = {};

	$scope.restartSet = function(m){
		var arr =[];
		arr = [{"node": 'outputNTPRestartAction', "index": "." + $scope.exp+'.' + $scope.slot + '.' + $scope.port,"value" : "1"}]
		publicService.loading('start');
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/setConfigsBatch", arr).success(function(r) {
			publicService.loading('start');
			$timeout(function(){
				var pars = [{"node": "outputNTPRestartResult", "index": "." + $scope.exp+'.' + $scope.slot + '.' + $scope.port,"num": ""}]
				publicService.loading('start');
				publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/getDeviceParamColl", pars).success(function(rr) {
					if(rr && rr.data){
						var s = JSON.parse(rr.data),
							tt = $translate.use() === 'ch', str1 = "", str2 = "";
						if(!tt){
							str1 = "restart success";
							str2= "restart success";
						}else{
							str1 = "重启成功";
							str2 = "重启成功";
						}
						if(s.outputNTPRestartResult == "1"){
							publicService.ngAlert(str1, "info");
						}else{
							publicService.ngAlert(str2, "success");
						}
					}
					publicService.loading('end');
				})
			},9000)
		})
	}

	$scope.restartCard = function(m){
		var arr =[];
		arr = [{"node": 'outputNTPRestartAction', "index": "." + $scope.exp+'.' + $scope.slot + '.0',"value" : "1"}]
		publicService.loading('start');
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/setConfigsBatch", arr).success(function(r) {
			publicService.loading('start');
			$timeout(function(){
				var pars = [{"node": "outputNTPRestartResult", "index": "." + $scope.exp+'.' + $scope.slot + '.0',"num": ""}]
				publicService.loading('start');
				publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/getDeviceParamColl", pars).success(function(rr) {
					if(rr && rr.data){
						var s = JSON.parse(rr.data),
							tt = $translate.use() === 'ch', str1 = "", str2 = "";
						if(!tt){
							str1 = "restart success";
							str2= "restart success";
						}else{
							str1 = "重启成功";
							str2 = "重启成功";
						}
						if(s.outputNTPRestartResult == "1"){
							publicService.ngAlert(str1, "info");
						}else{
							publicService.ngAlert(str2, "success");
						}
					}
					publicService.loading('end');
				})
			},9000)
		})
	}
}]);
