angular.module('sm2000outputNTPNetworkModule',[]).controller('outputNTPNetworkCtrl', ['$scope', '$stateParams', '$state', "$translate", 'publicService', function($scope, $stateParams, $state, $translate, publicService) {
	$scope.dev_Id = $stateParams.devid;
	$scope.slot = $stateParams.slot;
	$scope.exp = $stateParams.exp;
	$scope.port = '1';
	$scope.mauto = {};


	function parms(port) {
		var arr = [{
			"node": "outputNTPNetworkConfigIpState",
			"index": "." + $scope.exp + "." + $scope.slot + "." + port,
			"num": ""
		}, {
			"node": "outputNTPNetworkConfigIpInfo",
			"index": "." + $scope.exp + "." + $scope.slot + "." + port,
			"num": ""
		}, {
			"node": "outputNTPStatusNetworkHWAddr",
			"index": "." + $scope.exp + "." + $scope.slot + "." + port,
			"num": ""
		}, {
			"node": "outputNTPNetworkConfigAutoNegState",
			"index": "." + $scope.exp + "." + $scope.slot + "." + port,
			"num": ""
		}, {
			"node": "outputNTPNetworkConfigSpeed",
			"index": "." + $scope.exp + "." + $scope.slot + "." + port,
			"num": ""
		}, {
			"node": "outputNTPNetworkConfigDuplex",
			"index": "." + $scope.exp + "." + $scope.slot + "." + port,
			"num": ""
		}, {
			"node": "outputNTPNetworkConfigIpv6Info",
			"index": "." + $scope.exp + "." + $scope.slot + "." + port,
			"num": ""
		}];
		return arr;
	}


	dataNet($scope.dev_Id, parms($scope.port));

	$scope.dataNetwork = function(port) {
		dataNet($scope.dev_Id, parms(port))
	}
	$scope.change = function() {
		if($scope.mauto.outputNTPNetworkConfigAutoNegState == '0'){
			$scope.AutoNegStateD = true;
		}else{
			$scope.AutoNegStateD = false;
		}
	}

	function dataNet(deviceid, p) {
		publicService.loading('start');
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + deviceid + "/getDeviceParamColl", p).success(function(r) {
			if (r && r.data) {
				var d = JSON.parse(r.data);
				$scope.mauto = d;
				var info = d.outputNTPNetworkConfigIpInfo.split(',');
				$scope.mauto.address = info[0];
				$scope.mauto.netmask = info[1];
				$scope.mauto.gateway = info[2];
				_newVals();
				$scope.change();
			}
		});
	}

	$scope.configSub = function(x) {
	if (!verify.outputNTPNetworkConfig(x, publicService, $translate)) return;
		var indexObj = "." + $scope.exp + '.' + $scope.slot + '.' + $scope.port;
		ds = _changeVals(x);
		flag = true;
		var configSub_obj = [];
		for (var j in ds) {
			obj = {};
			switch (j) {
				case "address":
				case "netmask":
				case "gateway":
					if (flag) {
						var j = $scope.mauto.address,
							w = $scope.mauto.netmask,
							h = $scope.mauto.gateway,
							outputNTPNetworkConfigIpInfo = String(j + "," + w + "," + h);
						obj.value = outputNTPNetworkConfigIpInfo;
						obj.node = 'outputNTPNetworkConfigIpInfo';
						obj.index = indexObj;
						flag = false;
						configSub_obj.push(obj);
					}
					break;
				default:
					obj.value = ds[j];
					obj.node = j;
					obj.index = indexObj;
					configSub_obj.push(obj);
			}
		}
		configSubmit(configSub_obj);
		_newVals()
	}

	/**
	 * configSubmit
	 *   配置提交
	 */
	function configSubmit(configSub_obj) {
		if (!$scope.mauto) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return
		}
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/setConfigsBatch", configSub_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var doc;
			if (r.data.length == 0) {
				var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
				publicService.ngAlert(tt, "info");
				return;
			} else {
				if (r.data[0].code) {
					var tt = $translate.use() === 'ch' ? 　"设置成功" : "Set success";
					publicService.ngAlert(tt, "info");
				} else {
					publicService.ngAlert(r.data[0].message, "info");
				}
			}
		})
	}


	function _newVals() {
		var deviceContent = $scope.mauto;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		localStorage.setItem('valueDoms', JSON.stringify(obj));
	}

	function _changeVals(x) {
		var deviceContent = x;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		var _vals = JSON.parse(localStorage.getItem('valueDoms')),
			changeObj = {};
		for (var i = 0; i < obj.length; i++) {
			var _id = obj[i].name,
				_val = obj[i].value;
			for (var j = 0; j < _vals.length; j++) {
				var _id2 = _vals[j].name,
					_val2 = _vals[j].value;
				if (_id === _id2) {
					if (_val != _val2) {
						changeObj[_id] = _val;
					}
				}
			}
		}
		return changeObj;
	}
	$scope.downloadConfig = function() {
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/downloadConfig/config", parms($scope.port)).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}
}]);
