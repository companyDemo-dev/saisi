angular.module('sm2000outputNTPimageModule',[]).controller('outputNTPimageCtrl', ['$scope', '$stateParams', '$state',"$translate",'publicService', function($scope, $stateParams, $state,$translate,  publicService) {
	$scope.dev_Id = $stateParams.devid;
	$scope.slot = $stateParams.slot;
	$scope.exp = $stateParams.exp;
	$scope.mauto = {};


	var arr = [{"node": "outputNTPimageActiveImage","index":"." + $scope.exp+"." +  $scope.slot ,"num": ""},
			{"node": "outputNTPimageActiveVersion","index":"." + $scope.exp+"." +  $scope.slot ,"num": ""},
			{"node": "outputNTPimageBackupImage","index":"." + $scope.exp+"." +  $scope.slot ,"num": ""},
			{"node": "outputNTPimageBackupVersion","index":"." + $scope.exp+"." +  $scope.slot ,"num": ""},
			{"node": "outputNTPimageCurrentImage","index":"." + $scope.exp+"." +  $scope.slot ,"num": ""}];
	publicService.loading('start');
	publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/getDeviceParamColl", arr).success(function(r) {
		if(r && r.data){
			$scope.mauto = JSON.parse(r.data);
		}				
	});

	$scope.downloadConfig = function() {
		var arrs = [{node : "outputNTPimageTable",index : ''}];
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/downloadConfig/config", arrs).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}

	$scope.imageSet = function(m){
		var tt = $translate.use() === 'ch', str = "", str1 = "", _self = this;
		if(!tt){
			str = "Please input ";
			str1 = " Number between 1-2";
		}else{
			str = "请输入";
			str1 = " 为1-2之间的数字";
		}
		if(verifyFun.isNull(_self.mauto.outputNTPimageCurrentImage)){
			publicService.ngAlert(str + "imageCurrentImage", "info");
			return;
		}
		if(!verifyFun.between(_self.mauto.outputNTPimageCurrentImage,1,2)){
			publicService.ngAlert("imageCurrentImage" + str1, "info");
			return;
		}
		if(m.outputNTPchangeActiveStatus){
		var arr = [{"node": "outputNTPimageCurrentImage", "index": "." + $scope.exp+'.' + $scope.slot ,"value" : _self.mauto.outputNTPimageCurrentImage},{"node": "outputNTPchangeActiveStatus", "index": "." + $scope.exp+'.' + $scope.slot ,"value" : _self.mauto.outputNTPchangeActiveStatus}];
			
	}else{
		var arr = [{"node": "outputNTPimageCurrentImage", "index": "." + $scope.exp+'.' + $scope.slot ,"value" : _self.mauto.outputNTPimageCurrentImage}];
		
	}
		publicService.loading('start');
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/setConfigsBatch", arr).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var dataObj = r.data, str = "";
			if(dataObj[0].code){
				var tt = $translate.use() === 'ch' ? 　"设置成功" : "Set success";
				publicService.ngAlert(tt, "info");
				// $scope.mauto.inputPTPimageCurrentImage = _self.inputPTPimageCurrentImage;
			}else{
				publicService.ngAlert(dataObj[0].message, "info");
			}
		})
	}

}]);
