angular.module('sm2000outputNTPNetworkStartusModule',[]).controller('outputNTPNetworkStartusCtrl', ['$scope', '$stateParams', '$state',"$translate",'publicService', function($scope, $stateParams, $state,$translate,  publicService) {
	$scope.dev_Id = $stateParams.devid;
	$scope.slot = $stateParams.slot;
	$scope.exp = $stateParams.exp;
	$scope.port = '1';

	
	function parms(port){
		var arr = [{"node": "inputPTPNetworkStatusHWAddr","index":"." +  $scope.slot + "." + port ,"num": ""}];
		return arr;
	}
	dataNet($scope.dev_Id, $scope.port);

	$scope.dataNetworkStartus = function(p){
		dataNet($scope.dev_Id, p);
	}

	function dataNet(d, p){
		publicService.loading('start');
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + d + "/getDeviceParamColl", parms(p)).success(function(r) {
			if(r && r.data){
				$scope.inputPTPNetworkStatusHWAddr = JSON.parse(r.data)["inputPTPNetworkStatusHWAddr"];
			}				
		});
	}

	$scope.downloadConfig = function() {
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/downloadConfig/config", arr).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}
}]);
