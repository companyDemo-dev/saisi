angular.module('sm2000outputNTPStatusModule',[]).controller('outputNTPStatusCtrl', ['$scope', '$stateParams', '$state',"$translate",'publicService', function($scope, $stateParams, $state,$translate,  publicService) {
	$scope.dev_Id = $stateParams.devid;
	$scope.slot = $stateParams.slot;
	$scope.exp = $stateParams.exp;

	var arr = [{"node": "outputNTPclockState","index":"." + $scope.exp+"." +  $scope.slot ,"num": ""},
			{"node": "outputNTPclockRunningTime","index":"." + $scope.exp+"." +  $scope.slot ,"num": ""},
			{"node": "outputNTPclockCurrentTime","index":"." + $scope.exp+"." +  $scope.slot ,"num": ""},
			{"node": "outputNTPGeneralStatusCPUload","index":"." + $scope.exp+"." +  $scope.slot ,"num": ""},
			{"node": "outputNTPGeneralStatusMEMload","index":"." + $scope.exp+"." +  $scope.slot ,"num": ""}];
	publicService.loading('start');
	publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/getDeviceParamColl", arr).success(function(r) {
		if(r && r.data){
			$scope.mauto = JSON.parse(r.data);
		}				
	});

	$scope.downloadConfig = function() {
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/downloadConfig/config", arr).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}

}]);

