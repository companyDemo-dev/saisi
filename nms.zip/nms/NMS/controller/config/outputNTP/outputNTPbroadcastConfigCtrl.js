angular.module('outputNTPbroadcastConfigModule', []).controller('outputNTPbroadcastConfigCtrl', ['$scope', '$stateParams', '$state', "$translate", 'publicService', function($scope, $stateParams, $state, $translate, publicService) {
	$scope.dev_Id = $stateParams.devid;
	$scope.slot = $stateParams.slot;
	$scope.exp = $stateParams.exp;
	$scope.mauto = {};
    $scope.port = '1';
	$scope.databroadcast = function(port) {
		$scope.dataCast(port);
	}

	$scope.dataCast = function(port) {
		var arr = [{
			"node": "outputNTPbroadcastConfig",
			"index": "." + $scope.exp + "." + $scope.slot + "." + port,
			"num": ""
		}];
		publicService.loading('start');
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/getDeviceParamColl", arr).success(function(r) {
			if (r && r.data) {
				var databroad = JSON.parse(r.data.replace('\n', ''));
				var databroadOBJ = databroad.outputNTPbroadcastConfig.split(';');
				$scope.mauto.outputNTPbroadcastState =databroadOBJ[0];
				$scope.mauto.outputNTPbroadcastIP =databroadOBJ[1];
				$scope.mauto.outputNTPbroadcastInterval =databroadOBJ[2];
			}
		});
	}
	$scope.dataCast('1');
	$scope.configSet = function(m) {
		if (!verify.outputNTPbroadcast(m, publicService, $translate)) return;
		var arr = [];
		if($scope.port){
			var port = $scope.port;
		}else{
			var port = '1'
		}
		if (m.outputNTPbroadcastState) {
			var a = {
				"node": 'outputNTPbroadcastState',
				"index": "." + $scope.exp + '.' + $scope.slot + "." + port,
				"value": m.outputNTPbroadcastState
			};
			arr.push(a);
		}
		if (m.outputNTPbroadcastIP) {
			var b = {
				"node": 'outputNTPbroadcastIP',
				"index": "." + $scope.exp + '.' + $scope.slot + "." + port,
				"value": m.outputNTPbroadcastIP
			};
			arr.push(b);
		}
		if (m.outputNTPbroadcastInterval) {
			var c = {
				"node": 'outputNTPbroadcastInterval',
				"index": "." + $scope.exp + '.' + $scope.slot + "." + port,
				"value": m.outputNTPbroadcastInterval
			};
			arr.push(c);
		}

		publicService.loading('start');
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/setConfigsBatch", arr).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var dataObj = r.data,
				str = "";
			if (dataObj[0].code) {
				var tt = $translate.use() === 'ch' ? 　"设置成功" : "Set success";
				publicService.ngAlert(tt, "info");
			} else {
				publicService.ngAlert(dataObj[0].message, "info");
			}
		})
	}

	$scope.downloadConfig = function() {
		if($scope.port){
			var port = $scope.port;
		}else{
			var port = '1'
		}
		var arrD =[{
				"node": 'outputNTPbroadcastConfig',
				"index": "." + $scope.exp + '.' + $scope.slot + "." + port,
				"num": ''
			}]
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/downloadConfig/config", arrD).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}
}]);