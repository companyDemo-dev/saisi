angular.module('sm2000outputNTPAuthenticaConfigModule', []).controller('outputNTPAuthenticaConfigCtrl', ['$scope', '$stateParams', '$state', "$translate", 'publicService', function($scope, $stateParams, $state, $translate, publicService) {
	$scope.dev_Id = $stateParams.devid;
	$scope.slot = $stateParams.slot;
	$scope.exp = $stateParams.exp;
	$scope.port = '1';
	$scope.mauto = {};

	var arr = [{
		"node": "outputNTPntpAuthenticaConfigAutokeyState",
		"index": "." + $scope.exp + "." + $scope.slot + "." + $scope.port,
		"num": ""
	}, {
		"node": "outputNTPntpAuthenticaConfigMD5State",
		"index": "." + $scope.exp + "." + $scope.slot + "." + $scope.port,
		"num": ""
	}];
	publicService.loading('start');
	publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/getDeviceParamColl", arr).success(function(r) {
		if (r && r.data) {
			$scope.mauto = JSON.parse(r.data);
			_newVals();
		}
	});

	$scope.configSet = function(m) {
		var arr = [];
		if ($scope.port) {
			var port = $scope.port;
		} else {
			var port = '1'
		}
		ds = _changeVals(m);
		var configSub_obj = [];
		for (var j in ds) {
			obj = {};
			obj.value = ds[j];
			obj.node = j;
			obj.index = "." + $scope.exp + '.' + $scope.slot + "." + port;
			configSub_obj.push(obj);
		}
		configSubmit(configSub_obj);
		_newVals();
	}

	$scope.downloadConfig = function() {
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/downloadConfig/config", arr).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}


	$scope.downloadConfigauto = function(x) {
		var self = this;
		if ($scope.port) {
			var index = "." + $scope.exp + "." + $scope.slot + '.' + $scope.port;
		} else {
			var index = "." + $scope.exp + "." + $scope.slot + '.1';
		}
		var config_obj = [];
		config_obj = [{
			'node': x,
			'index': index
		}]
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/downloadConfig/config", config_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}
/**
	 * configSubmit
	 *   配置提交
	 */
	function configSubmit(configSub_obj) {
		if (!$scope.mauto) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return
		}
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/setConfigsBatch", configSub_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var doc;
			if (r.data.length == 0) {
				var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
				publicService.ngAlert(tt, "info");
				return;
			} else {
				if (r.data[0].code) {
					var tt = $translate.use() === 'ch' ? 　"设置成功" : "Set success";
					publicService.ngAlert(tt, "info");
				} else {
					publicService.ngAlert(r.data[0].message, "info");
				}
			}
		})
	}


	function _newVals() {
		var deviceContent = $scope.mauto;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		localStorage.setItem('valueDoms', JSON.stringify(obj));
	}

	function _changeVals(x) {
		var deviceContent = x;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		var _vals = JSON.parse(localStorage.getItem('valueDoms')),
			changeObj = {};
		for (var i = 0; i < obj.length; i++) {
			var _id = obj[i].name,
				_val = obj[i].value;
			for (var j = 0; j < _vals.length; j++) {
				var _id2 = _vals[j].name,
					_val2 = _vals[j].value;
				if (_id === _id2) {
					if (_val != _val2) {
						changeObj[_id] = _val;
					}
				}
			}
		}
		return changeObj;
	}
}]);