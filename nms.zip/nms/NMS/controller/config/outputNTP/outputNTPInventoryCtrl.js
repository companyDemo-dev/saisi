angular.module('outputNTPInventoryModule',[]).controller('outputNTPInventoryCtrl', ['$scope', '$stateParams', '$state',"$translate",'publicService', function($scope, $stateParams, $state,$translate,  publicService) {
	$scope.dev_Id = $stateParams.devid;
	$scope.slot = $stateParams.slot;
	$scope.exp = $stateParams.exp;

	var arr = [{"node": "outputNTPinventoryPartNum","index": "." + $scope.exp+"." + $scope.slot ,"num": ""},
			{"node": "outputNTPinventorySerialNum","index": "." + $scope.exp+"." + $scope.slot ,"num": ""},
			{"node": "outputNTPinventoryCLEINum","index": "." + $scope.exp+"." + $scope.slot ,"num": ""},
			{"node": "outputNTPinventoryHwNum","index": "." + $scope.exp+"." + $scope.slot ,"num": ""},
			{"node": "outputNTPinventorySwNum","index": "." + $scope.exp+"." + $scope.slot ,"num": ""},
			{"node": "outputNTPinventoryFPGAVersion","index": "." + $scope.exp+"." + $scope.slot ,"num": ""},
			{"node": "outputNTPinventoryCompatibilityNum","index": "." + $scope.exp+"." + $scope.slot ,"num": ""}];
	publicService.loading('start');
	publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/getDeviceParamColl", arr).success(function(r) {
		if(r && r.data){
			$scope.mauto = JSON.parse(r.data.replace('\n',''));
		}				
	});

	$scope.downloadConfig = function() {
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/downloadConfig/config", arr).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data.replace('\n','') + '';
		})
	}
}]);
