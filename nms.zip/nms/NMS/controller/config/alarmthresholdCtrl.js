angular.module('alarmthresholdModule', []).controller('alarmthresholdCtrl', ['$scope', '$state', '$rootScope', '$stateParams',  "$translate", '$state', 'publicService', function($scope, $state, $rootScope, $stateParams, $translate, $state, publicService) {

	$scope.portId1 = true;
	$scope.portId2 = false;
	$scope.soltId = '1';
	$scope.typeId = '1';
	/**
	 * downloadConfig
	 *   导出配置
	 */
	$scope.downloadConfig = function() {

		var self = this;
		if (!self.devID) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}

		var config_obj = [];
		var obj = {};
		obj.node = 'alarmConfigTable';
		obj.index = '';
		config_obj.push(obj);
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/downloadConfig/config", config_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}
	$scope.deviceContent = {};
	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data == null) return
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'SM2000') {
					deviceInfo.push(content[i]);
				}
			}
			$scope.deviceInfo = deviceInfo;
		}
	})


	$scope.seach = function() {
		var self = this;
		if($rootScope.sm2000devID){
		 self.devID = $rootScope.sm2000devID;
		}else{
			publicService.ngAlert('请选择设备', "info");
			return
		}

		if (self.devID.deviceStatus == 0) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}
		$scope.mauto = self.devID;
		publicService.loading('start');
		var devId = self.devID.id;
		var index = '.' + $scope.soltId + '.' + $scope.typeId;
		var dataObj = {},
			obj = [];
		for (var i = 1; i < 15; i++) {
			dataObj = {
				"node": "thresholdMTIElimit1Value",
				"index": index + '.' + i,
				"num": ""
			}
			obj.push(dataObj);
		}

		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + devId + "/getDeviceParamTable", obj).success(function(r) {
			if (r.data && r.data.length > 0) {
				$scope.configList = r.data;
			}
		});

		var dataObj2 = {},
			obj2 = [];
		for (var i = 1; i < 15; i++) {
			dataObj2 = {
				"node": "thresholdMTIElimit2Value",
				"index": index + '.' + i,
				"num": ""
			}
			obj2.push(dataObj2);
		}

		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + devId + "/getDeviceParamTable", obj2).success(function(r) {
			if (r.data && r.data.length > 0) {
				$scope.configList2 = r.data;
			}
		});


		var dataObj3 = {},
			obj3 = [];
		for (var i = 1; i < 15; i++) {
			dataObj3 = {
				"node": "thresholdTDEVValue",
				"index": index + '.' + i,
				"num": ""
			}
			obj3.push(dataObj3);
		}

		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + devId + "/getDeviceParamTable", obj3).success(function(r) {
			if (r.data && r.data.length > 0) {
				$scope.configList3 = r.data;
			}
		});


		var dataObj4 = {},
			obj4 = [];
		for (var i = 1; i < 15; i++) {
			dataObj4 = {
				"node": "thresholdFREQValue",
				"index": index + '.' + i,
				"num": ""
			}
			obj4.push(dataObj4);
		}

		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + devId + "/getDeviceParamTable", obj4).success(function(r) {
			if (r.data && r.data.length > 0) {
				$scope.configList4 = r.data;
			}
		});
	}

	$scope.listSetConfig = function(x) {
		$scope.deviceContent = x;
		_newVals();
	}
	$scope.change = function(x) {
		if (x == 1 || x == 2) {
			$scope.portId1 = true;
			$scope.portId2 = false;
		} else {
			$scope.portId1 = false;
			$scope.portId2 = true;
		}
	}
	$scope.configSub = function(x) {
		if (!verify.alarmthreshold(x, publicService, $translate)) return;

		var configSub_obj = [];
		var index = '.' + $scope.soltId + '.' + $scope.typeId + '.' + $scope.portId;
		if ($scope.alarmType == '1') {
			var node = 'thresholdMTIElimit1Value';
		} else if ($scope.alarmType == '2') {
			var node = 'thresholdMTIElimit2Value';
		} else if ($scope.alarmType == '3') {
			var node = 'thresholdTDEVValue';
		} else if ($scope.alarmType == '4') {
			var node = 'thresholdFREQValue';
		}
		obj = {};
		obj.value = x.value;
		obj.node = node;
		obj.index = index;
		configSub_obj.push(obj);


		configSubmit(configSub_obj);
		_newVals()
	}

	/**
	 * configSubmit
	 *   配置提交
	 */
	function configSubmit(configSub_obj) {
		if (!$scope.mauto) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return
		}
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/setConfigsBatch", configSub_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var doc;
			if (r.data.length == 0) {
				var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
				publicService.ngAlert(tt, "info");
				return;
			} else {
				var dataObj = r.data;
				var div = document.createElement('p');
				for (var i = 0; i < dataObj.length; i++) {
					if (dataObj[i].code === false) {
						var node = document.createTextNode(dataObj[i].message + ' ');
						div.appendChild(node);

					} else if (dataObj[i].code === true) {
						var node = document.createTextNode(dataObj[i].message + ' ');
						div.appendChild(node);
					}
				}
				var element = document.getElementById("ngTip");
				element.appendChild(div);
				var tt = $translate.use() === 'ch' ? 　"返回状态列表" : "Return state List";
				publicService.ngAlert(tt, "info");
				setTimeout(function() {
					element.removeChild(div);
					publicService.doRequest("GET", "/nms/spring/device/" + $scope.mauto.id + "/syncAlarms", {});
				}, 3000)
				$scope.seach();
			}

		})

	}

	function _newVals() {
		var deviceContent = $scope.deviceContent;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		localStorage.setItem('valueDoms', JSON.stringify(obj));
	}

	function _changeVals(x) {
		var deviceContent = x;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		var _vals = JSON.parse(localStorage.getItem('valueDoms')),
			changeObj = {};
		for (var i = 0; i < obj.length; i++) {
			var _id = obj[i].name,
				_val = obj[i].value;
			for (var j = 0; j < _vals.length; j++) {
				var _id2 = _vals[j].name,
					_val2 = _vals[j].value;
				if (_id === _id2) {
					if (_val != _val2) {
						changeObj[_id] = _val;
					}
				}
			}
		}
		return changeObj;
	}
}]);