angular.module('sm2000outputCardE1PConfigtableModule', []).controller('outputCardE1PConfigtableCtrl', ['$scope', '$stateParams', '$http', '$state', "$translate", 'publicService', function($scope, $stateParams, $http, $state, $translate, publicService) {
    $scope.mauto = $stateParams.mauto;
    $scope.deviceData = $stateParams.deviceData;
    if ($stateParams.mauto) {
        $scope.ioSignal = $stateParams.mauto.ioSignal;
        $scope.mainframeNum = $stateParams.mauto.ioStatusIndex;
        $scope.solt = $stateParams.mauto.ioStatusSlotID;
        $scope.ptpDevID = $stateParams.mauto.devID;
    }
    var objdata = []

    function loadPTPconfigData() {
        var indexs = '.' + $scope.mainframeNum + '.' + $scope.solt
        for (var i = 1; i < 17; i++) {
            var obj = {};
            var index = indexs + '.' + i;
            $scope.loadPTPconfigContent(index);
        }
    }

    $scope.loadPTPconfigContent = function(x) {
        var obj = [{
            "node": "outputConfigMainState",
            "index": x,
            "num": ""
        }, {
            "node": "outputConfigMainFrameType",
            "index": x,
            "num": ""
        }, {
            "node": "outputConfigMainCRCState",
            "index": x,
            "num": ""
        }, {
            "node": "outputConfigMainSSMState",
            "index": x,
            "num": ""
        }, {
            "node": "outputConfigMainSSMBit",
            "index": x,
            "num": ""
        }]
        publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/getDeviceParamColl", obj).success(function(r) {
            if (r.data && r.data.length > 0) {
                var obj = JSON.parse(r.data);
                objdata.push(obj);
                $scope.deviceContent = objdata;


                function huidiao(r) { //回调函数
                    var loadPortnamedata = r;
                    for (var i = 0; i < refdata.length; i++) {
                        if (i == 2) {
                            for (var j = 0; j < loadPortnamedata.length; j++) {
                                if (loadPortnamedata[j].portType == 'E1-T1') {
                                    if (loadPortnamedata[j].port == Nport) {
                                        portNamedata = loadPortnamedata[j].portName;
                                        refdata[i].portName = portNamedata;
                                        break
                                    } else {
                                        refdata[i].portName = 'E1-T1';
                                        break
                                    }
                                } else {
                                    refdata[i].portName = 'E1-T1';
                                }
                            }
                        }
                    }
                }

            }
        });
    }
    loadPTPconfigData();

    function loadreport(devId, port, callback) {
        var loadPortname = {};
        loadPortname.deviceId = devId;
        loadPortname.shelf = "";
        loadPortname.slot = "";
        loadPortname.portType = '';
        loadPortname.port = "";
        publicService.doRequest("GET", "/nms/spring/device/renamePort", loadPortname).success(function(r) {
            callback(r.data);
        })
    }


    /**
     * downloadConfig
     *   导出配置
     */
    $scope.downloadConfig = function(indexs) {
        var config_obj = [];

        var _vals = JSON.parse(localStorage.getItem('valueDoms'));
        for (var j = 0; j < _vals.length; j++) {
            var obj = {};
            if (_vals[j].name == "outE1Warmup" || _vals[j].name == "outE1Freerun" || _vals[j].name == "outE1Holdover" || _vals[j].name == "outE1Fasttrack") {
                obj.node = _vals[j].name;
                obj.index = indexs.substring(0, indexs.length - 2);
            } else {
                obj.node = _vals[j].name;
                obj.index = indexs;
            }
            config_obj.push(obj);
        }

        publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/downloadConfig/config", config_obj).success(function(r) {
            if (!r || !r.data || r.data.length < 0) return;
            window.location.href = 'http://' + location.hostname + r.data + '';
        })
    }

}]);
