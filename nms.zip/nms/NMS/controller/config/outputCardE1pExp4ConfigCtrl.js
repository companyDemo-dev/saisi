angular.module('sm2000outE1Exp4configModule',[]).controller('outE1Exp4config', ['$scope', '$stateParams',"ngDialog", '$http', '$state',"$translate", 'publicService', function($scope, $stateParams,ngDialog, $http, $state,$translate,  publicService) {
	$scope.mauto = $stateParams.mauto;
    $scope.deviceData = $stateParams.deviceData;

	if ($stateParams.mauto) {
		$scope.ioSignal = $stateParams.mauto.ioSignal;
		$scope.mainframeNum = $stateParams.mauto.ioStatusIndex;
		$scope.solt = $stateParams.mauto.ioStatusSlotID;
		$scope.ptpDevID = $stateParams.mauto.devID;
	}
	$scope.PTPport = '1';
	$scope.loadPTPconfigContent = function(x) {
		if ($scope.PTPport) {
			var index = '.' + $scope.mainframeNum + '.' + $scope.solt + '.' + $scope.PTPport;
		} else {
			var index = '.' + $scope.mainframeNum + '.' + $scope.solt + '.1';
		}
		$scope.indexE1 = index;
		var indexs = '.' + $scope.mainframeNum + '.' + $scope.solt;
		var obj = [{
			"node": "outputConfigExp4State",
			"index": index,
			"num": ""
		}, {
			"node": "outputConfigExp4FrameType",
			"index": index,
			"num": ""
		}, {
			"node": "outputConfigExp4CRCState",
			"index": index,
			"num": ""
		}, {
			"node": "outputConfigExp4SSMState",
			"index": index,
			"num": ""
		}, {
			"node": "outputConfigExp4SSMBit",
			"index": index,
			"num": ""
		}, {
			"node": "outE1Warmup",
			"index": indexs,
			"num": ""
		}, {
			"node": "outE1Freerun",
			"index": indexs,
			"num": ""
		}, {
			"node": "outE1Holdover",
			"index": indexs,
			"num": ""
		}, {
			"node": "outE1Fasttrack",
			"index": indexs,
			"num": ""
		}]
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/getDeviceParamColl", obj).success(function(r) {
			if (r.data && r.data.length > 0) {
				$scope.deviceContent = JSON.parse(r.data);
                loadreport($scope.ptpDevID)
				_newVals();
			}
		});
	}
	$scope.loadPTPconfigContent();
	
    function loadreport(devId) {
        var loadPortname = {};
        loadPortname.deviceId = devId;
        loadPortname.shelf = $scope.mainframeNum;
        loadPortname.slot = $scope.solt;
        loadPortname.portType = '';
        loadPortname.port = $scope.PTPport;
        publicService.doRequest("GET", "/nms/spring/device/renamePort", loadPortname).success(function(r) {
            var loadPortnamedata = r.data;
            if (loadPortnamedata.length > 0) {
                for (var i = 0; i < loadPortnamedata.length; i++) {
                    if ('E1-T1' == loadPortnamedata[i].portType) {
                        $scope.portNamedata = loadPortnamedata[i].portName;
                        return
                    } else {
                        $scope.portNamedata = $scope.ioSignal + '(' + $scope.PTPport + ')';
                    }
                }
            } else {
                $scope.portNamedata = $scope.ioSignal + '(' + $scope.PTPport + ')';
            }
        })
    }

    $scope.configCopy = function(x, toPTPport) {


        if (!$scope.toPTPport) {
            var tt = $translate.use() === 'ch' ? 　"请选择目标端口" : "Please select dist port";
            publicService.ngAlert(tt, "info");
            return;
        }
            t = $translate.use() === "ch" ? "确认将当前配置复制到端口" + toPTPport + "?" : "confirm copy to port" + toPTPport + "?";
            if (confirm(t)) {

                if ($scope.PTPport) {
                    var index = '.' + $scope.mainframeNum + '.' + $scope.solt + '.' + $scope.PTPport;
                } else {
                    var index = '.' + $scope.mainframeNum + '.' + $scope.solt + '.1';
                }
                $scope.indexE1 = index;
                var indexs = '.' + $scope.mainframeNum + '.' + $scope.solt;
		var obj = [{
			"node": "outputConfigExp4State",
			"index": index,
			"num": ""
		}, {
			"node": "outputConfigExp4FrameType",
			"index": index,
			"num": ""
		}, {
			"node": "outputConfigExp4CRCState",
			"index": index,
			"num": ""
		}, {
			"node": "outputConfigExp4SSMState",
			"index": index,
			"num": ""
		}, {
			"node": "outputConfigExp4SSMBit",
			"index": index,
			"num": ""
		}, {
			"node": "outE1Warmup",
			"index": indexs,
			"num": ""
		}, {
			"node": "outE1Freerun",
			"index": indexs,
			"num": ""
		}, {
			"node": "outE1Holdover",
			"index": indexs,
			"num": ""
		}, {
			"node": "outE1Fasttrack",
			"index": indexs,
			"num": ""
		}]
                publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/portConfigCopy?destPort=" + toPTPport, obj).success(function(r) {
                    if (!r || !r.data || r.data.length < 0) return;
                    publicService.ngAlert("操作成功", "info");
                })

            }
        }
	function _newVals() {
		var deviceContent = $scope.deviceContent;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		localStorage.setItem('valueDoms', JSON.stringify(obj));
	}

	function _changeVals(x) {
		var deviceContent = x;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		var _vals = JSON.parse(localStorage.getItem('valueDoms')),
			changeObj = {};
		for (var i = 0; i < obj.length; i++) {
			var _id = obj[i].name,
				_val = obj[i].value;
			for (var j = 0; j < _vals.length; j++) {
				var _id2 = _vals[j].name,
					_val2 = _vals[j].value;
				if (_id === _id2) {
					if (_val != _val2) {
						changeObj[_id] = _val;
					}
				}
			}
		}
		return changeObj;
	}

	$scope.configSub = function(x, index, currentUrl, flag) {
		var indexObj = '.' + $scope.mainframeNum + '.' + $scope.solt;
		ds = _changeVals(x);
		var configSub_obj = [];
		flag = true;
		ip = true;
		vlanF = true;
		for (var j in ds) {
			obj = {};
			switch (j) {
				case "outE1Freerun":
					var outE1Freerun = $scope.deviceContent.outE1Freerun;
					obj.value = outE1Freerun;
					obj.node = 'outE1Freerun';
					obj.index = indexObj;
					configSub_obj.push(obj);
					break;
				case "outE1Holdover":
					var outE1Holdover = $scope.deviceContent.outE1Holdover;
					obj.value = outE1Holdover;
					obj.node = 'outE1Holdover';
					obj.index = indexObj;
					configSub_obj.push(obj);
					break;
				case "outE1Fasttrack":
					var outE1Fasttrack = $scope.deviceContent.outE1Fasttrack;
					obj.value = outE1Fasttrack;
					obj.node = 'outE1Fasttrack';
					obj.index = indexObj;
					configSub_obj.push(obj);
					break;
				case "outE1Warmup":
					var outE1Warmup = $scope.deviceContent.outE1Warmup;
					obj.value = outE1Warmup;
					obj.node = 'outE1Warmup';
					obj.index = indexObj;
					configSub_obj.push(obj);
					break;
				default:
					obj.value = ds[j];
					obj.node = j;
					obj.index = index;
					configSub_obj.push(obj);
			}
		}
		configSubmit(configSub_obj, index, currentUrl);
		_newVals()
	}

	/**
	 * configSubmit
	 *   配置提交
	 */
	function configSubmit(configSub_obj, index, currentUrl) {
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/setConfigsBatch", configSub_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			if (r.data.length == 0) {
					var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
					publicService.ngAlert(tt, "info");
				return;
			} else {
				var dataObj = r.data;
					var div = document.createElement('p');
				for (var i = 0; i < dataObj.length; i++) {
						var node = document.createTextNode(dataObj[i].message+' ');
						div.appendChild(node);
				}
				var element = document.getElementById("ngTip");
				element.appendChild(div);
				var tt = $translate.use() === 'ch' ? 　"返回状态列表" : "Return state List";
				publicService.ngAlert(tt, "info");
				setTimeout(function() {
					element.removeChild(div);
				}, 3000)
			}

		})

	}
			/**
	 * downloadConfig
	 *   导出配置
	 */
	$scope.downloadConfig = function(indexs) {
		var config_obj = [];

		var _vals = JSON.parse(localStorage.getItem('valueDoms'));
		for (var j = 0; j < _vals.length; j++) {
			var obj = {};
			if (_vals[j].name == "outE1Warmup" || _vals[j].name == "outE1Freerun" || _vals[j].name == "outE1Holdover" || _vals[j].name == "outE1Fasttrack" ) {
				obj.node = _vals[j].name;
				obj.index = indexs.substring(0, indexs.length - 2);
			} else {
				obj.node = _vals[j].name;
				obj.index = indexs;
			}
			config_obj.push(obj);
		}

		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/downloadConfig/config", config_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}
    $scope.E1configall = function(mauto, deviceData) {
        ngDialog.open({
            template: "template/dialog/outE1configtable4.html",
            className: 'ngdialog-theme-default ngdialog-theme-custom',
            width: '600px',
            padding: '20px',
            controller: function($scope, $stateParams, publicService) {
                $scope.mauto = mauto;
                $scope.deviceData = deviceData;
                if (mauto) {
                    $scope.ioSignal = mauto.ioSignal;
                    $scope.mainframeNum = mauto.ioStatusIndex;
                    $scope.slot = mauto.ioStatusSlotID;
                    $scope.ptpDevID = mauto.devID;
                }
                var objdata = []

                function loadPTPconfigData() {
                    var indexs = '.' + $scope.mainframeNum + '.' + $scope.slot
                    for (var i = 1; i < 17; i++) {
                        var obj = {};
                        var index = indexs + '.' + i;
                        $scope.loadPTPconfigContent(index,i);
                    }
                }

                $scope.loadPTPconfigContent = function(x,m) {
                    var obj = [{
                        "node": "outputConfigExp4State",
                        "index": x,
                        "num": ""
                    }, {
                        "node": "outputConfigExp4FrameType",
                        "index": x,
                        "num": ""
                    }, {
                        "node": "outputConfigExp4CRCState",
                        "index": x,
                        "num": ""
                    }, {
                        "node": "outputConfigExp4SSMState",
                        "index": x,
                        "num": ""
                    }, {
                        "node": "outputConfigExp4SSMBit",
                        "index": x,
                        "num": ""
                    }]
                    publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/getDeviceParamColl", obj).success(function(r) {
                        if (r.data && r.data.length > 0) {
                            var obj = JSON.parse(r.data);
                            objdata.push(obj);
                            if(m == 15){
                               function huidiao(r) { //回调函数
                                var loadPortnamedata = r;
                                for (var i = 0; i < objdata.length; i++) {
                                        var Nport = i +1;
                                        for (var j = 0; j < loadPortnamedata.length; j++) {
                                            if (loadPortnamedata[j].portType == 'E1-T1') {
                                                if (loadPortnamedata[j].port == Nport) {
                                                    portNamedata = loadPortnamedata[j].portName;
                                                    objdata[i].portName = portNamedata;
                                                    break
                                                } else {
                                                    objdata[i].portName = 'E1-T1';
                                                }
                                            } else {
                                                objdata[i].portName = 'E1-T1';
                                            }
                                        }
                                }
                            }
                            loadreport($scope.ptpDevID, mauto, huidiao);
                            }
                            $scope.deviceContent = objdata;
                        }
                    });
                }
                loadPTPconfigData();

           function loadreport(devId, mauto, callback) {
                    var loadPortname = {};
                    loadPortname.deviceId = devId;
                    loadPortname.shelf = mauto.ioStatusIndex;
                    loadPortname.slot = mauto.ioStatusSlotID;
                    loadPortname.portType = '';
                    loadPortname.port = "";
                    publicService.doRequest("GET", "/nms/spring/device/renamePort", loadPortname).success(function(r) {
                        callback(r.data);
                    })
                }

                /**
                 * downloadConfig
                 *   导出配置
                 */
                $scope.downloadConfig = function(indexs) {
                    var config_obj = [];

                    var _vals = JSON.parse(localStorage.getItem('valueDoms'));
                    for (var j = 0; j < _vals.length; j++) {
                        var obj = {};
                        if (_vals[j].name == "outE1Warmup" || _vals[j].name == "outE1Freerun" || _vals[j].name == "outE1Holdover" || _vals[j].name == "outE1Fasttrack") {
                            obj.node = _vals[j].name;
                            obj.index = indexs.substring(0, indexs.length - 2);
                        } else {
                            obj.node = _vals[j].name;
                            obj.index = indexs;
                        }
                        config_obj.push(obj);
                    }

                    publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/downloadConfig/config", config_obj).success(function(r) {
                        if (!r || !r.data || r.data.length < 0) return;
                        window.location.href = 'http://' + location.hostname + r.data + '';
                    })
                }


            }
        })
    }
}]);
