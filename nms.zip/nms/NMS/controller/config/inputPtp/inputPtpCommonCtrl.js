angular.module('sm2000inputPtpCommonModule', []).controller('inputPtpCommonCtrl', ['$scope', '$stateParams', '$state', "$translate", 'publicService', function($scope, $stateParams, $state, $translate, publicService) {
	$scope.dev_Id = $stateParams.devid;
	$scope.slot = $stateParams.slot;

	var arr = [{
		"node": "inputPTPCommonConfigPpsCableDelay",
		"index": "." + $scope.slot,
		"num": ""
	},{
		"node": "inputPTPCommonConfigPriority",
		"index": "." + $scope.slot,
		"num": ""
	}];
	publicService.loading('start');
	publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/getDeviceParamColl", arr).success(function(r) {
		if (r && r.data) {
			$scope.inputPTPCommonConfigPpsCableDelay = JSON.parse(r.data).inputPTPCommonConfigPpsCableDelay;
			$scope.inputPTPCommonConfigPriority = JSON.parse(r.data).inputPTPCommonConfigPriority;
		}
	});

	$scope.subCommon = function(m) {
		var tt = $translate.use() === 'ch',
			str = "",
			str1 = "",
			str2 = "",
			str3 = "",
			_self = this;
		if (!tt) {
			str = "Please input ";
			str1 = " Number between -500000 - 500000";
			str2 = "Please input ";
			str3 = " Number between 0 - 255";
		} else {
			str = "请输入";
			str1 = " 为-500000 - 500000之间的数字";
			str2 = "请输入";
			str3 = " 为0 - 255之间的数字";
		}
		if (verifyFun.isNull(_self.inputPTPCommonConfigPpsCableDelay)) {
			publicService.ngAlert(str + "inputPTPCommonConfigPpsCableDelay", "info");
			return;
		}
		if (!verifyFun.between(_self.inputPTPCommonConfigPpsCableDelay, -500000, 500000)) {
			publicService.ngAlert("inputPTPCommonConfigPpsCableDelay" + str1, "info");
			return;
		}
		if (verifyFun.isNull(_self.inputPTPCommonConfigPriority)) {
			publicService.ngAlert(str2 + "inputPTPCommonConfigPriority", "info");
			return;
		}
		if (!verifyFun.between(_self.inputPTPCommonConfigPriority, 0, 255)) {
			publicService.ngAlert("inputPTPCommonConfigPriority" + str3, "info");
			return;
		}
		var pars = [{
			"node": "inputPTPCommonConfigPpsCableDelay",
			"index": '.' + $scope.slot,
			"value": _self.inputPTPCommonConfigPpsCableDelay
		},{
			"node": "inputPTPCommonConfigPriority",
			"index": '.' + $scope.slot,
			"value": _self.inputPTPCommonConfigPriority
		}];
		publicService.loading('start');
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/setConfigsBatch", pars).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var dataObj = r.data,
				str = "";
			if (dataObj[0].code) {
				var tt = $translate.use() === 'ch' ? 　"设置成功" : "Set success";
				publicService.ngAlert(tt, "info");
			} else {
				publicService.ngAlert(dataObj[0].message, "info");
			}
		})
	}

	$scope.downloadConfig = function() {
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/downloadConfig/config", arr).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}
}]);