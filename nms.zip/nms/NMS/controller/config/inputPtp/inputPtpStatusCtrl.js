angular.module('sm2000inputPtpStatusModule',[]).controller('inputPtpStatusCtrl', ['$scope', '$stateParams', '$state',"$translate",'publicService', function($scope, $stateParams, $state,$translate,  publicService) {
	$scope.dev_Id = $stateParams.devid;
	$scope.slot = $stateParams.slot;

	var arr = [{"node": "inputPTPStatusCurrFLLstate","index":"." +  $scope.slot ,"num": ""},
			{"node": "inputPTPStatusFLLstateDuration","index":"." +  $scope.slot ,"num": ""},
			{"node": "inputPTPStatusForwardFlowWeight","index":"." +  $scope.slot ,"num": ""},
			{"node": "inputPTPStatusReverseFlowWeight","index":"." +  $scope.slot ,"num": ""},
			{"node": "inputPTPStatusCorrectionFrequency","index":"." +  $scope.slot ,"num": ""},
			{"node": "inputPTPStatusPhaseCorrection","index":"." +  $scope.slot ,"num": ""},
			{"node": "inputPTPResidualPhaseError","index":"." +  $scope.slot ,"num": ""},
			{"node": "inputPTPMinimalRTD","index":"." +  $scope.slot ,"num": ""},
			{"node": "inputPTPPacketRateGM1","index":"." +  $scope.slot ,"num": ""},
			{"node": "inputPTPPacketRateDelay","index":"." +  $scope.slot ,"num": ""},
			{"node": "inputPTPClientConfigState","index":"." +  $scope.slot ,"num": ""},
			{"node": "inputPTPActiveRef","index":"." +  $scope.slot ,"num": ""},
			{"node": "inputPTPOverallQuality","index":"." +  $scope.slot ,"num": ""}];
	publicService.loading('start');
	publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/getDeviceParamColl", arr).success(function(r) {
		if(r && r.data){
			var obj = JSON.parse(r.data);
			if(obj.inputPTPOverallQuality == '1' && obj.inputPTPActiveRef == '1'){
				obj.inputPTPOverallQuality = '2';
			}else if(obj.inputPTPOverallQuality == '1' && obj.inputPTPActiveRef != '1'){
				obj.inputPTPOverallQuality = '1';
			}else{
				obj.inputPTPOverallQuality = '0';
			}
			if(obj.inputPTPClientConfigState == '1'){
				obj.inputPTPClientConfigState = 'enable';
			}else if(obj.inputPTPClientConfigState == '0'){
				obj.inputPTPClientConfigState = 'disable';
			}
			$scope.mauto = obj;
		}				
	});

	$scope.downloadConfig = function() {
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/downloadConfig/config", arr).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}

}]);

