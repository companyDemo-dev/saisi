angular.module('sm2000inputPtpInventoryModule',[]).controller('inputPtpInventoryCtrl', ['$scope', '$stateParams', '$state',"$translate",'publicService', function($scope, $stateParams, $state,$translate,  publicService) {
	$scope.dev_Id = $stateParams.devid;
	$scope.slot = $stateParams.slot;

	var arr = [{"node": "inputPTPinventoryAssetNum","index": "." + $scope.slot ,"num": ""},
			{"node": "inputPTPinventoryCLEINum","index": "." + $scope.slot ,"num": ""},
			{"node": "inputPTPinventoryFPGAVersion","index": "." + $scope.slot ,"num": ""},
			{"node": "inputPTPinventoryHwNum","index": "." + $scope.slot ,"num": ""},
			{"node": "inputPTPinventoryPartNum","index": "." + $scope.slot ,"num": ""},
			{"node": "inputPTPinventorySerialNum","index": "." + $scope.slot ,"num": ""},
			{"node": "inputPTPinventorySwNum","index": "." + $scope.slot ,"num": ""}];
	publicService.loading('start');
	publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/getDeviceParamColl", arr).success(function(r) {
		if(r && r.data){
			$scope.mauto = JSON.parse(r.data);
		}				
	});

	$scope.downloadConfig = function() {
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/downloadConfig/config", arr).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}
}]);
