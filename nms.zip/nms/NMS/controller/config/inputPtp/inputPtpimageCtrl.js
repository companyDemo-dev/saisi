angular.module('sm2000inputPtpimageModule',[]).controller('inputPtpimageCtrl', ['$scope', '$stateParams', '$state',"$translate",'publicService', function($scope, $stateParams, $state,$translate,  publicService) {
	$scope.dev_Id = $stateParams.devid;
	$scope.slot = $stateParams.slot;


	var arr = [{"node": "inputPTPimageActiveImage","index":"." +  $scope.slot ,"num": ""},
			{"node": "inputPTPimageActiveVersion","index":"." +  $scope.slot ,"num": ""},
			{"node": "inputPTPimageBackupImage","index":"." +  $scope.slot ,"num": ""},
			{"node": "inputPTPinventoryHwNum","index":"." +  $scope.slot ,"num": ""},
			{"node": "inputPTPimageBackupVersion","index":"." +  $scope.slot ,"num": ""},
			{"node": "inputPTPimageCurrentImage","index":"." +  $scope.slot ,"num": ""}];
	publicService.loading('start');
	publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/getDeviceParamColl", arr).success(function(r) {
		if(r && r.data){
			$scope.mauto = JSON.parse(r.data);
		}				
	});

	$scope.downloadConfig = function() {
		var arrs = [{node : "inputPTPimageTable",index : ''}];
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/downloadConfig/config", arrs).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}

	$scope.imageSet = function(m){
		var tt = $translate.use() === 'ch', str = "", str1 = "", _self = this;
		if(!tt){
			str = "Please input ";
			str1 = " Number between 1-2";
		}else{
			str = "请输入";
			str1 = " 为1-2之间的数字";
		}
		if(verifyFun.isNull(_self.deviceContent.inputPTPimageCurrentImage)){
			publicService.ngAlert(str + "imageCurrentImage", "info");
			return;
		}
		if(!verifyFun.between(_self.deviceContent.inputPTPimageCurrentImage,1,2)){
			publicService.ngAlert("imageCurrentImage" + str1, "info");
			return;
		}
		var arr = [{"node": "inputPTPimageCurrentImage", "index": '.' + $scope.slot ,"value" : _self.mauto.inputPTPimageCurrentImage}];
		publicService.loading('start');
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/setConfigsBatch", arr).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			// var dataObj = r.data, str = "";
			// if(dataObj[0].code){
			// 	var tt = $translate.use() === 'ch' ? 　"设置成功" : "Set success";
			// 	publicService.ngAlert(tt, "info");
			// 	// $scope.mauto.inputPTPimageCurrentImage = _self.inputPTPimageCurrentImage;
			// }else{
			// 	publicService.ngAlert(dataObj[0].message, "info");
			// }
			
			//检测底层设置数据是否真实更新（因为底层返回数据存在问题 没办法 只好在拉一次数据- -！）
			var tt = $translate.use() === 'ch' ? 　"设置成功" : "Set success",
				tt1 = $translate.use() === 'ch' ? 　"设置失败" : "Set fail",
				arr = [{"node": "inputPTPimageCurrentImage","index":"." +  $scope.slot, "num" : ""}];
			publicService.loading('start');
			publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/getDeviceParamColl", arr).success(function(r) {
				if(r && r.data){
					if(JSON.parse(r.data).inputPTPimageCurrentImage != _self.mauto.inputPTPimageCurrentImage){
						publicService.ngAlert(tt1, "info");
					}else{
						publicService.ngAlert(tt, "info");
					}
				}				
			});
		})
	}

}]);
