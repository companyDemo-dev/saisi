angular.module('sm2000inputPtprestartModule',[]).controller('inputPtprestartCtrl', ['$scope', '$stateParams', "$timeout",'$state',"$translate",'publicService', function($scope, $stateParams, $timeout,$state,$translate,  publicService) {
	$scope.dev_Id = $stateParams.devid;
	$scope.slot = $stateParams.slot;
	$scope.mauto = {};
	$scope.mauto.mod = "inputPTPrestartPTPclient";
	$scope.mauto.str = "0";

	$scope.$watch('mauto.mod',function(newValue,oldValue, scope){
		if(newValue === "inputPTPrestartAction"){
			$scope.mauto.port = "1";
		}else{
			$scope.mauto.str = "0";
		}
	});

	$scope.restartSet = function(m){
		var arr =[];
		if(m.mod === "inputPTPrestartAction"){
			arr = [{"node": m.mod, "index": '.' + $scope.slot + '.' + m.port,"value" : "1"}]
		}else{
			arr = [{"node": m.mod, "index": '.' + $scope.slot + '.0', "value" : m.str}]
		}
		publicService.loading('start');
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/setConfigsBatch", arr).success(function(r) {
			publicService.loading('start');
			$timeout(function(){
				if(m.mod === "inputPTPrestartAction"){
					var pars = [{"node": "inputPtpRestartResult", "index": '.' + $scope.slot + '.' + m.port}]
				}else{
					var pars = [{"node": "inputPtpRestartResult", "index": '.' + $scope.slot + '.0'}]
				}
				publicService.loading('start');
				publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/getDeviceParamColl", pars).success(function(rr) {
					if(rr && rr.data){
						var s = JSON.parse(rr.data),
							tt = $translate.use() === 'ch', str1 = "", str2 = "";
						if(!tt){
							str1 = "restart success";
							str2= "restart fail";
						}else{
							str1 = "重启成功";
							str2 = "重启失败";
						}
						if(s.inputPtpRestartResult == "1"){
							publicService.ngAlert(str1, "info");
						}else{
							publicService.ngAlert(str2, "success");
						}
					}
					publicService.loading('end');
				})
			},9000)
		})
	}
}]);
