angular.module('sm2000inputPtpClientModule',[]).controller('inputPtpClientCtrl', ['$scope', '$stateParams', '$state',"$translate",'publicService', function($scope, $stateParams, $state,$translate,  publicService) {
	$scope.dev_Id = $stateParams.devid;
	$scope.slot = $stateParams.slot;
	$scope.mauto = {};
	$scope.oldDate = {};

	var arr = [{"node": "inputPTPClientConfigState","index":"." +  $scope.slot ,"num": ""},
			{"node": "inputPTPClientConfigProfile","index":"." +  $scope.slot ,"num": ""},
			{"node": "inputPTPClientConfigGM1addr","index":"." +  $scope.slot ,"num": ""},
			{"node": "inputPTPClientConfigGM1state","index":"." +  $scope.slot ,"num": ""},
			{"node": "inputPTPClientConfigGM2addr","index":"." +  $scope.slot ,"num": ""},
			{"node": "inputPTPClientConfigGM2state","index":"." +  $scope.slot ,"num": ""},
			{"node": "inputPTPClientConfigDomain","index":"." +  $scope.slot ,"num": ""},
			{"node": "inputPTPClientConfigAnnounceIntv","index":"." +  $scope.slot ,"num": ""},
			{"node": "inputPTPClientConfigSyncIntv","index":"." +  $scope.slot ,"num": ""},
			{"node": "inputPTPClientConfigDelayIntv","index":"." +  $scope.slot ,"num": ""},
			{"node": "inputPTPClientConfigDSCP","index":"." +  $scope.slot ,"num": ""}];
	publicService.loading('start');
	publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/getDeviceParamColl", arr).success(function(r) {
		if(r && r.data){
			$scope.mauto = JSON.parse(r.data);
			$scope.oldDate = angular.extend({},$scope.mauto);
		}				
	});
	$scope.downloadConfig = function() {
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/downloadConfig/config", arr).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}

	function oldfilter(m){ //只针对修改过的值
		var pars = [], list = $scope.oldDate;
		for(var i in list){
			if(list[i] !== m[i]){
				pars.push({"node": i,"index":"." +  $scope.slot ,"value" : m[i]});
			}				
		}
		return pars
	}

	$scope.subClient = function(m){
		if (!verify.inputPTPClient(m, publicService, $translate)) return;
		publicService.loading('start');
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/setConfigsBatch", oldfilter(m)).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var dataObj = r.data, str = "";
			if(dataObj[0].code){
				var tt = $translate.use() === 'ch' ? 　"设置成功" : "Set success";
				publicService.ngAlert(tt, "info");
			}else{
				publicService.ngAlert(dataObj[0].message, "info");
			}
			$scope.oldDate = angular.extend({},m);
		})

	}
}]);
