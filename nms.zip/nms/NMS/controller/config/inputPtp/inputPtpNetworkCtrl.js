angular.module('sm2000inputPtpNetworkModule',[]).controller('inputPtpNetworkCtrl', ['$scope', '$stateParams', '$state',"$translate",'publicService', function($scope, $stateParams, $state,$translate,  publicService) {
	$scope.dev_Id = $stateParams.devid;
	$scope.slot = $stateParams.slot;
	$scope.port = '1';
	$scope.mauto = {};
	

	function parms(port){
		var arr = [{"node": "inputPTPNetworkConfigIpState","index":"." +  $scope.slot + "." + port, "num" : ""},
			{"node": "inputPTPNetworkConfigIpInfo","index":"." +  $scope.slot + "." + port, "num" : ""}];
		return arr;
	}


	dataNet($scope.dev_Id, parms($scope.port));

	$scope.dataNetwork = function(port){
		dataNet($scope.dev_Id, parms(port))
	}
	function dataNet(deviceid, p){
		publicService.loading('start');
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + deviceid + "/getDeviceParamColl", p).success(function(r) {
			if(r && r.data){
				var d = JSON.parse(r.data);
				$scope.mauto.inputPTPNetworkConfigIpState = d.inputPTPNetworkConfigIpState;
				var info = d.inputPTPNetworkConfigIpInfo.split(',');
				$scope.mauto.address = info[0];
				$scope.mauto.netmask = info[1];
				$scope.mauto.gateway = info[2];
			}				
		});
	}
	$scope.subNetwork = function(m){
		if (!verify.inputPTPNetwork(m, publicService, $translate)) return;
		publicService.loading('start');
		var arr = [{"node": "inputPTPNetworkConfigIpState", "index": '.' + $scope.slot + '.' + $scope.port, "value" : m.inputPTPNetworkConfigIpState},
				{"node": "inputPTPNetworkConfigIpInfo", "index": '.' + $scope.slot +'.' +  $scope.port,"value" : m.address + "," + m.netmask + "," + m.gateway}];
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/setConfigsBatch", arr).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var dataObj = r.data, str = "";
			if(dataObj[0].code){
				var tt = $translate.use() === 'ch' ? 　"设置成功" : "Set success";
				publicService.ngAlert(tt, "info");
			}else{
				publicService.ngAlert(dataObj[0].message, "info");
			}
		})
	}

	$scope.downloadConfig = function() {
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/downloadConfig/config", parms($scope.port)).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}
}]);
