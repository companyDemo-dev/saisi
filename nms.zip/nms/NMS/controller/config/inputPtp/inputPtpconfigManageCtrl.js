angular.module('sm2000inputPtpconfigManageModule',[]).controller('inputPtpconfigManageCtrl', ['$scope', '$stateParams', '$state',"$translate",'publicService', function($scope, $stateParams, $state,$translate,  publicService) {
	$scope.dev_Id = $stateParams.devid;
	$scope.slot = $stateParams.slot;
	$scope.mod = "inputPTPconfigManageBackup";

	$scope.configManageSet = function(m){
		var arr = [{"node": m, "index": '.' + $scope.slot ,"value" : "1"}];
		publicService.loading('start');
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.dev_Id + "/setConfigsBatch", arr).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var dataObj = r.data, str = "";
			if(dataObj[0].code){
				var tt = $translate.use() === 'ch' ? 　"设置成功" : "Set success";
				publicService.ngAlert(tt, "info");
			}else{
				publicService.ngAlert(dataObj[0].message, "info");
			}
		})
	}
}]);
