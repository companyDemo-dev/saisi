angular.module('sm2000imageInfoModule',[]).controller('imageInfoCtrl', ['$scope', 'publicService', function($scope, publicService) {
	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data == null) return
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'SM2000') {
					deviceInfo.push(content[i]);
				}
			}
			$scope.deviceInfo = deviceInfo;
		}
	})


	$scope.macChange = function(x) {
		imageInfolist(x);
	}


	function imageInfolist(x) {
		var obj = 'imageInfoTable';
		publicService.doRequest("GET", "/nms/spring/deviceConfig/" + x.id + "/configs/" + obj + "").success(function(r) {
			var data = r.data;
			var objData = [];
			for (i = 0; i < data.length; i++) {
				var obj = {};
				if (data[i].imageInfoModuleID == 'MC') {
					obj.module = data[i].imageInfoModuleID;
					if (data[i].imageCurrentState == 'active') {
						obj.active = data[i].imageVersion;
					}
					if (data[i].imageCurrentState == 'backup') {
						obj.backup = data[i].imageVersion;
					}
				}
				if (data[i].imageInfoModuleID == 'CC1') {
					obj.module = data[i].imageInfoModuleID;
					if (data[i].imageCurrentState == 'active') {
						obj.active = data[i].imageVersion;
					}
					if (data[i].imageCurrentState == 'backup') {
						obj.backup = data[i].imageVersion;
					}
				}
				if (data[i].imageInfoModuleID == 'CC2') {
					obj.module = data[i].imageInfoModuleID;
					if (data[i].imageCurrentState == 'active') {
						obj.active = data[i].imageVersion;
					}
					if (data[i].imageCurrentState == 'backup') {
						obj.backup = data[i].imageVersion;
					}
				}
				if (data[i].imageInfoModuleID == 'INPUT1') {
					obj.module = data[i].imageInfoModuleID;
					if (data[i].imageCurrentState == 'active') {
						obj.active = data[i].imageVersion;
					}
					if (data[i].imageCurrentState == 'backup') {
						obj.backup = data[i].imageVersion;
					}
				}
				if (data[i].imageInfoModuleID == 'INPUT2') {
					obj.module = data[i].imageInfoModuleID;
					if (data[i].imageCurrentState == 'active') {
						obj.active = data[i].imageVersion;
					}
					if (data[i].imageCurrentState == 'backup') {
						obj.backup = data[i].imageVersion;
					}
				}
				objData.push(obj);
			}
			$scope.imageInfolist = objData;
		})
	}
}]);
