angular.module('sm2000outputCardPTPConfigModule',[]).controller('outputCardPTPConfigCtrl', ['$scope', '$stateParams', '$http', "$translate", '$state', 'publicService', function($scope, $stateParams, $http, $translate, $state, publicService) {

	$scope.portNamedata = '';
	$scope.mauto = $stateParams.mauto;
    $scope.deviceData = $stateParams.deviceData;
	if ($stateParams.mauto) {
		$scope.ioSignal = $stateParams.mauto.ioSignal;
		$scope.mainframeNum = $stateParams.mauto.ioStatusIndex;
		$scope.solt = $stateParams.mauto.ioStatusSlotID;
		$scope.ptpDevID = $stateParams.mauto.devID;
	}
	$scope.PTPport = '1';
	$scope.vm = {
		"activeTab": 1
	};
	$scope.outputPTPntpSub = true;


	$scope.loadPTPconfigContent = function(x) {
		var par = document.getElementById('popover');
		angular.element(par).removeClass('popoverS');
		if ($scope.PTPport) {
			var index = '.' + $scope.mainframeNum + '.' + $scope.solt + '.' + $scope.PTPport;
		} else {
			var index = '.' + $scope.mainframeNum + '.' + $scope.solt + '.1';
		}
		$scope.indexs = index;
		var indexs = '.' + $scope.mainframeNum + '.' + $scope.solt;
		$scope.indexss = indexs;
		if ($scope.vm) {
			if ($scope.vm.activeTab == 1) {
				var obj = [{
					"node": "outputPTPCommonConfigServiceMode",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPCommonConfigPTPstate",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPCommonConfigMaxClients",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPCommonConfigProfile",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPCommonConfigClockID",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPCommonConfigPriority1",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPCommonConfigPriority2",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPCommonConfigDomain",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPCommonConfigDSCP",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPCommonConfigAnnounceLimit",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPCommonConfigSyncLimit",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPCommonConfigDelayLimit",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPCommonConfigDSCPstate",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPCommonConfigTTL",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPCommonConfigTwoStep",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPCommonConfigUnicastNegotiate",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPCommonConfigAlternateMaster",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPCommonConfigMgmtAddrMode",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPCommonConfigDither",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPCommonConfigUnicastLeaseDuration",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPCommonOtherConfigTimaScale",
					"index": indexs,
					"num": ""
				}]
			} else if ($scope.vm.activeTab == 2) {
				var obj = [{
					"node": "outputPTPMulticastVlanID",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPMulticastSyncIntv",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPMulticastAnnounceIntv",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPMulticastDelayIntv",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPMulticastAnnounceTimeout",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPMulticastClientTimeout",
					"index": index,
					"num": ""
				}];
			} else if ($scope.vm.activeTab == 3) {
				var obj = [{
					"node": "outputPTPSynceESMCstate",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPSynceQLstate",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPSynceOutQLmode",
					"index": index,
					"num": ""
				}];
			} else if ($scope.vm.activeTab == 4) {
				var obj = [{
					"node": "outputPTPNetworkConfigIpState",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPNetworkConfigIpInfo",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPNetworkConfigVlanMode",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPNetworkConfigAutoNegState",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPNetworkConfigSpeed",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPNetworkConfigDuplex",
					"index": index,
					"num": ""
				}];
			} else if ($scope.vm.activeTab == 5) {
				var obj = [{
					"node": "outputPTPSynceStatusEthMode",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPSynceStatusESMCstatus",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPSynceStatusTXssm",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPStatusPortEnabled",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPStatusClockID",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPStatusProfile",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPStatusPortState",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPStatusClockClass",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPStatusClockAccuracy",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPStatusTimescale",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPStatusClientNum",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPStatusNetworkHWAddr",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPStatusClientLoad",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPclockState",
					"index": indexs,
					"num": ""
				}, {
					"node": "outputPTPclockCurrentTime",
					"index": indexs,
					"num": ""
				}, {
					"node": "outputPTPclockRunningTime",
					"index": indexs,
					"num": ""
				}, {
					"node": "outputPTPimageActiveImage",
					"index": indexs,
					"num": ""
				}, {
					"node": "outputPTPimageActiveVersion",
					"index": indexs,
					"num": ""
				}, {
					"node": "outputPTPimageBackupImage",
					"index": indexs,
					"num": ""
				}, {
					"node": "outputPTPimageBackupVersion",
					"index": indexs,
					"num": ""
				}, {
					"node": "outputPTPimageCurrentImage",
					"index": indexs,
					"num": ""
				}]
			} else if ($scope.vm.activeTab == 6) {
				var obj = [{
					"node": "outputPTPrxAnnounceMessageClockID",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPrxAnnounceMessageClockClass",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPrxAnnounceMessageClockAccuracy",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPrxAnnounceMessageOffsetScaled",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPrxAnnounceMessageOffsetScaledLogVariance",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPrxAnnounceMessagePriority1",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPrxAnnounceMessagePriority2",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPrxAnnounceMessageTimeSource",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPrxAnnounceMessageCurrUtcOffset",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPrxAnnounceMessageStepsRemoved",
					"index": index,
					"num": ""
				}]
			} else if ($scope.vm.activeTab == 7) {
				$scope.loadMD5keyList();
				var obj = [{
					"node": "outputPTPntpAuthenticaConfigAutokeyState",
					"index": index,
					"num": ""
				}, {
					"node": "outputPTPntpAuthenticaConfigMD5State",
					"index": index,
					"num": ""
				}]
			} else if ($scope.vm.activeTab == 8) {
				$scope.loadPTPntpCount('outputPTPntpWhitelistCount', 'White');
				var obj = [{
					"node": "outputPTPntpListState",
					"index": index,
					"num": ""
				}]
			} else if ($scope.vm.activeTab == 9) {
				$scope.loadPTPntpCount('outputPTPntpBlacklistCount', 'Black');
				var obj = [{
					"node": "outputPTPntpListState",
					"index": index,
					"num": ""
				}]
			} else if ($scope.vm.activeTab == 10) {
				var obj = [{
					"node": "outputPTPimageActiveImage",
					"index": indexs,
					"num": ""
				}, {
					"node": "outputPTPimageActiveVersion",
					"index": indexs,
					"num": ""
				}, {
					"node": "outputPTPimageBackupImage",
					"index": indexs,
					"num": ""
				}, {
					"node": "outputPTPimageBackupVersion",
					"index": indexs,
					"num": ""
				}, {
					"node": "outputPTPimageCurrentImage",
					"index": indexs,
					"num": ""
				}]
			}
			publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/getDeviceParamColl", obj).success(function(r) {
				if (r.data && r.data.length > 0) {
					$scope.deviceContent = JSON.parse(r.data);
					if ($scope.deviceContent.outputPTPNetworkConfigIpInfo) {
						var time = new Array();
						time = $scope.deviceContent.outputPTPNetworkConfigIpInfo.split(",");
						$scope.deviceContent.ipAddress = time[0];
						$scope.deviceContent.maskAddress = time[1];
						$scope.deviceContent.gatewayAddress = time[2];
					}
					if($scope.deviceContent.outputPTPrxAnnounceMessageTimeSource){
						$scope.deviceContent.outputPTPrxAnnounceMessageTimeSource = toHex(parseInt($scope.deviceContent.outputPTPrxAnnounceMessageTimeSource));
					}
					
					if($scope.deviceContent.outputPTPrxAnnounceMessageClockAccuracy){
						$scope.deviceContent.outputPTPrxAnnounceMessageClockAccuracy = toHex(parseInt($scope.deviceContent.outputPTPrxAnnounceMessageClockAccuracy));
					}
					loadreport($scope.ptpDevID);
					_newVals();
					var par = document.getElementById('popover');
					angular.element(par).addClass('popoverS');
				}
			});
		}
	}
	$scope.loadPTPconfigContent();

	function  loadreport(devId){
		 var loadPortname = {};
	        loadPortname.deviceId = devId;
        loadPortname.shelf = $scope.mainframeNum;
        loadPortname.slot = $scope.solt;
	        loadPortname.portType = '';
	        loadPortname.port = $scope.PTPport;
	        publicService.doRequest("GET", "/nms/spring/device/renamePort", loadPortname).success(function(r) {
	           var loadPortnamedata = r.data;
	           if(loadPortnamedata.length >0){
	            	for (var i = 0; i < loadPortnamedata.length; i++) {
	            		if('PTP' == loadPortnamedata[i].portType){
						    $scope.portNamedata  =  loadPortnamedata[i].portName;
						    return
	            		}else{
	            			$scope.portNamedata = $scope.ioSignal + '('+$scope.PTPport+ ')';
	            		}
	            	}
	           }else{
	           	$scope.portNamedata = $scope.ioSignal + '('+$scope.PTPport+ ')';
	           }
	        })
  }
	function toHex(num){//将一个数字转化成16进制字符串形式
		return num<16?"0x0"+num.toString(16).toUpperCase():"0x"+num.toString(16).toUpperCase();
	}
	$scope.loadMD5keyList = function() {
		var obj = 'outputPTPntpAuthenticaKeysTable';
		publicService.doRequest("GET", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/configs/" + obj + "").success(function(r) {
			var data = r.data;
			$scope.deviceContents = r.data;
			for (var j = 0; j < data.length; j++) {
				if (data[j].outputPTPntpAuthenticaKeysSlotIndex === $scope.solt && data[j].outputPTPntpAuthenticaKeysPortIndex === $scope.PTPport) {
					var MD5keyObj = data[j].outputPTPntpAuthenticaKeysMD5key;
					var AutokeyObj = data[j].outputPTPntpAuthenticaKeysAutokey;
				}
			}

			if (MD5keyObj) {
				MD5keyObj = MD5keyObj.replace(/\ +/g,"");
				MD5keyObj = MD5keyObj.replace(/[\r\n]/g,"");
				var MD5key = MD5keyObj.match(/#(\S*)1MD5/)[1];
				$scope.deviceContents.MD5time = MD5key;
				var MD5key2 = MD5keyObj.match(/1MD5(\S*)#MD5key/)[1];
				var MD5key2obj = MD5key2.split('#MD5key');
				var obj = [];
				for (var i = 0; i < MD5key2obj.length; i++) {
					var data = {};
					data.name = i;
					if(i == 0)  {
					  	data.value = MD5key2obj[i];
					}else{
					  data.value = MD5key2obj[i].match(/MD5(\S*)/)[1];
					}
					obj.push(data);
				}


				var MD5key3 = MD5keyObj.match(/11SHA1(\S*)#SHA1key/)[1];
				var MD5key3obj = MD5key3.split('#SHA1key');
			
				for (var i = 0; i < MD5key3obj.length; i++) {
					var data = {};
					data.name = i+9;
					if(i == 0)  {
					  	data.value = MD5key3obj[i];
					}else{
					  data.value = MD5key3obj[i].match(/SHA1(\S*)/)[1];
					}
					obj.push(data);
				}
				$scope.MD5keyList = obj;
			} else {
				$scope.MD5keyList = '';
			}
			if (AutokeyObj) {
				AutokeyObj = AutokeyObj.replace(/\ +/g,"");
				AutokeyObj = AutokeyObj.replace(/[\r\n]/g,"");
				var Autokey = AutokeyObj.match(/-----BEGINPRIVATEKEY-----(\S*)-----ENDPRIVATEKEY-----/)[1];
				var Autokey2 = AutokeyObj.match(/#(\S*)-----BEGINPRIVATEKEY-----/)[1];
				$scope.deviceContents.Autokeytime = Autokey2;
				$scope.deviceContents.outputPTPntpAuthenticaKeysAutokey = Autokey;
			}
		})
	}

	function _newVals() {
		var deviceContent = $scope.deviceContent;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		localStorage.setItem('valueDoms', JSON.stringify(obj));
	}

	function _changeVals(x) {
		var deviceContent = x;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		var _vals = JSON.parse(localStorage.getItem('valueDoms')),
			changeObj = {};
		for (var i = 0; i < obj.length; i++) {
			var _id = obj[i].name,
				_val = obj[i].value;
			for (var j = 0; j < _vals.length; j++) {
				var _id2 = _vals[j].name,
					_val2 = _vals[j].value;
				if (_id === _id2) {
					if (_val != _val2) {
						changeObj[_id] = _val;
					}
				}
			}
		}
		return changeObj;
	}

	/**
	 * downloadConfig
	 *   导出配置
	 */
	$scope.downloadConfig = function(indexs, table) {
		var config_obj = [];
		if (!table) {
			var ip = true;
			var _vals = JSON.parse(localStorage.getItem('valueDoms'));
			for (var j = 0; j < _vals.length; j++) {
				var obj = {};
				if (_vals[j].name == "outputPTPCommonOtherConfigTimaScale") {
					obj.node = "outputPTPCommonOtherConfigTimaScale";
					obj.index = indexs.substring(0, indexs.length - 2);
				} else if (_vals[j].name == "ipAddress" || _vals[j].name == "maskAddress" || _vals[j].name == "gatewayAddress") {
					if (ip) {
						obj.node = "outputPTPNetworkConfigIpInfo";
						obj.index = indexs;
						ip = false;
					}
				} else {
					obj.node = _vals[j].name;
					obj.index = indexs;
				}
				config_obj.push(obj);
			}
		} else {
			if (table == 'outputPTPntpAuthenticaKeysTable') {
				var obj = {};
				obj.node = table;
				obj.index = '';
				config_obj.push(obj);
				var obj2 = {};
				obj2.node = 'outputPTPntpAuthenticaConfigAutokeyState';
				obj2.index = indexs;
				config_obj.push(obj2);
				var obj3 = {};
				obj3.node = 'outputPTPntpAuthenticaConfigMD5State';
				obj3.index = indexs;
				config_obj.push(obj3);
			} else {
				var num = parseInt($scope.PTPntpIndex);
				for (var i = 1; i <= num; i++) {
					var obj = {};
					obj.node = table;
					obj.index = indexs + '.' + i;
					config_obj.push(obj);
				}

			}
		}
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/downloadConfig/config", config_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}


	$scope.configSub = function(x, index, currentUrl, flag) {
		if (flag == "outputPTPCommon" && !verify.outputPTPCommon(x, publicService, $translate)) {
			return;
		} else if (flag === "outputPTPMulticast" && !verify.outputPTPMulticast(x, publicService, $translate)) {
			return;
		} else if (flag === "outputPTPNetwork" && !verify.outputPTPNetwork(x, publicService, $translate)) {
			return;
		} else if (flag === "outputPTPntpAuthenticaKeys" && !verify.outputPTPntpAuthenticaKeys(x, publicService, $translate)) {
			return;
		} else if (flag === "outputPTPntpListState" && !verify.outputPTPntpListState(x, publicService, $translate)) {
			return;
		} else if (flag === "outputPTPntpListState2" && !verify.outputPTPntpListState(x, publicService, $translate)) {
			return;
		}
		var indexObj = '.' + $scope.mainframeNum + '.' + $scope.solt;
		ds = _changeVals(x);
		var configSub_obj = [];
		flag = true;
		ip = true;
		vlanF = true;
		for (var j in ds) {
			obj = {};
			switch (j) {
				case "outputPTPCommonOtherConfigTimaScale":
					var outputPTPCommonOtherConfigTimaScale = $scope.deviceContent.outputPTPCommonOtherConfigTimaScale;
					obj.value = outputPTPCommonOtherConfigTimaScale;
					obj.node = 'outputPTPCommonOtherConfigTimaScale';
					obj.index = indexObj;
					configSub_obj.push(obj);
					break;
				case "ipAddress":
				case "maskAddress":
				case "gatewayAddress":
					if (ip) {
						var addr = $scope.deviceContent.ipAddress,
							mask = $scope.deviceContent.maskAddress,
							gateway = $scope.deviceContent.gatewayAddress,
							adr = new Array(addr, mask, gateway);
						var ipAddress = adr.join(',');
						obj.value = ipAddress;
						obj.node = 'outputPTPNetworkConfigIpInfo';
						obj.index = index;
						ip = false;
						configSub_obj.push(obj);
					}
					break;
				default:
					obj.value = ds[j];
					obj.node = j;
					obj.index = index;
					configSub_obj.push(obj);
			}
		}
		configSubmit(configSub_obj, index, currentUrl);
		_newVals()
	}

	/**
	 * configSubmit
	 *   配置提交
	 */
	function configSubmit(configSub_obj, index, currentUrl) {
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/setConfigsBatch", configSub_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			if (r.data.length == 0) {
				var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
				publicService.ngAlert(tt, "info");
				return;
			} else {
				var dataObj = r.data;
				var div = document.createElement('p');
				for (var i = 0; i < dataObj.length; i++) {
					if (dataObj[i].code === true) {
						var node = document.createTextNode(dataObj[i].message + ' ');
						div.appendChild(node);
						if (currentUrl == 'Autokey') {
							$scope.loadMD5keyList();
							$scope.loadPTPconfigContent();
						}
					} else if (dataObj[i].code === false) {
						var node = document.createTextNode(dataObj[i].message + ' ');
						div.appendChild(node);
					}
				}
				var element = document.getElementById("ngTip");
				element.appendChild(div);
				var tt = $translate.use() === 'ch' ? 　"返回状态列表" : "Return state List";
				publicService.ngAlert(tt, "info");
				setTimeout(function() {
					element.removeChild(div);
				}, 3000)


			}

		})

	}
	/**
	 * loadPTPntpCount
	 *   黑白名单加载
	 */

	var loadntpNUM = 1;
	$scope.loadPTPntpCount = function(node, x) {
		var index = '.' + $scope.mainframeNum + '.' + $scope.solt + '.' + $scope.PTPport + '.' + 1;
		var obj = [{
			"node": node,
			"index": index,
			"num": ""
		}]
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/getDeviceParamColl", obj).success(function(r) {
			if (r.data && r.data.length > 0) {
				var data = JSON.parse(r.data);
				var count = data[node];
				if (count == "null" && loadntpNUM > 0) {
					loadntpNUM = loadntpNUM - 1;
					$scope.loadPTPntpCount(node);
					$scope.PTPntpIndex = '0';
				} else {
					if (count == "null") {
						$scope.PTPntpIndex = '0';
						if (x == 'White') {
							$scope.loadPTPWhiteList1 = '';
						} else {
							$scope.loadPTPWhiteList2 = '';

						}
						return
					} else {
						if (count >= 500) {
							$scope.outputPTPntpSub = false;
						} else {
							$scope.outputPTPntpSub = true;
						}
						$scope.PTPntpIndex = count.toString();
						$scope.loadPTPntpList(node, count, x);
					}
				}
			}
		});
	}



	$scope.loadPTPntpList = function(node, count, x) {
		var index = '.' + $scope.mainframeNum + '.' + $scope.solt + '.' + $scope.PTPport;
		var a = {},
			obj = [];
		for (var i = 1; i <= count; i++) {
			a = {
				"node": 'outputPTPntp' + x + 'listAddr',
				"index": index + '.' + i,
				"num": ""
			}
			obj.push(a);
		}
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/getDeviceParamTable", obj).success(function(r) {

			var obj = r.data;
			var Whitelist = [];
			for (var i = 0; i < obj.length; i++) {
				var listAddr = obj[i]['outputPTPntp' + x + 'listAddr'].split(',');
				if (listAddr[1] == undefined || listAddr[1] == 'undefined') listAddr[1] = '--';
				var WhitelistAddrlistAddr = {
					"WhitelistAddrlistAddr1": listAddr[0],
					"WhitelistAddrlistAddr2": listAddr[1]
				};
				Whitelist.push(WhitelistAddrlistAddr);
			}
			if (x == 'White') {
				$scope.loadPTPWhiteList1 = Whitelist;
			} else {
				$scope.loadPTPWhiteList2 = Whitelist;

			}
		});
	}



	/**
	 * outputPTPntplistSub
	 *   黑白名单创建 激活
	 */
	$scope.outputPTPntplistSub = function(x, indexs, node) {
		if (!$scope.deviceContents) {
			var tt = $translate.use() === 'ch' ? 　"ip地址不能为空" : "IP address can not be empty!";
			publicService.ngAlert(tt, "info");
			return
		} else {
			if (!verify.ntpWhitelistIP(x, publicService, $translate)) {
				return;
			}
		}
		var reobj = [],
			obj = {};
		var index = indexs + '.' + parseInt(parseInt($scope.PTPntpIndex) + 1);
		obj.value = '5';
		obj.node = 'outputPTPntp' + node + 'listRowStatus';
		obj.index = index;
		reobj.push(obj);

		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/setConfigsBatch", reobj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			if (r.data.length == 0) {
				var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
				publicService.ngAlert(tt, "info");
				return;
			} else {
				var dataObj = r.data;
				if (dataObj[0].code === true) {
					var tt = $translate.use() === 'ch' ? 　"创建索引成功" : "Create index success";
					publicService.ngAlert(tt, "info");
					$scope.outputPTPntpAddrSub(x, index, node);
				} else if (dataObj[0].code === false) {
					var tt = $translate.use() === 'ch' ? 　"创建索引失败" : "Create index failed";
					publicService.ngAlert(tt, "info");
				}
			}
		})
	}


	$scope.outputPTPntpAddrSub = function(x, index, node) {
		var reobj = [],
			obj = {};
		if (x.outputPTPntpWhitelistAddr2) {
			var value = x.outputPTPntpWhitelistAddr + ',' + x.outputPTPntpWhitelistAddr2;
		} else {
			var value = x.outputPTPntpWhitelistAddr;
		}
		obj.value = value;
		obj.node = 'outputPTPntp' + node + 'listAddr';
		obj.index = index;
		reobj.push(obj);


		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/setConfigsBatch", reobj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			if (r.data.length == 0) {
				var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
				publicService.ngAlert(tt, "info");
				return;
			} else {
				var dataObj = r.data;
				if (dataObj[0].code === true) {
					var tt = $translate.use() === 'ch' ? 　"添加IP成功" : "Add IP success";
					publicService.ngAlert(tt, "info");
					$scope.outputPTPntpActiveSub(x, index, node);
				} else if (dataObj[0].code === false) {
					var tt = $translate.use() === 'ch' ? 　"添加IP失败" : "Add IP failed";
					publicService.ngAlert(tt, "info");
				}
			}
		})
	}



	$scope.outputPTPntpActiveSub = function(x, index, node) {
		var reobj = [],
			obj = {};
		obj.value = '1';
		obj.node = 'outputPTPntp' + node + 'listRowStatus';
		obj.index = index;
		reobj.push(obj);

		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/setConfigsBatch", reobj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			if (r.data.length == 0) {
				var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
				publicService.ngAlert(tt, "info");
				return;
			} else {
				var dataObj = r.data;
				if (dataObj[0].code === true) {
					var tt = $translate.use() === 'ch' ? 　"激活成功" : "active success";
					publicService.ngAlert(tt, "info");
					$scope.loadPTPntpCount('outputPTPntp' + node + 'listCount', node);
				} else if (dataObj[0].code === false) {
					var tt = $translate.use() === 'ch' ? 　"激活失败" : "active failed";
					publicService.ngAlert(tt, "info");
				}
			}
		})
	}


	$scope.PTPntpIpListDel1 = function(index, num, m, node) {

		var self = this;
		t = $translate.use() === "ch" ? "确认删除?" : "confirm delete？";
		if (confirm(t)) {
			self.loadPTPWhiteList1.splice(self.loadPTPWhiteList1.indexOf(m), 1)
			var reobj = [],
				obj = {};
			obj.value = '6';
			obj.node = 'outputPTPntp' + node + 'listRowStatus';
			obj.index = index + '.' + num;
			reobj.push(obj);

			publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/setConfigsBatch", reobj).success(function(r) {
				if (!r || !r.data || r.data.length < 0) return;
				var dataObj = r.data;
				if (dataObj[0].code === true) {
					var tt = $translate.use() === 'ch' ? 　"删除成功！" : "Delete success！";
					publicService.ngAlert(tt, "success");
					$scope.loadPTPntpCount('outputPTPntp' + node + 'listCount', node);
				} else if (dataObj[0].code === false) {
					var tt = $translate.use() === 'ch' ? 　"删除失败！" : "Delete failed！";
					publicService.ngAlert(tt, "success");
				}

			})
		}
	}
	$scope.PTPntpIpListDel2 = function(index, num, m, node) {

			var self = this;
			t = $translate.use() === "ch" ? "确认删除?" : "confirm delete？";
			if (confirm(t)) {
				self.loadPTPWhiteList2.splice(self.loadPTPWhiteList2.indexOf(m), 1)
				var reobj = [],
					obj = {};
				obj.value = '6';
				obj.node = 'outputPTPntp' + node + 'listRowStatus';
				obj.index = index + '.' + num;
				reobj.push(obj);

				publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/setConfigsBatch", reobj).success(function(r) {
					if (!r || !r.data || r.data.length < 0) return;
					var dataObj = r.data;
					if (dataObj[0].code === true) {
						publicService.ngAlert('删除成功');
						$scope.loadPTPntpCount('outputPTPntp' + node + 'listCount', node);
					} else if (dataObj[0].code === false) {
						publicService.ngAlert('删除失败');
					}

				})
			}
		}
		//重启ptp设备
	$scope.restSub = function(index) {
		var reobj = [],
			obj = {};
		obj.value = '1';
		obj.node = 'outputPtpRestartAction';
		obj.index = index;
		reobj.push(obj);
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/setConfigsBatch", reobj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			if (r.data.length == 0) {
				var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
				publicService.ngAlert(tt, "info");
				return;
			} else {
				var dataObj = r.data;
				if (dataObj[0].code === true) {
					var tt = $translate.use() === 'ch' ? 　"重启成功" : "restart successful";
					publicService.ngAlert(tt, "info");
				}else{
					var tt = $translate.use() === 'ch' ? 　"重启失败" : "restart failed";
					publicService.ngAlert(tt, "info");
				}
			}
		})
	}


	//恢复PTP
	$scope.restore = function(x) {
		var indexs = '.' + $scope.mainframeNum + '.' + $scope.solt;
		var reobj = [],
			obj = {};
		obj.value = x.outputPTPboardConfigManageRestore;
		obj.node = 'outputPTPboardConfigManageRestore';
		obj.index = indexs;
		reobj.push(obj);
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/setConfigsBatch", reobj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			if (r.data.length == 0) {
				var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
				publicService.ngAlert(tt, "info");
				return;
			} else {
				var dataObj = r.data;
				if (dataObj[0].code === true) {
					var tt = $translate.use() === 'ch' ? 　"恢复成功" : "recovery successful";
					publicService.ngAlert(tt, "info");
				} else if (dataObj[0].code === false) {
					var tt = $translate.use() === 'ch' ? 　"恢复失败" : "recovery failed";
					publicService.ngAlert(tt, "info");
				}
			}
		})
	}

		$scope.imageSet = function(m){
		var tt = $translate.use() === 'ch', str = "", str1 = "", _self = this;
		if(!tt){
			str = "Please input ";
			str1 = " Number between 1-2";
		}else{
			str = "请输入";
			str1 = " 为1-2之间的数字";
		}
		if(verifyFun.isNull(_self.deviceContent.outputPTPimageCurrentImage)){
			publicService.ngAlert(str + "imageCurrentImage", "info");
			return;
		}
		if(!verifyFun.between(_self.deviceContent.outputPTPimageCurrentImage,1,2)){
			publicService.ngAlert("imageCurrentImage" + str1, "info");
			return;
		}
		var arr = [{"node": "outputPTPimageCurrentImage", "index": $scope.indexss ,"value" : _self.deviceContent.outputPTPimageCurrentImage}];
		publicService.loading('start');
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/setConfigsBatch", arr).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			//检测底层设置数据是否真实更新（因为底层返回数据存在问题 没办法 只好在拉一次数据- -！）
			var tt = $translate.use() === 'ch' ? 　"设置成功" : "Set success",
				tt1 = $translate.use() === 'ch' ? 　"设置失败" : "Set fail",
				arr = [{"node": "outputPTPimageCurrentImage","index":$scope.indexss, "num" : ""}];
			publicService.loading('start');
			publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/getDeviceParamColl", arr).success(function(r) {
				if(r && r.data){
					if(JSON.parse(r.data).outputPTPimageCurrentImage != _self.deviceContent.outputPTPimageCurrentImage){
						publicService.ngAlert(tt1, "info");
					}else{
						publicService.ngAlert(tt, "info");
					}
				}				
			});
		})
	}
}]);
