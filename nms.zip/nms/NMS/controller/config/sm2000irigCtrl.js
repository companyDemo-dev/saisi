angular.module('sm2000irigModule',[]).controller('sm2000irigCtrl', ['$scope', '$state', '$rootScope', '$stateParams',  "$translate", '$state', 'publicService', function($scope, $state, $rootScope,  $stateParams, $translate, $state, publicService) {
	$scope.deviceContent = {};
	$scope.portNamedata = '';
	$scope.IRIGPortId = '1';
	/**
	 * downloadConfig
	 *   导出配置
	 */
	$scope.downloadConfig = function() {

		var self = this;
		if (!self.devID) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}

		var config_obj = [];
		var _vals = JSON.parse(localStorage.getItem('valueDoms'));
		for (var j = 0; j < _vals.length; j++) {
			var obj = {};
			obj.node = _vals[j].name;
			obj.index = $scope.indexs;
			config_obj.push(obj);
		}
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/downloadConfig/config", config_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}
	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data == null) return
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'SM2000') {
					deviceInfo.push(content[i]);
				}
			}
			$scope.deviceInfo = deviceInfo;
		}
	})


	$scope.seach = function() {
		var self = this;
		$scope.mauto = self.devID;
		if($rootScope.sm2000devID){
		   self.devID = $rootScope.sm2000devID;
		}else{
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}
		publicService.loading('start');

		var devId = self.devID.id;
		if ($scope.IRIGPortId) {
			var index = '.' + $scope.IRIGPortId;
		} else {
			var index = '.1';
		}
		$scope.indexs = index;
		obj = [{
			"node": "irigState",
			"index": index,
			"num": ""
		}, {
			"node": "irigPriority",
			"index": index,
			"num": ""
		}, {
			"node": "irigCableDelay",
			"index": index,
			"num": ""
		}, {
			"node": "irigPQLState",
			"index": index,
			"num": ""
		}, {
			"node": "irigPQL",
			"index": index,
			"num": ""
		}]

		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + devId + "/getDeviceParamColl", obj).success(function(r) {
			if (r.data && r.data.length > 0) {
				$scope.deviceContent = JSON.parse(r.data);
			}
			_newVals();
		});
		loadreport(devId);
	}

		//重启设备
	$scope.restartPM = function(x) {
		var reobj = [],
			obj = {};
		if (x == 'E1') {
			if($scope.inputCardConfigId == 1){
			    obj.value = $scope.inputCardConfigPortId;
			}else if($scope.inputCardConfigId == 2){
			    obj.value = (parseInt($scope.inputCardConfigPortId)+7).toString();
			}
		} else if (x == 'irig') {
			if($scope.IRIGPortId == 1){
			    obj.value = '7';
			}else if($scope.IRIGPortId == 2){
			    obj.value = '14';
			}
		} else{
			obj.value = x;
		}
		obj.node = 'restartPM';
		obj.index = '.0';
		reobj.push(obj);
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/setConfigsBatch", reobj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			if (r.data.length == 0) {
				var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
				publicService.ngAlert(tt, "info");
				return;
			} else {
				var dataObj = r.data;
				if (dataObj[0].code === true) {
					var tt = $translate.use() === 'ch' ? 　"重置成功" : "Resset success";
					publicService.ngAlert(tt, "info");
				} else if (dataObj[0].code === false) {
					var tt = $translate.use() === 'ch' ? 　"重置成功" : "Resset success";
					publicService.ngAlert(tt, "info");
				}
			}
		})
	}
function  loadreport(devId){
		 var loadPortname = {};
	        loadPortname.deviceId = devId;
	        loadPortname.shelf = "";
	        loadPortname.slot = "";
	        loadPortname.portType = '';
	        loadPortname.port = $scope.IRIGPortId;
	        publicService.doRequest("GET", "/nms/spring/device/renamePort", loadPortname).success(function(r) {
	           var loadPortnamedata = r.data;
	            	for (var i = 0; i < loadPortnamedata.length; i++) {
	            		if('IRIG' == loadPortnamedata[i].portType){
	            			$scope.portNamedata  =  loadPortnamedata[i].portName;
	            			return
	            		}else{
	            			$scope.portNamedata = 'IRIG'+$scope.IRIGPortId;
	            		}
	            	}
	        })
}
	function _newVals() {
		var deviceContent = $scope.deviceContent;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		localStorage.setItem('valueDoms', JSON.stringify(obj));
	}


	function _changeVals(x) {
		var deviceContent = x;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		var _vals = JSON.parse(localStorage.getItem('valueDoms')),
			changeObj = {};
		for (var i = 0; i < obj.length; i++) {
			var _id = obj[i].name,
				_val = obj[i].value;
			for (var j = 0; j < _vals.length; j++) {
				var _id2 = _vals[j].name,
					_val2 = _vals[j].value;
				if (_id === _id2) {
					if (_val != _val2) {
						changeObj[_id] = _val;
					}
				}
			}
		}
		return changeObj;
	}

	$scope.configSub = function(x) {
		if (!verify.IRIG(x, publicService, $translate)) return;
		ds = _changeVals(x);
		var configSub_obj = [];
		flag = true;
		for (var j in ds) {
			obj = {};
			obj.value = ds[j];
			obj.node = j;
			obj.index = $scope.indexs;
			configSub_obj.push(obj);
		}
		configSubmit(configSub_obj);
		_newVals()
	}
	$scope.macChange = function(x) {
		var self = this;
		$scope.mauto = self.devID;
		if (self.devID && self.devID.deviceStatus != 0) {
			localStorage.setItem("mauto", angular.toJson(self.devID));
			//子页面之间传值
			/*	$rootScope.shelfList = self.devID.shelfList;
			 */
			$rootScope.devIP = self.devID.ip;
			$rootScope.sm2000devID = self.devID;
			//界面显示
			$scope.shelfList = self.devID.shelfList;
			$scope.devIP = self.devID.ip;
			$scope.devExp = '0';
		} else if (self.devID && self.devID.deviceStatus != 1) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}
	}
	/**
	 * configSubmit
	 *   配置提交
	 */
	function configSubmit(configSub_obj) {
		if (!$scope.mauto) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return
		}
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/setConfigsBatch", configSub_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var doc;
			if (r.data.length == 0) {
				var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
				publicService.ngAlert(tt, "info");
				return;
			} else {
				var dataObj = r.data;
				var div = document.createElement('p');
				for (var i = 0; i < dataObj.length; i++) {
					if (dataObj[i].code === false) {
						var node = document.createTextNode(dataObj[i].message + ' ');
						div.appendChild(node);

					} else if (dataObj[i].code === true) {
						var node = document.createTextNode(dataObj[i].message + ' ');
						div.appendChild(node);
					}
				}
				var element = document.getElementById("ngTip");
				element.appendChild(div);
				var tt = $translate.use() === 'ch' ? 　"返回状态列表" : "Return state List";
				publicService.ngAlert(tt, "info");
				setTimeout(function() {
					element.removeChild(div);
				}, 3000)
			}

		})

	}
}]);
