angular.module('sm2000outputCardConfigModule', []).controller('outputCardConfigCtrl', ['$scope', '$state', '$rootScope', '$stateParams', "$translate", '$state', 'publicService', 'configName', function($scope, $state, $rootScope, $stateParams, $translate, $state, publicService, configName) {
	if ($scope.curLoginMsg) {
		if ($scope.curLoginMsg.roleList[0]) {
			var roleName = $scope.curLoginMsg.roleList[0].roleName;
			if (roleName.indexOf('维护级') > -1 || roleName.indexOf('监视级') > -1 || roleName.indexOf('Maintenance level') > -1 || roleName.indexOf('Monitoring level') > -1) {
				$scope.configSubD = true;
				$scope.restSubD = true;
				$scope.rebootSubD = true;
				$scope.vlanAddEditD = true;
				/*
									$scope.PTPntplistSubD = true;*/
				$scope.redundancyD = true;
			}
		}
	}
	$scope.configName = configName;



	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data == null) return
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'SM2000') {
					deviceInfo.push(content[i]);
				}
			}
			$rootScope.deviceInfo = deviceInfo;
		}
	})


	//e1初始化
	$scope.inputCardConfigId = '1';
	$scope.inputCardConfigPortId = '1';
	//ntp初始化
	$scope.ntpStatePortId = '1';
	$scope.ntpProbeStatePortId = '1';
	$scope.ntpStatusPortId = '1';
	//钟卡ptp初始化
	$scope.ptpCommonStateId = '1';
	$scope.ptpMulticastTableId = '1';
	$scope.ptpActiveProbeTableId = '1';
	$scope.ptpUnicastClientTableId = '1';
	$scope.portNamedata = '';
	//GNSS1初始化
	$scope.GNSS1Mode = function(m) {
		var obj = 'gnss1InfoTable';
		publicService.doRequest("GET", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/configs/" + obj + "", {}).success(function(r) {
			if (r.data[0]) {
				$scope.deviceContent = r.data[0];
				if ($scope.deviceContent.gnss1InfoVendor == "trimble") {
					$scope.gnss1TrackModeD = true;
				}
			}
		})
	}

	//GNSS2初始化
	$scope.GNSS2Mode = function(m) {
		var obj = 'gnss2InfoTable';
		publicService.doRequest("GET", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/configs/" + obj + "", {}).success(function(r) {
			if (r.data[0]) {
				$scope.deviceContent = r.data[0];
				if ($scope.deviceContent.gnss2InfoVendor == "trimble") {
					$scope.gnss2TrackModeD = true;
				}
			}
		})
	}



	$scope.otherOutputDF = function() {
		if (!$scope.mauto) return
		var obj = {};
		obj = [{
			"node": "refInput",
			"index": ".1",
			"num": ""
		}]
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/getDeviceParamColl", obj).success(function(r) {
			if (r.data && r.data.length > 0) {
				$scope.deviceContent = JSON.parse(r.data);
				var refInput = $scope.deviceContent.refInput;
				if (refInput == 'unknown') {
					$scope.otherOutputD = false;
				} else {
					$scope.otherOutputD = true;
				}
			}
		});

	}
	$scope.change = function(x) {
			if (x == 1) {
				$scope.gnss1D = false;
				$scope.gnss2D = false;
			} else {
				$scope.gnss1D = true;
				$scope.gnss2D = true;
			}
		}
		//网络初始化
	$scope.ipMode = '1';
	$scope.MCvisible = true;
	$scope.ipModeChange = function(m) {
			if (m == 1) {
				$scope.MCvisible = true;
				$scope.CCvisible = false;
			} else if (m == 2 || m == 3) {
				$scope.MCvisible = false;
				$scope.CCvisible = true;
			}
			$scope.loadconfigContent();
		}
		//防火墙初始化
	$scope.firewallType = '1';
	$scope.firewallTypeChange = function() {
		$scope.loadconfigContent();
	}
	$scope.pktServiceCCPort = '1';
	$scope.vlanPortId = '1';
	$scope.deviceContent = {};
	//VLAN使能初始化
	$scope.vlanModePortLoad = function() {
			obj = [{
				"node": "vlanModePortState",
				"index": '.' + $scope.vlanPortId,
				"num": ""
			}]
			publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/getDeviceParamColl", obj).success(function(r) {
				if (r.data && r.data.length > 0) {
					$scope.deviceContent = JSON.parse(r.data);
					_newVals();
				}
			});
		}
		//重启设备初始化
	$scope.loadrReboot = function(x) {
		publicService.doRequest("GET", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/configs/ioStatusTable", {}).success(function(r) {
			$scope.rebootList = [{
				'name': '重启系统',
				'value': 0,
				'index': 0
			}, {
				'name': '重启管理卡',
				'value': 1,
				'index': 1
			}];

			for (var i = 0; i < r.data.length; i++) {
				if (r.data[i].ioSignal == "PTP") {
					if (r.data[i].ioStatusIndex == '0') {
						var expName = 'MainShelf';
					} else if (r.data[i].ioStatusIndex == '1') {
						var expName = 'ExpShelf1';
					} else if (r.data[i].ioStatusIndex == '2') {
						var expName = 'ExpShelf2';
					} else if (r.data[i].ioStatusIndex == '3') {
						var expName = 'ExpShelf3';
					} else if (r.data[i].ioStatusIndex == '4') {
						var expName = 'ExpShelf4';
					}
					obj = {
						'name': '重启 PTP(' + expName + '-PTP card slot' + r.data[i].ioStatusSlotID + ')',
						'value': 6,
						'index': '.' + r.data[i].ioStatusIndex + '.' + r.data[i].ioStatusSlotID + '.0'
					}
					$scope.rebootList.push(obj);
				}
			}


			if (r.data[0].ioSignal == "4-E1") {
				obj = {
					'name': '重启 4-E1(1)',
					'value': 2,
					'index': 2
				};
				$scope.rebootList.push(obj);
			};
			if (r.data[1].ioSignal == "4-E1") {
				obj = {
					'name': '重启 4-E1(2)',
					'value': 3,
					'index': 3
				};
				$scope.rebootList.push(obj);
			};
			if (x == 1) {
				obj = {
					'name': '重启钟卡(1)',
					'value': 4,
					'index': 4
				};
				$scope.rebootList.push(obj);
			}
			if (x == 2) {
				obj = {
					'name': '重启钟卡(2)',
					'value': 5,
					'index': 5
				};
				$scope.rebootList.push(obj);
			}
			if (x == 3) {
				obj = {
					'name': '重启钟卡(1)',
					'value': 4,
					'index': 4
				};
				obj2 = {
					'name': '重启钟卡(2)',
					'value': 5,
					'index': 5
				};
				$scope.rebootList.push(obj);
				$scope.rebootList.push(obj2);
			}
			_newVals();
		})
	}

	//设置钟卡初始化
	$scope.setColockdisabled1 = true;
	$scope.setColockdisabled2 = true;
	$scope.zCardConfig = function() {
		obj = [{
			"node": "ccState",
			"index": '.2',
			"num": ""
		}]
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/getDeviceParamColl", obj).success(function(r) {
			if (r.data && r.data.length > 0) {
				$scope.deviceContent = JSON.parse(r.data);
				if ($scope.deviceContent.ccState) {
					var ccState = $scope.deviceContent.ccState;
					switch (ccState) {
						case "0":
							$scope.cc2Content = 'active';
							break;
						case "1":
							$scope.cc2Content = 'standby';
							break;
						case "2":
							$scope.cc2Content = 'active-warmup';
							break;
						case "3":
							$scope.cc2Content = 'standby-warmup';
							break;
						case "4":
							$scope.cc2Content = 'failed';
							break;
						case "5":
							$scope.cc2Content = 'disabled';
							break;
					}
					if (ccState == '1' || ccState == '2' || ccState == '3') {
						$scope.CC2visible = true;
						$scope.setColockdisabled2 = false;
					}

				}
			}
		});
	}


	$scope.loadconfigContent = function() {
		if ($scope.mauto) {
			var obj = {};
			var configName = $scope.configName,
				configDevId = $scope.mauto.id;
			switch (configName) {
				case "gnss1":
					obj = [{
						"node": "gnss1State",
						"index": "",
						"num": ""
					}, {
						"node": "gnss1Mode",
						"index": "",
						"num": ""
					}, {
						"node": "gnss1Mask",
						"index": "",
						"num": ""
					}, {
						"node": "gnss1TrackMode",
						"index": ".0",
						"num": ""
					}, {
						"node": "gnss1CableDelay",
						"index": "",
						"num": ""
					}, {
						"node": "gnss1Priority",
						"index": "",
						"num": ""
					}, {
						"node": "gnss1PQLState",
						"index": "",
						"num": ""
					}, {
						"node": "gnss1PQL",
						"index": "",
						"num": ""
					}, {
						"node": "gnss1CurrentPosMode",
						"index": "",
						"num": ""
					}, {
						"node": "gnss1CurrentPosition",
						"index": "",
						"num": ""
					}, {
						"node": "gnss1PositionConfig",
						"index": "",
						"num": ""
					}, ]
					$scope.GNSS1Mode();
					$scope.gnss1D = true;
					rename = 'GNSS';
					rePORT = 1;
					break;
				case "gnss2":
					obj = [{
						"node": "gnss2State",
						"index": "",
						"num": ""
					}, {
						"node": "gnss2Mode",
						"index": "",
						"num": ""
					}, {
						"node": "gnss2Mask",
						"index": "",
						"num": ""
					}, {
						"node": "gnss2TrackMode",
						"index": ".0",
						"num": ""
					}, {
						"node": "gnss2CableDelay",
						"index": "",
						"num": ""
					}, {
						"node": "gnss2Priority",
						"index": "",
						"num": ""
					}, {
						"node": "gnss2PQLState",
						"index": "",
						"num": ""
					}, {
						"node": "gnss2PQL",
						"index": "",
						"num": ""
					}, {
						"node": "gnss2CurrentPosMode",
						"index": "",
						"num": ""
					}, {
						"node": "gnss2CurrentPosition",
						"index": "",
						"num": ""
					}, {
						"node": "gnss2PositionConfig",
						"index": "",
						"num": ""
					}, ]
					$scope.GNSS2Mode();
					$scope.gnss2D = true;
					rename = 'GNSS';
					rePORT = 2;
					break;
				case "ppsTod1":
					obj = [{
						"node": "ppsTODState",
						"index": ".1",
						"num": ""
					}, {
						"node": "ppsTODPriority",
						"index": ".1",
						"num": ""
					}, {
						"node": "ppsTODCableDelay",
						"index": ".1",
						"num": ""
					}, {
						"node": "ppsTODPQLState",
						"index": ".1",
						"num": ""
					}, {
						"node": "ppsTODPQL",
						"index": ".1",
						"num": ""
					}]
					rename = 'PPS-TOD';
					rePORT = 1;
					break;
				case "ppsTod2":
					obj = [{
						"node": "ppsTODState",
						"index": ".2",
						"num": ""
					}, {
						"node": "ppsTODPriority",
						"index": ".2",
						"num": ""
					}, {
						"node": "ppsTODCableDelay",
						"index": ".2",
						"num": ""
					}, {
						"node": "ppsTODPQLState",
						"index": ".2",
						"num": ""
					}, {
						"node": "ppsTODPQL",
						"index": ".2",
						"num": ""
					}]
					rename = 'PPS-TOD';
					rePORT = 2;
					break;
				case "e1":
					if ($scope.inputCardConfigId && $scope.inputCardConfigPortId) {
						if ($scope.inputCardConfigId == '1') {
							var index = '.' + $scope.inputCardConfigPortId;
						} else if ($scope.inputCardConfigId == '2') {
							var index = '.' + parseInt(parseInt($scope.inputCardConfigPortId) + 4);
						}
					} else {
						var index = '.1';
					}
					$scope.indexs = index;
					obj = [{
						"node": "inputCardState",
						"index": index,
						"num": ""
					}, {
						"node": "inputCardPriority",
						"index": index,
						"num": ""
					}, {
						"node": "inputCardFrameType",
						"index": index,
						"num": ""
					}, {
						"node": "inputCardCRCState",
						"index": index,
						"num": ""
					}, {
						"node": "inputCardSSMState",
						"index": index,
						"num": ""
					}, {
						"node": "inputCardSSMBit",
						"index": index,
						"num": ""
					}, {
						"node": "inputCardPQL",
						"index": index,
						"num": ""
					}, {
						"node": "inputCardCfgUsed",
						"index": index,
						"num": ""
					}]
					rename = '4-E1';
					break;
				case "otherOutput":
					obj = [{
						"node": "refCriteriaConfig",
						"index": "",
						"num": ""
					}, {
						"node": "refModeConfig",
						"index": "",
						"num": ""
					}, {
						"node": "leapSecond",
						"index": "",
						"num": ""
					}, {
						"node": "systemTime",
						"index": "",
						"num": ""
					}]
					$scope.otherOutputDF();
					break;
				case "ntp":
					if ($scope.ntpStatePortId) {
						var index = '.' + $scope.ntpStatePortId;
					} else {
						var index = '.1';
					}
					$scope.indexs = index;
					obj = [{
						"node": "ntpState",
						"index": index,
						"num": ""
					}, {
						"node": "ntpDSCP",
						"index": index,
						"num": ""
					}, {
						"node": "ntpDSCPState",
						"index": index,
						"num": ""
					}, {
						"node": "ntpTTL",
						"index": index,
						"num": ""
					}, {
						"node": "ntpVlanID",
						"index": index,
						"num": ""
					}, {
						"node": "ntpPacketLimit",
						"index": index,
						"num": ""
					}]
					break;
				case "ntpProbe":
					if ($scope.ntpProbeStatePortId) {
						var index = '.' + $scope.ntpProbeStatePortId;
					} else {
						var index = '.1';
					}
					$scope.indexs = index;
					obj = [{
						"node": "ntpProbeServerIP",
						"index": index,
						"num": ""
					}, {
						"node": "ntpProbeInterval",
						"index": index,
						"num": ""
					}, {
						"node": "ntpProbeVlanID",
						"index": index,
						"num": ""
					}, {
						"node": "ntpProbeState",
						"index": index,
						"num": ""
					}, {
						"node": "ntpProbeDataFormat",
						"index": index,
						"num": ""
					}, {
						"node": "ttl",
						"index": index,
						"num": ""
					}, {
						"node": "dscp",
						"index": index,
						"num": ""
					}, {
						"node": "dscpState",
						"index": index,
						"num": ""
					}]
					break;
				case "ntpStatus":
					if ($scope.ntpStatusPortId) {
						var index = '.' + $scope.ntpStatusPortId;
					} else {
						var index = '.1';
					}
					$scope.indexs = index;
					obj = [{
						"node": "ntpStatusPortEnabled",
						"index": index,
						"num": ""
					}, {
						"node": "ntpStatusVersion",
						"index": index,
						"num": ""
					}, {
						"node": "ntpStatusMode",
						"index": index,
						"num": ""
					}, {
						"node": "ntpStatusLeapStatus",
						"index": index,
						"num": ""
					}, {
						"node": "ntpStatusStratumLevel",
						"index": index,
						"num": ""
					}, {
						"node": "ntpStatusRootDispersion",
						"index": index,
						"num": ""
					}]
					break;
				case "zptpCommon":
					if ($scope.ptpCommonStateId) {
						var index = '.' + $scope.ptpCommonStateId;
					} else {
						var index = '.1';
					}
					$scope.indexs = index;
					obj = [{
						"node": "ptpCommonTimescale",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonState",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonMaxClient",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonProfile",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonClockID",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonPriority1",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonPriority2",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonDomain",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonDSCP",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonDSCPState",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonSyncLimit",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonAnnounceLimit",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonDelayLimit",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonDither",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonTwoStep",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonTTL",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonMgmtAddrMode",
						"index": index,
						"num": ""
					}, {
						"node": "ptpCommonAlternateMaster",
						"index": index,
						"num": ""
					}, {
						"node": "ptpUnicastNegotiate",
						"index": index,
						"num": ""
					}, {
						"node": "ptpUnicastLeaseDuration",
						"index": index,
						"num": ""
					}]
					break;
				case "zptpMulticast":
					if ($scope.ptpMulticastTableId) {
						var index = '.' + $scope.ptpMulticastTableId;
					} else {
						var index = '.1';
					}
					$scope.indexs = index;
					obj = [{
						"node": "ptpMulticastVlanID",
						"index": index,
						"num": ""
					}, {
						"node": "ptpMulticastSyncIntv",
						"index": index,
						"num": ""
					}, {
						"node": "ptpMulticastAnnounceIntv",
						"index": index,
						"num": ""
					}, {
						"node": "ptpMulticastDelayIntv",
						"index": index,
						"num": ""
					}, {
						"node": "ptpMulticastAnnounceTimeout",
						"index": index,
						"num": ""
					}, {
						"node": "ptpMulticastClientTimeout",
						"index": index,
						"num": ""
					}]
					break;
				case "zUnicastClinet":
					obj = 'ptpUnicastClientTable';
					break;
				case "zptpProbe":
					if ($scope.ptpActiveProbeTableId) {
						var index = '.' + $scope.ptpActiveProbeTableId;
					} else {
						var index = '.1';
					}
					$scope.indexs = index;
					obj = [{
						"node": "ptpActiveProbeGMIpAddr",
						"index": index,
						"num": ""
					}, {
						"node": "ptpActiveProbeVlanID",
						"index": index,
						"num": ""
					}, {
						"node": "ptpActiveProbeGMClockID",
						"index": index,
						"num": ""
					}, {
						"node": "ptpActiveProbeInterval",
						"index": index,
						"num": ""
					}, {
						"node": "ptpActiveProbeDuration",
						"index": index,
						"num": ""
					}, {
						"node": "ptpActiveProbeProfile",
						"index": index,
						"num": ""
					}]
					break;
				case "alarmModle":
					obj = 'alarmConfigTable';
					rename = '';
					rePORT = '';
					break;
				case "alarmModleSub":
					obj = 'alarmConfigTable';
					rename = '';
					rePORT = '';
					break;
				case "IPETH":
					if ($scope.ipMode) {
						var index = '.' + $scope.ipMode;
					} else {
						var index = '.1';
					}
					if ($scope.firewallType) {
						var indexs = '.' + $scope.firewallType;
					} else {
						var indexs = '.1';
					}
					obj = [{
						"node": "ipMCMode",
						"index": '.0',
						"num": ""
					}, {
						"node": "ipPortState",
						"index": index,
						"num": ""
					}, {
						"node": "ipAddress",
						"index": index,
						"num": ""
					}, {
						"node": "ethAutoNegSpeed",
						"index": '.' + parseInt($scope.ipMode - 1),
						"num": ""
					}, {
						"node": "ethAutoNegState",
						"index": '.' + parseInt($scope.ipMode - 1),
						"num": ""
					}, {
						"node": "ethLinkSpeed",
						"index": '.' + parseInt($scope.ipMode - 1),
						"num": ""
					}, {
						"node": "pktServiceCCPortA",
						"index": '.0',
						"num": ""
					}, {
						"node": "pktServiceCCPortB",
						"index": '.0',
						"num": ""
					}, {
						"node": "firewallState",
						"index": indexs,
						"num": ""
					}]
					break;
				case "vlan":
					$scope.vlanModePortLoad();
					obj = 'vlanTable';
					break;
				case "reboot":
					$scope.loadrReboot();
					obj = [{
						"node": "cc1State",
						"index": '.1',
						"num": ""
					}, {
						"node": "cc2State",
						"index": '.1',
						"num": ""
					}]
					break;
				case "zSet":
					$scope.zCardConfig();
					obj = [{
						"node": "ccState",
						"index": '.1',
						"num": ""
					}]
					break;
				case "inventoryInfo":
					obj = 'inventoryInfoTable';
					break;
				default:
					configName = 'outputCardS';
					rename = '';
					rePORT = '';
			}

			if (rename == '4-E1') {
				if ($scope.inputCardConfigId == '1') {
					var rePORT = $scope.inputCardConfigPortId;
					var reSlot = 1;
				} else if ($scope.inputCardConfigId == '2') {
					var rePORT = $scope.inputCardConfigPortId;
					var reSlot = 2;
				}
			}
			var loadPortname = {};
			loadPortname.deviceId = $scope.mauto.id;
			loadPortname.shelf = "";
			loadPortname.slot = reSlot || "";
			loadPortname.portType = '';
			loadPortname.port = rePORT;
			publicService.doRequest("GET", "/nms/spring/device/renamePort", loadPortname).success(function(r) {
				var loadPortnamedata = r.data;
				if (loadPortnamedata.length > 0) {
					for (var i = 0; i < loadPortnamedata.length; i++) {
						if (rename == loadPortnamedata[i].portType) {
							$scope.portNamedata = loadPortnamedata[i].portName;
							return
						} else {
							$scope.portNamedata = rename;
						}
					}
				} else {
					$scope.portNamedata = rename;
				}
			})

			if (configName == 'outputCardS' || configName == 'outputCard') {

				if (!$scope.mauto.id || typeof $scope.mauto.id === 'undefined') {

					var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
					publicService.ngAlert(tt, "info");
					return;
				}

				if (!$scope.devExp || $scope.devExp == 'undefined' || $scope.devExp == '未选择') {
					var tt = $translate.use() === 'ch' ? 　"请选择机框" : "Please select machine frame";
					publicService.ngAlert(tt, "info");
					return;
				}
				publicService.doRequest("GET", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/getIoStatus", {
					shelfIndex: $scope.devExp
				}).success(function(r) {
					if (r.data && r.data.length > 0) {
						$scope.frameConfigList = r.data;
						if ($scope.devExp == '0') {
							$scope.inputCardConfigCard = r.data[0].ioSignal;
						} else {
							$scope.inputCardConfigCard = '4-E1';
						}
					}
				})



				publicService.doRequest("GET", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/configs/outputRedundancyTable", {}).success(function(r) {
					if (r.data && r.data.length > 0) {
						var ioLists = $scope.frameConfigList;
						redList = r.data;
						if ($scope.devExp == '0') {
							var a = 0;
						} else if ($scope.devExp == '1') {
							var a = 9;
						} else if ($scope.devExp == '2' || $scope.devExp == '3' || $scope.devExp == '4') {
							var a = 9 + parseInt(parseInt($scope.devExp) - 1) * 14;
						}
						for (var i = 0; i < ioLists.length; i++) {
							ioLists[i].ioStatusRedundancy = redList[parseInt(i + a)].outputRedundancyState;
						}
						$scope.frameConfigList = ioLists;
					}
				})
			} else if (configName == 'alarmModle' || configName == 'alarmModleSub' || configName == 'zUnicastClinet' || configName == 'vlan' || configName == 'inventoryInfo') {
				publicService.doRequest("GET", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/configs/" + obj + "", {}).success(function(r) {
					if (configName == 'vlan') {
						$scope.vlanModuleID = r.data[0].vlanCfg.vlanModuleID;
						var obj = [];
						if ($scope.vlanPortId == '1') {
							for (var i = 0; i < 16; i++) {
								var val = {};
								var vlanCfg = r.data[i].vlanCfg,
									vlan = [];
								val.vlanState = r.data[i].vlanState;
								val.vlanPortID = r.data[i].vlanPortID;
								val.vlanIndex = r.data[i].vlanIndex;
								if (vlanCfg == '') {
									val.index = 'none';
									val.id = 'none';
									val.priority = 'none';
									val.addr = 'none';
									val.netmask = 'none';
									val.gateway = 'none';
									val.destNetwork = 'none';
								} else {
									vlan = vlanCfg.split(',');
									index = vlan[0];
									val.index = index.replace(/index=/, '');

									id = vlan[1];
									val.id = id.replace(/id=/, '');

									priority = vlan[2];
									val.priority = priority.replace(/priority=/, '');

									addr = vlan[3];
									val.addr = addr.replace(/addr=/, '');

									netmask = vlan[4];
									val.netmask = netmask.replace(/netmask=/, '');

									gateway = vlan[5];
									val.gateway = gateway.replace(/\//g, '').replace(/gatewaynextHop=/, '');

									destNetwork = vlan[6];
									val.destNetwork = destNetwork.replace(/destNetwork=/, '');
								}
								obj.push(val);
							}
						} else if ($scope.vlanPortId == '2') {
							for (var i = 16; i < 32; i++) {
								var val = {};
								var vlanCfg = r.data[i].vlanCfg,
									vlan = [];
								val.vlanState = r.data[i].vlanState;
								val.vlanPortID = r.data[i].vlanPortID;
								val.vlanIndex = r.data[i].vlanIndex;
								if (vlanCfg == '') {
									val.index = 'none';
									val.id = 'none';
									val.priority = 'none';
									val.addr = 'none';
									val.netmask = 'none';
									val.gateway = 'none';
									val.destNetwork = 'none';
								} else {
									vlan = vlanCfg.split(',');
									index = vlan[0];
									val.index = index.replace(/index=/, '');

									id = vlan[1];
									val.id = id.replace(/id=/, '');

									priority = vlan[2];
									val.priority = priority.replace(/priority=/, '');

									addr = vlan[3];
									val.addr = addr.replace(/addr=/, '');

									netmask = vlan[4];
									val.netmask = netmask.replace(/netmask=/, '');

									gateway = vlan[5];
									val.gateway = gateway.replace(/\//g, '').replace(/gatewaynextHop=/, '');

									destNetwork = vlan[6];
									val.destNetwork = destNetwork.replace(/destNetwork=/, '');
								}
								obj.push(val);
							}
						}
						$scope.configList = obj;
					} else if (configName == 'alarmModle' || configName == 'alarmModleSub') {
						$scope.configList = r.data;
					} else if (configName == 'zUnicastClinet') {
						list = [];
						if ($scope.ptpUnicastClientTableId == '1') {
							for (var i = 0; i < 10; i++) {
								list.push(r.data[i]);
							}
							$scope.configList = list;
						} else if ($scope.ptpUnicastClientTableId == '2') {
							for (var i = 10; i < 20; i++) {
								list.push(r.data[i]);
							}
							$scope.configList = list;
						}
					} else if (configName == 'inventoryInfo') {
						$scope.configList = r.data;
					}
				})
			} else {

				if (!configDevId) {
					return
				}
				publicService.doRequest("POST", "/nms/spring/deviceConfig/" + configDevId + "/getDeviceParamColl", obj).success(function(r) {
					if (r.data && r.data.length > 0) {
						$scope.deviceContent = JSON.parse(r.data);
						if ($scope.deviceContent.gnss1PositionConfig) {
							var time = new Array();
							time = $scope.deviceContent.gnss1PositionConfig.split(",");
							$scope.deviceContent.gnss1CurrentPositionJ = time[0];
							$scope.deviceContent.gnss1CurrentPositionW = time[1];
							$scope.deviceContent.gnss1CurrentPositionH = time[2];
						}
						if ($scope.deviceContent.gnss2PositionConfig) {
							var time = new Array();
							time = $scope.deviceContent.gnss2PositionConfig.split(",");
							$scope.deviceContent.gnss2CurrentPositionJ = time[0];
							$scope.deviceContent.gnss2CurrentPositionW = time[1];
							$scope.deviceContent.gnss2CurrentPositionH = time[2];
						}
						if ($scope.deviceContent.ipAddress) {
							var time = new Array();
							time = $scope.deviceContent.ipAddress.split(",");
							$scope.deviceContent.ipAddress = time[0];
							$scope.deviceContent.maskAddress = time[1];
							$scope.deviceContent.gatewayAddress = time[2];
						}


						if ($scope.deviceContent.pktServiceCCPortA) {
							switch ($scope.deviceContent.pktServiceCCPortA) {
								case "0":
									$scope.deviceContent.pktServiceCCPortA = 'ptp-gm';
									break;
								case "1":
									$scope.deviceContent.pktServiceCCPortA = 'ptp-probe';
									break;
								case "2":
									$scope.deviceContent.pktServiceCCPortA = 'ntp-server';
									break;
								case "3":
									$scope.deviceContent.pktServiceCCPortA = 'ntp-probe';
									break;
							}
						}
						if ($scope.deviceContent.pktServiceCCPortB) {
							switch ($scope.deviceContent.pktServiceCCPortB) {
								case "0":
									$scope.deviceContent.pktServiceCCPortB = 'ptp-gm';
									break;
								case "1":
									$scope.deviceContent.pktServiceCCPortB = 'ptp-probe';
									break;
								case "2":
									$scope.deviceContent.pktServiceCCPortB = 'ntp-server';
									break;
								case "3":
									$scope.deviceContent.pktServiceCCPortB = 'ntp-probe';
									break;
							}
						}
						if ($scope.deviceContent.ethLinkSpeed) {
							switch ($scope.deviceContent.ethLinkSpeed) {
								case "0":
									$scope.deviceContent.ethLinkSpeed = 'none';
									break;
							}
						}
						$scope.deviceContent.pktServiceCCMode = '4';
						if ($scope.deviceContent.cc1State) {
							var sum = 0;
							if ($scope.deviceContent.cc1State != 'card not present') {
								sum = 1;
							}
							if ($scope.deviceContent.cc2State != 'card not present') {
								sum = 2;
							}
							if ($scope.deviceContent.cc2State != 'card not present' && $scope.deviceContent.cc2State != 'card not present') {
								sum = 3;
							}
							$scope.loadrReboot(sum);
						}
						if ($scope.deviceContent.ccState) {
							var ccState = $scope.deviceContent.ccState;
							switch (ccState) {
								case "0":
									$scope.cc1Content = 'active';
									break;
								case "1":
									$scope.cc1Content = 'standby';
									break;
								case "2":
									$scope.cc1Content = 'active-warmup';
									break;
								case "3":
									$scope.cc1Content = 'standby-warmup';
									break;
								case "4":
									$scope.cc1Content = 'failed';
									break;
								case "5":
									$scope.cc1Content = 'disabled';
									break;
							}
							if (ccState == '1' || ccState == '2' || ccState == '3') {
								$scope.CC1visible = true;
								$scope.setColockdisabled1 = false;
							}
						}
					}
					_newVals();
				});
			}
		}
	}
	$scope.loadconfigContent();

	function _newVals() {
		var deviceContent = $scope.deviceContent;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		localStorage.setItem('valueDoms', JSON.stringify(obj));
	}


	function _changeVals(x) {
		var deviceContent = x;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		var _vals = JSON.parse(localStorage.getItem('valueDoms')),
			changeObj = {};
		for (var i = 0; i < obj.length; i++) {
			var _id = obj[i].name,
				_val = obj[i].value;
			for (var j = 0; j < _vals.length; j++) {
				var _id2 = _vals[j].name,
					_val2 = _vals[j].value;
				if (_id === _id2) {
					if (_val != _val2) {
						changeObj[_id] = _val;
					}
				}
			}
		}
		return changeObj;
	}


	$scope.configSub = function(x, index, currentUrl, flag) {
		if (flag == "GNSS1" && !verify.gnss(x, publicService, $translate, "1")) {
			return;
		} else if (flag === "GNSS2" && !verify.gnss(x, publicService, $translate, "2")) {
			return;
		} else if (flag === "ppsTod" && !verify.ppsTod(x, publicService, $translate)) {
			return;
		} else if (flag === "E1" && !verify.e1(x, publicService, $translate)) {
			return;
		} else if (flag === "ntp" && !verify.ntp(x, publicService, $translate)) {
			return;
		} else if (flag === "ntp_probe" && !verify.ntp_probe(x, publicService, $translate)) {
			return;
		} else if (flag === "common" && !verify.common(x, publicService, $translate)) {
			return;
		} else if (flag === "multicast" && !verify.multicast(x, publicService, $translate)) {
			return;
		} else if (flag === "Unicast_clinet" && !verify.Unicast_clinet(x, publicService, $translate)) {
			return;
		} else if (flag === "ptp_probe" && !verify.ptp_probe(x, publicService, $translate)) {
			return;
		} else if (flag === "IPETH" && !verify.IPETH(x, publicService, $translate)) {
			return;
		} else if (flag === "ip_vlan" && !verify.ip_vlan(x, publicService, $translate)) {
			return;
		}

		if (index) {
			indexObj = index
		}
		ds = _changeVals(x);
		var configSub_obj = [];
		flag = true;
		ip = true;
		ip1 = true;
		ip2 = true;
		ip3 = true;
		vlanF = true;
		for (var j in ds) {
			obj = {};
			switch (j) {
				case "gnss1CurrentPositionJ":
				case "gnss1CurrentPositionW":
				case "gnss1CurrentPositionH":
					if (flag) {
						var j = $scope.deviceContent.gnss1CurrentPositionJ,
							w = $scope.deviceContent.gnss1CurrentPositionW,
							h = $scope.deviceContent.gnss1CurrentPositionH,
							gnss1PositionConfig = String(j + "," + w + "," + h);
						obj.value = gnss1PositionConfig;
						obj.node = 'gnss1PositionConfig';
						obj.index = indexObj;
						flag = false;
						configSub_obj.push(obj);
					}
					break;
				case "gnss2CurrentPositionJ":
				case "gnss2CurrentPositionW":
				case "gnss2CurrentPositionH":
					if (flag) {
						var j = $scope.deviceContent.gnss2CurrentPositionJ,
							w = $scope.deviceContent.gnss2CurrentPositionW,
							h = $scope.deviceContent.gnss2CurrentPositionH,
							gnss2PositionConfig = String(j + "," + w + "," + h);
						obj.value = gnss2PositionConfig;
						obj.node = 'gnss2PositionConfig';
						obj.index = indexObj;
						flag = false;
						configSub_obj.push(obj);
					}
					break;
				case "ptpMulticastVlanID":
					if ($scope.deviceContent.ptpMulticastVlanID == '0') {
						var tt = $translate.use() === 'ch' ? 　"错误的设置方式,不能设置为0 ！" : "Wrong setting mode！";
						publicService.ngAlert(tt, "info");
						return
					} else {
						var ptpMulticastVlanID = $scope.deviceContent.ptpMulticastVlanID;
						obj.value = ptpMulticastVlanID;
						obj.node = 'ptpMulticastVlanID';
						obj.index = indexObj;
						ip = false;
						configSub_obj.push(obj);
					}
					break;
				case "ipAddress":
				case "maskAddress":
				case "gatewayAddress":
					if (ip1) {
						var addr = $scope.deviceContent.ipAddress,
							mask = $scope.deviceContent.maskAddress,
							gateway = $scope.deviceContent.gatewayAddress,
							adr = new Array(addr, mask, gateway);
						var ipAddress = adr.join(',');
						obj.value = ipAddress;
						obj.node = 'ipAddress';
						obj.index = $scope.ipMode;
						ip1 = false;
						configSub_obj.push(obj);
					}
					break;
				case "ipPortState":
					t = $translate.use() === "ch" ? "确认是否操作端口状态！" : "Confirm whether operation port status!";
					if (confirm(t)) {
						var ipPortState = $scope.deviceContent.ipPortState;
						obj.value = ipPortState;
						obj.node = 'ipPortState';
						obj.index = $scope.ipMode;
						configSub_obj.push(obj);
					}
					break;
				case "ipMCMode":
					var ipMCMode = $scope.deviceContent.ipMCMode;
					obj.value = ipMCMode;
					obj.node = 'ipMCMode';
					obj.index = '.0';
					configSub_obj.push(obj);
					break;
				case "ethAutoNegState":
					var ethAutoNegState = $scope.deviceContent.ethAutoNegState;
					obj.value = ethAutoNegState;
					obj.node = 'ethAutoNegState';
					obj.index = parseInt($scope.ipMode) - 1;
					configSub_obj.push(obj);
					break;
				case "ethAutoNegSpeed":
					var ethAutoNegSpeed = $scope.deviceContent.ethAutoNegSpeed;
					obj.value = ethAutoNegSpeed;
					obj.node = 'ethAutoNegSpeed';
					obj.index = parseInt($scope.ipMode) - 1;
					configSub_obj.push(obj);
					break;
				case "pktServiceCCPort":
					return
					break;
				case "pktServiceCCMode":
					var pktServiceCCMode = $scope.deviceContent.pktServiceCCMode,
						pktServiceCCPort = $scope.pktServiceCCPort;
					if (pktServiceCCPort == '1') {
						obj.node = 'pktServiceCCPortA';
						obj.index = '.' + 0;
					} else if (pktServiceCCPort == '2') {
						obj.node = 'pktServiceCCPortB';
						obj.index = '.' + 0;
					}
					obj.value = pktServiceCCMode;
					configSub_obj.push(obj);
					currentUrl = 'pktServiceCCMode';
					break;
				case "vlanState":
					var vlanState = $scope.deviceContent.vlanState;
					obj.value = vlanState;
					obj.node = 'vlanState';
					obj.index = $scope.deviceContent.vlanIndex;
					configSub_obj.push(obj);
					break;
				case "addr":
				case "netmask":
				case "gateway":
				case "destNetwork":
					if (vlanF) {
						var addr = $scope.deviceContent.addr,
							netmask = $scope.deviceContent.netmask,
							gateway = $scope.deviceContent.gateway,
							destNetwork = $scope.deviceContent.destNetwork;
						if (destNetwork != 'n/a') {
							var vlanCfg = new Array('addr=' + addr, 'netmask=' + netmask, 'nextHop=' + gateway);
							vlanCfg.push('destNetwork=' + destNetwork);
						} else {
							var vlanCfg = new Array('addr=' + addr, 'netmask=' + netmask, 'gateway=' + gateway);
						}
						vlanCfg = vlanCfg.join(',');
						obj.value = vlanCfg;
						obj.node = 'vlanCfg';
						obj.index = $scope.deviceContent.vlanIndex;
						configSub_obj.push(obj);
						vlanF = false;
					}
					break;
				case "systemTime":
					obj.value = ds[j].replace(/\s/g, "").replace(/^(.{10})(.*)$/, "$1,$2");
					obj.node = j;
					obj.index = indexObj;
					configSub_obj.push(obj);
					break;
				default:
					obj.value = ds[j];
					obj.node = j;
					obj.index = indexObj;
					configSub_obj.push(obj);
			}
		}
		configSubmit(configSub_obj, index, currentUrl);
		_newVals()
	}

	/**
	 * configSubmit
	 *   配置提交
	 */
	function configSubmit(configSub_obj, index, currentUrl) {
		if (!$scope.mauto) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return
		}
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/setConfigsBatch", configSub_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var doc;
			if (r.data.length == 0) {
				var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
				publicService.ngAlert(tt, "info");
				return;
			} else {

				var dataObj = r.data;
				if (dataObj[0].code === true) {
					var tt = $translate.use() === 'ch' ? 　"设置成功" : "Set success";
					publicService.ngAlert(tt, "info");
					setTimeout(function() {
						$scope.loadconfigContent();
					}, 3000)
				} else if (dataObj[0].code === false) {
					var tt = $translate.use() === 'ch' ? 　"设置失败" : "Set failed";
					publicService.ngAlert(tt, "info");
					setTimeout(function() {
						$scope.loadconfigContent();
					}, 3000)
				}

				/*
					var dataObj = r.data;
					var div = document.createElement('p');
					for (var i = 0; i < dataObj.length; i++) {
						if (dataObj[i].code === false) {
							var node = document.createTextNode(dataObj[i].message + ' ');
							div.appendChild(node);

						} else if (dataObj[i].code === true) {
							var node = document.createTextNode(dataObj[i].message + ' ');
							div.appendChild(node);
							if (currentUrl == 'pktServiceCCMode') {
								$scope.loadconfigContent();
							}
						}
					}
					var element = document.getElementById("ngTip");
					element.appendChild(div);
					var tt = $translate.use() === 'ch' ? 　"返回状态列表" : "Return state List";
					publicService.ngAlert(tt, "info");
					setTimeout(function() {
						element.removeChild(div);
					}, 3000)*/
			}

		})

	}


	//重启设备
	$scope.rebootSub = function(configSub_obj) {
			var reobj = [],
				obj = {};
			if (configSub_obj.reboot == 0) {
				obj.value = '1';
				obj.node = 'systemReboot';
				obj.index = '.0';
				reobj.push(obj);
			} else if (configSub_obj.reboot == 1) {
				obj.value = '1';
				obj.node = 'mcReboot';
				obj.index = '.0';
				reobj.push(obj);
			} else if (configSub_obj.reboot == 4) {
				obj.value = '1';
				obj.node = 'cc1Reboot';
				obj.index = '.0';
				reobj.push(obj);
			} else if (configSub_obj.reboot == 5) {
				obj.value = '1';
				obj.node = 'cc2Reboot';
				obj.index = '.0';
				reobj.push(obj);
			} else if (configSub_obj.reboot == 2) {
				obj.value = '1';
				obj.node = 'input1Reboot';
				obj.index = '.0';
				reobj.push(obj);
			} else if (configSub_obj.reboot == 3) {
				obj.value = '1';
				obj.node = 'input2Reboot';
				obj.index = '.0';
				reobj.push(obj);
			} else {
				obj.value = '1';
				obj.node = 'outputPtpRestartAction';
				obj.index = configSub_obj.reboot;
				reobj.push(obj);
			}
			publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/setConfigsBatch", reobj).success(function(r) {
				if (!r || !r.data || r.data.length < 0) return;
				if (r.data.length == 0) {
					var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
					publicService.ngAlert(tt, "info");
					return;
				} else {
					var dataObj = r.data;
					if (dataObj[0].code === true) {
						var tt = $translate.use() === 'ch' ? 　"重启成功" : "Restart success";
						publicService.ngAlert(tt, "info");
					} else if (dataObj[0].code === false) {
						var tt = $translate.use() === 'ch' ? 　"重启成功" : "Restart success";
						publicService.ngAlert(tt, "info");
					}
				}
			})
		}
		//激活钟卡
	$scope.ccActive = function(x, data) {
		var reobj = [],
			obj = {};
		if (x == '1') {
			obj.value = '0';
			obj.node = 'ccState';
			obj.index = '.1';
			reobj.push(obj);
		} else if (x == '2') {
			obj.value = '0';
			obj.node = 'ccState';
			obj.index = '.2';
			reobj.push(obj);
		}

		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/setConfigsBatch", reobj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			if (r.data.length == 0) {
				var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
				publicService.ngAlert(tt, "info");
				return;
			} else {
				var dataObj = r.data;
				if (dataObj[0].code === true) {
					var tt = $translate.use() === 'ch' ? 　"设置成功" : "Set success";
					publicService.ngAlert(tt, "info");
					if (x == '1') {
						$scope.cc1Content = 'active';
						$scope.cc2Content = 'standby';
						$scope.setColockdisabled2 = false;
						$scope.setColockdisabled1 = true;
						$scope.CC1visible = false;
						$scope.CC2visible = true;

					} else if (x == '2') {
						$scope.cc1Content = 'standby';
						$scope.cc2Content = 'active';
						$scope.setColockdisabled1 = false;
						$scope.setColockdisabled2 = true;
						$scope.CC1visible = true;
						$scope.CC2visible = false;
					}
				} else if (dataObj[0].code === false) {
					var tt = $translate.use() === 'ch' ? 　"设置失败" : "Set failed";
					publicService.ngAlert(tt, "info");
				}
			}
		})
	}

	$scope.vlanDel = function(m) {
		var self = this;
		t = $translate.use() === "ch" ? "确认删除?" : "confirm delete？";
		if (confirm(t)) {
			self.configList.splice(self.configList.indexOf(m), 1)
			publicService.loading('start');
			if (m.destNetwork != 'n/a') {
				var vlanCfgV = 'delete-vlanid=' + m.id;
			} else {
				var vlanCfgV = 'delete-index=' + m.vlanIndex;
			}
			var reobj = [],
				obj = {};
			obj.value = vlanCfgV;
			obj.node = 'vlanCfg';
			obj.index = m.vlanIndex;
			reobj.push(obj);
			publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/setConfigsBatch", reobj).success(function(r) {
				if (!r || !r.data || r.data.length < 0) return;
				var dataObj = r.data;
				if (dataObj[0].code === true) {
					publicService.loading('end');
					var tt = $translate.use() === 'ch' ? 　"删除成功！" : "Delete success！";
					publicService.ngAlert(tt, "success");
				} else if (dataObj[0].code === false) {
					var tt = $translate.use() === 'ch' ? 　"删除失败！" : "Delete failed！";
					publicService.ngAlert(tt, "success");
				}
			})
		}
	}
	$scope.listSetConfig = function(x) {
			$scope.deviceContent = x;
			if (x.destNetwork != 'n/a') {
				$scope.all = false;
			} else {
				$scope.all = true;
			}
			if (x.alarmLevel == '5') {
				$scope.alarmLevelyD = true;
				$scope.alarmDelayD = true;
			} else {
				$scope.alarmLevelyD = false;
				$scope.alarmDelayD = false;
			}
			_newVals();
		}
		//重启设备
	$scope.restartPM = function(x) {
		var reobj = [],
			obj = {};
		if (x == 'E1') {
			if($scope.inputCardConfigId == 1){
			    obj.value = $scope.inputCardConfigPortId;
			}else if($scope.inputCardConfigId == 2){
			    obj.value = (parseInt($scope.inputCardConfigPortId)+7).toString();
			}
		} else if (x == 'irig') {
			if($scope.IRIGPortId == 1){
			    obj.value = '7';
			}else if($scope.IRIGPortId == 2){
			    obj.value = '14';
			}
		} else{
			obj.value = x;
		}
		obj.node = 'restartPM';
		obj.index = '.0';
		reobj.push(obj);
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/setConfigsBatch", reobj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			if (r.data.length == 0) {
				var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
				publicService.ngAlert(tt, "info");
				return;
			} else {
				var dataObj = r.data;
				if (dataObj[0].code === true) {
					var tt = $translate.use() === 'ch' ? 　"重置成功" : "Resset success";
					publicService.ngAlert(tt, "info");
				} else if (dataObj[0].code === false) {
					var tt = $translate.use() === 'ch' ? 　"重置成功" : "Resset success";
					publicService.ngAlert(tt, "info");
				}
			}
		})
	}

	$scope.restSub = function(x) {
		var configSub_obj = [];
		obj = {};
		obj.value = '2';
		obj.node = 'ipPortState';
		obj.index = '.' + $scope.ipMode;
		configSub_obj.push(obj);
		configSubmit(configSub_obj);

	}
	$scope.changePort = function() {
		if ($scope.devIP && $scope.devIP != "No selection device") {
			$scope.loadconfigContent();
		}
	}
	$scope.vlanAddEdit = function(m) {
		$state.go("index.config.vlanAddEdit", {
			mauto: m
		});
	}
	$scope.outPTPconfigEnt = function(m, x) {
		if (m) {
			m.devID = $scope.mauto.id;
			//$rootScope.mauto = m;
		}
		if (m.ioSignal == "PPS-TOD" || m.ioSignal == "IRIG") {
			$state.go("index.config.outPPSTODconfig", {
				mauto: m,
				deviceData: x
			});

		} else if (m.ioSignal == "PTP") {
			$state.go("index.config.outPTPconfig", {
				mauto: m,
				deviceData: x
			});

		} else if (m.ioSignal == "E1-T1") {
			var url;
			if (m.ioStatusIndex == '0') {
				url = 'index.config.outE1config';
			} else if (m.ioStatusIndex == '1') {
				url = 'index.config.outE1Exp1config';
			} else if (m.ioStatusIndex == '2') {
				url = 'index.config.outE1Exp2config';
			} else if (m.ioStatusIndex == '3') {
				url = 'index.config.outE1Exp3config';
			} else if (m.ioStatusIndex == '4') {
				url = 'index.config.outE1Exp4config';
			}
			$state.go(url, {
				mauto: m,
				deviceData: x
			});
		} else if (m.ioSignal == "input-PTP") {
			$state.go("index.config.inputPtp", {
				devid: m.devID,
				slot: m.ioStatusSlotID,
				deviceData: x
			});
		} else if (m.ioSignal == "NTP") {
			$state.go("index.config.outputNTP", {
				devid: m.devID,
				slot: m.ioStatusSlotID,
				exp: m.ioStatusIndex,
				deviceData: x
			});
		} else if (m.ioSignal == "FREQ") {
			var url;
			if (m.ioStatusIndex == '0') {
				url = 'index.config.outputCardFREQConfig';
			} else if (m.ioStatusIndex == '1') {
				url = 'index.config.outputCardFREQExp1Config';
			} else if (m.ioStatusIndex == '2') {
				url = 'index.config.outputCardFREQExp2Config';
			} else if (m.ioStatusIndex == '3') {
				url = 'index.config.outputCardFREQExp3Config';
			} else if (m.ioStatusIndex == '4') {
				url = 'index.config.outputCardFREQExp4Config';
			}
			$state.go(url, {
				devid: m.devID,
				slot: m.ioStatusSlotID,
				exp: m.ioStatusIndex,
				deviceData: x
			});
		}

	}


	$scope.outPTPchange = function(m) {
			var index = '.' + m.ioStatusIndex + '.' + m.ioStatusSlotID;
			t = $translate.use() === "ch" ? "确认切换？" : "confirm change？";
			if (confirm(t)) {
				var reobj = [],
					obj = {};
				obj.value = m.ioStatusRedundancyKey;
				obj.node = 'outputRedundancyState';
				obj.index = index;
				reobj.push(obj);

				publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/setConfigsBatch", reobj).success(function(r) {
					if (!r || !r.data || r.data.length < 0) return;
					if (r.data.length == 0) {
						var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
						publicService.ngAlert(tt, "info");
						return;
					} else {
						var dataObj = r.data;
						if (dataObj[0].code === true) {
							var tt = $translate.use() === 'ch' ? 　"设置成功" : "Set success";
							publicService.ngAlert(tt, "info");
							setTimeout(function() {
								$scope.loadconfigContent();
							}, 3000)
						} else if (dataObj[0].code === false) {
							var tt = $translate.use() === 'ch' ? 　"设置失败" : "Set failed";
							publicService.ngAlert(tt, "info");
							setTimeout(function() {
								$scope.loadconfigContent();
							}, 3000)
						}
					}
				})
			}
		}
		/**
		 * downloadConfig
		 *   导出配置
		 */
	$scope.downloadConfig = function(indexs, table) {
			if (!$scope.mauto) {
				var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
				publicService.ngAlert(tt, "info");
				return;
			}
			var config_obj = [];
			if (!table) {
				var _vals = JSON.parse(localStorage.getItem('valueDoms'));
				for (var j = 0; j < _vals.length; j++) {
					var obj = {};
					if (_vals[j].name == 'pktServiceCCMode') continue
					obj.node = _vals[j].name;
					obj.index = indexs;
					config_obj.push(obj);
				}
			} else {
				config_obj = [{
					'node': table,
					'index': ''
				}]
			}
			publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/downloadConfig/config", config_obj).success(function(r) {
				if (!r || !r.data || r.data.length < 0) return;
				window.location.href = 'http://' + location.hostname + r.data + '';
			})
		}
		/**
		 * downloadConfig2
		 *   导出配置
		 */
	$scope.downloadConfig2 = function() {
		if (!$scope.mauto) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}
		var config_obj = [];
		config_obj = [{
			'node': 'ioStatusTable',
			'index': ''
		}]
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/downloadConfig/config", config_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}
	$scope.seachIO = function() {
		var self = this;
		$scope.mauto = self.devID;
		$scope.devExp = self.devExp;
		if ($rootScope.sm2000devID) {
			$scope.mauto = $rootScope.sm2000devID;
			$scope.loadconfigContent();
		} else {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}
		if (!$scope.devExp || $scope.devExp == 'undefined' || $scope.devExp == '未选择') {
			var tt = $translate.use() === 'ch' ? 　"请选择机框" : "Please select machine frame";
			publicService.ngAlert(tt, "info");
			return;
		}
		var devId = $rootScope.sm2000devID.id;
		publicService.doRequest("GET", "/nms/spring/deviceConfig/" + devId + "/getIoStatus", {
			shelfIndex: self.devExp
		}).success(function(r) {
			if (r.data && r.data.length > 0) {
				$scope.frameConfigList = r.data;
				if ($scope.devExp == '0') {
					$scope.inputCardConfigCard = r.data[0].ioSignal;
				} else {
					$scope.inputCardConfigCard = '4-E1';
				}
			}
		})


		publicService.doRequest("GET", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/configs/outputRedundancyTable", {}).success(function(r) {
			if (r.data && r.data.length > 0) {
				var ioLists = $scope.frameConfigList;
				redList = r.data;
				if (self.devExp == '0') {
					var a = 0;
				} else if (self.devExp == '1') {
					var a = 9;
				} else if (self.devExp == '2' || self.devExp == '3' || self.devExp == '4') {
					var a = 9 + parseInt(parseInt(self.devExp) - 1) * 14;
				}
				for (var i = 0; i < ioLists.length; i++) {
					ioLists[i].ioStatusRedundancy = redList[parseInt(i + a)].outputRedundancyState;
				}
				$scope.frameConfigList = ioLists;
			}
		})
	}

	if ($stateParams.deviceData) {
		$scope.devID = $stateParams.deviceData;
		$rootScope.sm2000devID = $stateParams.deviceData;
		$rootScope.devIP = $stateParams.deviceData.name;
		$scope.shelfList = $stateParams.deviceData.shelfList;
		$scope.devExp = '0';
		$scope.seachIO();
	}
	if ($rootScope.sm2000devID) {
		$scope.mauto = $rootScope.sm2000devID;
		$rootScope.devIP = $rootScope.sm2000devID.name;
		$scope.shelfList = $rootScope.sm2000devID.shelfList;
		$scope.devExp = '0';
		$scope.seachIO();
	} else {
		$rootScope.devIP = '';
		$scope.frameConfigList = '';

	}
	$scope.macChange = function(x) {
		var self = this;
		$scope.mauto = self.devID;
		if (self.devID && self.devID.deviceStatus != 0) {
			localStorage.setItem("mauto", angular.toJson(self.devID));
			//子页面之间传值
			/*	$rootScope.shelfList = self.devID.shelfList;
			 */
			$rootScope.devIP = self.devID.name;
			$rootScope.sm2000devID = self.devID;
			//界面显示
			$scope.shelfList = self.devID.shelfList;
			$scope.devIP = self.devID.ip;
			$scope.devExp = '0';
		} else if (self.devID && self.devID.deviceStatus != 1) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}
	}

	$scope.seach = function() {
		if ($rootScope.sm2000devID) {
			$scope.mauto = $rootScope.sm2000devID;
			$scope.loadconfigContent();
		} else {
			publicService.ngAlert('请选择设备', "info");
		}
	}
}]);