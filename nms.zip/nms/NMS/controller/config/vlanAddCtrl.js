angular.module('sm2000vlanAddModule',[]).controller('vlanAddCtrl', ['$scope', '$rootScope',"$translate", "$state", "$timeout", 'publicService', function($scope, $rootScope,$translate,  $state, $timeout, publicService) {
	var mauto  = localStorage.getItem("mauto");
	if(mauto){
		mauto = JSON.parse(localStorage.getItem("mauto"));
		$scope.mauto = mauto;
	}
	$scope.idvisible = false;
	$scope.ipvisible = true;
	$scope.backArea = function() {
		window.history.back();
	}
	$scope.vlanIdChange = function(m) {
			if (m == 1) {
				$scope.idvisible = true;
				$scope.ipvisible = false;
			} else if (m == 2) {
				$scope.idvisible = false;
				$scope.ipvisible = true;
			}
		}
		/**
		 * vlanAddSub
		 *   添加VLAN
		 */
	$scope.vlanAddSub = function(x, vlanFACid) {
		if(!$scope.mauto.id){
				var tt = $translate.use() === 'ch' ?　"请选择设备" : "Please select device";
				publicService.ngAlert(tt,"info");
		}
		var reobj = [],
			obj = {},
			vlanCfg;
		if (vlanFACid == '1') {
			 vlanCfg = new Array('index=' + x.vadd_index, 'id=' + x.vadd_id, 'priority=' + x.vadd_priority, 'addr=' + x.vadd_addr, 'netmask=' + x.vadd_netmask, 'gateway=' + x.vadd_gateway);
		} else if (vlanFACid == '2') {
			 vlanCfg = new Array('id=' + x.vadd_id, 'priority=' + x.vadd_priority, 'addr=' + x.vadd_addr, 'netmask=' + x.vadd_netmask, 'nextHop=' + x.vadd_gateway, 'destNetwork=' + x.vadd_destNetwork+'/24');
		}
		vlanCfg = vlanCfg.join(',');
		obj.value = vlanCfg;
		obj.node = 'vlanCfg';
		obj.index = x.vadd_index;
		reobj.push(obj);

		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/setConfigsBatch", reobj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			if (r.data.length == 0) {
					var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
					publicService.ngAlert(tt, "info");
				return;
			} else {
				var dataObj = r.data;
				if (dataObj[0].code === true) {
					publicService.ngAlert(r.message, "info");
				} else if (dataObj[0].code === false) {
					publicService.ngAlert(r.message, "info");
				}
			}
		})
	}
}]);
