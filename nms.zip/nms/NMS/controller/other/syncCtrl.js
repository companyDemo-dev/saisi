angular.module('syncModule', []).controller('syncCtrl', ['$scope', '$rootScope', '$http', '$state', 'publicService', "$translate", function($scope, $rootScope, $http, $state, publicService, $translate) {

    publicService.doRequest("GET", 112, {
        page: "",
        pageSize: 200,
        name: "",
        ip: "",
        deviceStatus: "",
        areaId: "",
        deviceType: ""
    }).success(function(r) {
        if (r.data !== null && r.data.content && r.data.content.length > 0) {
            var content = r.data.content;
            var deviceInfo = [];
            for (i = 0; i < content.length; i++) {
                deviceInfo.push(content[i]);
            }
            $scope.deviceInfo = deviceInfo;
        }
    })
    $scope.configSub = function(m,x) {
       publicService.doRequest("GET", '/nms/spring/systemManage/updateSysDate/'+m.id+'?timeZone='+x, {}).success(function(r) {
       })
       publicService.ngAlert('设置成功', "info");

    }
}]);