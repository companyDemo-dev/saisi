angular.module('systemLogModule', []).controller('otherLanguageCtrl', ['$scope', '$rootScope', '$http', '$state', 'publicService', "$translate", function($scope, $rootScope, $http, $state, publicService, $translate) {


    /*    $scope.lang = localStorage.getItem("Language") || "ch";
        $scope.$watch("lang",function(a,b){
            $translate.use(a);
            localStorage.setItem("Language",a);
            $rootScope.LANG = a;
             $scope.setSystemLanguage(a);
        })*/
    if ($rootScope.LANG) {
        if ($rootScope.LANG != "ch") {
            $scope.lang = $rootScope.LANG;
        }else{
            $scope.lang = "ch";
        }

    } else {
        localStorage.setItem("Language", "ch");
        $rootScope.LANG = "ch";
        $scope.lang = "ch";
    }
    $scope.setSystemLanguage = function(a) {
        publicService.doRequest("PUT", "/nms/spring/systemManage/setSystemLanguage/" + a + "", '').success(function(r) {
            localStorage.setItem("Language", a);
            $rootScope.LANG = a;
            publicService.ngAlert(r.message, "success");
        })
    }
}]);