angular.module('otherPingModule',[]).controller('otherPingCtrl', ['$scope', '$rootScope', '$http', '$state', 'publicService', function($scope, $rootScope, $http, $state, publicService) {
	$scope.otherPingMod = {};
	$scope.otherPingMod.changePing = "0";
	$scope.otherPingMod.ipType = ""
	

	publicService.doRequest("GET", "/nms/spring/systemManage/getParamConfig", {
		type: 'deviceType'
	}).success(function(r) {
            if (r.data !== null && r.data && r.data.length > 0) {
                $scope.ipType = r.data;
            }
	})
	$scope.pingSub = function(m) {
		if(!m.ipType){
			publicService.ngAlert("请选择设备类型！");
			return;
		}
		if(!m.ipPing){
			publicService.ngAlert("请输入");
			return;
		}
		if (m.changePing == '0') {
			publicService.doRequest("GET", "/nms/spring/device/ipConnCheck", {
				'ip': m.ipPing,
				'deviceType': m.ipType
			}).success(function(r) {
				publicService.ngAlert(r.message);
			})

		} else if (m.changePing == '1') {
			publicService.doRequest("GET", "/nms/spring/device/ipV6ConnCheck", {
				'ip': m.ipPing,
				'deviceType': m.ipType
			}).success(function(r) {
				publicService.ngAlert(r.message);
			})

		}
	}
}]);
