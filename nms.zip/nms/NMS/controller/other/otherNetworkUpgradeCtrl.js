angular.module('otherNetworkUpgradeModule',[]).controller('otherNetworkUpgradeCtrl', ['$scope','$translate', '$rootScope', '$http', '$state', 'publicService','FileUploader', function($scope, $translate,$rootScope, $http, $state, publicService,FileUploader) {
    var uploader = $scope.uploader = new FileUploader({
        url: '/nms/spring/systemManage/updateWebApp/serverFile?token=' + $rootScope.curLoginMsg.sessionID,
        method: 'POST'
    });

    uploader.onAfterAddingFile = function(fileItem) {
    	$scope.fileName = fileItem.file.name
    };

    uploader.onSuccessItem = function(fileItem, response, status, headers) {
        if (!response.errCode) {
                    var tt = $translate.use() === 'ch' ? 　"上传成功！" : "Upload success!";
                    publicService.ngAlert(tt, "info");
            $state.go('login');
        } else {
            publicService.ngAlert(response.message,"danger")
        }
       
    };
    uploader.onErrorItem = function(fileItem, response, status, headers) {
    	publicService.ngAlert(status,"danger")
    };
}]);
