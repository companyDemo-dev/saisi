angular.module('mapdataModule', []).controller('mapdataCtrl', ['$scope', '$stateParams', '$rootScope', '$http', '$state', 'publicService', "$translate", function($scope, $stateParams, $rootScope, $http, $state, publicService, $translate) {


    var obj = {
        key :"",
        page: "",
        pageSize: 20
    };
    publicService.doRequest("GET", 'spring/systemManage/getFieldDataDictionaryPage', obj).success(function(r) {
        $scope.deviceMangeList = r.data.content;
    })

    $scope.portManageSub = function(m) {
        var url, method;
        url = '/nms/spring/systemManage/saveFieldDataDictionary';
        method = "POST";
        publicService.doRequest(method, url, m).success(function(r) {
            if (r.errCode) {
                publicService.ngAlert(r.message, "danger");
            } else {
                publicService.ngAlert('操作成功', "success");
            }
        })
    }
}]);