angular.module('otherlockFrameModule',[]).controller('otherlockFrameCtrl', ['$scope','$translate', '$rootScope', '$http', '$state', 'publicService', function($scope,$translate, $rootScope, $http, $state, publicService) {
	$scope.lockFrame = true;
	$scope.lockFrameSub = function() {
		var otherFrameObj = localStorage.getItem("otherFrame");
		if (!otherFrameObj) {
			var otherFrame = {
				"frameOffOn": "off",
				"pwOffOn": "off",
				"frameInterval": "5",
				"framePsw": 123
			};
		} else {
			var otherFrame = JSON.parse(otherFrameObj);
		}
		if (otherFrame.pwOffOn == 'on') {
			$scope.lockFrame = false;
			$scope.paswdFrame = true;
		} else {
			window.history.back();
		}
	};

	$scope.sendUp = function(x) {
		var otherFrame = JSON.parse(localStorage.getItem("otherFrame"));
		if (!x) {
			var tt = $translate.use() === 'ch' ? 　"解锁密码不能为空！" : "Unlock password can not be empty!";
			publicService.ngAlert(tt, "info");
		}
		if (otherFrame.framePsw == x) {
			window.history.back();
		} else {
			var tt = $translate.use() === 'ch' ? 　"请输入正确的解锁密码！" : "Please enter the correct unlock password!";
			publicService.ngAlert(tt, "info");
		}
	};
	$scope.exit = function() {
		delete $rootScope.curLoginMsg;
		$state.go('login');
	};
	/**
	 * macFrameTime
	 *  获取主机框时间
	 */
	var now1 = new Date();
	$scope.lockMacFrameTime = now1.getHours() + ':' + now1.getMinutes() + ':' + now1.getSeconds();
	$scope.SetTimer = function() {
		$scope.$apply(function() {
			var now = new Date();
			$scope.lockMacFrameTime = now.getHours() + ':' + now.getMinutes() + ':' + now.getSeconds();
		});
	};
	$scope.SetTimerInterval = setInterval($scope.SetTimer, 1000);
}]);
