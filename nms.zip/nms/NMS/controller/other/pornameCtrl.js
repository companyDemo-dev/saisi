angular.module('pornameModule', []).controller('pornameCtrl', ['$scope', '$stateParams', '$rootScope', '$http', '$state', 'publicService', "$translate", function($scope, $stateParams, $rootScope, $http, $state, publicService, $translate) {
  publicService.doRequest("GET", 112, {
        page: "",
        pageSize: 200,
        name: "",
        ip: "",
        deviceStatus: "",
        areaId: "",
        deviceType: ""
    }).success(function(r) {
        if (r.data == null) return
        if (r.data !== null && r.data.content && r.data.content.length > 0) {
            var content = r.data.content;
            var deviceInfo = [];
            for (i = 0; i < content.length; i++) {
                deviceInfo.push(content[i]);
            }
            $scope.deviceInfo = deviceInfo;
        }
    });
    $scope.seach = function(a,b) {
        if(!$scope.devId){
            var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
            publicService.ngAlert(tt, "info");
            return;
        }
        var obj = {};
        obj.deviceId = a;
        obj.shelf = "";
        obj.slot = "";
        obj.portType = b ||'';
        obj.port =  '';
        publicService.doRequest("GET", "/nms/spring/device/renamePort", obj).success(function(r) {
          $scope.deviceMangeList = r.data;
        })
    }
    
    $scope.deviceMangeEditAdd = function(m,x) {
        $state.go('index.other.pornameConfig', {
            mauto: m,devID:x
        })
    }
    $scope.portManageSub = function(m) {
        if(!$scope.devId){
            var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
            publicService.ngAlert(tt, "info");
            return;
        }
        var url, method;
        if (self.deviceTitle === "修改") {
            url = 114;
            method = "PUT";
            m.id = m.id;
        } else {
            url = '/nms/spring/device/renamePort';
            method = "POST";
        }
        m.device = {id:$scope.devId};
        var obj=[];
        obj.push(m);
        publicService.doRequest(method, url, obj).success(function(r) {
            if (r.errCode) {
                publicService.ngAlert(r.message, "danger");
            } else {
                publicService.ngAlert('操作成功', "success");
            }
        })
    }

    if($stateParams.mauto){
        $scope.mauto = $stateParams.mauto;
        if($stateParams.devID){
        $scope.deviceData = $stateParams.devID;
        $scope.devId = $stateParams.devID.id;
        if($scope.mauto.ioSignal == '4-E1'){
           $scope.portTypeList = [{
                'name': '4-E1'
            }, {
                'name': 'PPS-TOD'
            }, {
                'name': 'IRIG'
            }];
            $scope.portType = '4-E1';
        }else{
           $scope.portTypeList = [{
                'name': $scope.mauto.ioSignal
            }]; 
            $scope.portType = $scope.mauto.ioSignal;
        }
        $scope.seach($scope.devId,$scope.portType);
        }
    }
}]);