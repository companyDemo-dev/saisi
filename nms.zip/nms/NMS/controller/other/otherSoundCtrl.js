angular.module('otherSoundModule',[]).controller('otherSoundCtrl', ['$scope','$translate','$rootScope','$http','$state', 'publicService',  function($scope, $translate,$rootScope, $http, $state, publicService){
	var otherSound = JSON.parse(localStorage.getItem("otherSound"));
	$scope.otherSoundMod = {};
	$scope.otherSoundMod.soundOffOn = (otherSound && otherSound.soundOffOn) === "off" ? false : true;
	$scope.otherSoundMod.soundInterval = (otherSound && otherSound.soundInterval) || "30";
	$scope.otherSoundMod.soundLength = (otherSound && otherSound.soundLength) || "6";
	$scope.otherSoundOffOn = function(){
		var self = this;
		self.otherSoundMod.soundOffOn = !self.otherSoundMod.soundOffOn;
	}
	$scope.deviceManageSub = function(m){
		var obj = {
			soundOffOn : m.soundOffOn ? "on" : "off",
			soundInterval : m.soundInterval,
			soundLength : m.soundLength
		}
		$scope.$emit("otherSoundMsg", obj);//将消息传topbar
		localStorage.setItem("otherSound", angular.toJson(obj));
					var tt = $translate.use() === 'ch' ? 　"设置成功" : "Set success";
					publicService.ngAlert(tt, "info");
	}
}]);
