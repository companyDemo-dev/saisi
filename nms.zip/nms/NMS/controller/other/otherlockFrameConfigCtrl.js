angular.module('otherlockFrameConfigModule',[]).controller('otherlockFrameConfigCtrl', ['$scope', "$translate",'$rootScope', '$http', '$state', 'publicService', function($scope,$translate, $rootScope, $http, $state, publicService) {
	var otherFrameObj = localStorage.getItem("otherFrame");
	if (!otherFrameObj) {
		var otherFrame = {
			"frameOffOn": "off",
			"pwOffOn": "off",
			"frameInterval": "5",
			"framePsw": 123
		};
	} else {
		var otherFrame = JSON.parse(otherFrameObj);
	}
	$scope.otherlockFrame = {};
	$scope.otherlockFrame.frameOffOn = (otherFrame && otherFrame.frameOffOn) === "on" ? true : false;
	$scope.otherlockFrame.pwOffOn = (otherFrame && otherFrame.pwOffOn) === "on" ? true : false;
	$scope.otherlockFrame.frameInterval = (otherFrame && otherFrame.frameInterval) || 30;
	$scope.otherlockFrame.framePsw = (otherFrame && otherFrame.framePsw) || 123;
	$scope.otherFrameOffOn = function() {
		var self = this;
		self.otherlockFrame.frameOffOn = !self.otherlockFrame.frameOffOn;
	}
	$scope.otherPwOffOn = function() {
		var self = this;
		self.otherlockFrame.pwOffOn = !self.otherlockFrame.pwOffOn;
	}


	$scope.frameManageSub = function(m) {
		if (!m.framePsw) {
					var tt = $translate.use() === 'ch' ? 　"解锁密码不能为空！" : "Unlock password can not be empty!";
					publicService.ngAlert(tt, "info");
			return
		}
		var obj = {
			frameOffOn: m.frameOffOn ? "on" : "off",
			pwOffOn: m.pwOffOn ? "on" : "off",
			frameInterval: m.frameInterval,
			framePsw: m.framePsw
		}
		localStorage.setItem("otherFrame", angular.toJson(obj));
		$scope.$emit("otherFrame", obj);
					var tt = $translate.use() === 'ch' ? 　"设置成功" : "Set success";
					publicService.ngAlert(tt, "info");
	}
}]);
