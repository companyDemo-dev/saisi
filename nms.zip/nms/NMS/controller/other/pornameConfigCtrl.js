angular.module('pornameConfigModule', []).controller('pornameConfigCtrl', ['$scope', '$stateParams', '$rootScope', '$http', '$state', 'publicService', "$translate", function($scope, $stateParams, $rootScope, $http, $state, publicService, $translate) {
  publicService.doRequest("GET", 112, {
        page: "",
        pageSize: 200,
        name: "",
        ip: "",
        deviceStatus: "",
        areaId: "",
        deviceType: ""
    }).success(function(r) {
        if (r.data == null) return
        if (r.data !== null && r.data.content && r.data.content.length > 0) {
            var content = r.data.content;
            var deviceInfo = [];
            for (i = 0; i < content.length; i++) {
                deviceInfo.push(content[i]);
            }
            $scope.deviceInfo = deviceInfo;
        }
    });

    $scope.backDevice = function() {
        window.history.back();
    }
        $scope.backShow = true;
    if($stateParams.mauto){
        $scope.mauto = $stateParams.mauto;
        $scope.deviceData = $stateParams.devID;
        $scope.devId = $stateParams.devID.id;
        $scope.backShow = false;
        $scope.deviceTitle = "修改";
        if($scope.mauto.ioSignal == '4-E1'){
           $scope.portTypeList = [{
                'name': '4-E1'
            }, {
                'name': 'PPS-TOD'
            }, {
                'name': 'IRIG'
            }, {
                'name': 'GNSS'
            }];
            $scope.portType = '4-E1';
        }else{
           $scope.portTypeList = [{
                'name': $scope.mauto.ioSignal
            }]; 
            $scope.portType = $scope.mauto.ioSignal;
        }
    }else{
        $scope.deviceTitle = "添加";
        $scope.mauto = {};
    }
    publicService.doRequest("GET", "/nms/spring/systemManage/getParamConfig", {
        type: 'deviceType'
    }).success(function(r) {
            if (r.data !== null && r.data && r.data.length > 0) {
                $scope.deviceType = r.data;
            }
    })
    $scope.portManageSub = function(m) {

        if (!verify.pornameConfig(m, publicService, $translate)) return;
        if(!$scope.devId){
            var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
            publicService.ngAlert(tt, "info");
            return;
        }
        var url, method;
        if (self.deviceTitle === "修改") {
            url = 114;
            method = "PUT";
            m.id = m.id;
        } else {
            url = '/nms/spring/device/renamePort';
            method = "POST";
        }
   
        m.device = {id:$scope.devId};
        m.shelf = m.ioStatusIndex;
        m.slot = m.ioStatusSlotID;
        m.portType = $scope.portType;
        m.id = '';
        var obj=[];
        obj.push(m);
        publicService.doRequest(method, url, obj).success(function(r) {
            if (r.errCode) {
                publicService.ngAlert(r.message, "danger");
            } else {
                publicService.ngAlert('操作成功', "success");
            }
        })
    }
}]);