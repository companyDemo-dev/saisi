angular.module('passwordRuleModule',[]).controller('passwordRuleCtrl', ['$scope', "$translate",'$rootScope', '$http', '$state', 'publicService', function($scope,$translate, $rootScope, $http, $state, publicService) {
	$scope.mauto={
		isNumbers : "0",
		isComplexity : "0",
		isCharacter : "0",
		isEnglish : "0",
	}

	publicService.doRequest("GET", 119, {}).success(function(r){
		publicService.loading('end');
		if (r.errCode) {
			publicService.ngAlert(data.message, "danger");
		} else {
			var len = r.data.isLength.split('-');
			$scope.isLength1 = len[0];
			$scope.isLength2 = len[1];
			$scope.mauto = r.data;
			publicService.ngAlert(r.message,"success");
		}
	})
	$scope.passCon = function(m){
		if(!m) m = {};
		var _self = this,
			msg = $translate.use() === 'ch' ? 　"不能为空！" : " can not be empty!",
			msg1 = $translate.use() === 'ch' ? 　"格式错误！" : " wrong format!";
		if(verifyFun.isNull(_self.isLength1) || verifyFun.isNull(_self.isLength2)){
			publicService.ngAlert($translate.instant("PASSWORD_LEN") + msg,"warning");
			return ;
		}
		if(!verifyFun.isNumber(parseInt(_self.isLength1)) || !verifyFun.isNumber(parseInt(_self.isLength1)) || parseInt(_self.isLength1) > parseInt(_self.isLength2)){
			publicService.ngAlert($translate.instant("PASSWORD_LEN") + msg1,"warning");
			return ;
		}
		if(verifyFun.isNull(m.isExpiration)){
			publicService.ngAlert($translate.instant("P_E_DATAS") + msg,"warning");
			return ;
		}
		if(!verifyFun.isNumber(m.isExpiration)){
			publicService.ngAlert($translate.instant("P_E_DATAS") + msg1,"warning");
			return ;
		}
		m.isLength = _self.isLength1 + "-" + _self.isLength2;
		publicService.doRequest("POST", 120, m).success(function(r){
			publicService.loading('end');
			if (r.errCode) {
				publicService.ngAlert(r.message, "danger");
			} else {
				publicService.ngAlert(r.message,"success");
			}
		})
	}
}]);
