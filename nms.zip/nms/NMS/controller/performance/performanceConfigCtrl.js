angular.module('performanceConfigModule',[]).controller('performanceConfigCtrl', ['$scope', "$state",'$translate','publicService', "deviceInfoData", function($scope, $state,$translate, publicService,deviceInfoData){
    $scope.portList = [];
    $scope.seachMod = {};
    $scope.seachMod.performanceType = "mtie";
    $scope.performanceConfigList = [];

    $scope.deviceChange = function(m){
        if(!m.deviceId || m.deviceId === ""){$scope.portList = [];return;}
        publicService.doRequest("GET", "/nms/spring/deviceConfig/" + m.deviceId + "/getPerformancePortList", {}).success(function(r){
            $scope.portList = r.data;
        })
    }

    publicService.doRequest("GET", 112, {
        page: "",
        pageSize: 200,
        name: "",
        ip: "",
        deviceStatus: "",
        areaId: "",
        deviceType: ""
    }).success(function(r) {
        if (r.data !== null && r.data.content && r.data.content.length > 0) {
            var content = r.data.content;
            var deviceInfo = [];
            for (i = 0; i < content.length; i++) {
                    deviceInfo.push(content[i]);
            }
            $scope.deviceInfo = deviceInfo;
        }
    })
	$scope.seach = function(m){
        var self = this;
		self.seachMod = m;
		if(!self.seachMod.deviceId){
			var tt = $translate.use() === 'ch' ?　"请选择设备" : "Please select device";
            publicService.ngAlert(tt,"info");
			return;
		}
		self.paginationConf.onChange(self)
	}
    $scope.paginationConf = {
        currentPage: 1,
        totalItems: 0,
        itemsPerPage: 10,
        pagesLength: 15,
        perPageOptions: [10, 20, 30, 40, 50],
        rememberPerPage: 'perPageItems',
        onChange: function(self){
            if(!self) return;
        	var _self = this,
            	obj = {
        		page : _self.currentPage || 1,
        		pageSize : _self.itemsPerPage,    
        		deviceId : self.seachMod.deviceId || "",
        		performanceType : self.seachMod.performanceType  || "",
        		port : self.seachMod.port  || ""
        	};
            publicService.loading('start');
            publicService.doRequest("GET", 27, obj).success(function(r){
        		$scope.performanceConfigList = r.data.content;
                _self.currentPage = parseInt(r.data.number + 1);
                _self.totalItems = r.data.totalElements;
                _self.itemsPerPage = r.data.size;
        	})
        }
    };

    $scope.performanceConfigDel = function(m){ 
		var self = this;
            t = $translate.use() === "ch" ? "确认删除?" : "confirm delete？";
		if(confirm(t)){
			self.performanceConfigList.splice(self.performanceConfigList.indexOf(m),1)
			m.delete = 1;
			publicService.loading('start');
			publicService.doRequest("DELETE", "/nms/spring/performances/PerformanceMonitorParam/" + m.id, {}).success(function(data){
				publicService.loading('end');
                var tt = $translate.use() === 'ch' ?　"删除成功！" : "Delete success！";
                publicService.ngAlert(tt,"success");
			})
		}
	}

	$scope.performanceConfigEditAdd = function(m){
		$state.go('index.performance.performanceConfigEditAdd', {mauto : m})
	}
}]);
