angular.module('performanceConfigEditAddModule',[]).controller('performanceConfigEditAddCtrl', ['$scope','$stateParams',"$state", "$filter","$translate",'publicService', "deviceInfoData", function($scope, $stateParams, $state, $filter,$translate, publicService,deviceInfoData){
	publicService.doRequest("GET", 112, {
        page: "",
        pageSize: 200,
        name: "",
        ip: "",
        deviceStatus: "",
        areaId: "",
        deviceType: ""
    }).success(function(r) {
            if (r.data !== null && r.data.content && r.data.content.length > 0) {
                var content = r.data.content;
                var deviceInfo = [];
                for (i = 0; i < content.length; i++) {
                        deviceInfo.push(content[i]);
                }
                $scope.deviceInfo = deviceInfo;
            }
    })
	if($stateParams.mauto){
		$scope.mauto = $stateParams.mauto;
		$scope.mauto.autoTrapFlag +="";
		$scope.mauto.monitorStatus +="";
		$scope.mauto.monitorStartTime = $filter('date')($scope.mauto.monitorStartTime,'yyyy-MM-dd');
		$scope.mauto.monitorEndTime = $filter('date')($scope.mauto.monitorEndTime,'yyyy-MM-dd');
		$scope.performanceConfigTitle = "修改";
		$scope.mauto.device = $scope.mauto.device.id;
        publicService.doRequest("GET", "/nms/spring/deviceConfig/" + $scope.mauto.device+ "/getPerformancePortList", {}).success(function(r){
            $scope.portList = r.data;
        })
	}else{
		$scope.performanceConfigTitle = "添加";
		$scope.mauto = {};
		$scope.mauto.performanceType = "freq";
		$scope.mauto.autoTrapFlag = "0";
		$scope.mauto.monitorStatus = "0";
	}

	$scope.portList = [];
	$scope.deviceChange = function(m){
        if(!m.device || m.device === ""){$scope.portList = [];$scope.mauto.port = "";return;}
        publicService.doRequest("GET", "/nms/spring/deviceConfig/" + m.device + "/getPerformancePortList", {}).success(function(r){
            $scope.portList = r.data;
        })
    }

	$scope.performanceConfigSub = function(m){
		if(!verify.performanceConfigEditAdd(m,publicService,$translate)) return;
		publicService.loading('start');
		m.device = {id : m.device};
		publicService.doRequest("POST", 28, m).success(function(r){
			if (r && r.errCode) {
				publicService.ngAlert(r.message, "danger");
			}else{
				publicService.ngAlert(r.message,"success");
			}
		})
	}
	$scope.backPerformanceConfig = function(m){
		window.history.back();
	}
}]);
