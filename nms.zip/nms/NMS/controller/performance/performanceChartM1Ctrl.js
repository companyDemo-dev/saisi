angular.module('performanceChartM1Module',[]).controller('performanceChartM1Ctrl', ['$scope', '$rootScope', "$state", 'publicService', function($scope, $rootScope, $state, publicService) {
	loadChart(0, 0)
    publicService.doRequest("GET", 112, {
        page: "",
        pageSize: 200,
        name: "",
        ip: "",
        deviceStatus: "",
        areaId: "",
        deviceType: ""
    }).success(function(r) {
			if (r.data !== null && r.data.content && r.data.content.length > 0) {
				var content = r.data.content;
				var deviceInfo = [];
				for (i = 0; i < content.length; i++) {
						deviceInfo.push(content[i]);
				}
				$scope.deviceInfo = deviceInfo;
			}
    })
	$scope.performanceFrameM = '0';
	$scope.seach = function() {
		var labelData = ["6", "12", "18", "24", "30", "36", "42", "48", "54", "60"];
		var data = [],
			self = this;
		devId = self.devID.id;
		publicService.doRequest("GET", "/nms/spring/performances/getAid/" + devId, {}).success(function(r) {
			var d = r.data;
			switch ($scope.performanceFrameM) {
				case "0":
					var phase1M = d[0].phase1MData;
					break;
				case "1":
					var phase1M = d[1].phase1MData;
					break;
				case "2":
					var phase1M = d[2].phase1MData;
					break;
				case "3":
					var phase1M = d[3].phase1MData;
					break;
				case "4":
					var phase1M = d[4].phase1MData;
					break;
				case "5":
					var phase1M = d[5].phase1MData;
					break;
				case "6":
					var phase1M = d[6].phase1MData;
					break;
				case "7":
					var phase1M = d[7].phase1MData;
					break;
			}
			var series = [],
				series1 = [],
				phase1M = phase1M.replace(/ /g, ','),
				a = 1,
				time = (new Date()).getTime(),
				mtie1 = {};
			mtie1.name = "phase1M";
			mtie1.color = getRandomColor();
			mtie1.line_width = 2;
			phase1MOBJ = phase1M.split(',');
			for (var i = 0; i < 10; i++) {
				a = i * 6 - 1; //接口数据错位
				i == 0 ? mtie = phase1MOBJ[i] : mtie = phase1MOBJ[a];
				series.push(parseInt(mtie));
			} //!!!!
			mtie1.value = series;
			series1.push(mtie1);
			loadChart(series1, labelData)
		})
	}


	function loadChart(datax, datay) {
		datax == 0 ? datax = [{
			name: 'PV',
			value: ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0"],
			color: '#aad0db',
			line_width: 2
		}] : datax = datax;
		var data = datax;
		datay == 0 ? datay = ["6", "12", "18", "24", "30", "36", "42", "48", "54", "60"] : datay = datay;
		var labels = datay;

		var chart = new iChart.LineBasic2D({
			render: 'canvasDiv',
			data: data,
			align: 'center',
			title: {
				text: 'phase1M Chart',
				font: '微软雅黑',
				fontsize: 18,
				color: '#b4b4b4'
			},
			/*			subtitle: {
							text: '14:00-16:00访问量达到最大值',
							font: '微软雅黑',
							color: '#b4b4b4'
						},*/
			/*	footnote: {
					text: 'ichartjs.com',
					font: '微软雅黑',
					fontsize: 11,
					fontweight: 600,
					padding: '0 28',
					color: '#b4b4b4'
				},*/
			width: 1100,
			height: 450,
			shadow: true,
			shadow_color: '#202020',
			shadow_blur: 8,
			shadow_offsetx: 0,
			shadow_offsety: 0,
			background_color: '#2e2e2e',
			tip: {
				enable: true,
				shadow: true,
				move_duration: 400,
				border: {
					enable: true,
					radius: 5,
					width: 2,
					color: '#3f8695'
				},
				listeners: {
					//tip:提示框对象、name:数据名称、value:数据值、text:当前文本、i:数据点的索引
					parseText: function(tip, name, value, text, i) {
						return "" + value + "/ns";
					}
				}
			},
			crosshair: {
				enable: true,
				line_color: '#ec4646'
			},
			sub_option: {
				smooth: true,
				label: false,
				hollow: false,
				hollow_inside: false,
				point_size: 8
			},
			coordinate: {
				width: 910,
				height: 300,
				striped_factor: 0.18,
				grid_color: '#4e4e4e',
				axis: {
					color: '#252525',
					width: [0, 0, 4, 4]
				},
				scale: [{
					position: 'left',
					start_scale: 0,
					end_scale: 100,
				/*	scale_space: 10,*/
					scale_size: 2,
					scale_enable: false,
					label: {
						color: '#9d987a',
						font: '微软雅黑',
						fontsize: 11,
						fontweight: 600
					},
					scale_color: '#9f9f9f'
				}, {
					position: 'bottom',
					label: {
						color: '#9d987a',
						font: '微软雅黑',
						fontsize: 11,
						fontweight: 600
					},
					scale_enable: false,
					labels: labels
				}]
			}
		});
		//利用自定义组件构造左侧说明文本
		chart.plugin(new iChart.Custom({
			drawFn: function() {
				//计算位置
				var coo = chart.getCoordinate(),
					x = coo.get('originx'),
					y = coo.get('originy'),
					w = coo.width,
					h = coo.height;
				//在左上侧的位置，渲染一个单位的文字
				chart.target.textAlign('start')
					.textBaseline('bottom')
					.textFont('600 11px 微软雅黑')
					.fillText('/ns', x - 40, y - 12, false, '#9d987a')
					.textBaseline('top')
					.fillText('(/s)', x + w + 12, y + h + 10, false, '#9d987a');

			}
		}));
		//开始画图
		chart.draw();
	}


	function getRandomColor() {
		return '#' +
			(function(color) {
				return (color += '0123456789abcdef' [Math.floor(Math.random() * 16)]) && (color.length == 6) ? color : arguments.callee(color);
			})('');
	}
}]);
