angular.module('performanceChartModule', []).controller('performanceChartCtrl', ['$scope', '$rootScope', "$state", '$translate', 'publicService', function($scope, $rootScope, $state, $translate, publicService) {
	$scope.performanceFrameM = '0';
	$scope.modelType = '1';
	loadChart(0, 0)
	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				deviceInfo.push(content[i]);
			}
			$scope.deviceInfo = deviceInfo;
		}
	})
	$scope.portList = [];
	$scope.deviceChange = function(m) {
		if (!m || m.id === "") {
			$scope.portList = [];
			return;
		}
		publicService.doRequest("GET", "/nms/spring/deviceConfig/" + m.id + "/getPerformancePortList", {}).success(function(r) {
			$scope.portList = r.data;
		})
	}
	$scope.searchChanged = function() {
		loadChart(0, 0);
	}

	$scope.seach = function() {
		var data = [],
			self = this;
		if ($scope.performanceFrameM == 0) {
			url = 'mtie';
			time = 13;
			if (self.devID && self.devID.deviceType == 'SSU2000') {
				time = 8;
			}
		} else if ($scope.performanceFrameM == 1) {
			url = 'tdev';
			time = 11;
			if (self.devID && self.devID.deviceType == 'SSU2000') {
				time = 12;
			}
		} else if ($scope.performanceFrameM == 2) {
			url = 'freq';
			time = 11;
		} else if ($scope.performanceFrameM == 3) {
			url = 'phase1M';
			time = 11;
		}
		if (!self.devID) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}
		var devId = self.devID.id,
			obj = {
				deviceId: devId,
				type: url,
				stratTime: self.stratTime || "",
				endTime: self.endTime || "",
				port: self.port || "",
				limit: time
			}
		publicService.doRequest("GET", "/nms/spring/performances/getForChart", obj).success(function(r) {
			if (r.data && r.data.length > 0) {
				var d = r.data;
				for (var i = 0; i < d.length; i++) {
					var objs = {};
					objs.data = d[i].y;
					objs.name = '监测值';
					data.push(objs);
					var labelData = d[i].x;
				}
			} else {
				data = 0;
			}
			if (labelData) {
				loadChart(data, labelData);
			} else {
				loadChart(0, 0);

			}
		})
	}

	function numTolog(num) { //转换对数
		for (var i = 0; i < num.length; i++) {
			num[i] = Math.floor(Math.log(num[i]) / Math.log(10) * 100) / 100;
		}
		return num
	}

	function numToexp(num) { //转换对数

		num = Math.floor(Math.exp(num * Math.log(10)) * 100) / 100;

		return num
	}

	function loadChart(y, x) {
		/*		y =  ["400.04","100.06","30.06","-0.06","-0.04","-0.03","300.01","-0.01","0.0","1000.0","0.01"];
				datay = [{
					name: 'PV',
					value: y,
					color: '#aad0db',
					line_width: 2
				}];*/



		if ($scope.performanceFrameM == 0) {
			var chartName = 'MTIE';
		} else if ($scope.performanceFrameM == 1) {
			var chartName = 'TDEV';
		} else if ($scope.performanceFrameM == 2) {
			var chartName = 'FREQ';
		} else if ($scope.performanceFrameM == 3) {
			var chartName = 'Phase1M';
		}
		y == 0 ? datay = [{
			name: '监测值',
			data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
		}] : datay = y;

		if ($scope.performanceFrameM == 0 && $scope.modelType == 1) {
			var arr = [25.3, 26.1, 27.8, 36.0, 52.5, 126.6, 283.5, 309.4, 324.8, 383.7, 413.3, 569.9, 930.6];
			var baseData = {
				name: '模板',
				data: arr
			};
			datay.push(baseData);
		} else if ($scope.performanceFrameM == 1 && $scope.modelType == 1) {
			var arr = [3, 3, 3, 3, 3, 4.5, 15, 30, 30, 30, 30, 30, 30];
			var baseData = {
				name: '模板',
				data: arr
			};
			datay.push(baseData);
		} else if ($scope.performanceFrameM == 0 && $scope.modelType == 2) {
			var arr = [24, 24, 24, 50.6, 80, 133.5, 160, 160, 160, 160, 160, 160, 160];
			var baseData = {
				name: '模板',
				data: arr
			};
			datay.push(baseData);
		} else if ($scope.performanceFrameM == 1 && $scope.modelType == 2) {
			var arr = [3, 3, 3, 4.8, 3, 4.5, 12, 12, 12, 12, 12, 12, 12];
			var baseData = {
				name: '模板',
				data: arr
			};
			datay.push(baseData);
		}
		/*		var arr =[0.01, 0.1, 1, 10];
						
				x == 0 ?  datax = arr : datax = arr;*/
		/*		var datac = '10';
				var datayMax = Math.max.apply(null, datay[0].value);
				var datayMin = Math.min.apply(null, datay[0].value);
				if ($scope.performanceFrameM == 0 || $scope.performanceFrameM == 1) {
					if (datayMax == 0) {
						var datayMax = Math.max.apply(null, datay[1].value);
						var datayMin = Math.min.apply(null, datay[1].value);
					}
				}
				var datayc = Math.abs(datayMax - datayMin);
				datayc = datayc / 10;
				if (datayc > 0) {
					if (datayc.toFixed(3) == 0.000) {
						datac = 0.001;
					} else {
						datac = datayc.toFixed(3);
					}
				}
				if (datayc == 0) {
					if (datayMax != 0 || datayMin != 0) {
						var datayc = Math.abs(datayMax) / 10;
						datac = datayc.toFixed(3);
					}
				}*/
		if ($scope.performanceFrameM == 2 || $scope.performanceFrameM == 3) {
			x == 0 ?  datax = arr : datax = arr;
			
				$('#containerPer').highcharts({
				title: {
					text: chartName + '性能曲线',
					x: -20
				},/*
				subtitle: {
					text: '数据来源: ',
					x: -20
				},*/
				xAxis: {

					title: {
						text: '/s'
					},
                    gridLineWidth: 1,
					categories: x,
				},
				yAxis: {
					title: {
						text: '/ns'
					},
					gridLineWidth: 1,
					plotLines: [{
						value: 0,
						width: 1,
						color: '#808080'
					}]
				},
				tooltip: {
					valueSuffix: '/ns'
				},
				legend: {
					layout: 'vertical',
					align: 'right',
					verticalAlign: 'middle',
					borderWidth: 0
				},
				series: datay
			});

		} else {
			$('#containerPer').highcharts({
				title: {
					text: chartName + '对数性能曲线'
				},
				xAxis: {
					title: {
						text: '/s'
					},
					gridLineWidth: 1,
                tickInterval: 1,
					categories: ['0.1','2','4','10', '21', '45', '100', '213', '457', '1000', '2137', '4570', '10000', '21379', '45708', '100000', ]
				},
				yAxis: {
					title: {
						text: '/ns'
					},
					type: 'logarithmic',
					minorTickInterval: 0.1
				},
				tooltip: {
					headerFormat: '<b>{series.name}</b><br />',
					pointFormat: 'y = {point.y}/ns'
				},
				series: datay
			});
		}



		/*	var chart = new iChart.LineBasic2D({
				render: 'container',
				data: datay,
				align: 'center',
				title: {
					text: chartName + ' 性能曲线',
					font: '微软雅黑',
					fontsize: 18,
					color: '#b4b4b4'
				},
				width: 1100,
				height: 480,
				shadow: true,
				shadow_color: '#202020',
				shadow_blur: 8,
				shadow_offsetx: 0,
				shadow_offsety: 0,
				background_color: '#2e2e2e',
				tip: {
					enable: true,
					shadow: true,
					move_duration: 400,
					border: {
						enable: true,
						radius: 5,
						width: 2,
						color: '#3f8695'
					},
					listeners: {
						//tip:提示框对象、name:数据名称、value:数据值、text:当前文本、i:数据点的索引
						parseText: function(tip, name, value, text, i) {
							return  + numToexp(value) + /ns;
						}
					}
				},
				crosshair: {
					enable: true,
					line_color: '#ec4646'
				},
				sub_option: {
					smooth: true,
					label: false,
					hollow: false,
					hollow_inside: false,
					point_size: 8
				},
				coordinate: {
					width: 910,
					height: 300,
					striped_factor: 0.18,
					grid_color: '#4e4e4e',
					axis: {
						color: '#252525',
						width: [0, 0, 4, 4]
					},
					scale: [{
						position: 'left',
						start_scale: 0,
						end_scale: 10,
						scale_space: 10,
						scale_size: 2,
						scale_enable: false,
						label: {
							color: '#9d987a',
							font: '微软雅黑',
							fontsize: 11,
							fontweight: 600
						},
						scale_color: '#9f9f9f'
					}, {
						position: 'bottom',
						label: {
							color: '#9d987a',
							font: '微软雅黑',
							fontsize: 11,
							fontweight: 600
						},
						scale_enable: false,
						labels: datax
					}]
				}
			});*/
		/*	//利用自定义组件构造左侧说明文本
			chart.plugin(new iChart.Custom({
				drawFn: function() {
					//计算位置
					var coo = chart.getCoordinate(),
						x = coo.get('originx'),
						y = coo.get('originy'),
						w = coo.width,
						h = coo.height;
					//在左上侧的位置，渲染一个单位的文字
					chart.target.textAlign('start')
						.textBaseline('bottom')
						.textFont('600 11px 微软雅黑')
						.fillText('/ns', x - 40, y - 12, false, '#9d987a')
						.textBaseline('top')
						.fillText('(/s)', x + w + 12, y + h + 10, false, '#9d987a');
				}
			}));
			//开始画图
			chart.draw();*/


	}


	function getRandomColor() {
		return '#' +
			(function(color) {
				return (color += '0123456789abcdef' [Math.floor(Math.random() * 16)]) && (color.length == 6) ? color : arguments.callee(color);
			})('');
	}
}]);