angular.module('performanceTableModule',[]).controller('performanceTableCtrl', ['$scope', '$rootScope', "$state",'$translate', 'publicService', function($scope, $rootScope, $state,$translate, publicService) {
    publicService.doRequest("GET", 112, {
        page: "",
        pageSize: 200,
        name: "",
        ip: "",
        deviceStatus: "",
        areaId: "",
        deviceType: ""
    }).success(function(r) {
            if (r.data !== null && r.data.content && r.data.content.length > 0) {
                var content = r.data.content;
                var deviceInfo = [];
                for (i = 0; i < content.length; i++) {
                        deviceInfo.push(content[i]);
                }
                $scope.deviceInfo = deviceInfo;
            }
    })
    $scope.performanceFrameM = '0';
    $scope.performanceList = [];
    $scope.portList = [];
    $scope.deviceChange = function(m){
        if(!m || m.id === ""){
            $scope.portList = [];
            return;
        }
        publicService.doRequest("GET", "/nms/spring/deviceConfig/" + m.id + "/getPerformancePortList", {}).success(function(r){
            $scope.portList = r.data;
        })
    }

    $scope.seach = function(x) {
        var self = this;
        if (x == 0) {
            url = 'mtie';
            time = 13;
            if(self.devID && self.devID.deviceType == 'SSU2000'){
             time = 8;
            }
        } else if (x == 1) {
            url = 'tdev';
            time = 11;
            if(self.devID && self.devID.deviceType == 'SSU2000'){
            time = 12;
            }
        } else if (x == 2) {
            url = 'freq';
            time = 11;
        }else if (x == 3) {
            url = 'phase1M';
            time = 11;
        }
        if (!self.devID) {
            var tt = $translate.use() === 'ch' ?　"请选择设备" : "Please select device";
            publicService.ngAlert(tt,"info");
            return;
        }
        devId = self.devID.id;

        var obj = {
            deviceId: devId,
            type: url,
            stratTime: self.stratTime || "",
            endTime: self.endTime || "",
            port: self.port || "",
            limit: time
        }
        publicService.loading('start');
        publicService.doRequest("GET", "/nms/spring/performances/getForChart", obj).success(function(r) {
            publicService.loading('end');
            $scope.performanceList = r.data;
        })

    }
    $scope.performanceChange = function() {
        delete $scope.performanceList;
    }


}]);
