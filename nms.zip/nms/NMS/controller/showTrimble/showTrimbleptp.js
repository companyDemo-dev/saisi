angular.module('showTrimbleptpListModule', []).controller('showTrimbleptpCtrl', ['$scope', '$rootScope', '$timeout', '$stateParams', "$window", 'publicService', function($scope, $rootScope, $timeout, $stateParams, $window, publicService) {

/*	$scope.refInfoList = [];


	publicService.doRequest("GET", "/nms/spring/deviceConfig/" + $stateParams.id + "/getIoStatus", {
		shelfIndex: 0
	}).success(function(r) {
		if (r.data && r.data.length > 0) {
			var objData = r.data;
			for (i = 0; i < objData.length; i++) {
				if (objData[i].ioSignal == "input-PTP") {
					inputPTP(objData[i].ioStatusSlotID)
				}
			}
		}
	})

	function inputPTP(slot) {
		var arr = [{
			"node": "inputPTPClientConfigState",
			"index": '.'+slot,
			"num": ""
		}, {
			"node": "inputPTPActiveRef",
			"index": '.'+slot,
			"num": ""
		}, {
			"node": "inputPTPOverallQuality",
			"index": '.'+slot,
			"num": ""
		}];
		publicService.loading('start');
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $stateParams.id + "/getDeviceParamColl", arr).success(function(r) {

			if (r && r.data) {
				var obj = JSON.parse(r.data);
				if (obj.inputPTPOverallQuality == '1' && obj.inputPTPActiveRef == '1') {
					obj.inputPTPOverallQuality = 'selected';
				} else if (obj.inputPTPOverallQuality == '1' && obj.inputPTPActiveRef != '1') {
					obj.inputPTPOverallQuality = 'qualified';
				} else {
					obj.inputPTPOverallQuality = 'disqualified';
				}
				if (obj.inputPTPClientConfigState == '1') {
					obj.inputPTPClientConfigState = 'enable';
				} else if (obj.inputPTPClientConfigState == '0') {
					obj.inputPTPClientConfigState = 'disable';
				}
				var objPTP = {
					"inputPTPOverallQuality": obj.inputPTPOverallQuality,
					"inputPTPClientConfigState": obj.inputPTPClientConfigState
				}
				$scope.refInfoList.push(objPTP)
			}

		});
	}*/
	var obj = 'refInfoPtpinTable';
	publicService.doRequest("GET", "/nms/spring/deviceConfig/" + $stateParams.id + "/configs/" + obj + "", {}).success(function(r) {
		var refdata = r.data;
			$scope.refInfoList = refdata;
	})

	$scope.refInfoBack = function() {
		window.history.back();
	}
}]);