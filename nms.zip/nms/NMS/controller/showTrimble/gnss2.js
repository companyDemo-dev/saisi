angular.module('gnss22Module',[]).controller('gnss22Ctrl', ['$scope','$rootScope','$timeout','$stateParams', "$window", 'publicService',  function($scope, $rootScope, $timeout, $stateParams,$window, publicService){
	var obj = 'gnss2InfoTable';
	publicService.doRequest("GET", "/nms/spring/deviceConfig/" + $stateParams.id + "/configs/" + obj + "", {}).success(function(r) {
		$scope.deviceContent = r.data[0];
	})
	var obj2 = 'gnss2SVTable';
	publicService.doRequest("GET", "/nms/spring/deviceConfig/" + $stateParams.id + "/configs/" + obj2 + "", {}).success(function(r) {
				
		if(r.data[0].gnss2SVNum == 0){	
			$scope.refInfoList = '';
		}else{
			$scope.refInfoList = r.data;
		}
	})
	$scope.refInfoBack = function(){
		window.history.back();
	}
}]);
