angular.module('showoffsetModule', []).controller('showoffsetCtrl', ['$scope', '$rootScope', '$timeout', '$stateParams', "$window", 'publicService', function($scope, $rootScope, $timeout, $stateParams, $window, publicService) {


	$scope.ntpStatePortId = '1';
	$scope.seach = function() {
		var devId = $stateParams.id;
		if ($scope.ntpStatePortId) {
			var index = '.' + $scope.ntpStatePortId;
		} else {
			var index = '.1';
		}
		var obj = {};
		obj = [{
			"node": "userInfo",
			"index": index,
			"num": ""
		}]
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + devId + "/getDeviceParamColl", obj).success(function(r) {
			if (r.data && r.data.length > 0) {
				var UserInfoObj = r.data,
					s = UserInfoObj.indexOf('['),
					e = UserInfoObj.lastIndexOf("]");
				if (s > -1 && e > -1) {
					var UserInfo = UserInfoObj.substring(s, e + 1);
					UserInfo = UserInfo.split(/\n+/);

					var UserInfoArr = [];
					for (i = 0; i < UserInfo.length; i++) {
						UserInfoAbj = {};
						UserInfoArrp = UserInfo[i].split('] [');
						UserInfoAbj.ip = UserInfoArrp[1];
						UserInfoAbj.timeq = UserInfoArrp[2];
						UserInfoAbj.offset = UserInfoArrp[3].replace(']','');
						UserInfoArr.push(UserInfoAbj);
					}

					$scope.UserInfoList = UserInfoArr;
				} else {
					$scope.UserInfoList = [];
				}
			}
		})
	}
	$scope.seach();
	$scope.changePort = function() {
		$scope.seach();
	}

	$scope.refInfoBack = function(){
		window.history.back();
	}
}]);