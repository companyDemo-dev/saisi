angular.module('showTrimbleModule', []).controller('showTrimbleCtrl', ['$scope', '$rootScope', '$timeout', '$stateParams', "$window", 'publicService', function($scope, $rootScope, $timeout, $stateParams, $window, publicService) {
	var obj = 'refInfoTable';
	publicService.doRequest("GET", "/nms/spring/deviceConfig/" + $stateParams.id + "/configs/" + obj + "", {}).success(function(r) {
		var refdata = r.data;

		function huidiao(r) { //回调函数
			var loadPortnamedata = r;
			for (var i = 0; i < refdata.length; i++) {
				if (i == 0) {
					for (var j = 0; j < loadPortnamedata.length; j++) {
						if (loadPortnamedata[j].portType == 'GNSS'  ) {
							if (loadPortnamedata[j].port == 1) {
								portNamedata = loadPortnamedata[j].portName;
								refdata[i].portName = portNamedata;
								break
							} else {
								refdata[i].portName = 'GNSS';
							}
						}else{

								refdata[i].portName = 'GNSS';
						}
					}
				}
				if (i == 1) {
					for (var j = 0; j < loadPortnamedata.length; j++) {
						if (loadPortnamedata[j].portType == 'GNSS'  ) {
							if (loadPortnamedata[j].port == 2) {
								portNamedata = loadPortnamedata[j].portName;
								refdata[i].portName = portNamedata;
								break
							} else {
								refdata[i].portName = 'GNSS';
							}
						}else{

								refdata[i].portName = 'GNSS';
						}
					}
				}
				if (i == 2) {
					for (var j = 0; j < loadPortnamedata.length; j++) {
						if (loadPortnamedata[j].portType == 'PPS-TOD'  ) {
							if (loadPortnamedata[j].port == 1) {
								portNamedata = loadPortnamedata[j].portName;
								refdata[i].portName = portNamedata;
								break
							} else {
								refdata[i].portName = 'PPS-TOD';
							}
						}else{

								refdata[i].portName = 'PPS-TOD';
						}
					}
				}

				if (i == 3) {
					for (var x = 0; x < loadPortnamedata.length; x++) {
						if (loadPortnamedata[x].portType == 'PPS-TOD') {
							if (loadPortnamedata[x].port == 2) {
								portNamedata = loadPortnamedata[j].portName;
								refdata[i].portName = portNamedata;
								break
							}else {
								refdata[i].portName = 'PPS-TOD';
						}
						} else {
								refdata[i].portName = 'PPS-TOD';
							break
						}
					}
				}
				if (i >= 4 && i < 8) {
					var Nport = i-3;
					for (var x = 0; x < loadPortnamedata.length; x++) {
						if ('4-E1' == loadPortnamedata[x].portType) {
							if (loadPortnamedata[x].port == Nport && loadPortnamedata[x].slot == 1) {
								portNamedata = loadPortnamedata[x].portName;
								refdata[i].portName = portNamedata;
								break
							}else {
								refdata[i].portName = '4-E1';
						}
						} else {
								refdata[i].portName = '4-E1';
						}
					}

				}
				if (i >= 8) {
					var Nport = i-7;
					for (var x = 0; x < loadPortnamedata.length; x++) {
						if ('4-E1' == loadPortnamedata[x].portType) {
							if (loadPortnamedata[x].port == Nport && loadPortnamedata[x].slot == 2) {
								portNamedata = loadPortnamedata[x].portName;
								refdata[i].portName = portNamedata;
								break
							}else {
								refdata[i].portName = '4-E1';
						}
						} else {
								refdata[i].portName = '4-E1';
						}
					}

				}


			}
			$scope.refInfoList = refdata;
		}
		loadreport($stateParams.id, '', huidiao);
	})
	$scope.refInfoBack = function() {
		window.history.back();
	}

	function loadreport(devId, port, callback) {
		var loadPortname = {};
		loadPortname.deviceId = devId;
		loadPortname.shelf = "";
		loadPortname.slot = "";
		loadPortname.portType = '';
		loadPortname.port = "";
		publicService.doRequest("GET", "/nms/spring/device/renamePort", loadPortname).success(function(r) {
			callback(r.data);
		})
	}
}]);