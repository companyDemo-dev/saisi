angular.module('gnss11Module',[]).controller('gnss11Ctrl', ['$scope','$rootScope','$timeout','$stateParams', "$window", 'publicService',  function($scope, $rootScope, $timeout, $stateParams,$window, publicService){
	var obj = 'gnss1InfoTable';
	publicService.doRequest("GET", "/nms/spring/deviceConfig/" + $stateParams.id + "/configs/" + obj + "", {}).success(function(r) {
		$scope.deviceContent = r.data[0];
	})
	var obj2 = 'gnss1SVTable';
	publicService.doRequest("GET", "/nms/spring/deviceConfig/" + $stateParams.id + "/configs/" + obj2 + "", {}).success(function(r) {
	
		if(r.data[0].gnss1SVNum == 0){	
			$scope.refInfoList = '';
		}else{
			$scope.refInfoList = r.data;
		}
	})
	$scope.refInfoBack = function(){
		window.history.back();
	}
}]);
