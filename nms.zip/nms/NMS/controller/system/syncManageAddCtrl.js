angular.module('syncManageAddModule',[]).controller('syncManageAddCtrl', ['$scope', "$state","$translate",'publicService', function($scope, $state, $translate,publicService){
	$scope.backArea = function(){
		window.history.back();
	}
	$scope.syncManageSub = function(m){
		m.state = 1;
		if(!verify.syncManageAdd(m, publicService, $translate)) return
		publicService.doRequest("POST", '/nms/spring/systemManage/systemTimeRefConfig/save', m).success(function(r){
				publicService.ngAlert('添加成功', "info");
		})
	}
}]);
