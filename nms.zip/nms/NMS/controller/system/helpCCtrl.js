angular.module('helpCModule',[]).controller('helpCCtrl',['$scope', '$state', '$rootScope', '$stateParams', '$rootScope', "$translate", '$state', 'publicService', function($scope, $state, $rootScope, $rootScope, $stateParams, $translate, $state, publicService) {

			var myPDF = new PDFObject({
				url: "nms.pdf"
					// id: "myPDF",
					// width: "500px",
					// height: "300px",
					// pdfOpenParams: {
					// navpanes: 1,
					// statusbar: 0,
					// view: "FitH",
					// pagemode: "thumbs"

			}).embed("NMSPDF");
	

	}]);