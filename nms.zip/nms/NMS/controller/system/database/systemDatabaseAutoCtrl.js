angular.module('systemDatabaseAutoModule',[]).controller('systemDatabaseAutoCtrl', ['$scope','$translate','$http','$state', 'publicService',  function($scope, $translate, $http, $state, publicService){
	$scope.databaseAutoAdd = function(m){
		$state.go("index.system.databaseAutoAddEdit", {mauto : m});
	}
	publicService.loading('start');
	publicService.doRequest("GET", 11, {tableName : ""}).success(function(r){
		$scope.databaseAutoList = r.data.content;
		publicService.loading('end');
	})

	// publicService.doRequest("GET", 12, {}).success(function(r){
	// 	$rootScope.databaseTableName = r.data;
	// 	publicService.loading('end');
	// })
	$scope.databaseAutoDel = function(m){
		var self = this;
            t = $translate.use() === "ch" ? "确认删除?" : "confirm delete？";
		if(confirm(t)){
			self.databaseAutoList.splice(self.databaseAutoList.indexOf(m),1)
			m.isDelete = 1;
			m.delete = 1;
			publicService.loading('start');
			publicService.doRequest("DELETE", "/nms/spring/databaseBackup/backupConfigParam/" + m.id, {}).success(function(r){
				publicService.loading('end');
                publicService.ngAlert(r.message,"success");
			})
		}
	}
}]);
