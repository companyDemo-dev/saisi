angular.module('databaseConfigEditModule',[]).controller('databaseConfigEditCtrl', ['$scope', '$translate', "$timeout", '$rootScope', "$stateParams", '$state', 'publicService',  function($scope, $translate, $timeout, $rootScope, $stateParams, $state, publicService) {
	$scope.mauto = {};
	if ($stateParams.mauto) {
		$scope.mauto = $stateParams.mauto;
		$scope.autoT = "修改";
		$scope.mauto.isDelete = String($scope.mauto.isDelete);
	} else {
		$scope.autoT = "添加";
		$scope.mauto = {};
		$scope.mauto.isDelete = "0";

	}
	$scope.dababaseAutoSub = function(m) {
		var self = this;
		publicService.loading('start');
		var self = this;
		self.disabledFlag = true;
		publicService.doRequest("POST", 'spring/systemManage', m, self).success(function(r) {
			publicService.ngAlert(r.message, "success");
			publicService.loading('end');
			self.disabledFlag = false;
		})
	}
	$scope.backAuto = function() {
		window.history.back();
	}
}]);

