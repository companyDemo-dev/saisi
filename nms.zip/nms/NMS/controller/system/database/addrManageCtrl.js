angular.module('addrManageModule', []).controller('addrManageCtrl', ['$scope', '$rootScope', '$http', '$state', '$translate', "ngDialog", 'publicService', function($scope, $rootScope, $http, $state, $translate, ngDialog, publicService) {
    $scope.loadMenuTreeData = function() {
        $scope.showSelected = function(sel) {
            $scope.selectedNode = sel;
        };

        publicService.doRequest("GET", '/nms/spring/systemManage/address/search?code=GW&name=GW').success(function(data) {
            if (data.data && data.data.length > 0) {
                $scope.menuTreeData = data.data;
            }
        });
    }
    $scope.loadMenuTreeData();
    //打开菜单

    $scope.loadMenuChildData = function(sel) {
        let parentId = sel.id;
        publicService.doRequest("GET", '/nms/spring/systemManage/address/findByParent?parentId=' + parentId).success(function(data) {
            if (data.data && data.data.length > 0) {
                sel.children = data.data;
                $scope.menuTreeData.push(sel);
            }
        });
    }

    $scope.data = 1;
    $scope.menuFun = function(sel) {
        $scope.data += 1;
        if ($scope.data <= 2) {
            ngDialog.open({
                    template: "template/dialog/addrDialog.html",
                    className: 'ngdialog-theme-default ngdialog-theme-custom',
                    width: 407,
                    controller: function($scope, publicService) {
                        $scope.node = sel;
                        $scope.menuDigDel = function(m) {
                            t = $translate.use() === "ch" ? "确认删除?" : "confirm delete？";
                            if (confirm(t)) {
                                ngDialog.close('ngdialog1');
                                publicService.loading('start');

                                ngDialog.close({
                                    template: "template/dialog/addrDialog.html",
                                    className: 'ngdialog-theme-default ngdialog-theme-custom',
                                    width: 407,
                                    controller: function($scope, publicService) {},
                                    preCloseCallback: function($scope) {}
                                });
                                var n={};
                                n.id =m.id;
                                publicService.doRequest("DELETE", '/nms/spring/systemManage/address/delete',n).success(function() {
                                    publicService.loading('end');
                     
                                    var tt = $translate.use() === 'ch' ? 　"删除成功！" : "Delete success！";
                                    publicService.ngAlert(tt, "success");
                                })
                            }
                        };
                        //添加编辑菜单
                        $scope.menuDigEditAdd = function(x, obj) {
                            ngDialog.close({
                                template: "template/dialog/addrDialog.html",
                                className: 'ngdialog-theme-default ngdialog-theme-custom',
                                width: 407,
                                controller: function($scope, publicService) {},
                                preCloseCallback: function($scope) {}
                            });

                            ngDialog.open({
                                template: "template/dialog/addrManageAdd.html",
                                className: 'ngdialog-theme-default ngdialog-theme-custom',
                                width: 407,
                                controller: function($scope, publicService) {
                                    if (obj == 'edit') {
                                        $scope.menuDigWay = '修改区域';
                                        $scope.menuDigEditAddName = '' + sel.menuName + '';
                                        $scope.item = sel;
                                    } else {
                                        $scope.menuDigWay = '添加下级区域';
                                        $scope.menuDigEditAddName = '';
                                    }

                                    $scope.menuDigSub = function(m) {
                                        /*if(!verify.deviceManageEditAdd(m, publicService)) return;*/
                                        publicService.loading('start');

                                        var url, method,n={};
                                        if ($scope.menuDigWay === "修改区域") {
                                            method = "POST";
                                            n.parent = {
                                                id: x.parent.id
                                            };
                                            n.id = x.id;
                                        } else {
                                            method = "POST";
                                            n.parent = {
                                                id: x.id
                                            };
                                        }
                                        n.name = m.name;
                                        n.code = m.code;
                                        n.type = m.type;
                                        publicService.doRequest(method, '/nms/spring/systemManage/address/save', n).success(function(r) {
                                            if (r.errCode) {
                                                publicService.ngAlert(r.message, "danger");
                                            } else {
                                                ngDialog.close({
                                                    template: "template/dialog/addrManageAdd.html",
                                                    className: 'ngdialog-theme-default ngdialog-theme-custom',
                                                    width: 407
                                                });
                                            }
                                            self.disabledFlag = false;
                                        })
                                    }

                                }
                            })
                        }
                    }
                }) //open
        } else {
            $scope.data = 1;
        }
    }



    //添加1一级菜单
    $scope.menuAdd = function(x) {
        ngDialog.open({
            template: "template/dialog/addrManageAdd.html",
            className: 'ngdialog-theme-default ngdialog-theme-custom',
            width: 407,
            controller: function($scope, publicService) {
                $scope.menuDigWay = '添加一级区域';
                $scope.menuDigEditAddName = '';
                $scope.menuDigSub = function(m) {
                    /*if(!verify.deviceManageEditAdd(m, publicService)) return;*/
                    publicService.loading('start');
                    var url, method;
                    method = "POST";
                    m.parent = {
                        id: "qwer1234578"
                    };
                    publicService.doRequest(method, '/nms/spring/systemManage/address/save', m).success(function(r) {
                        if (r.errCode) {
                            publicService.ngAlert(r.message, "danger");
                        } else {
                            ngDialog.close({
                                template: "template/dialog/addrManageAdd.html",
                                className: 'ngdialog-theme-default ngdialog-theme-custom',
                                width: 407
                            });
                            publicService.doRequest("GET", 102, {
                                level: "1"
                            }).success(function(data) {
                                if (data.data && data.data.length > 0) {
                                    $rootScope.menuTreeData = data.data;
                                }
                            });
                            publicService.ngAlert($scope.menuDigWay + '成功！', "success");
                        }
                        self.disabledFlag = false;
                    })
                }
            }
        });

    };

}]);