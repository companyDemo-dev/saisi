angular.module('systemDatabasRecordModule', []).controller('systemDatabasRecordCtrl', ['$scope', '$translate', "$http", 'publicService', function($scope, $translate, $http, publicService) {
    publicService.loading('start');
    $scope.seachMod = {};
    $scope.seachMod.backupStrategy = "0";


    $scope.recordDowload = function(m) {
        publicService.doRequest("GET", "/nms/spring/databaseBackup/downloadBackupFile?src="+m, {}).success(function(r) {
            if (!r || !r.data || r.data.length < 0) return;
            window.location.href = 'http://' + location.hostname + r.data + '';
        })

    }
    $scope.recordDel = function(m) {
        var self = this;
        t = $translate.use() === "ch" ? "确认删除?" : "confirm delete？";
        if (confirm(t)) {
            self.databaseRecordList.splice(self.databaseRecordList.indexOf(m), 1);
            publicService.doRequest("DELETE", "/nms/spring/databaseBackup/backupLog/" + m.id, {}).success(function(r) {

                publicService.ngAlert(r.message, "success");
            })
        }
    }
    $scope.seach = function(m) {
        var self = this;
        self.seachMod = m;
        self.paginationConf.onChange()
    }
    $scope.paginationConf = {
        currentPage: 1,
        totalItems: 0,
        itemsPerPage: 10,
        pagesLength: 15,
        perPageOptions: [10, 20, 30, 40, 50],
        rememberPerPage: 'perPageItems',
        onChange: function() {
            $scope.seachMod = $scope.seachMod || {};
            var _self = this,
                obj = {
                    page: _self.currentPage || 1,
                    pageSize: _self.itemsPerPage,
                    tableName: $scope.seachMod.tableName || "",
                    backupStrategy: $scope.seachMod.backupStrategy || "",
                    bgnDate: $scope.seachMod.bgnDate || "",
                    endDate: $scope.seachMod.endDate || ""
                }
            publicService.loading('start');

            publicService.doRequest("GET", 14, obj).success(function(r) {
                $scope.databaseRecordList = r.data.content;
                _self.currentPage = r.data.number + 1;
                _self.totalItems = r.data.totalElements;
                _self.itemsPerPage = r.data.size;
            })
        }
    };
}]);
