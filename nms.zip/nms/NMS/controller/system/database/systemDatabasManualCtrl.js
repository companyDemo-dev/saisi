angular.module('systemDatabasManualModule',[]).controller('systemDatabasManualCtrl', ['$scope','$translate','$rootScope','$http','$state', 'publicService', '$stateParams', function($scope,$translate,  $rootScope, $http, $state, publicService,$stateParams){
	
	$scope.modelManual = {};
	if ($stateParams.mauto) {
		$scope.modelManual.backupLocation = $stateParams.mauto.currentPath;
		$scope.manualType = $stateParams.mauto.ManualType;
        $scope.modelManual.tableName = $stateParams.mauto.tableName;
    }else{
	$scope.manualType = "archive";
    }

	publicService.loading('start');
	publicService.doRequest("GET", "/nms/spring/systemManage/findBybackupObectConfig?manualType=archive", {}).success(function(r){
        publicService.loading('end');
		$scope.databaseTableName = r.data;
	})
	$scope.chooseManual = function(m,x){
        var setType ={};
        setType.ManualType = m;
        setType.tableName = x;
		$state.go('index.system.databaseManualConfig', {
			mauto: setType
		})
	}
	$scope.subManual = function(m,t){
		var self = this,
            url = "/nms/spring/databaseBackup/" + self.manualType;
		if(self.manualType === "archive"){
			if(!self.modelManual.tableName){
                    var tt = $translate.use() === 'ch' ? 　"表名不能为空！" : "Table name cannot be empty!";
                    publicService.ngAlert(tt, "info");
				return;
			}
			if(!self.modelManual.archiveEndDate){
                    var tt = $translate.use() === 'ch' ? 　"数据截止日期不能为空!" : "Data expiration date cannot be empty!";
                    publicService.ngAlert(tt, "info");
				return;
			}
		}else if(self.manualType === "backup"){
			if(!self.modelManual.tableName){
                    var tt = $translate.use() === 'ch' ? 　"数据截止日期不能为空!" : "Data expiration date cannot be empty!";
                    publicService.ngAlert(tt, "info");
				return;
			}
			if(!self.modelManual.backupLocation){
                    var tt = $translate.use() === 'ch' ? 　"文件路径不能为空!" : "File path cannot be empty!!";
                    publicService.ngAlert(tt, "info");
				return;
			}
		}else if(self.manualType === "restore"){
			if(!self.modelManual.backupLocation){
                    var tt = $translate.use() === 'ch' ? 　"文件路径不能为空!" : "File path cannot be empty!!";
                    publicService.ngAlert(tt, "info");
				return;
			}
		}
        self.disabledFlag = true;
        publicService.loading('start');
		publicService.doRequest("PUT", url, m, self).success(function(r){
            publicService.ngAlert(r.message, "info");
            self.disabledFlag = false;
    	})
	}


}]);
