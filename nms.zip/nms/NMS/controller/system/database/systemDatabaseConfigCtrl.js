angular.module('systemDatabaseConfigModule',[]).controller('systemDatabaseConfigCtrl', ['$scope', '$translate', '$http', '$state', 'publicService', function($scope, $translate, $http, $state, publicService) {
	$scope.databaseAutoAdd = function(m) {
		$state.go("index.system.ConfigEdit", {
			mauto: m
		});
	}

	var obj = {
		page: 1,
		pageSize: 200,
		configName: "",
		type: ""
	};
	publicService.doRequest("GET", 'spring/systemManage/page', obj).success(function(r) {
		$scope.databaseAutoList = r.data.content;
	})
	$scope.databaseAutoDel = function(m) {
		var self = this;
		t = $translate.use() === "ch" ? "确认删除?" : "confirm delete？";
		if (confirm(t)) {
			self.databaseAutoList.splice(self.databaseAutoList.indexOf(m), 1)
			m.isDelete = 1;
			m.delete = 1;
			publicService.loading('start');
			publicService.doRequest("DELETE", "/nms/spring/systemManage/" + m.id, {}).success(function(r) {
				publicService.loading('end');
				publicService.ngAlert(r.message, "success");
			})
		}
	}
}]);
