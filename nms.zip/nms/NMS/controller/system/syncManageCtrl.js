angular.module('syncManageModule', []).controller('syncManageCtrl', ['$scope', "$state", "$translate", 'publicService', function($scope, $state, $translate, publicService) {
	publicService.doRequest("GET", '/nms/spring/systemManage/systemTimeRefConfig/get').success(function(data) {
		if (data.data) {
			$scope.systemTimeList = data.data;
		}
	});

	$scope.goManageAdd = function(m) {
		$state.go('index.system.syncManageAdd');
	}

	$scope.syncMangeDel = function(m) {
		var self = this,
			t = $translate.use() === "ch" ? "确认删除?" : "confirm delete？";
		if (confirm(t)) {
			publicService.doRequest("DELETE", "/nms/spring/systemManage/systemTimeRefConfig/"+m.id+"/delete").success(function(r) {
				publicService.loading('end');
				if (r.errCode) {
					publicService.ngAlert(r.message, "danger");
				} else {
					publicService.ngAlert(r.message, "success");
					self.systemTimeList.splice(self.systemTimeList.indexOf(m), 1)
				}
			})
		}
	}
}]);