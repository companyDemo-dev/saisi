angular.module('sysaboutModule',[]).controller('sysaboutCtrl',['$scope', '$state', '$rootScope', '$stateParams', '$rootScope', "$translate", '$state', 'publicService', function($scope, $state, $rootScope, $rootScope, $stateParams, $translate, $state, publicService) {
  publicService.doRequest("GET", 112, {}).success(function(r) {
        if (r.data == null) return
        if (r.data !== null && r.data.content && r.data.content.length > 0) {
            var content = r.data.content;
            var deviceInfo = [];
            for (i = 0; i < content.length; i++) {
                deviceInfo.push(content[i]);
            }
            $scope.deviceInfo = deviceInfo;
        }
    });
	

	}]);