angular.module('serverAlarmThresholdAddModule', []).controller('serverAlarmThresholdAddCtrl', ['$scope', '$stateParams', "$translate", '$state', 'publicService',function($scope, $stateParams, $translate, $state, publicService) {

    if ($stateParams.mauto) {
        $scope.mauto = $stateParams.mauto;
        $scope.mauto.enable += "";
        $scope.alarmFilterTitle = "修改";
        $scope.devID = $scope.mauto.device.id;
        loadSouse($scope.devID)
            //$scope.activeAlarmModule = $scope.mauto.activeAlarmModule;
    } else {
        $scope.alarmFilterTitle = "添加";
    }


    $scope.alarmFilterEditAddsub = function(m) {
        if(!verify.alarmFilterAdd(m, publicService, $translate)) return
        publicService.doRequest("POST",'/nms/spring/alarm/serverAlarmThreshold/save', m).success(function(data) {
            publicService.loading('end');
             publicService.ngAlert('添加成功', "success");
        })
    }
    $scope.backFilter = function() {
        window.history.back();
    }



}]);