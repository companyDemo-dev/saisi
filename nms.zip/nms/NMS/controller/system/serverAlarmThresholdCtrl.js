angular.module('serverAlarmThresholdModule', []).controller('serverAlarmThresholdCtrl', ['$scope', '$translate', '$rootScope', '$http', '$state', 'publicService',  function($scope, $translate, $rootScope, $http, $state, publicService) {

    $scope.alarmFilterEditAdd = function(m) {
        $scope.did = "";
        $state.go('index.system.serverAlarmThresholdAdd', {
            mauto: m
        });
    }

    $scope.seach = function(m) {
      $scope.devidFun(m);
    }

    $scope.devidFun = function(m) {
        var obj = m  || '';
            publicService.doRequest("GET", "/nms/spring/alarm/serverAlarmThreshold/get", {}).success(function(r) {
                if (r.data) {
                    $scope.alarmFilterList= r.data;
                }
            })
    }
    $scope.seach();
    $scope.alarmFilterDel = function(m) {
        var self = this;
        t = $translate.use() === "ch" ? "确认删除?" : "confirm delete？";
        if (confirm(t)) {
            self.alarmFilterList.splice(self.alarmFilterList.indexOf(m), 1)
            publicService.loading('start');
            publicService.doRequest("DELETE", "/nms/spring/alarm/serverAlarmThreshold/"+m.id+"/delete", {}).success(function(data) {
                publicService.ngAlert('删除成功', "success");
            
            })
        }
    }
      
}]);