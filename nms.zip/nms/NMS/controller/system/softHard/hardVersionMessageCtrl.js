
angular.module('hardVersionMessageModule',[]).controller('hardVersionMessageCtrl', ['$scope','$translate', '$rootScope', 'publicService', function($scope,$translate, $rootScope, publicService) {
    publicService.doRequest("GET", '/nms/spring/systemManage/serverHardware', {}).success(function(r) {
        if (r.data !== null) {
            $scope.serverHardwareInfo = r.data;
        }
    });
}]);
