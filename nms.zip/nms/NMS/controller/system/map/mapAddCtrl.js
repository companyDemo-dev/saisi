angular.module('mapAddModule',[]).controller('mapAddCtrl', ['$scope','$translate','$rootScope','$state', 'publicService', 'FileUploader', function($scope,$translate, $rootScope, $state, publicService, FileUploader){
	var uploader = $scope.uploader = new FileUploader({
        url: '/nms/spring/files/uploadImage?token=' + $rootScope.curLoginMsg.sessionID,
        method: 'POST'
    });
    
    uploader.filters.push({
        name: 'imageFilter',
        fn: function(item /*{File|FileLikeObject}*/, options) {
            var type = '|' + item.type.slice(item.type.lastIndexOf('/') + 1) + '|';
            if(item.name.indexOf(" ") >= 0){
               publicService.ngAlert("文件名不合法","danger")
               return false
            }
            return '|jpg|png|jpeg|bmp|gif|'.indexOf(type) !== -1;
        }
    });
    $scope.backMap = function(){
        $state.go('index.system.map');
    	//window.history.back();
    }

    uploader.onSuccessItem = function(fileItem, response, status, headers) {
        if (!response.errCode) {
                    var tt = $translate.use() === 'ch' ? 　"上传成功！" : "Upload success!";
                    publicService.ngAlert(tt, "info");
        } else {
            publicService.ngAlert(response.message,"danger")
        }
       
    };
    uploader.onErrorItem = function(fileItem, response, status, headers) {
    	publicService.ngAlert(status,"danger")
    };
}]);
