angular.module('mapModule',[]).controller('mapCtrl', ['$scope','$translate','publicService', "mapDate", function($scope,$translate, publicService, mapDate){
	$scope.mapList = mapDate.data.data || [];
	$scope.mapDel = function(k, v){
		var self = this;
            t = $translate.use() === "ch" ? "确认删除?" : "confirm delete？";
		if(confirm(t)){
			delete $scope.mapList[k]
			publicService.doRequest("DELETE", "/nms/spring/files/delImageMap/" + v, {}).success(function(r){
				if (r.errCode) {
	               publicService.ngAlert(r.message, "danger")
	            } else {
                publicService.ngAlert(r.message,"success");
	            }
			})
		}
	}
}]);
