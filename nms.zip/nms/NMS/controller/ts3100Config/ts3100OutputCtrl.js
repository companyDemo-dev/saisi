angular.module('ts3100OutputCtrlModule',[]).controller('ts3100OutputCtrl', ['$scope', '$state', '$rootScope', '$stateParams',  "$translate", '$state', 'publicService', function($scope, $state, $rootScope, $stateParams, $translate, $state, publicService) {
/**
	 * downloadConfig
	 *   导出配置
	 */
	$scope.downloadConfig = function() {

		var self = this;
		if (!self.devID) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}

		var config_obj = [];
		var obj = {};
		obj.node = 'ioStatusTable';
		obj.index = '';
		config_obj.push(obj);
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/downloadConfig/config", config_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}
	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data == null) return
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'TS3100') {
					deviceInfo.push(content[i]);
				}
			}
			$scope.deviceInfo = deviceInfo;
		}
	})



	$scope.seach = function() {

		var self = this;
		$scope.mauto = self.devID;
		$scope.devExp = self.devExp;
		if ($rootScope.TS3100devID) {
			$scope.mauto = $rootScope.TS3100devID;
		} else {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}
		if (!$scope.devExp || $scope.devExp == 'undefined' || $scope.devExp == '未选择') {
			var tt = $translate.use() === 'ch' ? 　"请选择机框" : "Please select machine frame";
			publicService.ngAlert(tt, "info");
			return;
		}
		
		var devId = $rootScope.TS3100devID.id;
		publicService.doRequest("GET", "/nms/spring/deviceConfig/" + devId + "/getIoStatus", {
			shelfIndex: $scope.devExp
		}).success(function(r) {
			if (r.data && r.data.length > 0) {
				$scope.frameConfigList = r.data;
			}
		})
	}
	if ($stateParams.deviceData) {
		$scope.devID = $stateParams.deviceData;
		$rootScope.TS3100devID = $stateParams.deviceData;
		$rootScope.devIP = $stateParams.deviceData.name;
		$scope.shelfList = $stateParams.deviceData.shelfList;
		$scope.devExp = '0';
	}

	if ($rootScope.TS3100devID) {
			$scope.mauto = $rootScope.TS3100devID;
		$rootScope.devIP = $rootScope.TS3100devID.name;
		$scope.shelfList = $rootScope.TS3100devID.shelfList;
		$scope.devExp = '0';
		$scope.seach();
	}else{
		$rootScope.devIP = '';
		$scope.frameConfigList ='';

	}
	$scope.macChange = function(x) {
		var self = this;
		$scope.mauto = self.devID;
		if (self.devID && self.devID.deviceStatus != 0) {
			//子页面之间传值
			/*	$rootScope.shelfList = self.devID.shelfList;
				$rootScope.devIP = self.devID.ip;*/

			//界面显示
			$rootScope.devIP = self.devID.name;
			$rootScope.TS3100devID = self.devID;
			//界面显示
			$scope.shelfList = self.devID.shelfList;
			$scope.devIP = self.devID.ip;
			$scope.devExp = '0';
		} else if (self.devID && self.devID.deviceStatus != 1) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}

	}



	$scope.outPTPconfigEnt = function(m,x) {
		if (m) {
			m.devID = $scope.mauto.id;
			//$rootScope.mauto = m;
		}
		if(m.ioType == "TS3100") {
			$state.go("index.ts3100Cofing.ts3100mcCard", {
				mauto: m,
				deviceData: x
			});
		} else if (m.ioType == "GPS") {
			$state.go('index.ts3100Cofing.ts3100GPSCard', {
				mauto: m,
				deviceData: x
			});
		}else if (m.ioType.includes('SPAN-A')) {
			$state.go("index.ts3100Cofing.ts3100SPANA", {
				mauto: m,
				deviceData: x
			});

		}else if (m.ioType.includes('SPAN-B')) {
			$state.go("index.ts3100Cofing.ts3100SPANB", {
				mauto: m,
				deviceData: x
			});

		}else if (m.ioType.includes('T1-A')) {
			$state.go("index.ts3100Cofing.ts3100T1A", {
				mauto: m,
				deviceData: x
			});

		}else if (m.ioType.includes('T1-B')) {
			$state.go("index.ts3100Cofing.ts3100T1B", {
				mauto: m,
				deviceData: x
			});

		}
	}


}]);
