angular.module('7300alarmConfigTableModule',[]).controller('alarmConfigTableCtrl', ['$scope', '$state', '$rootScope', '$stateParams',  "$translate", '$state', 'publicService', function($scope, $state, $rootScope,  $stateParams, $translate, $state, publicService) {
		$scope.macChange = function(x) {
		var self = this;
		$scope.mauto = self.devID;
		if (self.devID && self.devID.deviceStatus != 0) {
			localStorage.setItem("mauto", angular.toJson(self.devID));
			//子页面之间传值
			/*	$rootScope.shelfList = self.devID.shelfList;
				*/
		    $rootScope.devIP = self.devID.ip;
		    $rootScope.LF7300devID = self.devID;
			//界面显示
			$scope.shelfList = self.devID.shelfList;
			$scope.devIP = self.devID.ip;
		} else if (self.devID && self.devID.deviceStatus != 1) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}
	}
	/**
	 * downloadConfig
	 *   导出配置
	 */
	$scope.downloadConfig = function() {

		var self = this;
		if (!self.devID) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}

		var config_obj = [];
		var obj = {};
		obj.node = 'alarmConfigTable';
		obj.index = '';
		config_obj.push(obj);
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/downloadConfig/config", config_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}
	$scope.deviceContent = {};
	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data == null) return
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'LF7300') {
					deviceInfo.push(content[i]);
				}
			}
			$scope.deviceInfo = deviceInfo;
		}
	})


	sum = 1;
	$scope.PREVIOUSD = true;
	$scope.seach = function(x) {
		var self = this;
		if($rootScope.LF7300devID){
		   self.devID = $rootScope.LF7300devID;
		}else{
			publicService.ngAlert('请选择设备', "info");
		}
		$scope.mauto = self.devID;
		if (!self.devID || typeof self.devID.id === 'undefined' || $scope.devIP == 'No selection device') {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}

		if (self.devID.deviceStatus == 0) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}
		publicService.loading('start');
		var devId = self.devID.id;
		/*			publicService.doRequest("GET", "/nms/spring/deviceConfig/" + devId + "/configs/alarmConfigTable", {}).success(function(r) {
						if (r.data && r.data.length > 0) {
							$scope.configList = r.data;
						}
					})*/
		var dataObj = {},
			obj = [];
		if (x == 'del') {
			if (sum <= 21) $scope.PREVIOUSD = true;
			sum = sum - 20;
			$scope.NEXTD = false;
		}
		if (x == 'add') {
			if (sum >= 41) $scope.NEXTD = true;
			sum = sum + 20;
			$scope.PREVIOUSD = false;
		}
		if (!sum) sum = 1;
		if (sum == 63) {
			for (var i = sum; i < (sum + 3); i++) {
				dataObj = [{
					"node": "alarmID",
					"index": '.' + i,
					"num": ""
				}, {
					"node": "alarmLevel",
					"index": '.' + i,
					"num": ""
				}, {
					"node": "alarmState",
					"index": '.' + i,
					"num": ""
				}, {
					"node": "alarmDescription",
					"index": '.' + i,
					"num": ""
				}]
				obj.push(dataObj);
			}

		} else {
			for (var i = sum; i < (sum + 20); i++) {
				dataObj = [{
					"node": "alarmID",
					"index": '.' + i,
					"num": ""
				}, {
					"node": "alarmLevel",
					"index": '.' + i,
					"num": ""
				}, {
					"node": "alarmState",
					"index": '.' + i,
					"num": ""
				}, {
					"node": "alarmDescription",
					"index": '.' + i,
					"num": ""
				}]
				obj.push(dataObj);
			}
		}
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + devId + "/getDeviceParamBatchTable", obj).success(function(r) {
			if (r.data && r.data.length > 0) {
				$scope.configList = r.data;
			}
		});
	}


	$scope.listSetConfig = function(x) {
		if(x.alarmLevel  == 'critical' || x.alarmLevel  == '严重'){
			x.alarmLevel  = 2
		}else if(x.alarmLevel  == 'major' || x.alarmLevel  == '主要'){
			x.alarmLevel  = 3
		}else if(x.alarmLevel  == 'minor' || x.alarmLevel  == '监视'){
			x.alarmLevel  = 4
		}else if(x.alarmLevel  == 'event' || x.alarmLevel  == '事件'){
			x.alarmLevel  = 5
		}
		if(x.alarmState  == 'disable' || x.alarmState  == '禁用'){
			x.alarmState  = 0
		}else if(x.alarmState  == 'enable' || x.alarmState  == '启用'){
			x.alarmState  = 1
		}
		$scope.deviceContent = x;
		_newVals();
	}
	$scope.configSub = function(x, index) {
		if (!verify.alarmConfig3000G(x, publicService, $translate)) return;
		if (index) {
			indexObj = parseInt(index) + 1;
		}
		ds = _changeVals(x);
		var configSub_obj = [];
		for (var j in ds) {
			obj = {};
			obj.value = ds[j];
			obj.node = j;
			obj.index = '.' + indexObj.toString();;
			configSub_obj.push(obj);

		}
		configSubmit(configSub_obj, index);
		_newVals()
	}

	/**
	 * configSubmit
	 *   配置提交
	 */
	function configSubmit(configSub_obj, index) {
		if (!$scope.mauto) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return
		}
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/setConfigsBatch", configSub_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var doc;
			if (r.data.length == 0) {
				var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
				publicService.ngAlert(tt, "info");
				return;
			} else {
				var dataObj = r.data;
				var div = document.createElement('p');
				for (var i = 0; i < dataObj.length; i++) {
					if (dataObj[i].code === false) {
						var node = document.createTextNode(dataObj[i].message + ' ');
						div.appendChild(node);

					} else if (dataObj[i].code === true) {
						var node = document.createTextNode(dataObj[i].message + ' ');
						div.appendChild(node);
					}
				}
				var element = document.getElementById("ngTip");
				element.appendChild(div);
				var tt = $translate.use() === 'ch' ? 　"返回状态列表" : "Return state List";
				publicService.ngAlert(tt, "info");
				$scope.seach()
				setTimeout(function() {
					element.removeChild(div);
					publicService.doRequest("GET", "/nms/spring/device/" + $scope.mauto.id + "/syncAlarms", {});
				}, 3000)


			}

		})

	}

	function _newVals() {
		var deviceContent = $scope.deviceContent;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		localStorage.setItem('valueDoms', JSON.stringify(obj));
	}

	function _changeVals(x) {
		var deviceContent = x;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		var _vals = JSON.parse(localStorage.getItem('valueDoms')),
			changeObj = {};
		for (var i = 0; i < obj.length; i++) {
			var _id = obj[i].name,
				_val = obj[i].value;
			for (var j = 0; j < _vals.length; j++) {
				var _id2 = _vals[j].name,
					_val2 = _vals[j].value;
				if (_id === _id2) {
					if (_val != _val2) {
						changeObj[_id] = _val;
					}
				}
			}
		}
		return changeObj;
	}
}]);
