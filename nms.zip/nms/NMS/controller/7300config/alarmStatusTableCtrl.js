angular.module('7300alarmStatusTableModule',[]).controller('alarmStatusTableCtrl', ['$scope', '$state', '$rootScope', '$stateParams', "$translate", '$state', 'publicService', function($scope, $state, $rootScope, $stateParams, $translate, $state, publicService) {
		$scope.macChange = function(x) {
		var self = this;
		$scope.mauto = self.devID;
		if (self.devID && self.devID.deviceStatus != 0) {
			localStorage.setItem("mauto", angular.toJson(self.devID));
			//子页面之间传值
			/*	$rootScope.shelfList = self.devID.shelfList;
				*/
		    $rootScope.devIP = self.devID.ip;
		    $rootScope.LF7300devID = self.devID;
			//界面显示
			$scope.shelfList = self.devID.shelfList;
			$scope.devIP = self.devID.ip;
		} else if (self.devID && self.devID.deviceStatus != 1) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}
	}
	/**
	 * downloadConfig
	 *   导出配置
	 */
	$scope.downloadConfig = function() {

		var self = this;
		if (!self.devID) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}

		var config_obj = [];
		var obj = {};
		obj.node = 'alarmStatusTable';
		obj.index = '';
		config_obj.push(obj);
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/downloadConfig/config", config_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}
	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data == null) return
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'LF7300') {
					deviceInfo.push(content[i]);
				}
			}
			$scope.deviceInfo = deviceInfo;
		}
	})



	$scope.seach = function() {
		var self = this;
		publicService.loading('start');
		if($rootScope.LF7300devID){
		   self.devID = $rootScope.LF7300devID;
		}else{
			publicService.ngAlert('请选择设备', "info");
		}
		$scope.mauto = self.devID;
		if (!self.devID || typeof self.devID.id === 'undefined' || $scope.devIP == 'No selection device') {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}

		if (self.devID.deviceStatus == 0) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}

		var devId = self.devID.id;
		publicService.doRequest("GET", "/nms/spring/deviceConfig/" + devId + "/configs/activeAlarmTable", {}).success(function(r) {
			if (r.data && r.data.length > 0) {
				$scope.configList = r.data;
			}
		})
	}
}]);
