angular.module('7300outputNTPntpBlacklistTableModule', []).controller('outputNTPntpBlacklistTableCtrl', ['$scope', '$state', '$rootScope', '$stateParams', "$translate", '$state', 'publicService', function($scope, $state, $rootScope, $stateParams, $translate, $state, publicService) {
	$scope.macChange = function(x) {
		var self = this;
		$scope.mauto = self.devID;
		if (self.devID && self.devID.deviceStatus != 0) {
			localStorage.setItem("mauto", angular.toJson(self.devID));
			//子页面之间传值
			/*	$rootScope.shelfList = self.devID.shelfList;
			 */
			$rootScope.devIP = self.devID.ip;
			$rootScope.ns7200devID = self.devID;
			//界面显示
			$scope.shelfList = self.devID.shelfList;
			$scope.devIP = self.devID.ip;
		} else if (self.devID && self.devID.deviceStatus != 1) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}
	}
	$scope.deviceContents = {};
	/**
	 * downloadConfig
	 *   导出配置
	 */
	$scope.downloadConfig = function() {

		var self = this;
		if (!self.devID) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}

		var config_obj = [];
		var obj = {};
		obj.node = 'ntpServerBlacklistTable';
		obj.index = '';
		config_obj.push(obj);
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/downloadConfig/config", config_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}
	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data == null) return
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'LF7300') {
					deviceInfo.push(content[i]);
				}
			}
			$scope.deviceInfo = deviceInfo;
		}
	})

	$scope.outputNTPSub = function(x) {
		var self = this;

		if ($rootScope.LF7300devID) {
			self.devID = $rootScope.LF7300devID;
		} else {
			publicService.ngAlert('请选择设备', "info");
		}
		$scope.mauto = self.devID;

		var arr = [{
			"node": 'outputNTPntpListState',
			"index": '.' + $scope.ntpStatePortId,
			"value": x
		}];
		publicService.loading('start');
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/setConfigsBatch", arr).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var dataObj = r.data,
				str = "";
			if (dataObj[0].code) {
				var tt = $translate.use() === 'ch' ? 　"设置成功" : "Set success";
				publicService.ngAlert(tt, "info");
				// $scope.mauto.inputPTPimageCurrentImage = _self.inputPTPimageCurrentImage;
			} else {
				publicService.ngAlert(dataObj[0].message, "info");
			}
		})
	}

	$scope.seach = function() {
		var self = this;

		if ($rootScope.ns7200devID) {
			self.devID = $rootScope.ns7200devID;
		} else {
			publicService.ngAlert('请选择设备', "info");
		}
		$scope.mauto = self.devID;
		if (!self.devID || typeof self.devID.id === 'undefined' || $scope.devIP == 'No selection device') {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}

		if (self.devID.deviceStatus == 0) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}
		publicService.loading('start');

		var devId = self.devID.id;
		var obj = {};

		if ($scope.ntpStatePortId) {
			var indexN = '.' + $scope.ntpStatePortId;
		} else {
			var indexN = '.1';
		}


		publicService.doRequest("GET", "/nms/spring/deviceConfig/" + devId + "/configs/outputNTPntpBlacklistTable", {}).success(function(r) {
				if (r.data && r.data.length > 0) {
					var dataObj = r.data;
					var obj = [];
					for (i = 0; i < dataObj.length; i++) {
						if (dataObj[i].outputNTPntpBlacklistPortIndex == $scope.ntpStatePortId) {
							var listAddr = dataObj[i]['outputNTPntpBlacklistAddr'].split(',');
							var WhitelistAddrlistAddr = {
								"WhitelistAddrlistAddr1": listAddr[0],
								"WhitelistAddrlistAddr2": listAddr[1]
							};
							obj.push(WhitelistAddrlistAddr)
						}
					}
					$scope.loadPTPWhiteList = obj;
				}else{
					$scope.loadPTPWhiteList = '';
				}
			})
			/*	obj = [{
					"node": "outputNTPntpBlacklistCount",
					"index": ""+indexN+".1",
					"num": ""
				}]
				publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/getDeviceParamColl", obj).success(function(r) {
					if (r.data && r.data.length > 0) {
						var num = JSON.parse(r.data);
						var count = num.outputNTPntpBlacklistCount
						if (count != "") {
							var a = {},
								obj2 = [];
							for (var i = 1; i <= count; i++) {
								a = {
									"node": 'outputNTPntpBlacklistAddr',
									"index": indexN + '.' + i,
									"num": ""
								}
								obj2.push(a);
							}
							publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/getDeviceParamTable", obj2).success(function(r) {
								if (r.data && r.data.length > 0) {
									var obj3 = r.data;
									var Whitelist = [];
									for (var i = 0; i < obj3.length; i++) {
										var listAddr = obj3[i]['outputNTPntpBlacklistAddr'].split(',');
										var WhitelistAddrlistAddr = {
											"WhitelistAddrlistAddr1": listAddr[0],
											"WhitelistAddrlistAddr2": listAddr[1]
										};
										Whitelist.push(WhitelistAddrlistAddr);
									}
									$scope.loadPTPWhiteList = Whitelist;
								}
							})

						}else{
							$scope.loadPTPWhiteList = '';
						}

					}
				});*/
	}

	/**
	 * outputPTPntplistSub
	 *   黑白名单创建 激活
	 */


	$scope.outputNTPAddrSub = function(x) {

		if (!verify.ntpWhitelistIP(x, publicService, $translate)) {
			return;
		}

		if (!$scope.mauto) {
			var tt = $translate.use() === 'ch' ? 　"请确认所选设备" : "Please confirm the selected device";
			publicService.ngAlert(tt, "info");
			return
		}
		var obj = {};
		publicService.doRequest("GET", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/configs/outputNTPntpBlacklistTable", {}).success(function(r) {

			if (r.data) {
				var dataObj = r.data;
				var obj = [];
				for (i = 0; i < dataObj.length; i++) {
					if (dataObj[i].outputNTPntpBlacklistPortIndex == $scope.ntpStatePortId) {
						obj.push(dataObj[i])
					}
				}
				var count = obj.length;
				if (count == "") count = '0';
				var reobj = [],
					obj = {};
				if (x.outputPTPntpWhitelistAddr2) {
					var value = x.outputPTPntpWhitelistAddr + ',' + x.outputPTPntpWhitelistAddr2;
				} else {
					var value = x.outputPTPntpWhitelistAddr;
				}
				if ($scope.ntpStatePortId) {
					var index = '.' + $scope.ntpStatePortId + '.' + parseInt(parseInt(count) + 1);
				} else {
					var index = '.1.' + parseInt(parseInt(count) + 1);
				}
				obj.value = value;
				obj.node = 'outputNTPntpBlacklistAddr';
				obj.index = index;
				reobj.push(obj);
				publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/setConfigsBatch", reobj).success(function(r) {
					if (!r || !r.data || r.data.length < 0) return;
					if (r.data.length == 0) {
						var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
						publicService.ngAlert(tt, "info");
						return;
					} else {
						var dataObj = r.data;
						if (dataObj[0].code === true) {
							var tt = $translate.use() === 'ch' ? 　"添加IP成功" : "Add IP success";
							publicService.ngAlert(tt, "info");
							$scope.outputPTPntpActiveSub(x, index);
						} else if (dataObj[0].code === false) {
							var tt = $translate.use() === 'ch' ? 　"添加IP失败" : "Add IP failed";
							publicService.ngAlert(tt, "info");
						}
					}
				})

			}
		});
	}


	$scope.outputPTPntpActiveSub = function(x, index) {
		var reobj = [],
			obj = {};
		obj.value = '1';
		obj.node = 'outputNTPntpBlacklistRowStatus';
		obj.index = index;
		reobj.push(obj);

		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/setConfigsBatch", reobj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			if (r.data.length == 0) {
				var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
				publicService.ngAlert(tt, "info");
				return;
			} else {
				var dataObj = r.data;
				if (dataObj[0].code === true) {
					var tt = $translate.use() === 'ch' ? 　"激活成功" : "active success";
					publicService.ngAlert(tt, "info");
					$scope.seach();
				} else if (dataObj[0].code === false) {
					var tt = $translate.use() === 'ch' ? 　"激活失败" : "active failed";
					publicService.ngAlert(tt, "info");
				}
			}
		})
	}



	$scope.PTPntpIpListDel = function(x) {
		var t = $translate.use() === "ch" ? "确认删除?" : "confirm delete？";
		if (confirm(t)) {
			if ($scope.ntpStatePortId) {
				var index = '.' + $scope.ntpStatePortId + '.' + x;
			} else {
				var index = '.1.' + x;
			}
			var reobj = [],
				obj = {};
			obj.value = '6';
			obj.node = 'outputNTPntpBlacklistRowStatus';
			obj.index = index;
			reobj.push(obj);

			publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/setConfigsBatch", reobj).success(function(r) {
				if (!r || !r.data || r.data.length < 0) return;
				if (r.data.length == 0) {
					var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
					publicService.ngAlert(tt, "info");
					return;
				} else {
					var dataObj = r.data;
					if (dataObj[0].code === true) {
						var tt = $translate.use() === 'ch' ? 　"删除成功" : "delete success";
						publicService.ngAlert(tt, "info");
						$scope.seach();

					} else if (dataObj[0].code === false) {
						var tt = $translate.use() === 'ch' ? 　"删除失败" : "delete failed";
						publicService.ngAlert(tt, "info");
					}
				}
			})
		}
	}
}]);