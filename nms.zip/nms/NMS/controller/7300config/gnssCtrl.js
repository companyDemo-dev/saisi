angular.module('7300gnssModule',[]).controller('gnssCtrl', ['$scope', '$state', '$rootScope', '$stateParams', '$rootScope', "$translate", '$state', 'publicService', function($scope, $state, $rootScope, $rootScope, $stateParams, $translate, $state, publicService) {
	/**
	 * downloadConfig
	 *   导出配置
	 */
	$scope.downloadConfig = function() {

		var self = this;
		if (!self.devID) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}

		var config_obj = [];
		var _vals = JSON.parse(localStorage.getItem('valueDoms'));
		for (var j = 0; j < _vals.length; j++) {
			var obj = {};
			obj.node = _vals[j].name;
			obj.index = '';
			config_obj.push(obj);
		}
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/downloadConfig/config", config_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}
	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data == null) return
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'LF7300') {
					deviceInfo.push(content[i]);
				}
			}
			$scope.deviceInfo = deviceInfo;
		}
	})



	$scope.seach = function() {
			var self = this;
			$scope.mauto = self.devID;
			if (!self.devID || typeof self.devID.id === 'undefined' || $scope.devIP == 'No selection device') {
				var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
				publicService.ngAlert(tt, "info");
				return;
			}

			if (self.devID.deviceStatus == 0) {
				var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
				publicService.ngAlert(tt, "info");
				return
			}
			publicService.loading('start');

			var devId = self.devID.id;
			obj = [{
				"node": "gnssState",
				"index": ".0",
				"num": ""
			}, {
				"node": "gnssMode",
				"index": ".0",
				"num": ""
			},  {
				"node": "gnssTrackMode",
				"index": ".0",
				"num": ""
			}, {
				"node": "gnssCableDelay",
				"index": ".0",
				"num": ""
			}, {
				"node": "gnssPriority",
				"index": ".0",
				"num": ""
			}, {
				"node": "gnssPQLState",
				"index": ".0",
				"num": ""
			}, {
				"node": "gnssPQL",
				"index": ".0",
				"num": ""
			}, {
				"node": "gnssCurrentPosMode",
				"index": ".0",
				"num": ""
			}, {
				"node": "gnssCurrentPosition",
				"index": ".0",
				"num": ""
			}, {
				"node": "gnssPositionConfig",
				"index": ".0",
				"num": ""
			}, {
				"node": "gnssElevMask",
				"index": ".0",
				"num": ""
			}, {
				"node": "gnssCurrentTrackedGnssType",
				"index": ".0",
				"num": ""
			},  ]
			$scope.GNSS1Mode();
			$scope.gnss1D = true;

			publicService.doRequest("POST", "/nms/spring/deviceConfig/" + devId + "/getDeviceParamColl", obj).success(function(r) {
				if (r.data && r.data.length > 0) {
					$scope.deviceContent = JSON.parse(r.data);
					if ($scope.deviceContent.gnssPositionConfig) {
						var time = new Array();
						time = $scope.deviceContent.gnssPositionConfig.split(",");
						$scope.deviceContent.gnssCurrentPositionJ = time[0];
						$scope.deviceContent.gnssCurrentPositionW = time[1];
						$scope.deviceContent.gnssCurrentPositionH = time[2];
					}
				}
				_newVals();
			});
		}
		//GNSS1初始化
	$scope.GNSS1Mode = function(m) {
		var obj = 'gnss1InfoTable';
		publicService.doRequest("GET", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/configs/" + obj + "", {}).success(function(r) {
			if (r.data[0]) {
				$scope.deviceContent = r.data[0];
				if ($scope.deviceContent.gnss1InfoVendor == "trimble") {
					$scope.gnss1TrackModeD = true;
				}
			}
		})
	}
	$scope.change = function(x) {
		if (x == 1) {
			$scope.gnss1D = false;
		} else {
			$scope.gnss1D = true;
		}
	}

	function _newVals() {
		var deviceContent = $scope.deviceContent;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		localStorage.setItem('valueDoms', JSON.stringify(obj));
	}


	function _changeVals(x) {
		var deviceContent = x;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		var _vals = JSON.parse(localStorage.getItem('valueDoms')),
			changeObj = {};
		for (var i = 0; i < obj.length; i++) {
			var _id = obj[i].name,
				_val = obj[i].value;
			for (var j = 0; j < _vals.length; j++) {
				var _id2 = _vals[j].name,
					_val2 = _vals[j].value;
				if (_id === _id2) {
					if (_val != _val2) {
						changeObj[_id] = _val;
					}
				}
			}
		}
		return changeObj;
	}

	$scope.configSub = function(x, index) {
		if (!verify.gnss_7300(x, publicService, $translate, "1")) return;
		if (index) {
			indexObj = '.' + index
		}
		ds = _changeVals(x);
		var configSub_obj = [];
		flag = true;
		for (var j in ds) {
			obj = {};
			switch (j) {
				case "gnss1CurrentPositionJ":
				case "gnss1CurrentPositionW":
				case "gnss1CurrentPositionH":
					if (flag) {
						var j = $scope.deviceContent.gnss1CurrentPositionJ,
							w = $scope.deviceContent.gnss1CurrentPositionW,
							h = $scope.deviceContent.gnss1CurrentPositionH,
							gnss1PositionConfig = String(j + "," + w + "," + h);
						obj.value = gnss1PositionConfig;
						obj.node = 'gnss1PositionConfig';
						obj.index = indexObj;
						flag = false;
						configSub_obj.push(obj);
					}
					break;
				default:
					obj.value = ds[j];
					obj.node = j;
					obj.index = indexObj;
					configSub_obj.push(obj);
			}
		}
		configSubmit(configSub_obj, index);
		_newVals()
	}

	/**
	 * configSubmit
	 *   配置提交
	 */
	function configSubmit(configSub_obj, index) {
		if (!$scope.mauto) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return
		}
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/setConfigsBatch", configSub_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var doc;
			if (r.data.length == 0) {
				var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
				publicService.ngAlert(tt, "info");
				return;
			} else {
				var dataObj = r.data;
				var div = document.createElement('p');
				for (var i = 0; i < dataObj.length; i++) {
					if (dataObj[i].code === false) {
						var node = document.createTextNode(dataObj[i].message + ' ');
						div.appendChild(node);

					} else if (dataObj[i].code === true) {
						var node = document.createTextNode(dataObj[i].message + ' ');
						div.appendChild(node);
					}
				}
				var element = document.getElementById("ngTip");
				element.appendChild(div);
				var tt = $translate.use() === 'ch' ? 　"返回状态列表" : "Return state List";
				publicService.ngAlert(tt, "info");
				setTimeout(function() {
					element.removeChild(div);
				}, 3000)
			}

		})

	}
}]);
