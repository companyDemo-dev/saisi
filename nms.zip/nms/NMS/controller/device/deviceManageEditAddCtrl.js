angular.module('deviceManageEditAddModule', []).controller('deviceManageEditAddCtrl', ['$scope', '$stateParams', '$translate', 'publicService', "$timeout", "areaData", "ngDialog", function($scope, $stateParams, $translate, publicService, $timeout, areaData, ngDialog) {
	$scope.backDevice = function() {
		window.history.back();
	}
$scope.change = function(areaId) {
	$scope.loadDeviceData(areaId)
}

$scope.loadDeviceData = function(areaId) {
	obj = {
		page: 1,
		pageSize: 1000,
		name: "",
		ip: "",
		deviceStatus: 1,
		areaId: areaId || '',
		deviceType: ""
	}
	publicService.doRequest("GET", '/nms/spring/device/forManager', obj).success(function(r) {
			var deviceList = r.data.content;
			if (deviceList) {
				for (var i = 0; i < deviceList.length; i++) {
					deviceList[i].ticked = false;
				}
				$scope.iDeviceData = deviceList;
				$scope.iDeviceDataN = deviceList;
			}

		}) //获取设备列表
}
$scope.loadDeviceData()

	$scope.areaData = areaData.data.data;
	if ($stateParams.mauto) {
		$scope.mauto = $stateParams.mauto;
		$scope.deviceTitle = "修改";
	} else {
		$scope.deviceTitle = "添加";
		$scope.mauto = {};
		$scope.mauto.area = {};
		$scope.mauto.deviceType = "SM2000";
		$scope.mauto.img = "1";
	}
	publicService.doRequest("GET", "/nms/spring/systemManage/getParamConfig", {
		type: 'deviceType'
	}).success(function(r) {
		if (r.data !== null && r.data && r.data.length > 0) {
			$scope.deviceType = r.data;
		}
	})


	publicService.doRequest("GET", '/nms/spring/systemManage/address/findByParent?parentId=qwer1234578').success(function(data) {
		if (data.data && data.data.length > 0) {
			$scope.proviceList = data.data;
		}
	});

	$scope.stationd = false;
	$scope.detaild = false;
	$scope.frameld = false;
	$scope.loadLocation1 = function(m) {
		m = JSON.parse(m);
		publicService.doRequest("GET", '/nms/spring/systemManage/address/findByParent?parentId=' + m.id).success(function(data) {
			if (data.data && data.data.length > 0) {
				$scope.cityList = data.data;
			}
		});

	}

	$scope.loadLocation2 = function(m) {
		m = JSON.parse(m);
		publicService.doRequest("GET", '/nms/spring/systemManage/address/findByParent?parentId=' + m.id).success(function(data) {
			if (data.data && data.data.length > 0) {
				$scope.stationd = true;
				$scope.stationList = data.data;
			}
		});

	}


	$scope.loadLocation3 = function(m) {
		m = JSON.parse(m);
		publicService.doRequest("GET", '/nms/spring/systemManage/address/findByParent?parentId=' + m.id).success(function(data) {
			if (data.data && data.data.length > 0) {
				$scope.detaild = true;
				$scope.detailList = data.data;
			}
		});

	}

	$scope.loadLocation4 = function(m) {
		m = JSON.parse(m);
		publicService.doRequest("GET", '/nms/spring/systemManage/address/findByParent?parentId=' + m.id).success(function(data) {
			if (data.data && data.data.length > 0) {
				$scope.frameld = true;
				$scope.frameList = data.data;
			}
		});

	}
	$scope.showngDialog1 = function(m) {
		ngDialog.open({
			template: "template/dialog/newTuopuDialog.html",
			className: 'ngdialog-theme-default ngdialog-theme-custom',
			controller: function($scope, publicService) {
				$scope.subPs = function(oos) {
					if (!oos || !oos.slot) {
						var tt = $translate.use() === 'ch' ? 　"输入槽位不能为空！" : "Slot cannot be empty！";
						publicService.ngAlert(tt, "info");
						return;
					}
					if (oos.port === "") {
						var tt = $translate.use() === 'ch' ? 　"输入端口不能为空！" : "Port cannot be empty！";
						publicService.ngAlert(tt, "info");
						return;
					}
					if (!oos || !oos._slot) {
						var tt = $translate.use() === 'ch' ? 　"输出槽位不能为空！" : "Slot cannot be empty！";
						publicService.ngAlert(tt, "info");
						return;
					}
					if (oos._port === "") {
						var tt = $translate.use() === 'ch' ? 　"输出端口不能为空！" : "Port cannot be empty！";
						publicService.ngAlert(tt, "info");
						return;
					}
					ngDialog.close('ngdialog1');
					SetData1(oos)
				}
			}
		});

	}

	function SetData1(oos) {
		$scope.port1 = oos.port;
		$scope.slot1 = oos.slot;
		$scope._port1 = oos._port;
		$scope._slot1 = oos._slot;
	}

	$scope.showngDialog2 = function(m) {
		ngDialog.open({
			template: "template/dialog/newTuopuDialog.html",
			className: 'ngdialog-theme-default ngdialog-theme-custom',
			controller: function($scope, publicService) {
				$scope.subPs = function(oos) {
					if (!oos || !oos.slot) {
						var tt = $translate.use() === 'ch' ? 　"输入槽位不能为空！" : "Slot cannot be empty！";
						publicService.ngAlert(tt, "info");
						return;
					}
					if (oos.port === "") {
						var tt = $translate.use() === 'ch' ? 　"输入端口不能为空！" : "Port cannot be empty！";
						publicService.ngAlert(tt, "info");
						return;
					}
					if (!oos || !oos._slot) {
						var tt = $translate.use() === 'ch' ? 　"输出槽位不能为空！" : "Slot cannot be empty！";
						publicService.ngAlert(tt, "info");
						return;
					}
					if (oos._port === "") {
						var tt = $translate.use() === 'ch' ? 　"输出端口不能为空！" : "Port cannot be empty！";
						publicService.ngAlert(tt, "info");
						return;
					}
					ngDialog.close('ngdialog1');
					SetData2(oos)
				}
			}
		});
	}

	function SetData2(oos) {
		$scope.port2 = oos.port;
		$scope.slot2 = oos.slot;
		$scope._port2 = oos._port;
		$scope._slot2 = oos._slot;
	}


	$scope.deviceManageSub = function(m) {
		var self = this;
		m.nodeType = 1;
		m.status = 0;
		m.ownerId = "";
		if (!verify.deviceManageEditAdd(m, publicService, $translate)) return;
		publicService.loading('start');
		var url, method;
		if (self.deviceTitle === "修改") {
			url = 114;
			method = "PUT";
			m.id = m.id;
		} else {
			url = 114;
			method = "POST";
		}
		if (m.provice) {
			var provice = JSON.parse(m.provice);
			provice = provice.name || '';
		}
		if (m.city) {
			var city = JSON.parse(m.city);
			city = city.name || '';
		}

		if (m.station) {
			var station = JSON.parse(m.station);
			station = station.name || '';
		}

		if (m.detail) {
			var detail = JSON.parse(m.detail);
			detail = detail.name || '';
		}

		if (m.frame) {
			var frame = JSON.parse(m.frame);
			frame = frame.name || '';
		}
		m.deviceLocation = {
			provice: provice,
			city: city,
			station: station,
			detail: detail,
			frame: frame,

		}
		if (m.children) {
			delete m.children;
			delete m.timestamp;
			delete m.imageVersion;
			delete m.moduleId;
			delete m.disconnectCount;
			delete m.parentInfo;
			delete m.flag;
			delete m.label;
			delete m.type;
			delete m.deviceStatus;
			delete m.$$hashKey;
		}
		delete m.provice;
		delete m.station;
		delete m.city;
		delete m.detail;
		delete m.frame;
		self.disabledFlag = true;
		publicService.doRequest(method, url, m, self).success(function(r) {
			if (r.errCode) {
				publicService.ngAlert(r.message, "danger");
			} else {
				publicService.ngAlert(r.message, "success");
				if($scope.port1){
				asInputsetlineData(m)
				}
			}
			self.disabledFlag = false;
		})
	}


	function asInputsetlineData(m) {
		var o = {};
		o.areaId = m.area.id || "";
		o.userId = localStorage.getItem("curUserId") || "";
		o.viewDataType = "";
		publicService.doRequest("GET", 5, o).success(function(r) {
			$scope.tuopoData = r.data.length === 0 ? {} : r.data[0];
			$scope.tuopoData.data && ($scope.tuopoData.data = JSON.parse($scope.tuopoData.data));
			var areaId = m.area.id,
				userid = localStorage.getItem("curUserId") || "";
			    targetId = m.ip,
				sourceId = $scope.oDeviceData,
				res = $scope.tuopoData;
			if (res) {
				o1 = res.data;
				if (o1[sourceId]) {
					if (o1[sourceId].targetIds && o1[sourceId].targetIds.length > 0) {
						var _ars = o1[sourceId].targetIds,
							ja = [];
						for (var i = 0; i < _ars.length; i++) {
							ja.push(_ars[i].ip);
						}
						if (ja.indexOf(targetId) !== -1) return;
						o1[sourceId].targetIds.push({
							port: $scope.port1,
							slot: $scope.slot1,
							_port: $scope._port1,
							_slot: $scope._slot1,
							ip: targetId
						});
					} else {
						var f = o1[sourceId].targetIds instanceof Array;
						!f && (o1[sourceId].targetIds = []);
						o1[sourceId].targetIds.push({
							port: $scope.port1,
							slot: $scope.slot1,
							_port: $scope._port1,
							_slot: $scope._slot1,
							ip: targetId
						});
					}
				} else {
					o1[sourceId] = {};
					o1[sourceId].targetIds = [];
					o1[sourceId].targetIds.push({
						port: $scope.port1,
						slot: $scope.slot1,
						_port: $scope._port1,
						_slot: $scope._slot1,
						ip: targetId
					})
				}
			} else {
				res.data = {};
				res.data[sourceId] = {};
				res.data[sourceId].targetIds = [];
				res.data[sourceId].targetIds.push({
					port: $scope.port1,
					slot: $scope.slot1,
					_port: $scope._port1,
					_slot: $scope._slot1,
					ip: targetId
				});

			}
			res.data = JSON.stringify(res.data);
			publicService.doRequest("POST", 5, $scope.tuopoData).success(function() {
				$scope.tuopoData.data = JSON.parse($scope.tuopoData.data)
				if($scope.port2){
				  asOutputsetlineData(m)
				}
			})

		})
	}


	function asOutputsetlineData(m) {
		var o = {};
		o.areaId = m.area.id || "";
		o.userId = localStorage.getItem("curUserId") || "";
		o.viewDataType = "";
		publicService.doRequest("GET", 5, o).success(function(r) {
			$scope.tuopoData = r.data.length === 0 ? {} : r.data[0];
			$scope.tuopoData.data && ($scope.tuopoData.data = JSON.parse($scope.tuopoData.data));
			var areaId = m.area.id,
				userid = localStorage.getItem("curUserId") || "";
			    targetId = $scope.oDeviceDataN,
				sourceId = m.ip,
				res = $scope.tuopoData;
			if (res) {
				o1 = res.data;
				if (o1[sourceId]) {
					if (o1[sourceId].targetIds && o1[sourceId].targetIds.length > 0) {
						var _ars = o1[sourceId].targetIds,
							ja = [];
						for (var i = 0; i < _ars.length; i++) {
							ja.push(_ars[i].ip);
						}
						if (ja.indexOf(targetId) !== -1) return;
						o1[sourceId].targetIds.push({
							port: $scope.port2,
							slot: $scope.slot2,
							_port: $scope._port2,
							_slot: $scope._slot2,
							ip: targetId
						});
					} else {
						var f = o1[sourceId].targetIds instanceof Array;
						!f && (o1[sourceId].targetIds = []);
						o1[sourceId].targetIds.push({
							port: $scope.port2,
							slot: $scope.slot2,
							_port: $scope._port2,
							_slot: $scope._slot2,
							ip: targetId
						});
					}
				} else {
					o1[sourceId] = {};
					o1[sourceId].targetIds = [];
					o1[sourceId].targetIds.push({
						port: $scope.port2,
						slot: $scope.slot2,
						_port: $scope._port2,
						_slot: $scope._slot2,
						ip: targetId
					})
				}
			} else {
				res.data = {};
				res.data[sourceId] = {};
				res.data[sourceId].targetIds = [];
				res.data[sourceId].targetIds.push({
					port: $scope.port2,
					slot: $scope.slot2,
					_port: $scope._port2,
					_slot: $scope._slot2,
					ip: targetId
				});

			}
			res.data = JSON.stringify(res.data);
			publicService.doRequest("POST", 5, $scope.tuopoData).success(function() {
				$scope.tuopoData.data = JSON.parse($scope.tuopoData.data)
			})

		})
	}
}]);
