angular.module('upgradeCmdModule',[]).controller('upgradeCmdCtrl', ['$scope', "$state","$translate", "ngDialog", 'publicService', function($scope, $state, $translate,ngDialog, publicService) {

	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'SM2000') {
					deviceInfo.push(content[i]);
				}
			}
			$scope.deviceInfo = deviceInfo;
		}
	})
	$scope.PTPChange = function(m) {
		if (m == '6' || m == '7' || m == '8'|| m == '9') {
			$scope.PTPvisible = true;
			$scope.PTPupgrade(m);
			$scope.devExpe = '0';
		} else {
			$scope.PTPvisible = false;
		}
		$scope.deviceUpgradMod.ftpIP = location.hostname;
		$scope.deviceUpgradMod.ftpUser = 'saisi';
		$scope.deviceUpgradMod.ftpPassword = 'saisi';

	}

	$scope.PTPupgrade = function(x) {
		if ($scope.devID) {
			publicService.doRequest("GET", "/nms/spring/deviceConfig/" + $scope.devID.id + "/configs/ioStatusTable").success(function(r) {
				if (r.data && r.data.length > 0) {
					var data = r.data;
					var ptpSolt = [];
					for (var i = 0; i < data.length; i++) {
						var obj = {};
						if (data[i].ioSignal == "PTP" && x == '6') {
							var index = data[i].ioStatusIndex;
							if (index == '0') {
								exp = 'MainShelf';
							} else if (index == '1') {
								exp = 'ExpShelf1';
							} else if (index == '2') {
								exp = 'ExpShelf2';
							} else if (index == '3') {
								exp = 'ExpShelf3';
							} else if (index == '4') {
								exp = 'ExpShelf4';
							}
							obj.exp = exp;
							obj.index = index;
							obj.solt = data[i].ioStatusSlotID;
							ptpSolt.push(obj);
						}
					
						if (data[i].ioSignal == "input-PTP" && x == '7') {
							var index = data[i].ioStatusIndex;
							obj.exp =  'MainShelf';
							obj.index = index;
							obj.solt = data[i].ioStatusSlotID;
							ptpSolt.push(obj);
						}
						if (data[i].ioSignal == "NTP" && x == '8') {
							var index = data[i].ioStatusIndex;
							if (index == '0') {
								exp = 'MainShelf';
							} else if (index == '1') {
								exp = 'ExpShelf1';
							} else if (index == '2') {
								exp = 'ExpShelf2';
							} else if (index == '3') {
								exp = 'ExpShelf3';
							} else if (index == '4') {
								exp = 'ExpShelf4';
							}
							obj.exp =  exp;
							obj.index = index;
							obj.solt = data[i].ioStatusSlotID;
							ptpSolt.push(obj);
						}
						if (data[i].ioSignal == "E1-T1" && x == '9') {
							var index = data[i].ioStatusIndex;
							if (index == '0') {
								exp = 'MainShelf';
							} else if (index == '1') {
								exp = 'ExpShelf1';
							} else if (index == '2') {
								exp = 'ExpShelf2';
							} else if (index == '3') {
								exp = 'ExpShelf3';
							} else if (index == '4') {
								exp = 'ExpShelf4';
							}
							obj.exp =  exp;
							obj.index = index;
							obj.solt = data[i].ioStatusSlotID;
							ptpSolt.push(obj);
						}
					}
					$scope.PTPSoltList = ptpSolt;
				}
			})
		} else {
				var tt = $translate.use() === 'ch' ?　"请选择设备" : "Please select device";
				publicService.ngAlert(tt,"info");
			return;
		}

	}
	$scope.upgradSub = function(m) {
			if (!m) return
			var obj = {};
			var objBack = [];
			var ftpIP = m.ftpIP,
				ftpName = m.ftpName,
				ftpUser = m.ftpUser,
				ftpPassword = m.ftpPassword,
				upgradeModule = m.upgradeModule;
			if (upgradeModule == "6") {
				index = $scope.solt,
					node = 'outputPTPupgradeCmd';
			} else {
				index = upgradeModule,
					node = 'upgradeCmd';
			}

			if (upgradeModule == "7") {
				var b = $scope.solt;
				b = b.substring(2,b.length);
				index = b;
				node = 'inputPTPupgradeCmd';
			}

			if (upgradeModule == "8") {
				index = $scope.solt;
				node = 'outputNTPupgradeCmd';
			}
			var value = ftpName + ',ftp:' + ftpIP + ',' + ftpUser + ',' + ftpPassword;
			obj.value = value;
			obj.index = index;
			obj.node = node;
			objBack.push(obj);
			if ($scope.devID) {
				publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.devID.id + "/setConfigsBatch", objBack).success(function(r) {
					if (!r || !r.data || r.data.length < 0) return;
					var dataObj = r.data;
					if (dataObj[0].code === true) {
						upgradeStatusTable(upgradeModule);
					} else if (dataObj[0].code === false) {
					var tt = $translate.use() === 'ch' ? 　"设置失败" : "Set failed";
					publicService.ngAlert(tt, "info");						}
				})
			} else {
					var tt = $translate.use() === 'ch' ?　"请选择设备" : "Please select device";
				publicService.ngAlert(tt,"info");
				return;
			}
		}
		/**
		 *  upgradeStatusTable
		 *  升级状态返回
		 */
	function upgradeStatusTable(x) {
		if (x == '1' || x == '2' || x == '3' || x == '4' || x == '5') {
			obj = [{
				"node": "upgradeStatus",
				"index": '.' + x,
				"num": ""
			}]
		} else if (x == '6') {
			obj = [{
				"node": "outputPTPupgradeStatus",
				"index": '.' + $scope.solt,
				"num": ""
			}]
		}else if (x == '7') {

				var b = $scope.solt;
				b = b.substring(2,b.length);
				index = b;
			obj = [{
				"node": "inputPTPupgradeStatus",
				"index": index,
				"num": ""
			}]
		}else if (x == '8') {
			index = $scope.solt;
			obj = [{
				"node": "outputNTPupgradeStatus",
				"index": index,
				"num": ""
			}]
		}
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.devID.id + "/getDeviceParamColl", obj).success(function(r) {
			if (r.data && r.data.length > 0) {
				var data = JSON.parse(r.data);
				if (x == '1' || x == '2' || x == '3' || x == '4' || x == '5') {
					var upgradeStatus = data.upgradeStatus;
				} else if (x == '6') {
					var upgradeStatus = data.outputPTPupgradeStatus;
				}else if (x == '7') {
					var upgradeStatus = data.inputPTPupgradeStatus;
				}else if (x == '8') {
					var upgradeStatus = data.outputNTPupgradeStatus;
				}
				var par = document.getElementById('popover');
				angular.element(par).removeClass('popoverS');
				if (upgradeStatus == '6') {
					var tt = $translate.use() === 'ch' ? 　"升级成功" : "upgrade success";
					publicService.ngAlert(tt, "info");
					upgradeSucceed(6, x);
				} else if (upgradeStatus == '2') {
					var tt = $translate.use() === 'ch' ? 　"文件接收失败" : "File receive failed";
					publicService.ngAlert(tt, "info");
					upgradeSucceed(2, x);
				} else if (upgradeStatus == '3') {
					var tt = $translate.use() === 'ch' ? 　"文件接收成功，更新中..." : "Document received successfully, updated...";
					publicService.ngAlert(tt, "info");
					upgradeSucceed(3, x);
				} else if (upgradeStatus == '1') {
					var tt = $translate.use() === 'ch' ? 　"文件接收中..." : "File receiving...";
					publicService.ngAlert(tt, "info");
					upgradeSucceed(1, x);
				} else {
					upgradeSucceed(0, x);
				}
			}
		});
	}

	function upgradeSucceed(con, x) {
		var index = $scope.solt;
		var devID = $scope.devID.id
		if (con === 6 || con === 2) {
			var par = document.getElementById('popover');
			angular.element(par).addClass('popoverS');
			if (con === 6) {
				ngDialog.open({
					template: "template/dialog/upgradeReboot.html",
					className: 'ngdialog-theme-default ngdialog-theme-custom',
					width: 407,
					controller: function($scope, publicService) {
						$scope.menuDigWay = '';
						$scope.backArea = function() {
							ngDialog.close({
								template: "template/dialog/upgradeReboot.html",
								className: 'ngdialog-theme-default ngdialog-theme-custom',
								width: 407,
								controller: function($scope, publicService) {},
								preCloseCallback: function($scope) {}
							});
						}
						$scope.menuDigSub = function() {
							publicService.loading('start');
							var reobj = [],
								obj = {};
							if (x == '1') {
								obj.value = '1';
								obj.node = 'mcReboot';
								obj.index = '.0';
								reobj.push(obj);
							} else if (x == '2') {
								obj.value = '1';
								obj.node = 'cc1Reboot';
								obj.index = '.0';
								reobj.push(obj);
							} else if (x == '3') {
								obj.value = '1';
								obj.node = 'cc2Reboot';
								obj.index = '.0';
								reobj.push(obj);
							} else if (x == '4') {
								obj.value = '1';
								obj.node = 'input1Reboot';
								obj.index = '.0';
								reobj.push(obj);
							} else if (x == '5') {
								obj.value = '1';
								obj.node = 'input2Reboot';
								obj.index = '.0';
								reobj.push(obj);
							} else if (x == '6') {
								obj.value = '1';
								obj.node = 'outputPtpRestartAction';
								obj.index = index + ".0";
								reobj.push(obj);
							}else if (x == '7') {
								obj.value = '1';
								obj.node = 'inputPTPrestartAction';
								obj.index = index + ".0";
								reobj.push(obj);
							}else if (x == '8') {
								obj.value = '1';
								obj.node = 'outputNTPRestartAction';
								obj.index = index + ".0";
								reobj.push(obj);
							}
							publicService.doRequest("POST", "/nms/spring/deviceConfig/" + devID + "/setConfigsBatch", reobj).success(function(r) {
								if (!r || !r.data || r.data.length < 0) return;
								if (r.data.length == 0) {
					var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
					publicService.ngAlert(tt, "info");
									return;
								} else {
									var dataObj = r.data;
									if (dataObj[0].code === true) {
					var tt = $translate.use() === 'ch' ? 　"重启成功" : "restart success";
					publicService.ngAlert(tt, "info");
									} else if (dataObj[0].code === false) {
					var tt = $translate.use() === 'ch' ? 　"重启成功" : "restart success";
					publicService.ngAlert(tt, "info");
									}
								}
							})
						}
					}
				});
			}
			return;
		} else {
			setTimeout(function() {
				upgradeStatusTable(x);
			}, 3000);
		}
	}
}]);
