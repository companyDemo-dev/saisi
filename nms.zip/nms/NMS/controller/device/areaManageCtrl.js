angular.module('areaManageModule',[]).controller('areaManageCtrl', ['$scope', "$state","$translate", 'publicService', "areaData", function($scope, $state,$translate, publicService, areaData) {
	$scope.areaList = areaData.data.data;
	$scope.areaMangeDel = function(m) {
		var self = this,
			t = $translate.use() === "ch" ? "确认删除?" : "confirm delete？";
		if (confirm(t)) {
			publicService.loading('start');
			publicService.doRequest("DELETE", "/nms/spring/device/area/" + m.id, {}).success(function(r) {
				publicService.loading('end');
				if (r.errCode) {
					publicService.ngAlert(r.message, "danger");
				} else {
                	publicService.ngAlert(r.message,"success");
					self.areaList.splice(self.areaList.indexOf(m), 1)
				}
			})
		}
	}
}]);
