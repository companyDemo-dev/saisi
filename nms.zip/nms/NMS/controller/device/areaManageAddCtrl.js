angular.module('areaManageAddModule',[]).controller('areaManageAddCtrl', ['$scope', "$state","$translate",'publicService', function($scope, $state, $translate,publicService){
	$scope.backArea = function(){
		//window.history.back();
		$state.go('index.device.areaManage');
	}
	$scope.areaManageSub = function(m){
		if(!verify.areaManageAdd(m, publicService, $translate)) return;
		var data = {
            name: m,
            code: 0,
        };
        publicService.loading('start');
        var self = this;
        self.disabledFlag = true;
		publicService.doRequest("POST", 113, data, self).success(function(r){
			if(r.errCode){
				publicService.ngAlert(r.message, "danger");
			}else{
				$scope.areaName = "";
					publicService.ngAlert(r.message, "info");
			}
			self.disabledFlag = false;
		})
	}
}]);
