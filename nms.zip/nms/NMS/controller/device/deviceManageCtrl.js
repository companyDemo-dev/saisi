angular.module('deviceManageModule',[]).controller('deviceManageCtrl', ['$scope', "$state","$translate", 'publicService', function($scope, $state,$translate, publicService) {
	publicService.doRequest("GET", 111, {}).success(function(r) {
		$scope.areaData = r.data;
	})
	$scope.alloca = "0";
	$scope.seach = function() {
		if (this.alloca == -1) {
			var areaIds = -1;
		} else {
			if (this.area) {
				areaIds = this.area;
			} else {
				areaIds = 0;
			}
		}
		if (!this.area) {
			$scope.deviceMangeList = [];
		}
		$scope.paginationConf.onChange(areaIds);
	}

	$scope.paginationConf = {
		currentPage: 1,
		totalItems: 0,
		itemsPerPage: 10,
		pagesLength: 15,
		perPageOptions: [10, 20, 30, 40, 50],
		rememberPerPage: 'perPageItems',
		onChange: function(areaIds) {
			if (areaIds == null && areaIds == undefined) areaIds = '0';
			$scope.seachMod = $scope.seachMod || {};
			var _self = this,
				obj = {
					page: _self.currentPage || 1,
					pageSize: _self.itemsPerPage,
					name: "",
					ip: "",
					deviceStatus: "",
					areaId: areaIds,
					deviceType: ""
				}
			publicService.loading('start');
			publicService.doRequest("GET", 116, obj).success(function(r) {
				$scope.deviceMangeList = r.data.content || [];
				_self.currentPage = parseInt(r.data.number + 1);
				_self.totalItems = r.data.totalElements;
				_self.itemsPerPage = r.data.size;
			})
		}
	};

	$scope.deviceMangeEditAdd = function(m) {
		$state.go('index.device.deviceManageEditAdd', {
			mauto: m
		})
	}

	function choseList(did,version){
		var list = $scope.deviceMangeList;
		for (var i = 0; i < list.length; i++) {
			if(did === list[i].id){
				list[i].imageVersion = version;
				break;
			}
		}
	}

	$scope.versionT = function(m){
		if(m.deviceStatus !== '0'){
			publicService.loading('start');
			publicService.doRequest("GET", "/nms/spring/device/" + m.id + "/syncDeviceVersion",{}).success(function(r) {
				publicService.loading('end');
				if (r.errCode) {
					publicService.ngAlert(r.message, "danger");
				} else {
					var d = r.data;
					d.imageVersion && choseList(d.id, d.imageVersion);
                	//publicService.ngAlert(r.message,"success");
				}
			})
		}
	}

	$scope.deviceMangeDel = function(m) {
		var self = this,
			t = $translate.use() === "ch" ? "确认删除?" : "confirm delete？";
		if (confirm(t)) {
			self.deviceMangeList.splice(self.deviceMangeList.indexOf(m), 1)
			publicService.loading('start');
			publicService.doRequest("DELETE", "/nms/spring/device/" + m.id, {}).success(function(r) {
				publicService.loading('end');
				// publicService.ngAlert('删除成功！', "success");
				if (r.errCode) {
					publicService.ngAlert(r.message, "danger");
				} else {
                	publicService.ngAlert(r.message,"success");
				}
			})
			var o = {};
			o.areaId = m.area.id || "";
			o.userId = localStorage.getItem("curUserId") || "";
			o.viewDataType = "";
			publicService.doRequest("GET", 5, o).success(function(r) { //同时删除与设备有关的拓扑图位置和信号;
				if (r.data.length > 0) {
					var tup = r.data[0],
						obj = JSON.parse(tup.data);
					for (var j in obj) {
						if (j === m.ip) {
							delete obj[j];
						} else if (obj[j]["targetIds"]) {
							var tag = obj[j]["targetIds"];
							if (tag.length > 0) {
								for (var f = 0; f < tag.length; f++) {
									if (tag[f].ip === m.ip) {
										tag.splice(f, 1);
									}
								}
							}
						}
					}
					tup.data = JSON.stringify(obj);
					publicService.doRequest("POST", 5, tup);
				}
			})
		}
	}
}]);
