angular.module('SYNLOCKCModule',[]).controller('SYNLOCKCCtrl',['$scope', '$state', '$rootScope', '$stateParams', '$rootScope', "$translate", '$state', 'publicService', function($scope, $state, $rootScope, $rootScope, $stateParams, $translate, $state, publicService) {

		var DEVICETYPE = $state.params.router, _URL = "";
		$scope.DEVICE_TITLE = $state.params.title;
		if(DEVICETYPE === "TS3100"){
			_URL = 32;
		}else if(DEVICETYPE === "TS3000"){
			_URL = 33;
		}else if(DEVICETYPE === "HP55400"){
			_URL = 34;
		}
		publicService.doRequest("GET", 30, {
			deviceType: DEVICETYPE
		}).success(function(r) {
			if (r.errCode) {
				publicService.ngAlert(r.message, "danger");
			} else {
				$scope.ssuDeviceList = r.data;
			}
		})

		publicService.doRequest("GET", _URL, {
			deviceType: DEVICETYPE
		}).success(function(r) {
			if (r.errCode) {
				publicService.ngAlert(r.message, "danger");
			} else {
				$scope.command = r.data;
			}
		})

		$scope.seach = function(m) {
			if (!m.ssudevice) {
					var tt = $translate.use() === 'ch' ?　"请选择设备" : "Please select device";
					publicService.ngAlert(tt,"info");
				return;
			}
			if (!m.comm) {
					var tt = $translate.use() === 'ch' ?　"请选择命令" : "Please select command";
					publicService.ngAlert(tt,"info");
				return;
			}

			if (!$scope.card || $scope.card.length === 0) {
				publicService.doRequest("GET", "/nms/spring/deviceConfig/" + DEVICETYPE.toLowerCase() + "/" + m.ssudevice + "/getParamByCommand/" + m.comm, {}).success(function(r) {
					if (r.errCode) {
						publicService.ngAlert(r.message, "danger");
					} else {
						if (r.data.machineFrames.length == 0) {
							executeTL1(m, true);
						} else {
							$scope.card = r.data.machineFrames;
						}
						$scope.comFlag = r.data.haveSet;
					}
				})
			} else {
				if (verifyFun.isNull(m.card)) {
					publicService.ngAlert("请选择板卡", "danger");
					return;
				}
				executeTL1(m);
			}
		}

		function executeTL1(m, flag) {
			publicService.doRequest("POST", "/nms/spring/deviceConfig/" + DEVICETYPE.toLowerCase() + "/" + m.ssudevice + "/executeTL1", params(m, flag)).success(function(r) {
				if (r.errCode) {
					publicService.ngAlert(r.message, "danger");
				} else {
					$scope.comList = contr(r.data);
					_newVals();
					if (r.data.length == 0) {
						$scope.comINACTIVE = 'none';
					}
					if ($scope.curLoginMsg) {
						var roleName = $scope.curLoginMsg.roleList[0].roleName;
						if (roleName == '维护级' || roleName == '监视级') {
							$scope.comFlag = false;
						}
					}

				}
			})
		}

		
		$scope.commandD = false;
		$scope.commc = function(s,m) {
			var self = this;
			s && ($scope.card = []);
			$scope.comList = [];
			$scope.comINACTIVE = '';
			if (self.ssu.card) self.ssu.card = '';
			$scope.commandD = true;
		}

		$scope.subCom = function(m, index) {
			var oo = {};
			var self = this;
			var data = m[index];
			  var obj ={};
			for(m in data){
				obj[m] = data[m].v1;
			}
			oo.value = JSON.stringify(obj);

			oo.command = self.ssu.comm;

			oo.param = self.ssu.card.name || "";
			publicService.doRequest("POST", "/nms/spring/deviceConfig/" + DEVICETYPE.toLowerCase() + "/" + self.ssu.ssudevice + "/executeTL1", oo).success(function(r) {
				if (r.errCode) {
					publicService.ngAlert(r.message, "danger");
				} else {
					publicService.ngAlert("设置成功", "success");
				}
			})
		}

		function params(m, flag) {
			var o = {};
			o.command = m.comm;
			o.param = m.card && m.card.name ? m.card.name : "";
			return o;
		}

		function contr(jsondata) {
			var obj = [];
			for (i = 0; i < jsondata.length; i++) {
				var mydata = jsondata[i];
				for (var x in mydata) {
					//alert(x+"="+mydata[x]);
					var data = {};
					if (mydata[x] == null) continue;
					if (mydata[x].indexOf('#') > -1) {
						var ss = mydata[x].split('#');
						data.v1 = ss[0];
						data.v2 = ss[1];
						data.v3 = ss[2];
						mydata[x] = data;
					} else {
						data.v1 = mydata[x];
						mydata[x] = data;
					}
				}
				obj.push(mydata);
			}
			return obj
		}


		function _newVals() {
			var comList = $scope.comList;
			var obj = [];
			for (var x in comList) {
				var comObj = comList[x];
				for (m in comObj) {
					var data = {};
					data.name = m;
					data.value = comObj[m].v1;
					obj.push(data);
				}
			}
			localStorage.setItem('ssuvalueDoms', JSON.stringify(obj));
		}

		function _changeVals(x) {
			var comList = x;
			var obj = [];
			for (var x in comList) {
				var comObj = comList[x];
				for (m in comObj) {
					var data = {};
					data.name = m;
					data.value = comObj[m].v1;
					obj.push(data);
				}
			}
			var changeObj = {};
			for (var i = 0; i < obj.length; i++) {
				var _id = obj[i].name,
					_val = obj[i].value;
				changeObj[_id] = _val;
			}
			return changeObj;
		}
	}]);