angular.module('SYSConfigModule', []).controller('SYSConfigCtrl', ['$scope', '$state', '$stateParams', '$rootScope', "$translate", '$state', 'publicService', function($scope, $state, $stateParams, $rootScope, $translate, $state, publicService) {

	$scope.alarmM = 'alarm1';

	/**
	 * downloadConfig
	 *   导出配置
	 */
	$scope.downloadConfig = function() {

		var self = this;
		if (!self.devID) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}

		var config_obj = [];
		var obj = {};
		obj.node = 'alarmConfigTable';
		obj.index = '';
		config_obj.push(obj);
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $rootScope.SYNLOCKdevID.id + "/downloadConfig/config", config_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}
	$scope.deviceContent = {};
	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data == null) return
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'SYNLOCK') {
					deviceInfo.push(content[i]);
				}
			}
			$scope.deviceInfo = deviceInfo;
		}
	})


	sum = 1;
	$scope.PREVIOUSD = true;
	$scope.seach = function(x) {
		var self = this;
		$scope.mauto = self.devID;
		$scope.devExp = self.devExp;
		if ($rootScope.SYNLOCKdevID) {
			$scope.mauto = $rootScope.SYNLOCKdevID;
		} else {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}
		publicService.loading('start');

		var devId = $rootScope.SYNLOCKdevID.id;
		url = $scope.alarmM;

		publicService.doRequest("GET", "/nms/spring/deviceConfig/" + devId + "/configs/" + url, '').success(function(r) {
			if (r.data && r.data.length > 0) {
				var alarmData = r.data;/*
				var obj = [];
				for(i=0;i<alarmData.length;i++){
					alarmData[i] = alarmData[i];
					obj.push(alarmData[i]);
				}*/
				$scope.configList = alarmData;
			}
			_newVals();
		});
	}
	if ($rootScope.SYNLOCKdevID) {
		$scope.mauto = $rootScope.SYNLOCKdevID;
		$rootScope.devIP = $rootScope.SYNLOCKdevID.name;
		$scope.shelfList = $rootScope.SYNLOCKdevID.shelfList;
		$scope.devExp = '0';
		$scope.seach()
	}
/*		function contr(mydata) {
		var obj = [];
			for (var x in mydata) {
				//alert(x+"="+mydata[x]);
				var data = {};
				if (mydata[x] == null) continue;
				if (mydata[x].indexOf('#') > -1) {
					var ss = mydata[x].split('#');
					data.v1 = ss[0];
					data.v2 = ss[1];
					data.v3 = ss[2];
					mydata[x] = data;
				} else {
					data.v1 = mydata[x];
					mydata[x] = data;
				}
			}
			obj.push(mydata);
		return obj
	}*/
	$scope.listSetConfig = function(x) {
		$scope.deviceContent = x;
		_newVals();
	}

	$scope.macChange = function(x) {
		var self = this;
		$scope.mauto = self.devID;
		if (self.devID && self.devID.deviceStatus != 0) {
			//子页面之间传值
			/*	$rootScope.shelfList = self.devID.shelfList;
				$rootScope.devIP = self.devID.ip;*/

			//界面显示
			$rootScope.devIP = self.devID.name;
			$rootScope.SYNLOCKdevID = self.devID;
			//界面显示
			$scope.shelfList = self.devID.shelfList;
			$scope.devIP = self.devID.ip;
			$scope.devExp = '0';
		} else if (self.devID && self.devID.deviceStatus != 1) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}

	}
	$scope.configSub = function(x, index) {
		var configSub_obj = [];
			obj = {};
			obj.value =  x.value;
			obj.node = x.type;
			obj.index = 'ALM';
			configSub_obj.push(obj);
		configSubmit(configSub_obj, index);
	}

	/**
	 * configSubmit
	 *   配置提交
	 */
	function configSubmit(configSub_obj, index) {
		if (!$scope.mauto) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return
		}
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/setConfigsBatch", configSub_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var doc;
			if (r.data.length == 0) {
				var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
				publicService.ngAlert(tt, "info");
				return;
			} else {
                var dataObj = r.data;
                var tt = $translate.use() === 'ch' ? 　"设置成功" : "set success！";
                publicService.ngAlert(tt, "info");
                return;
            }

		})

	}

	function _newVals() {
		var deviceContent = $scope.deviceContent;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		localStorage.setItem('valueDoms', JSON.stringify(obj));
	}

	function _changeVals(x) {
		var deviceContent = x;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		var _vals = JSON.parse(localStorage.getItem('valueDoms')),
			changeObj = {};
		for (var i = 0; i < obj.length; i++) {
			var _id = obj[i].name,
				_val = obj[i].value;
			for (var j = 0; j < _vals.length; j++) {
				var _id2 = _vals[j].name,
					_val2 = _vals[j].value;
				if (_id === _id2) {
					if (_val != _val2) {
						changeObj[_id] = _val;
					}
				}
			}
		}
		return changeObj;
	}
}]);