angular.module('3000GrebootModule',[]).controller('rebootCtrl', ['$scope', '$state', '$rootScope', '$stateParams',  "$translate", '$state', 'publicService', function($scope, $state, $rootScope,  $stateParams, $translate, $state, publicService) {
			$scope.macChange = function(x) {
		var self = this;
		$scope.mauto = self.devID;
		if (self.devID && self.devID.deviceStatus != 0) {
			localStorage.setItem("mauto", angular.toJson(self.devID));
			//子页面之间传值
			/*	$rootScope.shelfList = self.devID.shelfList;
				*/
		    $rootScope.devIP = self.devID.ip;
		    $rootScope.ns7200devID = self.devID;
			//界面显示
			$scope.shelfList = self.devID.shelfList;
			$scope.devIP = self.devID.ip;
		} else if (self.devID && self.devID.deviceStatus != 1) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}
	}
	$scope.deviceContent = {};
	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data == null) return
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'TS3000G') {
					deviceInfo.push(content[i]);
				}
			}
			$scope.deviceInfo = deviceInfo;
		}
	});

	$scope.mauto = {};
	$scope.devidFun = function(m){
		var obj = [{
			"node": "systemReboot",
			"index": ".0",
			"num": ""
		}]
		if(!m){$scope.mauto ={}; return; }
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + m.id + "/getDeviceParamColl", obj).success(function(r) {
			if(r && r.data){
				$scope.mauto = {}
				$scope.mauto = JSON.parse(r.data);
				localStorage.setItem("oldRebootCtrl", r.data);
			}				
		});
	}

	$scope.boardConfig = function(newData){
	if (!verify.reboot(newData, publicService, $translate)) return;
		var self = this;
		if(!self.devID) return;
		var oldData = JSON.parse(localStorage.getItem("oldRebootCtrl")),
			arr = [];
		for(ls in oldData){
			if(oldData[ls] !== newData[ls]){
				arr.push({"node": ls, "index": ".0", "value" : newData[ls]})
			}
		}
		if (arr.length == 0) {
			var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
			publicService.ngAlert(tt, "info");
			return;
		}
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/setConfigsBatch", arr).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var dataObj = r.data, str = "";
			var tt = $translate.use() === 'ch' ? 　"返回状态列表" : "Return state List";
			for (var i = 0; i < dataObj.length; i++) {
				str += dataObj[i].message + ';'
			}
			publicService.ngAlert(str + tt, "info");
			localStorage.setItem("oldRebootCtrl", JSON.stringify(newData));
		})
	}

}]);

