angular.module('3000GrefConfigTableModule',[]).controller('refConfigTableCtrl', ['$scope', '$state', '$rootScope', '$stateParams', "$translate", '$state', 'publicService', function($scope, $state, $rootScope, $stateParams, $translate, $state, publicService) {
$scope.macChange = function(x) {
		var self = this;
		$scope.mauto = self.devID;
		if (self.devID && self.devID.deviceStatus != 0) {
			localStorage.setItem("mauto", angular.toJson(self.devID));
			//子页面之间传值
			/*	$rootScope.shelfList = self.devID.shelfList;
				*/
		    $rootScope.devIP = self.devID.ip;
		    $rootScope.ns7200devID = self.devID;
			//界面显示
			$scope.shelfList = self.devID.shelfList;
			$scope.devIP = self.devID.ip;
		} else if (self.devID && self.devID.deviceStatus != 1) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}
	}

	$scope.deviceContent = {};
	$scope.gnss1D = true;
	$scope.change = function(x) {
		if (x == 1) {
			$scope.gnss1D = false;
		}
	}
	$scope.showGnss1State = function() {
			$state.go("index.7200config.gnss1State");
		}
	$scope.showGnss1Lite = function() {
			$state.go("index.7200config.gnss1Lite");
		}
		/**
		 * downloadConfig
		 *   导出配置
		 */
	$scope.downloadConfig = function() {
		var self = this;
		if (!self.devID) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}
		if (!$scope.download) {
			var tt = $translate.use() === 'ch' ? 　"请先获取数据" : "Please get date";
			publicService.ngAlert(tt, "info");
			return;
		}

		var config_obj = [];
		var _vals = JSON.parse(localStorage.getItem('valueDoms'));
		flag = true;
		for (var j = 0; j < _vals.length; j++) {
			var obj = {};
			if (_vals[j].name == 'gnss1CurrentPositionJ' || _vals[j].name == 'gnss1CurrentPositionW' || _vals[j].name == 'gnss1CurrentPositionH') {
				if (flag) {
					obj.node = 'gpsConfigPosition';
					obj.index = '.0';
					config_obj.push(obj);
					flag = false;
				}
			} else if (_vals[j].name == 'gpsConfigPosition') {
				continue
			} else {
				obj.node = _vals[j].name;
				obj.index = '.0';
				config_obj.push(obj);
			}
		}

		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/downloadConfig/config", config_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}
	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data == null) return
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'TS3000G') {
					deviceInfo.push(content[i]);
				}
			}
			$scope.deviceInfo = deviceInfo;
		}
	})

$scope.listSetConfig = function(x) {
		$scope.deviceContent = x;
	}

	$scope.configSub = function(x, index) {
		if (!verify.refConfig3000G(x, publicService, $translate)) return;
		var configSub_obj = [];
			obj = {};
			obj.value = x.refConfigFP;
			obj.node = 'refConfigFP';
			obj.index = '.' + index;
			configSub_obj.push(obj);
		configSubmit(configSub_obj, index);
	}

/**
	 * configSubmit
	 *   配置提交
	 */
	function configSubmit(configSub_obj, index) {
		if (!$scope.mauto) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return
		}
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/setConfigsBatch", configSub_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var doc;
			if (r.data.length == 0) {
				var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
				publicService.ngAlert(tt, "info");
				return;
			} else {
				var dataObj = r.data;
				publicService.ngAlert(dataObj[0].message, "info");
			}

		})

	}

	$scope.seach = function() {
		var self = this;
		if($rootScope.ns7200devID){
		   self.devID = $rootScope.ns7200devID;
		}else{
			publicService.ngAlert('请选择设备', "info");
		}
		$scope.mauto = self.devID;
		if (!self.devID || typeof self.devID.id === 'undefined' || $scope.devIP == 'No selection device') {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}

		if (self.devID.deviceStatus == 0) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}
		publicService.loading('start');
		var devId = self.devID.id;
		
		publicService.doRequest("GET", "/nms/spring/deviceConfig/" + devId + "/configs/refConfigTable", {}).success(function(r) {
			if (r.data && r.data.length > 0) {
				$scope.refConfigTable = r.data;
				_newVals()
			}
		})
	}

	function _newVals() {
		var deviceContent = $scope.deviceContent;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		localStorage.setItem('valueDoms', JSON.stringify(obj));
	}

	function _changeVals(x) {
		var deviceContent = x;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		var _vals = JSON.parse(localStorage.getItem('valueDoms')),
			changeObj = {};
		for (var i = 0; i < obj.length; i++) {
			var _id = obj[i].name,
				_val = obj[i].value;
			for (var j = 0; j < _vals.length; j++) {
				var _id2 = _vals[j].name,
					_val2 = _vals[j].value;
				if (_id === _id2) {
					if (_val != _val2) {
						changeObj[_id] = _val;
					}
				}
			}
		}
		return changeObj;
	}
}]);
