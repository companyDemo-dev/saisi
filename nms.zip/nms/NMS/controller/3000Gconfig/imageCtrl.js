angular.module('3000GimageModule',[]).controller('imageCtrl', ['$scope', '$state', '$rootScope', '$stateParams',  "$translate", '$state', 'publicService', function($scope, $state, $rootScope,  $stateParams, $translate, $state, publicService) {
			$scope.macChange = function(x) {
		var self = this;
		$scope.mauto = self.devID;
		if (self.devID && self.devID.deviceStatus != 0) {
			localStorage.setItem("mauto", angular.toJson(self.devID));
			//子页面之间传值
			/*	$rootScope.shelfList = self.devID.shelfList;
				*/
		    $rootScope.devIP = self.devID.ip;
		    $rootScope.ns7200devID = self.devID;
			//界面显示
			$scope.shelfList = self.devID.shelfList;
			$scope.devIP = self.devID.ip;
		} else if (self.devID && self.devID.deviceStatus != 1) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}
	}
	$scope.deviceContent = {};
					/**
	 * downloadConfig
	 *   导出配置
	 */
	$scope.downloadConfig = function() {

		var self = this;
		if (!self.devID) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}
		var config_obj = [];
		var obj = {};
		obj.node = 'imageInfoTable';
		obj.index = '';
		config_obj.push(obj);
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/downloadConfig/config", config_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}
	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data == null) return
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'TS3000G') {
					deviceInfo.push(content[i]);
				}
			}
			$scope.deviceInfo = deviceInfo;
		}
	});

	$scope.mauto = {};
	$scope.devidFun = function(m){
		
		
		var self = this;

		if($rootScope.ns7200devID){
		   self.devID = $rootScope.ns7200devID;
		}else{
			publicService.ngAlert('请选择设备', "info");
		}
		$scope.mauto = self.devID;
		var devId = self.devID.id;
		publicService.loading('start');
		var obj = [{
			"node": "mcImageActive",
			"index": ".0",
			"num": ""
		}];
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + devId + "/getDeviceParamColl", obj).success(function(r) {
			if(r && r.data){
				$scope.mcImageActiveFlag = JSON.parse(r.data).mcImageActive;
				publicService.doRequest("GET", "/nms/spring/deviceConfig/" + devId + "/configs/imageInfoTable", {}).success(function(r) {
					if(r && r.data){
						$scope.imageInfoTable = r.data;
					}				
				});
			}				
		});
	}
	$scope.activation = function(m,index){
		if(!this.devID){ return; }
		var obj = [{"node": "mcImageActive", "index": ".0", "value" : String(index || "0")}];
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + this.devID.id + "/setConfigsBatch", obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var dataObj = r.data, str = "";
			if(dataObj[0].code){
				var doms = angular.element(document.getElementById('imageInfoTable')).find("tr");
				angular.forEach(doms,function(a,b){
					var td = angular.element(a).find("td");
					if(index === (b + 1)){
						td[2].innerHTML = "激活";
					}else{
						angular.forEach(td,function(aa,bb){
							if(bb === 2){
								aa.innerHTML = "";
							}
						})
					}
				})
				var tt = $translate.use() === 'ch' ? 　"设置成功" : "Set success";
				publicService.ngAlert(tt, "info");
			}else{
				publicService.ngAlert(dataObj[0].message, "info");
			}
		})
	}

}]);
