angular.module('3000Ggnss2Module',[]).controller('gnss2Ctrl', ['$scope', '$state', '$rootScope', '$stateParams',  "$translate", '$state', 'publicService',  function($scope, $state, $rootScope,  $stateParams, $translate, $state, publicService) {
			$scope.macChange = function(x) {
		var self = this;
		$scope.mauto = self.devID;
		if (self.devID && self.devID.deviceStatus != 0) {
			localStorage.setItem("mauto", angular.toJson(self.devID));
			//子页面之间传值
			/*	$rootScope.shelfList = self.devID.shelfList;
				*/
		    $rootScope.devIP = self.devID.ip;
		    $rootScope.ns7200devID = self.devID;
			//界面显示
			$scope.shelfList = self.devID.shelfList;
			$scope.devIP = self.devID.ip;
		} else if (self.devID && self.devID.deviceStatus != 1) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}
	}
	$scope.deviceContent = {};
	$scope.gnss2D = true;
	$scope.change = function(x) {
		if(x == 1){
			$scope.gnss2D = false;
		}
	}
		$scope.showGnss2State = function() {
			$state.go("index.3000Gconfig.gnss2State");
		}
		$scope.showGnss2Lite = function() {
			$state.go("index.3000Gconfig.gnss2Lite");
		}
     /**
	 * downloadConfig
	 *   导出配置
	 */
	$scope.downloadConfig = function() {
		var self = this;
		if (!self.devID) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}
		if (!$scope.download) {
			var tt = $translate.use() === 'ch' ? 　"请先获取数据" : "Please get date";
			publicService.ngAlert(tt, "info");
			return;
		}
		var config_obj = [];
		var _vals = JSON.parse(localStorage.getItem('valueDoms'));
		flag = true;
		for (var j = 0; j < _vals.length; j++) {
			var obj = {};
			if (_vals[j].name == 'gnss2CurrentPositionJ' || _vals[j].name == 'gnss2CurrentPositionW' || _vals[j].name == 'gnss2CurrentPositionH') {
				if (flag) {
					obj.node = 'gnssConfigPosition';
					obj.index = '.0';
					config_obj.push(obj);
					flag = false;
				}
			} else if (_vals[j].name == 'gnssConfigPosition') {
				continue
			} else {
				obj.node = _vals[j].name;
				obj.index = '.0';
				config_obj.push(obj);
			}
		}

		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/downloadConfig/config", config_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}
publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data == null) return
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'TS3000G') {
					deviceInfo.push(content[i]);
				}
			}
			$scope.deviceInfo = deviceInfo;
		}
	})



	$scope.seach = function() {
		var self = this;
	
		if($rootScope.ns7200devID){
		   self.devID = $rootScope.ns7200devID;
		}else{
			publicService.ngAlert('请选择设备', "info");
		}
		$scope.mauto = self.devID;
		publicService.loading('start');
		if (!self.devID || typeof self.devID.id === 'undefined' || $scope.devIP == 'No selection device') {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}

		if (self.devID.deviceStatus == 0) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}

		var devId = self.devID.id;
		var obj = {};
		obj = [{
			"node": "gnssConfigMode",
			"index": ".0",
			"num": ""
		}, {
			"node": "gnssConfigElevMask",
			"index": ".0",
			"num": ""
		}, {
			"node": "gnssConfigTrackMode",
			"index": ".0",
			"num": ""
		}, {
			"node": "gnssConfigCableDelay",
			"index": ".0",
			"num": ""
		}, {
			"node": "gnssConfigPosition",
			"index": ".0",
			"num": ""
		}]
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + devId + "/getDeviceParamColl", obj).success(function(r) {
			if (r.data && r.data.length > 0) {
				$scope.deviceContent = JSON.parse(r.data);
				$scope.download = true;
				if ($scope.deviceContent.gnssConfigPosition) {
					var time = new Array();
					time = $scope.deviceContent.gnssConfigPosition.split(",");
					$scope.deviceContent.gnss2CurrentPositionJ = time[0];
					$scope.deviceContent.gnss2CurrentPositionW = time[1];
					$scope.deviceContent.gnss2CurrentPositionH = time[2];
				}
			}
			_newVals();
		});
	}


	$scope.configSub = function(x, index) {
	if (!verify.gnss23000G(x, publicService, $translate)) return;
		if (index) {
			indexObj = index;
		}
		ds = _changeVals(x);
		flag = true;
		var configSub_obj = [];
		for (var j in ds) {
			obj = {};
			switch (j) {
				case "gnss2CurrentPositionJ":
				case "gnss2CurrentPositionW":
				case "gnss2CurrentPositionH":
					if (flag) {
						var j = $scope.deviceContent.gnss2CurrentPositionJ,
							w = $scope.deviceContent.gnss2CurrentPositionW,
							h = $scope.deviceContent.gnss2CurrentPositionH,
							gnssConfigPosition = String(j + "," + w + "," + h);
						obj.value = gnssConfigPosition;
						obj.node = 'gnssConfigPosition';
						obj.index = indexObj;
						flag = false;
						configSub_obj.push(obj);
					}
					break;
				default:
					obj.value = ds[j];
					obj.node = j;
					obj.index = indexObj;
					configSub_obj.push(obj);
			}
		}
		configSubmit(configSub_obj, index);
		_newVals()
	}

	/**
	 * configSubmit
	 *   配置提交
	 */
	function configSubmit(configSub_obj, index) {
		if (!$scope.mauto) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return
		}
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.mauto.id + "/setConfigsBatch", configSub_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var doc;
			if (r.data.length == 0) {
				var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
				publicService.ngAlert(tt, "info");
				return;
			} else {
				var dataObj = r.data;
				var div = document.createElement('p');
				for (var i = 0; i < dataObj.length; i++) {
					if (dataObj[i].code === false) {
						var node = document.createTextNode(dataObj[i].message + ' ');
						div.appendChild(node);

					} else if (dataObj[i].code === true) {
						var node = document.createTextNode(dataObj[i].message + ' ');
						div.appendChild(node);
					}
				}
				var element = document.getElementById("ngTip");
				element.appendChild(div);
				var tt = $translate.use() === 'ch' ? 　"返回状态列表" : "Return state List";
				publicService.ngAlert(tt, "info");
				setTimeout(function() {
					element.removeChild(div);
				}, 3000)
			}

		})

	}

	function _newVals() {
		var deviceContent = $scope.deviceContent;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		localStorage.setItem('valueDoms', JSON.stringify(obj));
	}

	function _changeVals(x) {
		var deviceContent = x;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		var _vals = JSON.parse(localStorage.getItem('valueDoms')),
			changeObj = {};
		for (var i = 0; i < obj.length; i++) {
			var _id = obj[i].name,
				_val = obj[i].value;
			for (var j = 0; j < _vals.length; j++) {
				var _id2 = _vals[j].name,
					_val2 = _vals[j].value;
				if (_id === _id2) {
					if (_val != _val2) {
						changeObj[_id] = _val;
					}
				}
			}
		}
		return changeObj;
	}

}]);
