angular.module('ssu2000OutputCardCtrlModule',[]).controller('ssu2000OutputCardCtrl', ['$scope', '$state', '$rootScope', '$stateParams',  "$translate", '$state', 'publicService', function($scope, $state, $rootScope, $stateParams, $translate, $state, publicService) {
/**
	 * downloadConfig
	 *   导出配置
	 */
	$scope.downloadConfig = function() {

		var self = this;
		if (!self.devID) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}

		var config_obj = [];
		var obj = {};
		obj.node = 'ioStatusTable';
		obj.index = '';
		config_obj.push(obj);
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/downloadConfig/config", config_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}
	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data == null) return
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'SSU2000') {
					deviceInfo.push(content[i]);
				}
			}
			$scope.deviceInfo = deviceInfo;
		}
	})



	$scope.seach = function() {

		var self = this;
		$scope.mauto = self.devID;
		$scope.devExp = self.devExp;
		if ($rootScope.SSU2000devID) {
			$scope.mauto = $rootScope.SSU2000devID;
		} else {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}
		if (!$scope.devExp || $scope.devExp == 'undefined' || $scope.devExp == '未选择') {
			var tt = $translate.use() === 'ch' ? 　"请选择机框" : "Please select machine frame";
			publicService.ngAlert(tt, "info");
			return;
		}
		
		var devId = $rootScope.SSU2000devID.id;
		publicService.doRequest("GET", "/nms/spring/deviceConfig/" + devId + "/getIoStatus", {
			shelfIndex: $scope.devExp
		}).success(function(r) {
			if (r.data && r.data.length > 0) {
				$scope.frameConfigList = r.data;
			}
		})
	}
	if ($stateParams.deviceData) {
		$scope.devID = $stateParams.deviceData;
		$rootScope.SSU2000devID = $stateParams.deviceData;
		$rootScope.devIP = $stateParams.deviceData.name;
		$scope.shelfList = $stateParams.deviceData.shelfList;
		$scope.devExp = '0';
	}

	if ($rootScope.SSU2000devID) {
			$scope.mauto = $rootScope.SSU2000devID;
		$rootScope.devIP = $rootScope.SSU2000devID.name;
		$scope.shelfList = $rootScope.SSU2000devID.shelfList;
		$scope.devExp = '0';
		$scope.seach();
	}else{
		$rootScope.devIP = '';
		$scope.frameConfigList ='';

	}
	$scope.macChange = function(x) {
		var self = this;
		$scope.mauto = self.devID;
		if (self.devID && self.devID.deviceStatus != 0) {
			//子页面之间传值
			/*	$rootScope.shelfList = self.devID.shelfList;
				$rootScope.devIP = self.devID.ip;*/

			//界面显示
			$rootScope.devIP = self.devID.name;
			$rootScope.SSU2000devID = self.devID;
			//界面显示
			$scope.shelfList = self.devID.shelfList;
			$scope.devIP = self.devID.ip;
			$scope.devExp = '0';
		} else if (self.devID && self.devID.deviceStatus != 1) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}

	}



	$scope.outPTPconfigEnt = function(m,x) {
		if (m) {
			m.devID = $scope.mauto.id;
			//$rootScope.mauto = m;
		}
		if (m.ioSignal == "Clock Stratum 2E") {
			$state.go("index.ssuConfig.ssu2000ccCard", {
				mauto: m,
				deviceData: x
			});
		} else if(m.ioSignal == "Communications") {
			$state.go("index.ssuConfig.ssu2000mcCard", {
				mauto: m,
				deviceData: x
			});
		} else if (m.ioSignal == "Input GPS") {
			$state.go('index.ssuConfig.ssu2000gpsCard', {
				mauto: m,
				deviceData: x
			});
		}else if (m.ioSignal.includes('Input DS1 3Port')) {
			$state.go("index.ssuConfig.ssu2000DS1Card", {
				mauto: m,
				deviceData: x
			});

		}else if (m.ioSignal.includes('Input Sine')) {
			$state.go("index.ssuConfig.ssu2000sineCard", {
				mauto: m,
				deviceData: x
			});

		}else if (m.ioSignal.includes('Output 2048 kHz')) {
			$state.go("index.ssuConfig.ssu20002048Card", {
				mauto: m,
				deviceData: x
			});

		}
	}

}]);
