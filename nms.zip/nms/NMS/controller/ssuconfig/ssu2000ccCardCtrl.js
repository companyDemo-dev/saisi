angular.module('ssu2000ccCardCtrlModule', []).controller('ssu2000ccCardCtrl', ['$scope', '$state', '$stateParams', '$rootScope', "$translate", '$state', 'publicService', function($scope, $state, $stateParams, $rootScope, $translate, $state, publicService) {
    $scope.mauto = $stateParams.mauto;
    $scope.ipMode = '1';
    if ($stateParams.mauto) {
        $scope.ioSignal = $stateParams.mauto.ioSignal;
        $scope.mainframeNum = $stateParams.mauto.ioStatusIndex;
        $scope.solt = $stateParams.mauto.ioStatusSlotID;
        $scope.ptpDevID = $stateParams.mauto.devID;
        $scope.deviceData = $stateParams.deviceData;
    }
    /**
     * downloadConfig
     *   导出配置
     */
    $scope.downloadConfig = function() {

        var config_obj = [];
        var _vals = JSON.parse(localStorage.getItem('valueDoms'));
        for (var j = 0; j < _vals.length; j++) {
            var obj = {};
            obj.node = _vals[j].name;
            obj.index = '';
            config_obj.push(obj);
        }
        publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/downloadConfig/config", config_obj).success(function(r) {
            if (!r || !r.data || r.data.length < 0) return;
            window.location.href = 'http://' + location.hostname + r.data + '';
        })
    }
    publicService.doRequest("GET", 112, {
        page: "",
        pageSize: 200,
        name: "",
        ip: "",
        deviceStatus: "",
        areaId: "",
        deviceType: ""
    }).success(function(r) {
        if (r.data == null) return
        if (r.data !== null && r.data.content && r.data.content.length > 0) {
            var content = r.data.content;
            var deviceInfo = [];
            for (i = 0; i < content.length; i++) {
                if (content[i].deviceStatus == 1 && content[i].deviceType == 'TP1000') {
                    deviceInfo.push(content[i]);
                }
            }
            $scope.deviceInfo = deviceInfo;
        }
    })



    $scope.seach = function() {
        url = 'clock';
        publicService.doRequest("GET", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/configs/" + url, '').success(function(r) {
            if (r.data) {
                var obj = r.data.ClockParameters;
                if ($scope.ipMode == '1') {
                    dataObj = obj[0];
                } else if ($scope.ipMode == '2') {
                    dataObj = obj[1];
                } 
                $scope.deviceContent = dataObj;
            }
            _newVals();
        });
    }
    $scope.seach();

    /*    function contr(mydata) {
            var obj = [];
            for (var x in mydata) {
                //alert(x+"="+mydata[x]);
                var data = {};
                if (mydata[x] == null) continue;
                if (mydata[x].indexOf('#') > -1) {
                    var ss = mydata[x].split('#');
                    data.v1 = ss[0];
                    data.v2 = ss[1];
                    data.v3 = ss[2];
                    mydata[x] = data;
                } else {
                    data.v1 = mydata[x];
                    mydata[x] = data;
                }
            }
            obj.push(mydata);
            return obj
        }*/

    function _newVals() {
        var deviceContent = $scope.deviceContent;
        var obj = [];
        for (var x in deviceContent) {
            var data = {};
            data.value = deviceContent[x];
            data.name = x;
            obj.push(data);
        }
        localStorage.setItem('valueDoms', JSON.stringify(obj));
    }


    function _changeVals(x) {
        var changeContent = x;
        var obj = [];
        for (var x in changeContent) {
            var data = {};
            data.name = x;
            data.value = changeContent[x];
            obj.push(data);
        }
        var _vals = JSON.parse(localStorage.getItem('valueDoms')),
            changeObj = {};
        for (var i = 0; i < obj.length; i++) {
            if (obj[i].name == 'sprdchn') {
                var _id = obj[i].name,
                    _val = obj[i].value;
            } else {
                var _id = obj[i].name,
                    _val = obj[i].value;
            }
            for (var j = 0; j < _vals.length; j++) {
                var _id2 = _vals[j].name,
                    _val2 = _vals[j].value;
                if (_id === _id2) {
                    if (JSON.stringify(_val) != JSON.stringify(_val2)) {
                        changeObj[_id] = _val;
                    }
                }
            }
        }
        return changeObj;
    }

    /*    function sprdchn(data) {
            if (data.v1[0].name) {
                var sprdchnvalue = data.v1;
                var sprdchnObj = [];
                for (i = 0; i < sprdchnvalue.length; i++) {
                    sprdchnObj.push(sprdchnvalue[i].name);
                }
                return {'v1':sprdchnObj}
            } else {
                return {'v1':data.v1}
            }
        }*/
    $scope.configSub = function(x, index) {
        if (!verify.SSU2000ccCard(x, publicService, $translate, "1")) return;
        ds = _changeVals(x);
        var configSub_obj = [];
        flag1 = true;
        flag2 = true;
        flag3 = true;
        for (var j in ds) {
            obj = {};
            if (j == "sprdchn") {
                var sprdchnObj = ds[j];
                var sprdchnData = [];
                for (var i = 0; i < sprdchnObj.length; i++) {
                    sprdchnData += sprdchnObj[i].name + "&";
                };
                obj.value = sprdchnData;
                obj.node = 'sprdchn';
                obj.index = 'ITH';
                configSub_obj.push(obj);
            } else if (j == "loslog" || j == "losalm") {
                if (flag1) {
                    var sprdchnObj = "LOG-" + $scope.deviceContent.loslog + "&ALM-" + $scope.deviceContent.losalm;
                    obj.value = sprdchnObj;
                    obj.node = 'inplos';
                    obj.index = 'ITH';
                    configSub_obj.push(obj);
                    flag1 = false;
                }
            } else if (j == "isqlog" || j == "isqalm") {
                if (flag2) {
                    var sprdchnObj = "LOG-" + $scope.deviceContent.isqlog + "&ALM-" + $scope.deviceContent.isqalm;
                    obj.value = sprdchnObj;
                    obj.node = 'indisq';
                    obj.index = 'ITH';
                    configSub_obj.push(obj);
                    flag2 = false;
                }
            } else if (j == "cri" || j == "rpt" || j == "pm" || j == "thr") {
                if (flag3) {
                    var sprdchnObj = "THR-" + $scope.deviceContent.thr + "&RPT-" + $scope.deviceContent.rpt + "&PM-" + $scope.deviceContent.pm + "&CRI-" + $scope.deviceContent.cri;
                    obj.value = sprdchnObj;
                    obj.node = 'sprd12S';
                    obj.index = 'ITH';
                    configSub_obj.push(obj);
                    flag3 = false;
                }
            } else {
                obj.value = ds[j];
                obj.node = j;
                obj.index = 'ITH';
                configSub_obj.push(obj);
            }
        }
        configSubmit(configSub_obj, index);
        _newVals();
    }

    /**
     * configSubmit
     *   配置提交
     */
    function configSubmit(configSub_obj, index) {
        if (!$scope.mauto) {
            var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
            publicService.ngAlert(tt, "info");
            return
        }
        publicService.doRequest("POST", "/nms/spring/deviceConfig/" + $scope.ptpDevID + "/setConfigsBatch", configSub_obj).success(function(r) {
            if (!r || !r.data || r.data.length < 0) return;
            var doc;
            if (r.data.length == 0) {
                var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
                publicService.ngAlert(tt, "info");
                return;
            } else {
                var dataObj = r.data;
                var tt = $translate.use() === 'ch' ? 　"设置成功" : "set success！";
                publicService.ngAlert(tt, "info");
                return;
            }

        })

    }
}]);