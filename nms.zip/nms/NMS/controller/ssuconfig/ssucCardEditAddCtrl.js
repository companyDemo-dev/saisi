angular.module('ssucCardEditAddModule',[]).controller('ssucCardEditAddCtrl', ['$scope','$stateParams', '$rootScope', '$state',"$timeout", 'publicService', function($scope,$stateParams, $rootScope,$state, $timeout,publicService) {
	$timeout(function() {
		if ( $stateParams.mauto) {
			$scope.deviceTitle = "修改";
			$scope.mauto =  $stateParams.mauto;
		} else {
			$scope.deviceTitle = "添加";
		}
	}, 0)


	$scope.backArea = function() {
		window.history.back();
		delete $rootScope.mauto;
	}

	$scope.deviceManageSub = function(m) {
		var self = this;
		/*if(!verify.deviceManageEditAdd(m, publicService)) return;*/
		publicService.loading('start');

		var url, method;
		if (self.deviceTitle === "修改") {
			url = 117;
			method = "PUT";
		} else {
			url = 117;
			method = "POST";
		}
		self.disabledFlag = true;
		publicService.doRequest(method, url, m, self).success(function(r) {
			if (r.errCode) {
				publicService.ngAlert(r.message, "danger");
			} else {
				publicService.ngAlert(r.message, "success");
			}
			self.disabledFlag = false;
		})
	}
}]);
