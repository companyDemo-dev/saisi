angular.module('loginModule', []).controller('loginCtrl', ['$scope', '$rootScope', '$http', '$translate', '$state', "publicService", "ngDialog", "ngTip", function($scope, $rootScope, $http, $translate, $state, publicService, ngDialog, ngTip) {
	$scope.mauto = {};
	$translate.use(localStorage.getItem("Language"));
	$scope.dialogClose = false;
	$scope.loginin = function(m) {
		if (!verify.login(m, publicService, $translate)) return;
		publicService.loading('start');
		$http({
			data: m,
			method: "POST",
			url: "/nms/spring/user/login"
		}).success(function(r) {
			if (r.errCode === 1) {
				publicService.ngAlert(r.message, "danger");
				return;
			}
			if (r.errCode === 2) { //密码过期;
				var token = r.data.sessionID,
					mod = {};
				ngDialog.open({
					template: "template/dialog/passwordEdit.html",
					className: 'ngdialog-theme-default ngdialog-theme-custom',
					scope: $scope,
					controller: function($scope, publicService) {
						$scope.$parent.dialogClose = true;
						$scope.editCon = function(o) {
							if (!verify.passEdit(o, publicService, $translate)) return;
							var obj = {
								"name": m.userName,
								"newpassword": o.password,
								"oldpassword": m.password
							};
							$http({
								data: obj,
								method: "POST",
								url: "/nms/spring/user/modifyPassword?token=" + token
							}).success(function(rr) {
								if (rr.errCode === 1) {
									publicService.ngAlert(rr.message, "danger");
								} else {
									publicService.ngAlert(rr.message, "success");
								}
							})
						}
					},
					preCloseCallback: function(scope) {
						if ($scope.dialogClose) {
							$scope.dialogClose = false;
						}
					}
				});
				publicService.ngAlert(r.message, "info");
				return;
			}
			if (r.errCode === 3) {

				ngDialog.open({
					template: "template/dialog/license.html",
					className: 'ngdialog-theme-default ngdialog-theme-custom',
					scope: $scope,
					controller: function($scope, publicService) {
						publicService.doRequest("GET", '/nms/spring/systemManage/getHwaKey', {}).success(function(r) {
							if (r.data == null) return
							if (r.data !== null) {
								$scope.getHwaKey = r.data.machineCode;
							}
						});
						$scope.editCon = function(a) {
							$http({
								data: {license:a},
								method: "PUT",
								url: "/nms/spring/systemManage/updateLicense"
							}).success(function(rr) {
								if (rr.data) {
									publicService.ngAlert('序列号已激活', "success");
									ngDialog.close({
										template: "template/dialog/license.html",
										className: 'ngdialog-theme-default ngdialog-theme-custom',
										scope: $scope,
										controller: function($scope, publicService) {},
										preCloseCallback: function($scope) {}
									});
								} else {
									publicService.ngAlert('序列号无效！', "danger");

								}
							})
						}

						$scope.cancleCon = function(a) {
							ngDialog.close({
										template: "template/dialog/license.html",
										className: 'ngdialog-theme-default ngdialog-theme-custom',
										scope: $scope,
										controller: function($scope, publicService) {},
										preCloseCallback: function($scope) {}
							});
					/*		$rootScope.curLoginMsg = r.data;
							$state.go("index", {
								ExpiredFlag: 0
							});
							ngTip.tip(r.message, "info", 7200000)
							var par = document.getElementById('popover');
							if (par) {
								angular.element(par).removeClass('popoverS');
							}*/
						}
					}
				})
				publicService.ngAlert(r.message, "info");

			} else {
				$rootScope.curLoginMsg = r.data;
				$state.go('index');
			}
			publicService.activeText = null;
			publicService.loading('end');
		})

	}

	document.onkeyup = function(e) {
		var keycode = window.event ? e.keyCode : e.which,
			url = window.location.hash;
		if (keycode === 13 && url.indexOf("#/login") > -1 && !$scope.dialogClose) $scope.loginin($scope.mauto);
	}
}]);
