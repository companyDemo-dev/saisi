angular.module('7200snmpConfigModule',[]).controller('snmpConfigCtrl', ['$scope', '$state', '$rootScope', '$stateParams', '$rootScope', "$translate", '$state', 'publicService', function($scope, $state, $rootScope, $rootScope, $stateParams, $translate, $state, publicService) {


	}]);
