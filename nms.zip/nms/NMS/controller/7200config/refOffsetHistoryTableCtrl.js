angular.module('7200refOffsetHistoryTableModule',[]).controller('refOffsetHistoryTableCtrl', ['$scope', '$state', '$rootScope', '$stateParams',  "$translate", '$state', 'publicService', function($scope, $state, $rootScope, $stateParams, $translate, $state, publicService) {
			$scope.macChange = function(x) {
		var self = this;
		$scope.mauto = self.devID;
		if (self.devID && self.devID.deviceStatus != 0) {
			localStorage.setItem("mauto", angular.toJson(self.devID));
			//子页面之间传值
			/*	$rootScope.shelfList = self.devID.shelfList;
				*/
		    $rootScope.devIP = self.devID.ip;
		    $rootScope.ns7200devID = self.devID;
			//界面显示
			$scope.shelfList = self.devID.shelfList;
			$scope.devIP = self.devID.ip;
		} else if (self.devID && self.devID.deviceStatus != 1) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}
	}
	$scope.mauto = {};
					/**
	 * downloadConfig
	 *   导出配置
	 */
	$scope.downloadConfig = function() {

		var self = this;
		if (!self.devID) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}
		if(!$scope.mauto.refOffsetHistoryShowNumber || !$scope.condition){
			var tt = $translate.use() === 'ch' ? 　"请先设置限制条件" : "Please set condition first!";
			publicService.ngAlert(tt, "info");
			return;
		}

		var config_obj = [];
		var obj = {};
		obj.node = 'refOffsetHistoryTable';
		obj.index = '';
		config_obj.push(obj);
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/downloadConfig/config", config_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}
	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data == null) return
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'NS7200') {
					deviceInfo.push(content[i]);
				}
			}
			$scope.deviceInfo = deviceInfo;
		}
	});

	$scope.devidFun = function(m){
		
		var self = this;

		if($rootScope.ns7200devID){
		   self.devID = $rootScope.ns7200devID;
		}else{
			publicService.ngAlert('请选择设备', "info");
		}
		$scope.mauto = self.devID;
		var devId = self.devID.id;
		var obj = [{
			"node": "refOffsetHistoryShowFlag",
			"index": ".0",
			"num": ""
		}, {
			"node": "refOffsetHistoryShowNumber",
			"index": ".0",
			"num": ""
		}]
		
		publicService.loading('start');
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + devId + "/getDeviceParamColl", obj).success(function(r) {
			if(r && r.data){
				var o = JSON.parse(r.data);
				$scope.mauto = o;
				$scope.refOffsetHistoryTable = [];
			}				
		});
	}
	$scope.refOffsetHistoryTableList = function(m){
		if(!this.devID){$scope.mauto ={}; return; }
		var obj = [{
			"node": "refOffsetHistoryShowFlag",
			"index": ".0",
			"num": ""
		}, {
			"node": "refOffsetHistoryShowNumber",
			"index": ".0",
			"num": ""
		}]
		publicService.doRequest("GET", "/nms/spring/deviceConfig/" + this.devID.id + "/configs/refOffsetHistoryTable", m).success(function(r) {
			if(r && r.data){
				$scope.refOffsetHistoryTable = r.data;
			}				
		});
		$scope.devidFun(m);
	}

	$scope.refOffsetHistoryTableSET = function(m){
	if (!verify.refOffsetHistoryTableSET(m, publicService, $translate)) return;
		if(!this.devID){$scope.mauto ={}; return; }
		var arr = [];
		for(i in m){
			arr.push({"node": i, "index": ".0", "value" : m[i]})
		}
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + this.devID.id + "/setConfigsBatch", arr).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var dataObj = r.data, str = "";
			for (var i = 0; i < dataObj.length; i++) {
				str += dataObj[i].message + ';'
			}
			publicService.ngAlert(str, "info");
			$scope.condition = true;
		});
	}
}]);
