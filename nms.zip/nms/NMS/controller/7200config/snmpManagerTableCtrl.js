angular.module('7200snmpManagerTableModule',[]).controller('snmpManagerTableCtrl', ['$scope', '$state', '$rootScope', '$stateParams',  "$translate", '$state', 'publicService', function($scope, $state, $rootScope,  $stateParams, $translate, $state, publicService) {
			$scope.macChange = function(x) {
		var self = this;
		$scope.mauto = self.devID;
		if (self.devID && self.devID.deviceStatus != 0) {
			localStorage.setItem("mauto", angular.toJson(self.devID));
			//子页面之间传值
			/*	$rootScope.shelfList = self.devID.shelfList;
				*/
		    $rootScope.devIP = self.devID.ip;
		    $rootScope.ns7200devID = self.devID;
			//界面显示
			$scope.shelfList = self.devID.shelfList;
			$scope.devIP = self.devID.ip;
		} else if (self.devID && self.devID.deviceStatus != 1) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}
	}
	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data == null) return
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'NS7200') {
					deviceInfo.push(content[i]);
				}
			}
			$scope.deviceInfo = deviceInfo;
		}
	});

// <td>{{item.snmpManagerID}}</td>
// 							<td>{{item.snmpManagerAddress}}</td>
// 							<td>{{item.snmpManagerEngineID}}</td>
	$scope.mauto = {}
	$scope.snmpManagerTableList =[];
	$scope.devidFun = function(m){
		if(!m){
			$scope.mauto = {};
			angular.extend($scope.mauto, $scope.mautoInit);
			return; 
		}
		var obj = [{"node": "snmpManagerID","index": ".1","num": ""},
		{"node": "snmpManagerAddress","index": ".1","num": ""},
		{"node": "snmpManagerEngineID","index": ".1","num": ""},
		{"node": "snmpManagerRowStatus","index": ".1","num": ""}];

		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + m.id + "/getDeviceParamColl", obj).success(function(r) {
			if(r && r.data){
				$scope.mauto = JSON.parse(r.data);
			}				
		});

		publicService.doRequest("GET", "/nms/spring/deviceConfig/" + m.id + "/configs/snmpManagerTable", {}).success(function(r) {
			if(r && r.data){
				$scope.snmpManagerTableList = r.data;
			}				
		});
	}

	$scope.snmpUserTableSet = function(m){
		var self = this ;
		if(!self.devID) return;
		var arr = [{"node": "snmpManagerID", "index": "." + (self.snmpManagerTableList.length + 1 + '') ,"value" : m.snmpManagerID || ""},
		{"node": "snmpManagerAddress", "index": "." + (self.snmpManagerTableList.length + 1 + '') ,"value" : m.snmpManagerAddress},
		{"node": "snmpManagerEngineID", "index": "." + (self.snmpManagerTableList.length + 1 + '') ,"value" : m.snmpManagerEngineID},
		{"node": "snmpManagerRowStatus", "index": "." + (self.snmpManagerTableList.length + 1 + '') ,"value" : "1"}];


		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/setConfigsBatch", arr).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var dataObj = r.data, str = "";
			if(dataObj[0].code){
				var doms = angular.element(document.getElementById('imageInfoTable')).find("tr");
				var tt = $translate.use() === 'ch' ? 　"设置成功" : "Set success";
				publicService.ngAlert(tt, "info");
				var obj = {};
				$scope.snmpManagerTableList.push(angular.extend(obj, m));
			}else{
				publicService.ngAlert(dataObj[0].message, "info");
			}
		})
	}

	$scope.snmpManagerTableDel = function(m, index){
		var self = this,
			t = $translate.use() === "ch" ? "确认删除?" : "confirm delete？";
		var arr = [{"node": "snmpManagerID", "index": "." + index ,"value" : m.snmpManagerID || ""},
		{"node": "snmpManagerAddress", "index": "." + index ,"value" : m.snmpManagerAddress},
		{"node": "snmpManagerEngineID", "index": "." + index ,"value" : m.snmpManagerEngineID},
		{"node": "snmpManagerRowStatus", "index": "." + index ,"value" : "6"}];

		if (confirm(t)) {
			publicService.loading('start');
			publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/setConfigsBatch", arr).success(function(r) {
				if (!r || !r.data || r.data.length < 0) return;
				var dataObj = r.data, str = "";
				if(dataObj[0].code){
					var doms = angular.element(document.getElementById('imageInfoTable')).find("tr");
					var tt = $translate.use() === 'ch' ? 　"删除成功" : "Set success";
					publicService.ngAlert(tt, "info");
					self.snmpManagerTableList.splice(self.snmpManagerTableList.indexOf(m), 1);
				}else{
					publicService.ngAlert(dataObj[0].message, "info");
				}
			})
		}
	}
}]);

