angular.module('7200upgradeModule',[]).controller('upgradeCtrl', ['$scope', '$state', '$rootScope', '$stateParams',  "$translate", '$state', 'publicService', function($scope, $state, $rootScope, $stateParams, $translate, $state, publicService) {
			$scope.macChange = function(x) {
		var self = this;
		$scope.mauto = self.devID;
		if (self.devID && self.devID.deviceStatus != 0) {
			localStorage.setItem("mauto", angular.toJson(self.devID));
			//子页面之间传值
			/*	$rootScope.shelfList = self.devID.shelfList;
				*/
		    $rootScope.devIP = self.devID.ip;
		    $rootScope.ns7200devID = self.devID;
			//界面显示
			$scope.shelfList = self.devID.shelfList;
			$scope.devIP = self.devID.ip;
		} else if (self.devID && self.devID.deviceStatus != 1) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}
		
		$scope.mauto.ip = location.hostname;
		$scope.mauto.userName = 'saisi';
		$scope.mauto.password = 'saisi';
	}
	$scope.deviceContent = {};
	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data == null) return
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'NS7200') {
					deviceInfo.push(content[i]);
				}
			}
			$scope.deviceInfo = deviceInfo;
		}
	})

	$scope.mauto = {};
	$scope.devidFun = function(m){
		if(!m){$scope.mauto ={}; return; }
		publicService.loading('start');
		var obj = [{"node": "upgradeCmd","index": ".0","num": ""},
		{"node": "upgradeStatus","index": ".0","num": ""}];
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + m.id + "/getDeviceParamColl", obj).success(function(r) {
			if(r && r.data){
				$scope.mauto = {}
				$scope.mauto = JSON.parse(r.data);
			}				
		});
	}
	$scope.upgrade = function(m){
		var self = this;
		if(!self.devID) return;
		if (!verify.upgrade(m, publicService, $translate)) return;
		var str = m.fileName + ",ftp:" + m.ip + "," + m.userName + "," + m.password, arr = [];
		arr.push({"node": "upgradeCmd", "index": ".0" ,"value" : str});
		var par = document.getElementById('popover');
        if(par){
            angular.element(par).removeClass('popoverS');
        }
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/setConfigsBatch", arr)
		.success(function(){
			publicService.loading('start');
		/*	var par = document.getElementById('popover');
            if(par){
                angular.element(par).removeClass('popoverS');
            }*/
		})
	}


}]);
