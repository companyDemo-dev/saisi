angular.module('7200ntpServerModule',[]).controller('ntpServerCtrl', ['$scope', '$state', '$rootScope', '$stateParams', "$translate", '$state', 'publicService', function($scope, $state, $rootScope, $stateParams, $translate, $state, publicService) {
			$scope.macChange = function(x) {
		var self = this;
		$scope.mauto = self.devID;
		if (self.devID && self.devID.deviceStatus != 0) {
			localStorage.setItem("mauto", angular.toJson(self.devID));
			//子页面之间传值
			/*	$rootScope.shelfList = self.devID.shelfList;
				*/
		    $rootScope.devIP = self.devID.ip;
		    $rootScope.ns7200devID = self.devID;
			//界面显示
			$scope.shelfList = self.devID.shelfList;
			$scope.devIP = self.devID.ip;
		} else if (self.devID && self.devID.deviceStatus != 1) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}
	}
	$scope.deviceContent = {};
			/**
	 * downloadConfig
	 *   导出配置
	 */
	$scope.downloadConfig = function() {
		var self = this;
		if (!self.devID) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}
		if (!$scope.download) {
			var tt = $translate.use() === 'ch' ? 　"请先获取数据" : "Please get date";
			publicService.ngAlert(tt, "info");
			return;
		}
		if ($scope.ntpStatePortId) {
			var index = '.' + $scope.ntpStatePortId;
		} else {
			var index = '.1';
		}
		var config_obj = [];
		var _vals = JSON.parse(localStorage.getItem('oldBackupConfig'));
		flag = true;
		for (var j = 0; j < _vals.length; j++) {
			var obj = {};
			if (_vals[j].name == 'ipAddress' || _vals[j].name == 'maskAddress' || _vals[j].name == 'gatewayAddress') {
				if (flag) {
					obj.node = 'ntpServerPortIPaddress';
					obj.index = index;
					config_obj.push(obj);
					flag = false;
				}
			} else if (_vals[j].name == 'ntpServerPortIPaddress') {
				continue
			} else {
				obj.node = _vals[j].name;
				obj.index = index;
				config_obj.push(obj);
			}
		}
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/downloadConfig/config", config_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}
	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data == null) return
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'NS7200') {
					deviceInfo.push(content[i]);
				}
			}
			$scope.deviceInfo = deviceInfo;
		}
	})



	$scope.seach = function() {
		var self = this;

		if($rootScope.ns7200devID){
		   self.devID = $rootScope.ns7200devID;
		}else{
			publicService.ngAlert('请选择设备', "info");
		}
		$scope.mauto = self.devID;
		if (!self.devID || typeof self.devID.id === 'undefined' || $scope.devIP == 'No selection device') {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}

		if (self.devID.deviceStatus == 0) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}
		if (!self.ntpStatePortId || typeof self.ntpStatePortId === 'undefined') {
			var tt = $translate.use() === 'ch' ? 　"请选择端口" : "Please select port";
			publicService.ngAlert(tt, "info");
			return;
		}
		publicService.loading('start');
		if ($scope.ntpStatePortId) {
			var index = '.' + $scope.ntpStatePortId;
		} else {
			var index = '.1';
		}
		var devId = self.devID.id;
		var obj = {};
		obj = [{
			"node": "ntpServerListEnable",
			"index": index,
			"num": ""
		}, {
			"node": "ntpServerAutoKeyEnable",
			"index": index,
			"num": ""
		}, {
			"node": "ntpServerMd5Enable",
			"index": index,
			"num": ""
		}, {
			"node": "ntpServerBroadcastEnable",
			"index": index,
			"num": ""
		}, {
			"node": "ntpServerBroadcastAddr",
			"index": index,
			"num": ""
		}, {
			"node": "ntpServerBroadcastInterval",
			"index": index,
			"num": ""
		}, {
			"node": "ntpServerManycastEnable",
			"index": index,
			"num": ""
		}, {
			"node": "ntpServerManycastAddr",
			"index": index,
			"num": ""
		}, {
			"node": "ntpServerManycastInterval",
			"index": index,
			"num": ""
		}, {
			"node": "ntpServerPortIPaddress",
			"index": index,
			"num": ""
		}, {
			"node": "ntpServerConfigPortState",
			"index": index,
			"num": ""
		}]
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + devId + "/getDeviceParamColl", obj).success(function(r) {
			if (r.data && r.data.length > 0) {
				$scope.deviceContent = JSON.parse(r.data);
				$scope.download = true;

				if ($scope.deviceContent.ntpServerPortIPaddress) {
					var time = new Array();
					time = $scope.deviceContent.ntpServerPortIPaddress.split(",");
					$scope.deviceContent.ipAddress = time[0];
					$scope.deviceContent.maskAddress = time[1];
					$scope.deviceContent.gatewayAddress = time[2];
				}
			}
			_newVals();
		});
	}



	$scope.configSub = function(x) {

		if (!verify.ntpServer(x, publicService, $translate)) return;
		var self = this;
		if (!self.devID) return;
		if ($scope.ntpStatePortId) {
			var index = '.' + $scope.ntpStatePortId;
		} else {
			var index = '.1';
		}

		ds = _changeVals(x);
		flag = true;
		configSub_obj = [];
		for (ls in ds) {
			obj = {};
				switch (ls) {
					case "ipAddress":
					case "maskAddress":
					case "gatewayAddress":
						if (flag) {
							var addr = $scope.deviceContent.ipAddress,
								mask = $scope.deviceContent.maskAddress,
								gateway = $scope.deviceContent.gatewayAddress,
								adr = new Array(addr, mask, gateway);
							var ntpServerPortIPaddress = adr.join(',');
							obj.value = ntpServerPortIPaddress;
							obj.node = 'ntpServerPortIPaddress';
							obj.index = index;
							flag = false;
							configSub_obj.push(obj);
						}
						break;
					default:
						configSub_obj.push({
							"node": ls,
							"index": index,
							"value": x[ls]
						})
				}
		}
		if (configSub_obj.length == 0) {
			var tt = $translate.use() === 'ch' ? 　"未修改任何数据" : "No data has been modified";
			publicService.ngAlert(tt, "info");
			return;
		}

		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/setConfigsBatch", configSub_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var dataObj = r.data,
				str = "";
			for (var i = 0; i < dataObj.length; i++) {
				str += dataObj[i].message + ';'
			}
			publicService.ngAlert(str, "info");
			$scope.seach();
		})
	}


	function _newVals() {
		var deviceContent = $scope.deviceContent;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		localStorage.setItem('oldBackupConfig', JSON.stringify(obj));
	}
	function _changeVals(x) {
		var deviceContent = x;
		var obj = [];
		for (var x in deviceContent) {
			var data = {};
			data.name = x;
			data.value = deviceContent[x];
			obj.push(data);
		}
		var _vals = JSON.parse(localStorage.getItem('oldBackupConfig')),
			changeObj = {};
		for (var i = 0; i < obj.length; i++) {
			var _id = obj[i].name,
				_val = obj[i].value;
			for (var j = 0; j < _vals.length; j++) {
				var _id2 = _vals[j].name,
					_val2 = _vals[j].value;
				if (_id === _id2) {
					if (_val != _val2) {
						changeObj[_id] = _val;
					}
				}
			}
		}
		return changeObj;
	}


	$scope.downloadConfigauto = function() {
		var self = this;
		if (!self.devID) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}
		
		if (!$scope.download) {
			var tt = $translate.use() === 'ch' ? 　"请先获取数据" : "Please get date";
			publicService.ngAlert(tt, "info");
			return;
		}
		if ($scope.ntpStatePortId) {
			var index = '.' + $scope.ntpStatePortId;
		} else {
			var index = '.1';
		}
		var config_obj = [];
		config_obj = [{
			'node': 'ntpServerAutoKeyVlue',
			'index': index
		}]
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/downloadConfig/config", config_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}

	
	$scope.downloadConfigmd5 = function() {
		var self = this;
		if (!self.devID) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}

		if (!$scope.download) {
			var tt = $translate.use() === 'ch' ? 　"请先获取数据" : "Please get date";
			publicService.ngAlert(tt, "info");
			return;
		}
		if ($scope.ntpStatePortId) {
			var index = '.' + $scope.ntpStatePortId;
		} else {
			var index = '.1';
		}
		var config_obj = [];
		config_obj = [{
			'node': 'ntpServerMd5Value',
			'index': index
		}]
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/downloadConfig/config", config_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			window.location.href = 'http://' + location.hostname + r.data + '';
		})
	}

	$scope.restSub = function() {
		var self = this;
		if (!self.devID) {
			var tt = $translate.use() === 'ch' ? 　"请选择设备" : "Please select device";
			publicService.ngAlert(tt, "info");
			return;
		}

		if (!$scope.download) {
			var tt = $translate.use() === 'ch' ? 　"请先获取数据" : "Please get date";
			publicService.ngAlert(tt, "info");
			return;
		}
		if ($scope.ntpStatePortId) {
			var index = '.' + $scope.ntpStatePortId;
		} else {
			var index = '.1';
		}
		var configSub_obj = [];

		configSub_obj.push({
			"node": 'ntpServerConfigPortState',
			"index": index,
			"value": '2'
		})
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/setConfigsBatch", configSub_obj).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var dataObj = r.data,
				str = "";
			for (var i = 0; i < dataObj.length; i++) {
				str += '重启成功'
			}
			publicService.ngAlert(str, "info");
		})
	}
}]);
