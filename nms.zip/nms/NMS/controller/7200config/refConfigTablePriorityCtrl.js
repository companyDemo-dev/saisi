angular.module('7200refConfigTablePriorityModule',[]).controller('refConfigTablePriorityCtrl', ['$scope', '$state', '$rootScope', '$stateParams', "$translate", '$state', 'publicService', function($scope, $state, $rootScope, $stateParams, $translate, $state, publicService) {
			$scope.macChange = function(x) {
		var self = this;
		$scope.mauto = self.devID;
		if (self.devID && self.devID.deviceStatus != 0) {
			localStorage.setItem("mauto", angular.toJson(self.devID));
			//子页面之间传值
			/*	$rootScope.shelfList = self.devID.shelfList;
				*/
		    $rootScope.devIP = self.devID.ip;
		    $rootScope.ns7200devID = self.devID;
			//界面显示
			$scope.shelfList = self.devID.shelfList;
			$scope.devIP = self.devID.ip;
		} else if (self.devID && self.devID.deviceStatus != 1) {
			var tt = $translate.use() === 'ch' ? 　"该设备处于离线状态！" : "The device is offline！";
			publicService.ngAlert(tt, "info");
			return
		}
	}
	var obj = $state.params.obj || {},
		tt = $translate.use() === 'ch';
	$scope.priority = obj.refPriority;
	
	$scope.prioritySub = function(){
		if(verifyFun.isNull(this.priority)){
			if(!tt){
				var str = " can not be empty",
					str1 = " Number between 1-16";
			}else{
				var str = "不能为空",
					str1 = " 为1-16之间的数字";
			}
			publicService.ngAlert("refPriority" + str, "info");
			return;
		}
		if(!verifyFun.between(this.priority,1,16)){
			publicService.ngAlert("refPriority" + str1, "info");
			return;
		}
		var arr = [{"node": "refPriority", "index": '.' + obj.index ,"value" : this.priority}];
		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + obj.deviceID + "/setConfigsBatch", arr).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var dataObj = r.data, str = "";
			if(dataObj[0].code){
				var doms = angular.element(document.getElementById('imageInfoTable')).find("tr");
				var tt = $translate.use() === 'ch' ? 　"设置成功" : "Set success";
				publicService.ngAlert(tt, "info");
			}else{
				publicService.ngAlert(dataObj[0].message, "info");
			}
		})
	}
	$scope.backAuto = function() {
		window.history.back();
	}
}]);
