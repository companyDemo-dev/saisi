angular.module('7200snmpUserTableModule',[]).controller('snmpUserTableCtrl', ['$scope', '$state', '$rootScope', '$stateParams', '$rootScope', "$translate", '$state', 'publicService', function($scope, $state, $rootScope, $rootScope, $stateParams, $translate, $state, publicService) {
	publicService.doRequest("GET", 112, {
		page: "",
		pageSize: 200,
		name: "",
		ip: "",
		deviceStatus: "",
		areaId: "",
		deviceType: ""
	}).success(function(r) {
		if (r.data == null) return
		if (r.data !== null && r.data.content && r.data.content.length > 0) {
			var content = r.data.content;
			var deviceInfo = [];
			for (i = 0; i < content.length; i++) {
				if (content[i].deviceStatus == 1 && content[i].deviceType == 'NS7200') {
					deviceInfo.push(content[i]);
				}
			}
			$scope.deviceInfo = deviceInfo;
		}
	});
	$scope.mauto = {snmpUserType : "0",snmpUserRowStatus : "0"}
	$scope.mautoInit ={
		snmpUserName : "",
		snmpUserType : "0",
		snmpUserAuthKey : "",
		snmpUserPrivateKey : "",
		snmpUserRowStatus : "0"
	};
	$scope.snmpUserTableList =[];
	$scope.devidFun = function(m){
		if(!m){
			$scope.mauto = {};
			angular.extend($scope.mauto, $scope.mautoInit);
			return; 
		}
		var obj = [{"node": "snmpUserName","index": ".1","num": ""},
		{"node": "snmpUserType","index": ".1","num": ""},
		{"node": "snmpUserAuthKey","index": ".1","num": ""},
		{"node": "snmpUserPrivateKey","index": ".1","num": ""},
		{"node": "snmpUserRowStatus","index": ".1","num": ""}];

		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + m.id + "/getDeviceParamColl", obj).success(function(r) {
			if(r && r.data){
				$scope.mauto = JSON.parse(r.data);
			}				
		});

		publicService.doRequest("GET", "/nms/spring/deviceConfig/" + m.id + "/configs/snmpUserTable", {}).success(function(r) {
			if(r && r.data){
				$scope.snmpUserTableList = r.data;
			}				
		});
	}

	$scope.snmpUserTableSet = function(m){
		var self = this ;
		if(!self.devID) return;
		var arr = [{"node": "snmpUserName", "index": "." + (self.snmpUserTableList.length + 1 + '') ,"value" : m.snmpUserName || ""},
		{"node": "snmpUserType", "index": "." + (self.snmpUserTableList.length + 1 + '') ,"value" : m.snmpUserType},
		{"node": "snmpUserAuthKey", "index": "." + (self.snmpUserTableList.length + 1 + '') ,"value" : m.snmpUserAuthKey},
		{"node": "snmpUserPrivateKey", "index": "." + (self.snmpUserTableList.length + 1 + '') ,"value" : m.snmpUserPrivateKey},
		{"node": "snmpUserRowStatus", "index": "." + (self.snmpUserTableList.length + 1 + '') ,"value" : "1"}];


		var str = $translate.use() === 'ch' ? 　"不能为空" : "Can not be empty";
		if(m.snmpUserType == 2 || m.snmpUserType == 3){
			publicService.ngAlert("snmpUserAuthKey " + str, "info");
			return;
		}else if(m.snmpUserType == 4 || m.snmpUserType == 5 ||  m.snmpUserType == 6 || m.snmpUserType == 7){
			publicService.ngAlert("snmpUserPrivateKey " + str, "info");
			return;
		}

		publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/setConfigsBatch", arr).success(function(r) {
			if (!r || !r.data || r.data.length < 0) return;
			var dataObj = r.data, str = "";
			if(dataObj[0].code){
				var doms = angular.element(document.getElementById('imageInfoTable')).find("tr");
				var tt = $translate.use() === 'ch' ? 　"设置成功" : "Set success";
				publicService.ngAlert(tt, "info");
				var obj = {};
				$scope.snmpUserTableList.push(angular.extend(obj, m));
			}else{
				publicService.ngAlert(dataObj[0].message, "info");
			}
		})
	}

	$scope.snmpUserTableDel = function(m, index){
		var self = this,
			t = $translate.use() === "ch" ? "确认删除?" : "confirm delete？";
		var arr = [{"node": "snmpUserName", "index": "." + index ,"value" : m.snmpUserName || ""},
		{"node": "snmpUserType", "index": "." + index ,"value" : m.snmpUserType},
		{"node": "snmpUserAuthKey", "index": "." + index ,"value" : m.snmpUserAuthKey},
		{"node": "snmpUserPrivateKey", "index": "." + index ,"value" : m.snmpUserPrivateKey},
		{"node": "snmpUserRowStatus", "index": "." + index ,"value" : "6"}];

		if (confirm(t)) {
			publicService.loading('start');
			publicService.doRequest("POST", "/nms/spring/deviceConfig/" + self.devID.id + "/setConfigsBatch", arr).success(function(r) {
				if (!r || !r.data || r.data.length < 0) return;
				var dataObj = r.data, str = "";
				if(dataObj[0].code){
					var doms = angular.element(document.getElementById('imageInfoTable')).find("tr");
					var tt = $translate.use() === 'ch' ? 　"删除成功" : "Set success";
					publicService.ngAlert(tt, "info");
					self.snmpUserTableList.splice(self.snmpUserTableList.indexOf(m), 1);
				}else{
					publicService.ngAlert(dataObj[0].message, "info");
				}
			})
		}
	}
}]);

