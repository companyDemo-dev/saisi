angular.module('topbarModule',[]).controller('topbarCtrl',['$scope','$rootScope','$http','$state',"$timeout", "$translate", "publicService",function($scope,$rootScope,$http,$state,$timeout,$translate,publicService){
    function keysrt(key,desc) {
        return function(a,b){
            return desc ? ~~(a[key] < b[key]) : ~~(a[key] > b[key]);
        }
    }
    $scope.activeText = publicService.activeText || "index";
    $translate.use(localStorage.getItem("Language") || 'ch');

    $rootScope.LANG = localStorage.getItem("Language") || "ch";
    publicService.doRequest("GET", 1, {}).success(function(data){
        var list = data.data || [];
        $scope.oneMenu = list;
        publicService.oneMenu = $scope.oneMenu;
    });


    if($scope.curLoginMsg)  $scope.userName = $scope.curLoginMsg.userName;
    $scope.loginOut = function() {
        var t = $translate.use() === "ch" ? "确定要退出吗?" : "Are you sure you want to quit ？";
        if(confirm(t)){
            publicService.doRequest("POST", 29 , {userName : $scope.curLoginMsg.userName}).success(function(r){
                if (r.errCode) {
                    publicService.ngAlert(r.message, "danger");
                } else {
                    console.log($rootScope.curLoginMsg)
                    delete $rootScope.curLoginMsg;
                      location.reload();
                }
                publicService.loading('end');
            })
            
        }
    }

    publicService.doRequest("GET", "/nms/spring/systemManage/getParamConfig", {
        type: 'deviceType'
    }).success(function(r) {
        if (r.data !== null && r.data && r.data.length > 0) {
            $scope.deviceTypeList = r.data;
        }
    })
    $scope.deviceTypeSelectFlag = true ; //网元管理下拉设备类型显隐
    $scope.fers = function(dom){ // 一级菜单触发事件
        if(dom.children && dom.children.length === 0){// 拓扑图
               $scope.activeText = 'index';//清空路由
               publicService.activeText = 'index';//清空路由
  
            $scope.deviceTypeSelectFlag = true ;
        }else if(dom.children && dom.children.length > 0 && dom.url !== "index.config"){//非配置 非拓扑
            $rootScope.twoMenu = null;
            publicService.tuopu = null;
            $rootScope.twoMenu = dom.children;
            var appElement = document.querySelector('[ng-controller=twoMenuCtrl]'),
                scope= angular.element(appElement).scope();
            if(scope) scope.clo = 0;
            publicService.activeText = dom.url

            $state.go(dom.children[0].url);
            $scope.deviceTypeSelectFlag = true ;
        }else{//配置 
            $scope.deviceTypeSelectFlag = !$scope.deviceTypeSelectFlag;
        }

    }
    
    function menuSelect(t, list){
        for (var i = 0; i < list.length; i++) {
            if(list[i].url ===t){
                return list[i].children;
            }
        }
    }

    $scope.deviceTypeSelectEve = function(url, type){
        $scope.deviceTypeSelectFlag = true ;
        if(type === "SM2000"){
            $rootScope.twoMenu = menuSelect("index.config", this.oneMenu);
        }else if(type === "NS7200"){
            $rootScope.twoMenu = menuSelect("index.7200config", this.oneMenu);
        }else if(type === "SSU2000"){
            $rootScope.twoMenu = menuSelect("index.ssuConfig", this.oneMenu);
        }else if(type === "SM2000_GN"){
            $rootScope.twoMenu = menuSelect("index.sm2000GNconfig", this.oneMenu);
        }else if(type === "TS3100"){
            $rootScope.twoMenu = menuSelect("index.ts3100Cofing", this.oneMenu);
        }
        else if(type === "HP55400"){
            $rootScope.twoMenu = menuSelect("index.hp55400Cofing", this.oneMenu);
        }
        else if(type === "STFS1000"){
            $rootScope.twoMenu = menuSelect("index.STFS1000Cofing", this.oneMenu);
        }
        else if(type === "GNSS97"){
            $rootScope.twoMenu = menuSelect("index.GNSS97Config", this.oneMenu);
        }
        else if(type === "SYNLOCK"){
            $rootScope.twoMenu = menuSelect("index.SYNLOCKConfig", this.oneMenu);
        }
        else if(type === "TP1000"){
            $rootScope.twoMenu = menuSelect("index.tp1000Config", this.oneMenu);
        }
        else if(type === "TS3000G"){
            $rootScope.twoMenu = menuSelect("index.3000Gconfig", this.oneMenu);
        }
        else if(type === "LF7300"){
            $rootScope.twoMenu = menuSelect("index.7300config", this.oneMenu);
        }
        $state.go(url);
    }
    function playOrPaused(){ //声音
        var audio = document.getElementById('audio');
        if(audio.paused){
            audio.play();
            return;
        }
        audio.pause();
    }
    var GJTS, GJT,
        otherSound = JSON.parse(localStorage.getItem("otherSound"));


    var GJTS, GJT,
        otherSound = JSON.parse(localStorage.getItem("otherSound")),
        soo = (otherSound && otherSound.soundOffOn === "on") ? "on" : "off";
    $scope.soundMo = soo;
    $scope.soundInterval = (otherSound && (+otherSound.soundInterval) * 1000) || 30000;//间隔时间 
    $scope.soundLength = (otherSound && (+otherSound.soundLength) * 1000) || 6000; //单次

    function setIsta(){//输回声音
        function test(){
            sWitch();
            GJTS = $timeout(test,$scope.soundInterval);
        }
        test();
    }

    function sWitch() {//根据时间来控制告警开关
        var sum = 0, g = 3000, 
            f = Math.floor($scope.soundLength / g);
        function test1(){
            sum++;
            playOrPaused()
            GJT = $timeout(test1,g);
            if(sum === f){
                $timeout.cancel(GJT)
            }
        }
        test1();
    }  
    var watch = $scope.$watch('soundMo',function(newValue,oldValue, scope){
        $timeout.cancel(GJTS);
        $timeout.cancel(GJT);
        if(newValue === "on"){
            setIsta();
        }
        var sou = JSON.parse(localStorage.getItem("otherSound"));
        if(sou){
            sou.soundOffOn = newValue;
        }else{
            sou = {soundOffOn : newValue}
        }
        localStorage.setItem("otherSound", angular.toJson(sou))
    });
    
    $scope.$on("otherSoundMod",function (event, msg) { //监听来自父controller的信息
        if(msg){
            $scope.soundMo = msg.soundOffOn === "on" ? "on" : "off";
            $scope.soundLength = (+msg.soundLength) * 1000;
            $scope.soundInterval = ((+msg.soundInterval) + (+msg.soundLength)) * 1000;
        }
    });

    $scope.sound =function(m){
        $scope.soundMo = $scope.soundMo === "on" ? "off" : "on";
    }   
}]);
