		var app=angular.module("app",[]);
		app.controller("global",['$scope',"$http",function($scope,$http){
			$(document).ready(function(){				

				var topo = {
					deviceModels : [],
					linksModel:[],
					beginNode : null,
					currentNode : null,
					stage : null,
					scene : null,
					flagLineDrag: true,
					right_Menu : $("#right_Menu"),
					newNode : function(x, y, w, h, obj){
						var node = new JTopo.Node(obj.name),
							_self = this,
							ref = $("#topo_ref"),
							alarmNum = $("#alarmNum"),
							topo_tip = $("#topo_tip");
						node.setLocation(x, y);
						node.setSize(w, h);
						node.deviceModel = obj
						node.setImage(_self.select_Picture(obj.deviceType), true);
						if(obj.alarm){
							node.alarm = "";
							if(obj.alarm === "red"){
								node.alarmColor = "214,15,15"
							}else if(obj.alarm === "blue"){
								node.alarmColor = '0,200,255'
							}else if(obj.alarm === "yellow"){
								node.alarmColor ='204,218,15'
							}else if(obj.alarm === "green"){
								node.alarmColor = '15,214,21'
							}
							node.addEventListener("mouseover", function(e){
								var obj = e.target.deviceModel;
								ref.text(obj.ref);
								alarmNum.text(obj.alarmNum);
								topo_tip.css({
									top: event.pageY,
									left: event.pageX + 15
								}).show();
							});
							node.addEventListener("mouseout", function(e){
								topo_tip.hide()
							});
							node.addEventListener("mousedrag", function(e){
								topo_tip.hide()
							});
						}
						_self.scene.add(node);
						return node;
					},
					select_Picture : function(t){
						var str = "";
						if(t === "sm2000"){
							str = "img/1.png"
						}else if(t === "ssu2000"){
							str = "img/server.png"
						}else if(t === "ts3100"){
							str = "img/wanjet.png"
						}else if(t === "new_device"){
							str = "img/terminal.png"
						}
						return str
					},
					topoM : function(arr,id){
		            	for (var i = 0; i < arr.length; i++) {
		            		if(id === arr[i].deviceModel.id){
		            			return arr[i];
		            		}
		            	}
		            },
					dataParams :function(method){
						var obj = {
			   				areaId : "china",
			   				userId:"",
			   				viewDataType:""
			   			};
			   			var o ={};
			   			if(method === "GET"){
			   				o["params"] = obj;
			   				o.method  = "GET";
			   			}else if(method === "POST"){
			   				o["data"] = obj;
			   				o.method  = "POST";
			   			}
			   			o.url = "/nms/spring/viewData"
			   			o.headers = {
				            'Content-Type': 'application/json;charset=UTF-8'
				        };
			   			return o;
					},
					topo_id : function (){
						return this.scene.getDisplayedElements().length + 1;　
					},
					nameQc : function (n){
						var all = this.scene.getDisplayedElements(),
							flag = false;
		            	for (var i = 0; i < all.length; i++) {
		            		if(all[i].elementType === "node" && all[i].deviceModel.name === n){
		            			flag = true;
		            		}
		            	}
		            	return flag;
					},
					events :function(){
						var _self = this,
							topo_save = $("#topo_save"),	
							topo_add = $("#topo_add"),
							topo_fix = $("[name=topo_fix]");
						topo_fix.change(function(e){
							var f = e.target.id;
							if(f === "topo_Drag"){
								_self.flagLineDrag = true;
							}else if(f === "topo_Line"){
								_self.flagLineDrag = false;
							}
						})
						topo_save.click(function(){
							var allElements = _self.scene.getDisplayedElements(),
								dataObj = {},
								linkArr = [],
								nodeObj = {};
							for (var i = 0; i < allElements.length; i++) {
								if(allElements[i].elementType === "node"){
									nodeObj[allElements[i].deviceModel.id] = {x:allElements[i].x , y:allElements[i].y,name:allElements[i].deviceModel.name}
								}else if(allElements[i].elementType === "link"){
									var o = {};
									o.sourceid = allElements[i].nodeA.deviceModel.id;
									o.targetid = allElements[i].nodeZ.deviceModel.id;
									o.arrowsRadius = 8;
									o.lineWidth = 1;
									o.bundleGap = allElements[i].bundleGap || 0;
									if(undefined !== allElements[i].dashedPattern){
										o.dashedPattern = allElements[i].dashedPattern || 0;
									}
									linkArr.push(o);
								}
							}
							dataObj.linkArr = linkArr;
							dataObj.nodeObj = nodeObj;

					        $http(_self.dataParams("GET")).success(function(e){
					        	var o = _self.dataParams("POST");
					        	if(e.data.length > 0 && e.data[0].bigData !== ""){
					        		var d = e.data[0].bigData;
					        		var data = JSON.parse(d);
					        		o.data.id = e.data[0].id;
					        	}
					        	o.data.bigData = JSON.stringify(dataObj);
					        	$http(o);
					        })
						})
						topo_add.click(function(){
							var name = prompt("请输入设备名称", "");
					        if(!name)
					        {  
					            alert("设备名称不能为空");
					            return;
					        }else if(_self.nameQc(name))
					        {  
					            alert("设备名称重复，请重新输入");
					            return;
					        }  
					        _self.newNode(0, 0, 0, 0, {id : _self.topo_id(),name:name,deviceType:"new_device"})
						})
						_self.right_Menu.find("a").click(function(){
			            	var _this = $(this);
			            	if(_this.hasClass("editColor")){
			            	}else if(_this.hasClass("deleteLine")){
			            		_self.scene.remove(_self.currentNode);
			            		var index = _self.linksModel.indexOf(_self.currentNode);
			            		_self.linksModel.splice(index, 1);
			            		// _self.linksModel.re
			            	}else if(_this.hasClass("sLine")){
			            		delete _self.currentNode.dashedPattern;
			            	}else if(_this.hasClass("xLine")){
			            		_self.currentNode.dashedPattern = 5;
			            	}else if(_this.hasClass("offset")){
			            		_self.currentNode.bundleGap  = -15;
			            	}
			            	_self.right_Menu.hide();
			            })
					},
					init :function(){ 
						var _self = this,
							canvas = document.getElementById('canvas');
							textfield = $("#jtopo_textfield"),
							tempNodeA = new JTopo.Node('tempA'),
							tempNodeZ = new JTopo.Node('tempZ'),
							link = new JTopo.Link(tempNodeA, tempNodeZ);
						_self.stage = new JTopo.Stage(canvas);
						_self.scene = new JTopo.Scene(_self.stage);
						_self.stage.wheelZoom = 1.2;
						_self.scene.background = 'img/bg.jpg',
			            tempNodeA.setSize(1, 1);
			            tempNodeZ.setSize(1, 1);
						var devices = [
							{name:"191","id":1,deviceType:"sm2000",alarm:"red",ref:"参考源1",alarmNum:"11"},
							{name:"192","id":2,deviceType:"ts3100",alarm:"blue",ref:"参考源2",alarmNum:"12"},
							{name:"193","id":3,deviceType:"sm2000",alarm:"yellow",ref:"参考源3",alarmNum:"13"},
							{name:"194","id":4,deviceType:"ssu2000",alarm:"green",ref:"参考源4",alarmNum:"14"}
						];
						$http(_self.dataParams("GET")).success(function(e){
				        	if(e.data.length > 0 && e.data[0].bigData !== ""){
				        		var data = JSON.parse(e.data[0].bigData),
				        			nodeObj = data.nodeObj,
				        			links = data.linkArr,
				        			nodeidkeys = Object.keys(nodeObj),
				        			deviceidkeys = devices.map(function(a){return a.id});
				        		for (var i = 0; i < nodeidkeys.length; i++) {
				        			if(deviceidkeys.indexOf(parseInt(nodeidkeys[i])) === -1){
				        				_self.deviceModels.push(_self.newNode(nodeObj[nodeidkeys[i]].x, nodeObj[nodeidkeys[i]].y, 30, 30,{id : nodeidkeys[i],name:nodeObj[nodeidkeys[i]].name,deviceType:"new_device"}));
				        			}
				        		} 
			        			for (var i = 0; i < devices.length; i++) {
			        				if(nodeObj[devices[i].id]){
			        					_self.deviceModels.push(_self.newNode(nodeObj[devices[i].id].x, nodeObj[devices[i].id].y, 30, 30, devices[i]));
			        				}
					            }
				        		if(links.length > 0){
				        			for (var i = 0; i < links.length; i++) {
				        				var l = new JTopo.Link(_self.topoM(_self.deviceModels,links[i].sourceid), _self.topoM(_self.deviceModels,links[i].targetid));
				                        l.arrowsRadius = links[i].arrowsRadius; 
				                        l.bundleGap = links[i].bundleGap; 
				                        l.lineWidth = links[i].lineWidth;
				                        l.sourceid = links[i].sourceid; 
				                        l.targetid = links[i].targetid;
				                        if(links[i].dashedPattern){
				                        	l.dashedPattern = links[i].dashedPattern
				                        }
				                        _self.scene.add(l);
				                        _self.linksModel.push(l);
				                        l.addEventListener('mouseup', function(event){
							                _self.currentNode = this;
							                if(event.button == 2){// 右键
							                    _self.right_Menu.css({
							                        top: event.pageY,
							                        left: event.pageX
							                    }).show();    
							                }
							            });
				        			}
				        		}
				        	}else{
				        		for (var i = 0; i < devices.length; i++) {
			        				_self.newNode(0,0, 30, 30, devices[i])
					            }
				        	}
				        })

			            _self.scene.mouseup(function(e){
			                if(e.button == 2){
			                	_self.beginNode = null;
			                    _self.scene.remove(link);
			                    return;
			                }
			                if(e.target != null && e.target instanceof JTopo.Node){
			                    if(_self.beginNode == null){
			                        _self.scene.remove(link);
			                        _self.beginNode = e.target;
			                    }else if(_self.beginNode !== e.target && !_self.flagLineDrag){
			                    	if(_self.scene){
						            	var all = _self.scene.getDisplayedElements();
						            	for (var i = 0; i < all.length; i++) {
						            		if(all[i].elementType === "link" && all[i].nodeA.deviceModel.id === _self.beginNode.deviceModel.id && all[i].nodeZ.deviceModel.id === e.target.deviceModel.id){
												return;
						            		}
						            	}
					            	}
			                        var endNode = e.target;
			                        var l = new JTopo.Link(_self.beginNode, endNode);
			                        l.arrowsRadius = 8; 
			                        l.lineWidth = 1
			                        l.bundleGap = 0;
			                        _self.scene.add(l);
			                        _self.beginNode = null;
			                        _self.scene.remove(link);
					  				l.addEventListener('mouseup', function(event){
						                _self.currentNode = this;
						                if(event.button == 2){// 右键
						                    _self.right_Menu.css({
						                        top: event.pageY,
						                        left: event.pageX
						                    }).show();    
						                }
						            });
						            _self.linksModel.push(l);
			                    }else{
			                        _self.beginNode = null;
			                    }
			                }else{
			                    _self.scene.remove(link);
			                }
			            });
			            
			            _self.scene.mousedown(function(e){
			                if(e.target == null || e.target === _self.beginNode || e.target === link){
			                    _self.scene.remove(link);
			                }
			            });
        	            _self.stage.click(function(event){
			                if(event.button == 0){
			                    _self.right_Menu.hide();
			                }
			            });

						_self.scene.dbclick(function(event){
			                if(event.target == null) return;
			                var e = event.target;
			                textfield.css({
			                    top: event.pageY,
			                    left: event.pageX - e.width / 2
			                }).show().attr('value', e.text).focus().select();
			                e.text = "";
			                textfield[0].JTopoNode = e;
			            });
			            textfield.blur(function(){
			                textfield[0].JTopoNode.text = textfield.hide().val();
			            });


        	             _self.events();
		        	    setInterval(function(){
			            	if(_self.scene){
				            	var all = _self.scene.getDisplayedElements();
				            	for (var i = 0; i < all.length; i++) {
				            		if(all[i].elementType === "node" && all[i].deviceModel.deviceType !== "new_device"){
										if(all[i].alarm == ''){
						                    all[i].alarm = null;
						                }else{
						                    all[i].alarm = '';
						                }
				            		}
				            	}
			            	}
			            }, 600);
					}
				}
				topo.init();
				// setInterval(function(){
				// 	console.log(topo)
	   //          }, 3600);

				// var canvas = document.getElementById('canvas');
				// var stage = new JTopo.Stage(canvas);
				// var scene = new JTopo.Scene(stage);	
				// stage.wheelZoom = 1.2;
				// scene.background = 'img/bg.jpg';
				// var devices = [
				// 	{name:"191","id":1,deviceType:"sm2000",alarm:"red",ref:"参考源1",alarmNum:"11"},
				// 	{name:"192","id":2,deviceType:"ts3100",alarm:"blue",ref:"参考源2",alarmNum:"12"},
				// 	{name:"193","id":3,deviceType:"sm2000",alarm:"yellow",ref:"参考源3",alarmNum:"13"},
				// 	{name:"194","id":4,deviceType:"ssu2000",alarm:"green",ref:"参考源4",alarmNum:"14"}
				// ];
				// var DEVICE_JPOTO = [];
				// var beginNode = null;
				// var currentNode = null;

	   //          $http(params("GET")).success(function(e){
		  //       	if(e.data.length > 0 && e.data[0].bigData !== ""){
		  //       		var d = e.data[0].bigData;
		  //       		var data = JSON.parse(d);
		  //       		var nodeObj = data.nodeObj;
		  //       		var links = data.linkArr;
		  //       		var nodeidkeys = Object.keys(nodeObj)
		  //       		var deviceidkeys = devices.map(function(a){return a.id});
		  //       		for (var i = 0; i < nodeidkeys.length; i++) {
		  //       			console.log(nodeidkeys[i])
		  //       			if(deviceidkeys.indexOf(parseInt(nodeidkeys[i])) === -1){
		  //       				DEVICE_JPOTO.push(newNode(nodeObj[nodeidkeys[i]].x, nodeObj[nodeidkeys[i]].y, 30, 30,{id : nodeidkeys[i],name:nodeObj[nodeidkeys[i]].name,deviceType:"new_device"}));
		  //       			}
		  //       		} 
	   //      			for (var i = 0; i < devices.length; i++) {
	   //      				if(nodeObj[devices[i].id]){
	   //      					DEVICE_JPOTO.push(newNode(nodeObj[devices[i].id].x, nodeObj[devices[i].id].y, 30, 30, devices[i]));
	   //      				}
			 //            }
		  //       		if(links.length > 0){
		  //       			for (var i = 0; i < links.length; i++) {
		  //       				var l = new JTopo.Link(topoM(DEVICE_JPOTO,links[i].sourceid), topoM(DEVICE_JPOTO,links[i].targetid));
		  //                       l.arrowsRadius = links[i].arrowsRadius; 
		  //                       l.bundleGap = links[i].bundleGap; 
		  //                       l.lineWidth = links[i].lineWidth;
		  //                       l.sourceid = links[i].sourceid; 
		  //                       l.targetid = links[i].targetid;
		  //                       if(links[i].dashedPattern){
		  //                       	l.dashedPattern = links[i].dashedPattern
		  //                       }
		  //                       scene.add(l);
		  //                       l.addEventListener('mouseup', function(event){
				// 	                currentNode = this;
				// 	                handler(event);
				// 	            });
		  //       			}
		  //       		}
		  //       	}else{
		  //       		for (var i = 0; i < devices.length; i++) {
	   //      				newNode(0,0, 30, 30, devices[i])
			 //            }
		  //       	}
		  //       })


	   //          function topoM(arr,id){
	   //          	for (var i = 0; i < arr.length; i++) {
	   //          		if(id === arr[i].deviceModel.id){
	   //          			return arr[i];
	   //          		}
	   //          	}
	   //          }


				
	   //          var tempNodeA = new JTopo.Node('tempA');;
	   //          tempNodeA.setSize(1, 1);
	            
	   //          var tempNodeZ = new JTopo.Node('tempZ');;
	   //          tempNodeZ.setSize(1, 1);
	            
	   //          var link = new JTopo.Link(tempNodeA, tempNodeZ);
	            
	   //          scene.mouseup(function(e){
	   //              if(e.button == 2){
	   //              	beginNode = null;
	   //                  scene.remove(link);
	   //                  return;
	   //              }
	   //              if(e.target != null && e.target instanceof JTopo.Node){
	   //                  if(beginNode == null){
	   //                      scene.remove(link);
	   //                      beginNode = e.target;
	   //                  }else if(beginNode !== e.target){
	   //                  	if(scene){
				//             	var all = scene.getDisplayedElements();
				//             	for (var i = 0; i < all.length; i++) {
				//             		if(all[i].elementType === "link" && all[i].nodeA.deviceModel.id === beginNode.deviceModel.id && all[i].nodeZ.deviceModel.id === e.target.deviceModel.id){
				// 						return;
				//             		}
				//             	}
			 //            	}
	   //                      var endNode = e.target;
	   //                      var l = new JTopo.Link(beginNode, endNode);
	   //                      l.arrowsRadius = 8; 
	   //                      l.lineWidth = 1
	   //                      l.bundleGap = 0;
	   //                      scene.add(l);
	   //                      beginNode = null;
	   //                      scene.remove(link);
			 //  				l.addEventListener('mouseup', function(event){
				//                 currentNode = this;
				//                 handler(event);
				//             });
	   //                  }else{
	   //                      beginNode = null;
	   //                  }
	   //              }else{
	   //                  scene.remove(link);
	   //              }
	   //          });
	            
	   //          scene.mousedown(function(e){
	   //              if(e.target == null || e.target === beginNode || e.target === link){
	   //                  scene.remove(link);
	   //              }
	   //          });

	   //          $("#but1").click(function(){
				// 	var allElements = scene.getDisplayedElements(),
				// 		dataObj = {},
				// 		linkArr = [],
				// 		nodeObj = {};
				// 	for (var i = 0; i < allElements.length; i++) {
				// 		if(allElements[i].elementType === "node"){
				// 			nodeObj[allElements[i].deviceModel.id] = {x:allElements[i].x , y:allElements[i].y,name:allElements[i].deviceModel.name}
				// 		}else if(allElements[i].elementType === "link"){
				// 			var o = {};
				// 			o.sourceid = allElements[i].nodeA.deviceModel.id;
				// 			o.targetid = allElements[i].nodeZ.deviceModel.id;
				// 			o.arrowsRadius = 8;
				// 			o.lineWidth = 1;
				// 			o.bundleGap = allElements[i].bundleGap || 0;
				// 			if(undefined !== allElements[i].dashedPattern){
				// 				o.dashedPattern = allElements[i].dashedPattern || 0;
				// 			}
				// 			linkArr.push(o);
				// 		}
				// 	}
				// 	dataObj.linkArr = linkArr;
				// 	dataObj.nodeObj = nodeObj;

			 //        $http(params("GET")).success(function(e){
			 //        	var o = params("POST");
			 //        	if(e.data.length > 0 && e.data[0].bigData !== ""){
			 //        		var d = e.data[0].bigData;
			 //        		var data = JSON.parse(d);
			 //        		o.data.id = e.data[0].id;
			 //        	}
			 //        	o.data.bigData = JSON.stringify(dataObj);
			 //        	$http(o)
			 //        })

				// })

				// function topo_id(){
				// 	return scene.getDisplayedElements().length + 1;　
				// }
				// var textfield = $("#jtopo_textfield");
				// scene.dbclick(function(event){
	   //              if(event.target == null) return;
	   //              var e = event.target;
	   //              textfield.css({
	   //                  top: event.pageY,
	   //                  left: event.pageX - e.width/2
	   //              }).show().attr('value', e.text).focus().select();
	   //              e.text = "";
	   //              textfield[0].JTopoNode = e;
	   //          });
	   //          $("#jtopo_textfield").blur(function(){
	   //              textfield[0].JTopoNode.text = textfield.hide().val();
	   //          });
				// function params(method){
				// 	var obj = {
		  //  				areaId : "china",
		  //  				userId:"",
		  //  				viewDataType:""
		  //  			};
		  //  			var o ={};
		  //  			if(method === "GET"){
		  //  				o["params"] = obj;
		  //  				o.method  = "GET";
		  //  			}else if(method === "POST"){
		  //  				o["data"] = obj;
		  //  				o.method  = "POST";
		  //  			}
		  //  			o.url = "/nms/spring/viewData"
		  //  			o.headers = {
			 //            'Content-Type': 'application/json;charset=UTF-8'
			 //        };
		  //  			return o;
				// }
				// $("#but2").click(function(){
				// 	var name = prompt("请输入设备名称", ""); 
			 //        if(!name)
			 //        {  
			 //            alert("设备名称不能为空");
			 //            return;
			 //        }else if(nameQc(name))//如果返回的有内容  
			 //        {  
			 //            alert("设备名称重复，请重新输入");
			 //            return;
			 //        }  
			 //        newNode(0, 0, 0, 0, {id : topo_id(),name:name,deviceType:"new_device"})
				// })
				
				// function nameQc(n){
				// 	var all = scene.getDisplayedElements(),
				// 		flag = false;
	   //          	for (var i = 0; i < all.length; i++) {
	   //          		if(all[i].elementType === "node" && all[i].deviceModel.name === n){
	   //          			flag = true;
	   //          		}
	   //          	}
	   //          	return flag;
				// }

				// function newNode(x, y, w, h, obj){
				// 	var node = new JTopo.Node(obj.name);
				// 	node.setLocation(x, y);
				// 	node.setSize(w, h);
				// 	node.deviceModel = obj
				// 	node.setImage(choseImg(obj.deviceType), true);
				// 	if(obj.alarm){
				// 		node.alarm = "";
				// 		if(obj.alarm === "red"){
				// 			node.alarmColor = "214,15,15"
				// 		}else if(obj.alarm === "blue"){
				// 				node.alarmColor = '0,200,255'
				// 		}else if(obj.alarm === "yellow"){
				// 				node.alarmColor ='204,218,15'
				// 		}else if(obj.alarm === "green"){
				// 				node.alarmColor = '15,214,21'
				// 		}
				// 		node.addEventListener("mouseover", function(e){
				// 			var obj = e.target.deviceModel;
				// 			$('#ref').text(obj.ref);
				// 			$('#alarmNum').text(obj.alarmNum);
				// 			$("#topo-tip").css({
		  //                       top: event.pageY,
		  //                       left: event.pageX + 15
		  //                   }).show();
				// 		});
				// 		node.addEventListener("mouseout", function(e){
				// 			$("#topo-tip").hide()
				// 		});
				// 		node.addEventListener("mousedrag", function(e){
				// 			$("#topo-tip").hide()
				// 		});
				// 	}
				// 	scene.add(node);
				// 	return node;
				// }
				// function choseImg(t){
				// 	var str = "";
				// 	if(t === "sm2000"){
				// 		str = "img/host.png"
				// 	}else if(t === "ssu2000"){
				// 		str = "img/server.png"
				// 	}else if(t === "ts3100"){
				// 		str = "img/wanjet.png"
				// 	}else if(t === "new_device"){
				// 		str = "img/terminal.png"
				// 	}
				// 	return str
				// }

	   //          function handler(event){
	   //              if(event.button == 2){// 右键
	   //                  $("#contextmenu").css({
	   //                      top: event.pageY,
	   //                      left: event.pageX
	   //                  }).show();    
	   //              }
	   //          }
	   //          stage.click(function(event){
	   //              if(event.button == 0){
	   //                  $("#contextmenu").hide();
	   //              }
	   //          });
	   //          $("#contextmenu a").click(function(){
	   //          	var self = $(this);
	   //          	if(self.hasClass("editColor")){

	   //          	}else if(self.hasClass("deleteLine")){
	   //          		scene.remove(currentNode)
	   //          	}else if(self.hasClass("sLine")){
	   //          		delete currentNode.dashedPattern;
	   //          	}else if(self.hasClass("xLine")){
	   //          		currentNode.dashedPattern = 5;
	   //          	}else if(self.hasClass("offset")){
	   //          		currentNode.bundleGap  = -15;
	   //          	}
	   //          	$("#contextmenu").hide();
	   //          })
	   //          setInterval(function(){
	   //          	if(scene){
		  //           	var all = scene.getDisplayedElements();
		  //           	for (var i = 0; i < all.length; i++) {
		  //           		if(all[i].elementType === "node" && all[i].deviceModel.deviceType !== "new_device"){
				// 				if(all[i].alarm == ''){
				//                     all[i].alarm = null;
				//                 }else{
				//                     all[i].alarm = '';
				//                 }
		  //           		}
		  //           	}
	   //          	}
	   //          }, 600);
		});
		}]);