routerApp.config(['$stateProvider', '$urlRouterProvider',function($stateProvider, $urlRouterProvider) {
    $stateProvider
    .state('index.ssuConfig', {
        url: '/ssuConfig',
        views: {
            'center@index': {
                templateUrl: 'template/center.html'
            }
        }
    })
    .state('index.ssuConfig.ssuc', {//安全
        url: '/ssuc',
        templateUrl: 'template/ssuconfig/ssuconfig.html',
        controller : "ssucCtrl",
        resolve: {
            load : loadJS("ssucCtrlModule",['controller/ssuconfig/ssucCtrl.js'])
        }
    })
    .state('index.ssuConfig.ssucCard', {//安全
        url: '/ssucCard',
        templateUrl: 'template/ssuconfig/ssuCardconfig.html',
        controller : "ssucCardCtrl",
        resolve: {
            load : loadJS("ssucCardModule",['controller/ssuconfig/ssucCardCtrl.js'])
        }
    })
    .state('index.ssuConfig.ssucCardEditAdd', {//安全
        url: '/ssucCardEditAdd',
        templateUrl: 'template/ssuconfig/ssuCardEditAddconfig.html',
        controller : "ssucCardEditAddCtrl",
        params: {mauto : null},
        resolve: {
            load : loadJS("ssucCardEditAddModule",['controller/ssuconfig/ssucCardEditAddCtrl.js'])
        }
    })
    
    .state('index.ssuConfig.ssu2000OutputCard', {//安全
        url: '/ssu2000OutputCard',
        templateUrl: 'template/ssuconfig/ssu2000OutputCard.html',
        controller : "ssu2000OutputCardCtrl",
        resolve: {
            load : loadJS("ssu2000OutputCardCtrlModule",['controller/ssuconfig/ssu2000OutputCardCtrl.js'])
        },
        params: {
           mauto : null,
            deviceData : null
        }
    })
    
    .state('index.ssuConfig.ssu2000mcCard', {//安全
        url: '/ssu2000mcCard',
        templateUrl: 'template/ssuconfig/ssu2000mcCard.html',
        controller : "ssu2000mcCardCtrl",
        resolve: {
            load : loadJS("ssu2000mcCardCtrlModule",['controller/ssuconfig/ssu2000mcCardCtrl.js'])
        },
        params: {
           mauto : null,
            deviceData : null
        }
    })
    
    .state('index.ssuConfig.ssu2000ccCard', {//安全
        url: '/ssu2000ccCard',
        templateUrl: 'template/ssuconfig/ssu2000ccCard.html',
        controller : "ssu2000ccCardCtrl",
        resolve: {
            load : loadJS("ssu2000ccCardCtrlModule",['controller/ssuconfig/ssu2000ccCardCtrl.js'])
        },
        params: {
           mauto : null,
            deviceData : null
        }
    })
    
    .state('index.ssuConfig.ssu2000ccCardshow', {//安全
        url: '/ssu2000ccCardshow',
        templateUrl: 'template/ssuconfig/ssu2000ccCardshow.html',
        controller : "ssu2000ccCardshowCtrl",
        resolve: {
            load : loadJS("ssu2000ccCardshowCtrlModule",['controller/ssuconfig/ssu2000ccCardshowCtrl.js'])
        },
        params: {
           mauto : null,
            deviceData : null
        }
    })

    
    .state('index.ssuConfig.ssu2000DS1Card', {//安全
        url: '/ssu2000DS1Card',
        templateUrl: 'template/ssuconfig/ssu2000DS1Card.html',
        controller : "ssu2000DS1CardCtrl",
        resolve: {
            load : loadJS("ssu2000DS1CardCtrlModule",['controller/ssuconfig/ssu2000DS1CardCtrl.js'])
        },
        params: {
           mauto : null,
            deviceData : null
        }
    })

    
    .state('index.ssuConfig.ssu2000gpsCard', {//安全
        url: '/ssu2000gpsCard',
        templateUrl: 'template/ssuconfig/ssu2000gpsCard.html',
        controller : "ssu2000gpsCardCtrl",
        resolve: {
            load : loadJS("ssu2000gpsCardCtrlModule",['controller/ssuconfig/ssu2000gpsCardCtrl.js'])
        },
        params: {
           mauto : null,
            deviceData : null
        }
    })
    
    
    .state('index.ssuConfig.ssu2000JCCCard', {//安全
        url: '/ssu2000JCCCard',
        templateUrl: 'template/ssuconfig/ssu2000JCCCard.html',
        controller : "ssu2000JCCCardCtrl",
        resolve: {
            load : loadJS("ssu2000JCCCardCtrlModule",['controller/ssuconfig/ssu2000JCCCardCtrl.js'])
        },
        params: {
           mauto : null,
            deviceData : null
        }
    })
    
    
    .state('index.ssuConfig.ssu2000sineCard', {//安全
        url: '/ssu2000sineCard',
        templateUrl: 'template/ssuconfig/ssu2000sineCard.html',
        controller : "ssu2000sineCardCtrl",
        resolve: {
            load : loadJS("ssu2000sineCardCtrlModule",['controller/ssuconfig/ssu2000sineCardCtrl.js'])
        },
        params: {
           mauto : null,
            deviceData : null
        }
    })
    
    
    .state('index.ssuConfig.ssu20002048Card', {//安全
        url: '/ssu20002048Card',
        templateUrl: 'template/ssuconfig/ssu20002048Card.html',
        controller : "ssu20002048CardCtrl",
        resolve: {
            load : loadJS("ssu20002048CardCtrlModule",['controller/ssuconfig/ssu20002048CardCtrl.js'])
        },
        params: {
           mauto : null,
            deviceData : null
        }
    })
    
    .state('index.ssuConfig.ssu2000alarmConfig', {//安全
        url: '/ssu2000alarmConfig',
        templateUrl: 'template/ssuconfig/ssu2000alarmConfig.html',
        controller : "ssu2000alarmConfigCtrl",
        resolve: {
            load : loadJS("ssu2000alarmConfigCtrlModule",['controller/ssuconfig/ssu2000alarmConfigCtrl.js'])
        },
        params: {
           mauto : null,
            deviceData : null
        }
    })
    .state('index.ssuConfig.ssu2000alarmShow', {//安全
        url: '/ssu2000alarmShow',
        templateUrl: 'template/ssuconfig/ssu2000alarmShow.html',
        controller : "ssu2000alarmShowCtrl",
        resolve: {
            load : loadJS("ssu2000alarmShowCtrlModule",['controller/ssuconfig/ssu2000alarmShowCtrl.js'])
        },
        params: {
           mauto : null,
            deviceData : null
        }
    })
}]);
                               