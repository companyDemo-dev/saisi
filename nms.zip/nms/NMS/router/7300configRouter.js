routerApp.config(['$stateProvider', '$urlRouterProvider', function($stateProvider, $urlRouterProvider) {
    $stateProvider
        .state('index.7300config', {
            url: '/7300config',
            views: {
                'center@index': {
                    templateUrl: 'template/center.html'
                }
            }
        })
       .state('index.7300config.gnss', {
            url: '/gnss',
            templateUrl: 'template/7300config/gnss.html',
            controller: "gnssCtrl",
            resolve : {
                load : loadJS("7300gnssModule",['controller/7300config/gnssCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.7300config.alarmConfigTable', {
            url: '/alarmConfigTable',
            templateUrl: 'template/7300config/alarmConfigTable.html',
            controller: "alarmConfigTableCtrl",
            resolve : {
                load : loadJS("7300alarmConfigTableModule",['controller/7300config/alarmConfigTableCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.7300config.alarmStatusTable', {
            url: '/alarmStatusTable',
            templateUrl: 'template/7300config/alarmStatusTable.html',
            controller: "alarmStatusTableCtrl",
            resolve : {
                load : loadJS("7300alarmStatusTableModule",['controller/7300config/alarmStatusTableCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.7300config.IPETH', {
            url: '/IPETH',
            templateUrl: 'template/7300config/IPETH.html',
            controller: "IPETHCtrl",
            resolve : {
                load : loadJS("7300IPETHModule",['controller/7300config/IPETHCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.7300config.inventoryGroup', {
            url: '/inventoryGroup',
            templateUrl: 'template/7300config/inventoryGroup.html',
            controller: "inventoryGroupCtrl",
            resolve : {
                load : loadJS("7300inventoryGroupModule",['controller/7300config/inventoryGroupCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.7300config.reboot', {
            url: '/reboot',
            templateUrl: 'template/7300config/reboot.html',
            controller: "rebootCtrl",
            resolve : {
                load : loadJS("7300rebootModule",['controller/7300config/rebootCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.7300config.image', {
            url: '/image',
            templateUrl: 'template/7300config/image.html',
            controller: "imageCtrl",
            resolve : {
                load : loadJS("7300imageModule",['controller/7300config/imageCtrl.js'])
            },
            params: {mauto : null}
        })


        .state('index.7300config.outputIRIGTable', {
            url: '/outputIRIGTable',
            templateUrl: 'template/7300config/outputIRIGTable.html',
            controller: "outputIRIGTableCtrl",
            resolve : {
                load : loadJS("7300outputIRIGTableModule",['controller/7300config/outputIRIGTableCtrl.js'])
            },
            params: {mauto : null}
        })
       .state('index.7300config.outputNppsTable', {
            url: '/outputNppsTable',
            templateUrl: 'template/7300config/outputNppsTable.html',
            controller: "outputNppsTableCtrl",
            resolve : {
                load : loadJS("7300outputNppsTableModule",['controller/7300config/outputNppsTableCtrl.js'])
            },
            params: {mauto : null}
        })
 
        .state('index.7300config.outputNTPconfig', {
            url: '/outputNTPconfig',
            templateUrl: 'template/7300config/outputNTPntpWhitelistTable.html',
            controller: "outputNTPntpWhitelistTableCtrl",
            resolve : {
                load : loadJS("7300outputNTPntpWhitelistTableModule",['controller/7300config/outputNTPntpWhitelistTableCtrl.js'])
            }
        })
        
        .state('index.7300config.outputNTPntplistConfigTable', {
            url: '/outputNTPntplistConfigTable',
            templateUrl: 'template/7300config/outputNTPntplistConfigTable.html',
            controller: "outputNTPntplistConfigTableCtrl",
            resolve : {
                load : loadJS("7300outputNTPntplistConfigTableModule",['controller/7300config/outputNTPntplistConfigTableCtrl.js'])
            }
        })
        
        .state('index.7300config.outputNTPntpWhitelistTable', {
            url: '/outputNTPntpWhitelistTable',
            templateUrl: 'template/7300config/outputNTPntpWhitelistTable.html',
            controller: "outputNTPntpWhitelistTableCtrl",
            resolve : {
                load : loadJS("7300outputNTPntpWhitelistTableModule",['controller/7300config/outputNTPntpWhitelistTableCtrl.js'])
            }
        })
        
        .state('index.7300config.outputNTPntpBlacklistTable', {
            url: '/outputNTPntpBlacklistTable',
            templateUrl: 'template/7300config/outputNTPntpBlacklistTable.html',
            controller: "outputNTPntpBlacklistTableCtrl",
            resolve : {
                load : loadJS("7300outputNTPntpBlacklistTableModule",['controller/7300config/outputNTPntpBlacklistTableCtrl.js'])
            }
        })
        .state('index.7300config.outputNTPAuthenticaConfig', {
            url: '/outputNTPAuthenticaConfig',
            templateUrl: 'template/7300config/outputNTPAuthenticaConfig.html',
            controller: "outputNTPAuthenticaConfigCtrl",
            resolve : {
                load : loadJS("7300outputNTPAuthenticaConfigModule",['controller/7300config/outputNTPAuthenticaConfigCtrl.js'])
            }
        })
 
        .state('index.7300config.outputPPSTodTable', {
            url: '/outputPPSTodTable',
            templateUrl: 'template/7300config/outputPPSTodTable.html',
            controller: "outputPPSTodTableCtrl",
            resolve : {
                load : loadJS("7300outputPPSTodTableModule",['controller/7300config/outputPPSTodTableCtrl.js'])
            }
        })
 
        .state('index.7300config.ptpClientTable', {
            url: '/ptpClientTable',
            templateUrl: 'template/7300config/ptpClientTable.html',
            controller: "ptpClientTableCtrl",
            resolve : {
                load : loadJS("7300ptpClientTableModule",['controller/7300config/ptpClientTableCtrl.js'])
            }
        })
 
        .state('index.7300config.ptpCommonTable', {
            url: '/ptpCommonTable',
            templateUrl: 'template/7300config/ptpCommonTable.html',
            controller: "ptpCommonTableCtrl",
            resolve : {
                load : loadJS("7300ptpCommonTableModule",['controller/7300config/ptpCommonTableCtrl.js'])
            }
        })
 
        .state('index.7300config.ptpMulticastTable', {
            url: '/ptpMulticastTable',
            templateUrl: 'template/7300config/ptpMulticastTable.html',
            controller: "ptpMulticastTableCtrl",
            resolve : {
                load : loadJS("7300ptpMulticastTableModule",['controller/7300config/ptpMulticastTableCtrl.js'])
            }
        })
      
 
        .state('index.7300config.PtpStatusTable', {
            url: '/PtpStatusTable',
            templateUrl: 'template/7300config/PtpStatusTable.html',
            controller: "PtpStatusTableconfigCtrl",
            resolve : {
                load : loadJS("7300PtpStatusTableModule",['controller/7300config/PtpStatusTableconfigCtrl.js'])
            }
        })
      
 
        .state('index.7300config.ptpUnicastClientTable', {
            url: '/ptpUnicastClientTable',
            templateUrl: 'template/7300config/ptpUnicastClientTable.html',
            controller: "ptpUnicastClientTableCtrl",
            resolve : {
                load : loadJS("7300ptpUnicastClientTableModule",['controller/7300config/ptpUnicastClientTableCtrl.js'])
            }
        })
 

      
}]);
