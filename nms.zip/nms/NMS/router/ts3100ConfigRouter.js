routerApp.config(['$stateProvider', '$urlRouterProvider', function($stateProvider, $urlRouterProvider) {
    $stateProvider
    .state('index.STFS1000Cofing', {//STFS1000配置
        url: '/STFS1000Cofing',
        views: {
            'center@index': {
                templateUrl: 'template/center.html'
            }
        }
    })
    .state('index.STFS1000Cofing.STFS1000C', {
        url: '/STFS1000C',
        templateUrl: 'template/STFS1000Config/STFS1000C.html',
        controller: "STFS1000CCtrl",
        params: {router : 'STFS1000', title:'STFS1000配置'},
        resolve: {
            load : loadJS("STFS1000Module",['controller/STFS1000Config/STFS1000CCtrl.js'])
        }
    })
     
    

    
    .state('index.GNSS97Config', {//GNSS97配置
        url: '/GNSS97Cofing',
        views: {
            'center@index': {
                templateUrl: 'template/center.html'
            }
        }
    })
    .state('index.GNSS97Config.GNSS97C', {
        url: '/GNSS97C',
        templateUrl: 'template/GNSS97Config/GNSS97Config.html',
        controller: "GNSS97CCtrl",
        params: {router : 'GNSS97', title:'GNSS97配置'},
        resolve: {
            load : loadJS("GNSS97CModule",['controller/GNSS97Config/GNSS97CCtrl.js'])
        }
    })
    
    .state('index.tp1000Config', {//tp1000配置
        url: '/tp1000Config',
        views: {
            'center@index': {
                templateUrl: 'template/center.html'
            }
        },
        params: {
           mauto : null,
            deviceData : null
        }
    })
    .state('index.tp1000Config.tp1000OutputCard', {
        url: '/tp1000OutputCard',
        templateUrl: 'template/tp1000Config/tp1000OutputCard.html',
        controller: "tp1000OutputCardCtrl",
        params: {
           mauto : null,
            deviceData : null
        },
        resolve: {
            load : loadJS("tp1000OutputCardModule",['controller/tp1000Config/tp1000OutputCardCtrl.js'])
        }
    })
    .state('index.tp1000Config.tp1000InputCard', {
        url: '/tp1000InputCard',
        templateUrl: 'template/tp1000Config/tp1000InputCard.html',
        controller: "tp1000InputCardCtrl",
        params: {
           mauto : null,
            deviceData : null
        },
        resolve: {
            load : loadJS("tp1000InputCardModule",['controller/tp1000Config/tp1000InputCardCtrl.js'])
        }
    })
    .state('index.tp1000Config.tp1000Alarmtable', {
        url: '/tp1000Alarmtable',
        templateUrl: 'template/tp1000Config/tp1000Alarmtable.html',
        controller: "tp1000AlarmtableCtrl",
        params: {
           mauto : null,
            deviceData : null
        },
        resolve: {
            load : loadJS("tp1000AlarmtableModule",['controller/tp1000Config/tp1000AlarmtableCtrl.js'])
        }
    })
    .state('index.tp1000Config.outa', {
        url: '/outa',
        templateUrl: 'template/tp1000Config/outa.html',
        controller: "outaCtrl",
        params: {
           mauto : null,
            deviceData : null
        },
        resolve: {
            load : loadJS("outaModule",['controller/tp1000Config/outaCtrl.js'])
        }
    })
    .state('index.tp1000Config.rtma', {
        url: '/rtma',
        templateUrl: 'template/tp1000Config/TRMA.html',
        controller: "rtmaCtrl",
        params: {
           mauto : null,
            deviceData : null
        },
        resolve: {
            load : loadJS("rtmaModule",['controller/tp1000Config/rtmaCtrl.js'])
        }
    })
    .state('index.tp1000Config.e422', {
        url: '/e422',
        templateUrl: 'template/tp1000Config/e422.html',
        controller: "e422Ctrl",
        params: {
           mauto : null,
            deviceData : null
        },
        resolve: {
            load : loadJS("e422Module",['controller/tp1000Config/e422Ctrl.js'])
        }
    })
    .state('index.tp1000Config.tp1000ntp', {
        url: '/tp1000ntp',
        templateUrl: 'template/tp1000Config/tp1000ntp.html',
        controller: "tp1000ntpCtrl",
        params: {
           mauto : null,
            deviceData : null
        },
        resolve: {
            load : loadJS("tp1000ntpModule",['controller/tp1000Config/tp1000ntpCtrl.js'])
        }
    })
    .state('index.tp1000Config.gps', {
        url: '/gps',
        templateUrl: 'template/tp1000Config/gps.html',
        controller: "gpsCtrl",
        params: {
           mauto : null,
            deviceData : null
        },
        resolve: {
            load : loadJS("gpsModule",['controller/tp1000Config/gpsCtrl.js'])
        }
    })
    .state('index.tp1000Config.prs', {
        url: '/prs',
        templateUrl: 'template/tp1000Config/prs.html',
        controller: "prsCtrl",
        params: {
           mauto : null,
            deviceData : null
        },
        resolve: {
            load : loadJS("prsModule",['controller/tp1000Config/prsCtrl.js'])
        }
    })
    .state('index.tp1000Config.inpList', {
        url: '/inpList',
        templateUrl: 'template/tp1000Config/inpList.html',
        controller: "inpListCtrl",
        params: {
           mauto : null,
            deviceData : null
        },
        resolve: {
            load : loadJS("inpListModule",['controller/tp1000Config/inpListCtrl.js'])
        }
    })
    .state('index.tp1000Config.ccCard', {
        url: '/ccCard',
        templateUrl: 'template/tp1000Config/ccCard.html',
        controller: "ccCardCtrl",
        params: {
           mauto : null,
        deviceData : null
        },
        resolve: {
            load : loadJS("ccCardModule",['controller/tp1000Config/ccCardCtrl.js'])
        }
    })
    .state('index.tp1000Config.ccCard2', {
        url: '/ccCard2',
        templateUrl: 'template/tp1000Config/ccCard.html',
        controller: "ccCardCtrl",
        params: {
           mauto : null,
            deviceData : null
        },
        resolve: {
            load : loadJS("ccCardModule",['controller/tp1000Config/ccCardCtrl.js'])
        }
    })
    .state('index.tp1000Config.mcCard', {
        url: '/mcCard',
        templateUrl: 'template/tp1000Config/mcCard.html',
        controller: "mcCardCtrl",
        params: {
           mauto : null,
            deviceData : null
        },
        resolve: {
            load : loadJS("mcCardModule",['controller/tp1000Config/mcCardCtrl.js'])
        }
    })



    .state('index.hp55400Config', {//HP55400配置
        url: '/hp55400Config',
        views: {
            'center@index': {
                templateUrl: 'template/center.html'
            }
        }
    })
    .state('index.hp55400Config.tongyi', {
        url: '/tongyi',
        templateUrl: 'template/hp55400Config/hp55400C.html',
        controller: "hp55400CCtrl",
        params: {
           mauto : null,
            deviceData : null
        },
        resolve: {
            load : loadJS("hp55400CModule",['controller/hp55400Config/hp55400CCtrl.js'])
        }
    })
    .state('index.hp55400Config.hp55400C', {
        url: '/hp55400C',
        templateUrl: 'template/hp55400Config/hp55400OutputCard.html',
        controller: "hp55400OutputCardCtrl",
        params: {
           mauto : null,
            deviceData : null
        },
        resolve: {
            load : loadJS("hp55400OutputCardModule",['controller/hp55400Config/hp55400OutputCardCtrl.js'])
        }
    })
    .state('index.hp55400Config.hp55400mcCard', {
        url: '/hp55400mcCard',
        templateUrl: 'template/hp55400Config/hp55400mcCard.html',
        controller: "hp55400mcCardCtrl",
        params: {
           mauto : null,
            deviceData : null
        },
        resolve: {
            load : loadJS("hp55400mcCardModule",['controller/hp55400Config/hp55400mcCardCtrl.js'])
        }
    })
    .state('index.hp55400Config.hp55400ccCard', {
        url: '/hp55400ccCard',
        templateUrl: 'template/hp55400Config/hp55400ccCard.html',
        controller: "hp55400ccCardCtrl",
        params: {
           mauto : null,
        deviceData : null
        },
        resolve: {
            load : loadJS("hp55400ccCardModule",['controller/hp55400Config/hp55400ccCardCtrl.js'])
        }
    })
    .state('index.hp55400Config.hp55400outa', {
        url: '/hp55400outa',
        templateUrl: 'template/hp55400Config/hp55400outa.html',
        controller: "hp55400outaCtrl",
        params: {
           mauto : null,
            deviceData : null
        },
        resolve: {
            load : loadJS("hp55400outaModule",['controller/hp55400Config/hp55400outaCtrl.js'])
        }
    })
    .state('index.hp55400Config.hp55400Alarmtable', {
        url: '/hp55400Alarmtable',
        templateUrl: 'template/hp55400Config/hp55400Alarmtable.html',
        controller: "hp55400AlarmtableCtrl",
        resolve: {
            load : loadJS("hp55400AlarmtableModule",['controller/hp55400Config/hp55400AlarmtableCtrl.js'])
        }
    })
    .state('index.hp55400Config.hp55400Alarmset', {
        url: '/hp55400Alarmset',
        templateUrl: 'template/hp55400Config/hp55400Alarmset.html',
        controller: "hp55400AlarmsetCtrl",
        resolve: {
            load : loadJS("hp55400AlarmsetModule",['controller/hp55400Config/hp55400AlarmsetCtrl.js'])
        }
    })
    .state('index.hp55400Config.hp55400ithPort', {
        url: '/hp55400ithPort',
        templateUrl: 'template/hp55400Config/hp55400ithPort.html',
        controller: "hp55400ithPortCtrl",
        resolve: {
            load : loadJS("hp55400ithPortModule",['controller/hp55400Config/hp55400ithPortCtrl.js'])
        }
    })
    .state('index.hp55400Config.hp55400outPort', {
        url: '/hp55400outPort',
        templateUrl: 'template/hp55400Config/hp55400outPort.html',
        controller: "hp55400outPortCtrl",
        resolve: {
            load : loadJS("hp55400outPortModule",['controller/hp55400Config/hp55400outPortCtrl.js'])
        }
    })

    .state('index.ts3100Cofing', {
        url: '/ts3100Cofing',
        views: {
            'center@index': {
                templateUrl: 'template/center.html'
            }
        }
    })

    .state('index.ts3100Cofing.ts3100C', {
        url: '/ts3100C',
        templateUrl: 'template/ts3100Config/ts3100C.html',
        controller: "ts3100CCtrl",
        params: {router : 'TS3100',title:'TS3100配置'},
        resolve: {
            load : loadJS("ts3100CModule",['controller/ts3100Config/ts3100CCtrl.js'])
        }
    })
    
    .state('index.ts3100Cofing.ts3100mcCard', {//安全
        url: '/ts3100mcCard',
        templateUrl: 'template/ts3100Config/ts3100mcCard.html',
        controller : "ts3100mcCardCtrl",
        resolve: {
            load : loadJS("ts3100mcCardCtrlModule",['controller/ts3100Config/ts3100mcCardCtrl.js'])
        },
        params: {
           mauto : null,
            deviceData : null
        }
    })
    
    .state('index.ts3100Cofing.ts3100GPSCard', {//安全
        url: '/ts3100GPSCard',
        templateUrl: 'template/ts3100Config/ts3100GPSCard.html',
        controller : "ts3100GPSCardCtrl",
        resolve: {
            load : loadJS("ts3100GPSCardCtrlModule",['controller/ts3100Config/ts3100GPSCardCtrl.js'])
        },
        params: {
           mauto : null,
            deviceData : null
        }
    })
    
    .state('index.ts3100Cofing.ts3100Output', {//安全
        url: '/ts3100Output',
        templateUrl: 'template/ts3100Config/ts3100Output.html',
        controller : "ts3100OutputCtrl",
        resolve: {
            load : loadJS("ts3100OutputCtrlModule",['controller/ts3100Config/ts3100OutputCtrl.js'])
        },
        params: {
           mauto : null,
            deviceData : null
        }
    })
    
    .state('index.ts3100Cofing.ts3100SPANA', {//安全
        url: '/ts3100SPANA',
        templateUrl: 'template/ts3100Config/ts3100SPANA.html',
        controller : "ts3100SPANACtrl",
        resolve: {
            load : loadJS("ts3100SPANACtrlModule",['controller/ts3100Config/ts3100SPANACtrl.js'])
        },
        params: {
           mauto : null,
            deviceData : null
        }
    })
    
    .state('index.ts3100Cofing.ts3100SPANB', {//安全
        url: '/ts3100SPANB',
        templateUrl: 'template/ts3100Config/ts3100SPANB.html',
        controller : "ts3100SPANBCtrl",
        resolve: {
            load : loadJS("ts3100SPANBCtrlModule",['controller/ts3100Config/ts3100SPANBCtrl.js'])
        },
        params: {
           mauto : null,
            deviceData : null
        }
    })
    
    .state('index.ts3100Cofing.ts3100T1A', {//安全
        url: '/ts3100T1A',
        templateUrl: 'template/ts3100Config/ts3100T1A.html',
        controller : "ts3100T1ACtrl",
        resolve: {
            load : loadJS("ts3100T1ACtrlModule",['controller/ts3100Config/ts3100T1ACtrl.js'])
        },
        params: {
           mauto : null,
            deviceData : null
        }
    })
    
    .state('index.ts3100Cofing.ts3100T1B', {//安全
        url: '/ts3100T1B',
        templateUrl: 'template/ts3100Config/ts3100T1B.html',
        controller : "ts3100T1BCtrl",
        resolve: {
            load : loadJS("ts3100T1BCtrlModule",['controller/ts3100Config/ts3100T1BCtrl.js'])
        },
        params: {
           mauto : null,
            deviceData : null
        }
    })
    .state('index.ts3100Cofing.ts3100Alarmset', {
        url: '/ts3100Alarmset',
        templateUrl: 'template/ts3100Config/ts3100Alarmset.html',
        controller: "ts3100AlarmsetCtrl",
        resolve: {
            load : loadJS("ts3100AlarmsetModule",['controller/ts3100Config/ts3100AlarmsetCtrl.js'])
        }
    })
    
    .state('index.SYNLOCKConfig', {//SYNLOCK配置
        url: '/SYNLOCKConfig',
        views: {
            'center@index': {
                templateUrl: 'template/center.html'
            }
        }
    })
    .state('index.SYNLOCKConfig.SYNLOCKOutputCard', {
        url: '/SYNLOCKOutputCard',
        templateUrl: 'template/SYNLOCKConfig/SYNLOCKOutputCard.html',
        controller: "SYNLOCKOutputCardCtrl",
        params: {router : 'SYNLOCK', title:'SYNLOCK配置'},
        resolve: {
            load : loadJS("SYNLOCKOutputCardModule",['controller/SYNLOCKConfig/SYNLOCKOutputCardCtrl.js'])
        }
    })
    .state('index.SYNLOCKConfig.IMCConfig', {
        url: '/IMCConfig',
        templateUrl: 'template/SYNLOCKConfig/IMCConfig.html',
        controller: "IMCConfigCtrl",
        params: {router : 'SYNLOCK', title:'系统参数'},
        resolve: {
            load : loadJS("IMCConfigModule",['controller/SYNLOCKConfig/IMCConfigCtrl.js'])
        }
    })
    .state('index.SYNLOCKConfig.RBDConfig', {
        url: '/RBDConfig',
        templateUrl: 'template/SYNLOCKConfig/RBDConfig.html',
        controller: "RBDConfigCtrl",
        params: {router : 'SYNLOCK', title:'系统参数'},
        resolve: {
            load : loadJS("RBDConfigModule",['controller/SYNLOCKConfig/RBDConfigCtrl.js'])
        }
    })
    .state('index.SYNLOCKConfig.LCIConfig', {
        url: '/LCIConfig',
        templateUrl: 'template/SYNLOCKConfig/LCIConfig.html',
        controller: "LCIConfigCtrl",
        params: {router : 'SYNLOCK', title:'系统参数'},
        resolve: {
            load : loadJS("LCIConfigModule",['controller/SYNLOCKConfig/LCIConfigCtrl.js'])
        }
    })
    .state('index.SYNLOCKConfig.FSYConfig', {
        url: '/FSYConfig',
        templateUrl: 'template/SYNLOCKConfig/FSYConfig.html',
        controller: "FSYConfigCtrl",
        params: {router : 'SYNLOCK', title:'系统参数'},
        resolve: {
            load : loadJS("FSYConfigModule",['controller/SYNLOCKConfig/FSYConfigCtrl.js'])
        }
    })

    .state('index.SYNLOCKConfig.TIAConfig', {
        url: '/TIAConfig',
        templateUrl: 'template/SYNLOCKConfig/TIAConfig.html',
        controller: "TIAConfigCtrl",
        params: {router : 'SYNLOCK', title:'系统参数'},
        resolve: {
            load : loadJS("TIAConfigModule",['controller/SYNLOCKConfig/TIAConfigCtrl.js'])
        }
    })

    .state('index.SYNLOCKConfig.TOAConfig', {
        url: '/TOAConfig',
        templateUrl: 'template/SYNLOCKConfig/TOAConfig.html',
        controller: "TOAConfigCtrl",
        params: {router : 'SYNLOCK', title:'系统参数'},
        resolve: {
            load : loadJS("TOAConfigModule",['controller/SYNLOCKConfig/TOAConfigCtrl.js'])
        }
    })

    .state('index.SYNLOCKConfig.TOEConfig', {
        url: '/TOEConfig',
        templateUrl: 'template/SYNLOCKConfig/TOEConfig.html',
        controller: "TOEConfigCtrl",
        params: {router : 'SYNLOCK', title:'系统参数'},
        resolve: {
            load : loadJS("TOEConfigModule",['controller/SYNLOCKConfig/TOEConfigCtrl.js'])
        }
    })

    .state('index.SYNLOCKConfig.TOGConfig', {
        url: '/TOGConfig',
        templateUrl: 'template/SYNLOCKConfig/TOGConfig.html',
        controller: "TOGConfigCtrl",
        params: {router : 'SYNLOCK', title:'系统参数'},
        resolve: {
            load : loadJS("TOGConfigModule",['controller/SYNLOCKConfig/TOGConfigCtrl.js'])
        }
    })

    .state('index.SYNLOCKConfig.LANConfig', {
        url: '/LANConfig',
        templateUrl: 'template/SYNLOCKConfig/LANConfig.html',
        controller: "LANConfigCtrl",
        params: {router : 'SYNLOCK', title:'系统参数'},
        resolve: {
            load : loadJS("LANConfigModule",['controller/SYNLOCKConfig/LANConfigCtrl.js'])
        }
    })

    .state('index.SYNLOCKConfig.SYSConfig', {
        url: '/SYSConfig',
        templateUrl: 'template/SYNLOCKConfig/SYSConfig.html',
        controller: "SYSConfigCtrl",
        params: {router : 'SYNLOCK', title:'系统参数'},
        resolve: {
            load : loadJS("SYSConfigModule",['controller/SYNLOCKConfig/SYSConfigCtrl.js'])
        }
    })

    .state('index.SYNLOCKConfig.BGPRConfig', {
        url: '/BGPRConfig',
        templateUrl: 'template/SYNLOCKConfig/BGPRConfig.html',
        controller: "BGPRConfigCtrl",
        params: {router : 'SYNLOCK', title:'系统参数'},
        resolve: {
            load : loadJS("BGPRConfigModule",['controller/SYNLOCKConfig/BGPRConfigCtrl.js'])
        }
    })

    .state('index.SYNLOCKConfig.BDSSRConfig', {
        url: '/BDSSRConfig',
        templateUrl: 'template/SYNLOCKConfig/BDSSRConfig.html',
        controller: "BDSSRConfigCtrl",
        params: {router : 'SYNLOCK', title:'系统参数'},
        resolve: {
            load : loadJS("BDSSRConfigModule",['controller/SYNLOCKConfig/BDSSRConfigCtrl.js'])
        }
    })


}]);



