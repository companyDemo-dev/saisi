routerApp.config(['$stateProvider', '$urlRouterProvider', function($stateProvider, $urlRouterProvider) {
    $stateProvider
        .state('index.sm2000GNconfig', {
            url: '/sm2000GN',
            views: {
                'center@index': {
                    templateUrl: 'template/center.html'
                }
            }
        })

    .state('index.sm2000GNconfig.alarmModle', {
        url: '/alarmModle',
        templateUrl: 'template/sm2000GNconfig/alarmModle.html',
        controller: "alarmModlegnCtrl",
        params: {
            mauto: null
        },
        resolve: {
            load : loadJS("sm2000GNalarmModlegnModule",['controller/sm2000GNconfig/alarmModleCtrl.js'])
        }
    })

    .state('index.sm2000GNconfig.alarmModleSub', {
        url: '/alarmModleSub',
        templateUrl: 'template/sm2000GNconfig/alarmModleSub.html',
        controller: "alarmStatusgnTablegnCtrl",
        params: {
            mauto: null
        },
        resolve: {
            load : loadJS("sm2000GNalarmStatusgnTablegnModule",['controller/sm2000GNconfig/alarmModleSubCtrl.js'])
        }
    })



    .state('index.sm2000GNconfig.IPETH', {
        url: '/IPETH',
        templateUrl: 'template/sm2000GNconfig/IPETH.html',
        controller: "IPETHgnCtrl",
        params: {
            mauto: null
        },
        resolve: {
            load : loadJS("sm2000GNIPETHgnModule",['controller/sm2000GNconfig/IPETHCtrl.js'])
        }
    })

    .state('index.sm2000GNconfig.vlan', {
        url: '/vlan',
        templateUrl: 'template/sm2000GNconfig/vlan.html',
        controller: "vlangnCtrl",
        params: {
            mauto: null
        },
        resolve: {
            load : loadJS("sm2000GNvlangnModule",['controller/sm2000GNconfig/vlanCtrl.js'])
        }
    })

    .state('index.sm2000GNconfig.ntpconfig', {
        url: '/ntpconfig',
        templateUrl: 'template/sm2000GNconfig/ntpconfig.html',
        controller: "ntpconfiggnCtrl",
        params: {
            mauto: null
        },
        resolve: {
            load : loadJS("sm2000GNntpconfiggnModule",['controller/sm2000GNconfig/ntpconfigCtrl.js'])
        }
    })
    .state('index.sm2000GNconfig.ntpprobe', {
        url: '/ntpprobe',
        templateUrl: 'template/sm2000GNconfig/ntpprobe.html',
        controller: "ntpprobegnCtrl",
        params: {
            mauto: null
        },
        resolve: {
            load : loadJS("sm2000GNntpprobegnModule",['controller/sm2000GNconfig/ntpprobeCtrl.js'])
        }
    })

    .state('index.sm2000GNconfig.ntpstatus', {
        url: '/ntpstatus',
        templateUrl: 'template/sm2000GNconfig/ntpstatus.html',
        controller: "ntpstatusgnCtrl",
        params: {
            mauto: null
        },
        resolve: {
            load : loadJS("sm2000GNntpstatusgnModule",['controller/sm2000GNconfig/ntpstatusCtrl.js'])
        }
    })

    .state('index.sm2000GNconfig.ptpProbe', {
        url: '/ptpProbe',
        templateUrl: 'template/sm2000GNconfig/ptpProbe.html',
        controller: "ptpProbegnCtrl",
        params: {
            mauto: null
        },
        resolve: {
            load : loadJS("sm2000GNptpProbegnModule",['controller/sm2000GNconfig/ptpProbeCtrl.js'])
        }
    })

    .state('index.sm2000GNconfig.ptpMulticast', {
        url: '/ptpMulticast',
        templateUrl: 'template/sm2000GNconfig/ptpMulticast.html',
        controller: "ptpMulticastgnCtrl",
        params: {
            mauto: null
        },
        resolve: {
            load : loadJS("sm2000GNptpMulticastgnModule",['controller/sm2000GNconfig/ptpMulticastCtrl.js'])
        }
    })

    .state('index.sm2000GNconfig.ptpCommon', {
        url: '/ptpCommon',
        templateUrl: 'template/sm2000GNconfig/ptpCommon.html',
        controller: "ptpCommongnCtrl",
        params: {
            mauto: null
        },
        resolve: {
            load : loadJS("sm2000GNptpCommongnModule",['controller/sm2000GNconfig/ptpCommonCtrl.js'])
        }
    })

    .state('index.sm2000GNconfig.ptpUnicastClient', {
        url: '/ptpUnicastClient',
        templateUrl: 'template/sm2000GNconfig/ptpUnicastClient.html',
        controller: "ptpUnicastClientgnCtrl",
        params: {
            mauto: null
        },
        resolve: {
            load : loadJS("sm2000GNptpUnicastClientgnModule",['controller/sm2000GNconfig/ptpUnicastClientCtrl.js'])
        }
    })
    .state('index.sm2000GNconfig.Reference', {
        url: '/Reference',
        templateUrl: 'template/sm2000GNconfig/Reference.html',
        controller: "ReferencegnCtrl",
        params: {
            mauto: null
        },
        resolve: {
            load : loadJS("sm2000GNReferenceModule",['controller/sm2000GNconfig/ReferenceCtrl.js'])
        }
    })
    .state('index.sm2000GNconfig.GNSS1', {
        url: '/GNSS1',
        templateUrl: 'template/sm2000GNconfig/gnss1.html',
        controller: "GNSS1gnCtrl",
        params: {
            mauto: null
        },
        resolve: {
            load : loadJS("sm2000GNGNSS1gnModule",['controller/sm2000GNconfig/gnss1Ctrl.js'])
        }
    })
    .state('index.sm2000GNconfig.GNSS2', {
        url: '/GNSS2',
        templateUrl: 'template/sm2000GNconfig/gnss2.html',
        controller: "GNSS2gnCtrl",
        params: {
            mauto: null
        },
        resolve: {
            load : loadJS("sm2000GNGNSS2gnModule",['controller/sm2000GNconfig/gnss2Ctrl.js'])
        }
    })

    .state('index.sm2000GNconfig.ppstod', {
        url: '/ppstod',
        templateUrl: 'template/sm2000GNconfig/ppstod.html',
        controller: "ppstodgnCtrl",
        params: {
            mauto: null
        },
        resolve: {
            load : loadJS("sm2000GNppstodgnModule",['controller/sm2000GNconfig/ppstodCtrl.js'])
        }
    })
    .state('index.sm2000GNconfig.other', {
        url: '/other',
        templateUrl: 'template/sm2000GNconfig/other.html',
        controller: "othergnCtrl",
        params: {
            mauto: null
        },
        resolve: {
            load : loadJS("sm2000GNothergnModule",['controller/sm2000GNconfig/otherCtrl.js'])
        }
    })
    .state('index.sm2000GNconfig.Reboot', {
        url: '/Reboot',
        templateUrl: 'template/sm2000GNconfig/reboot.html',
        controller: "RebootgnCtrl",
        params: {
            mauto: null
        },
        resolve: {
            load : loadJS("sm2000GNRebootgnModule",['controller/sm2000GNconfig/rebootCtrl.js'])
        }
    })
    .state('index.sm2000GNconfig.Upgrade', {
        url: '/Upgrade',
        templateUrl: 'template/sm2000GNconfig/upgrade.html',
        controller: "UpgradegnCtrl",
        params: {
            mauto: null
        },
        resolve: {
            load : loadJS("sm2000GNUpgradegnModule",['controller/sm2000GNconfig/upgradeCtrl.js'])
        }
    })
    .state('index.sm2000GNconfig.Backup', {
        url: '/Backup',
        templateUrl: 'template/sm2000GNconfig/Backup.html',
        controller: "BackupgnCtrl",
        params: {
            mauto: null
        },
        resolve: {
            load : loadJS("sm2000GNBackupgnModule",['controller/sm2000GNconfig/BackupCtrl.js'])
        }
    })
    .state('index.sm2000GNconfig.image', {
        url: '/image',
        templateUrl: 'template/sm2000GNconfig/image.html',
        controller: "imagegnCtrl",
        params: {
            mauto: null
        },
        resolve: {
            load : loadJS("sm2000GNimagegnModule",['controller/sm2000GNconfig/imageCtrl.js'])
        }
    })
    .state('index.sm2000GNconfig.OutputCard', {
        url: '/OutputCard',
        templateUrl: 'template/sm2000GNconfig/OutputCard.html',
        controller: "OutputCardgnCtrl",
        params: {
            mauto: null
        },
        resolve: {
            load : loadJS("sm2000GNOutputCardgnModule",['controller/sm2000GNconfig/OutputCardCtrl.js'])
        }
    })
    .state('index.sm2000GNconfig.outE12048config', {
        url: '/outE12048config',
        templateUrl: 'template/sm2000GNconfig/outE12048config.html',
        controller: "outE12048configCtrl",
        params: {
            mauto: null
        },
        resolve: {
            load : loadJS("sm2000GNoutE12048configModule",['controller/sm2000GNconfig/outE12048configCtrl.js'])
        }
    })
    .state('index.sm2000GNconfig.outE1config', {
        url: '/outE1configGN',
        templateUrl: 'template/sm2000GNconfig/outE1config.html',
        controller: "outputCardGNE1PConfigCtrl",
        params: {
            mauto: null
        },
        resolve: {
            load : loadJS("sm2000GNoutputCardGNE1PConfigModule",['controller/sm2000GNconfig/outputCardGNE1PConfigCtrl.js'])
        }
    })
    .state('index.sm2000GNconfig.outPPSTODconfig', {
        url: '/outPPSTODconfig',
        templateUrl: 'template/sm2000GNconfig/outPPSTODconfig.html',
        controller: "outputCardGNppstodConfigCtrl",
        params: {
            mauto: null
        },
        resolve: {
            load : loadJS("sm2000GNoutputCardGNppstodConfigModule",['controller/sm2000GNconfig/outputCardppstodConfigCtrl.js'])
        }
    })
    .state('index.sm2000GNconfig.vlanAddEdit', {
        url: '/vlanAddEdit',
        templateUrl: 'template/sm2000GNconfig/vlanAdd.html',
        controller: "vlangnAddgnCtrl",
        params: {
            mauto: null
        },
        resolve: {
            load : loadJS("sm2000GNvlangnAddgnModule",['controller/sm2000GNconfig/vlanAddCtrl.js'])
        }
    })
    .state('index.sm2000GNconfig.inputCard', {
        url: '/inputCard',
        templateUrl: 'template/sm2000GNconfig/inputOutput.html',
        controller: "inputOutputgnCtrl",
        params: {
            mauto: null
        },
        resolve: {
            load : loadJS("sm2000GNinputOutputgnModule",['controller/sm2000GNconfig/inputOutputCtrl.js'])
        }
    })
    .state('index.sm2000GNconfig.systemTime', {
        url: '/systemTime',
        templateUrl: 'template/sm2000GNconfig/systemTime.html',
        controller: "systemTimeCtrl",
        params: {
            mauto: null
        },
        resolve: {
            load : loadJS("sm2000GNsystemTimeModule",['controller/sm2000GNconfig/systemTimeCtrl.js'])
        }
    })
}]);
