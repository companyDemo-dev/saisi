routerApp.config(['$stateProvider', '$urlRouterProvider', function($stateProvider, $urlRouterProvider) {
    $stateProvider
        .state('index.3000Gconfig', {
            url: '/3000Gconfig',
            views: {
                'center@index': {
                    templateUrl: 'template/center.html'
                }
            }
        })
       .state('index.3000Gconfig.ntpPortTable', {
            url: '/ntpPortTable',
            templateUrl: 'template/3000Gconfig/ntpPortTable.html',
            controller: "ntpPortTableCtrl",
            resolve : {
                load : loadJS("3000GntpPortTableModule",['controller/3000Gconfig/ntpPortTableCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.3000Gconfig.ntpSlotTable', {
            url: '/ntpSlotTable',
            templateUrl: 'template/3000Gconfig/ntpSlotTable.html',
            controller: "ntpSlotTableCtrl",
            resolve : {
                load : loadJS("3000GntpSlotTableModule",['controller/3000Gconfig/ntpSlotTableCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.3000Gconfig.ntpSlotshow', {
            url: '/ntpSlotshow',
            templateUrl: 'template/3000Gconfig/ntpSlotshow.html',
            controller: "ntpSlotshowCtrl",
            resolve : {
                load : loadJS("3000GntpSlotshowModule",['controller/3000Gconfig/ntpSlotshowCtrl.js'])
            },
            params: {mauto : null}
        })
       .state('index.3000Gconfig.input', {
            url: '/input',
            templateUrl: 'template/3000Gconfig/input.html',
            controller: "inputCtrl",
            resolve : {
                load : loadJS("3000GinputModule",['controller/3000Gconfig/inputCtrl.js'])
            },
            params: {mauto : null}
        })
       .state('index.3000Gconfig.output', {
            url: '/output',
            templateUrl: 'template/3000Gconfig/output.html',
            controller: "outputCtrl",
            resolve : {
                load : loadJS("3000GoutputModule",['controller/3000Gconfig/outputCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.3000Gconfig.gnss1', {
            url: '/gnss1',
            templateUrl: 'template/3000Gconfig/gnss1.html',
            controller: "gnss1Ctrl",
            resolve : {
                load : loadJS("3000Ggnss1Module",['controller/3000Gconfig/gnss1Ctrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.3000Gconfig.gnss1State', {
            url: '/gnss1State',
            templateUrl: 'template/3000Gconfig/gnss1State.html',
            controller: "gnss1StateCtrl",
            resolve : {
                load : loadJS("3000Ggnss1StateModule",['controller/3000Gconfig/gnss1StateCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.3000Gconfig.gnss1Lite', {
            url: '/gnss1Lite',
            templateUrl: 'template/3000Gconfig/gnss1Lite.html',
            controller: "gnss1LiteCtrl",
            resolve : {
                load : loadJS("3000Ggnss1LiteModule",['controller/3000Gconfig/gnss1LiteCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.3000Gconfig.gnss2', {
            url: '/gnss2',
            templateUrl: 'template/3000Gconfig/gnss2.html',
            controller: "gnss2Ctrl",
            resolve : {
                load : loadJS("3000Ggnss2Module",['controller/3000Gconfig/gnss2Ctrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.3000Gconfig.gnss2State', {
            url: '/gnss2State',
            templateUrl: 'template/3000Gconfig/gnss2State.html',
            controller: "gnss2StateCtrl",
            resolve : {
                load : loadJS("3000Ggnss2StateModule",['controller/3000Gconfig/gnss2StateCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.3000Gconfig.gnss2Lite', {
            url: '/gnss2Lite',
            templateUrl: 'template/3000Gconfig/gnss2Lite.html',
            controller: "gnss2LiteCtrl",
            resolve : {
                load : loadJS("3000Ggnss2LiteModule",['controller/3000Gconfig/gnss2LiteCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.3000Gconfig.alarmConfigTable', {
            url: '/alarmConfigTable',
            templateUrl: 'template/3000Gconfig/alarmConfigTable.html',
            controller: "alarmConfigTableCtrl",
            resolve : {
                load : loadJS("3000GalarmConfigTableModule",['controller/3000Gconfig/alarmConfigTableCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.3000Gconfig.alarmStatusTable', {
            url: '/alarmStatusTable',
            templateUrl: 'template/3000Gconfig/alarmStatusTable.html',
            controller: "alarmStatusTableCtrl",
            resolve : {
                load : loadJS("3000GalarmStatusTableModule",['controller/3000Gconfig/alarmStatusTableCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.3000Gconfig.IPETH', {
            url: '/IPETH',
            templateUrl: 'template/3000Gconfig/IPETH.html',
            controller: "IPETHCtrl",
            resolve : {
                load : loadJS("3000GIPETHModule",['controller/3000Gconfig/IPETHCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.3000Gconfig.inventoryGroup', {
            url: '/inventoryGroup',
            templateUrl: 'template/3000Gconfig/inventoryGroup.html',
            controller: "inventoryGroupCtrl",
            resolve : {
                load : loadJS("3000GinventoryGroupModule",['controller/3000Gconfig/inventoryGroupCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.3000Gconfig.reboot', {
            url: '/reboot',
            templateUrl: 'template/3000Gconfig/reboot.html',
            controller: "rebootCtrl",
            resolve : {
                load : loadJS("3000GrebootModule",['controller/3000Gconfig/rebootCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.3000Gconfig.image', {
            url: '/image',
            templateUrl: 'template/3000Gconfig/image.html',
            controller: "imageCtrl",
            resolve : {
                load : loadJS("3000GimageModule",['controller/3000Gconfig/imageCtrl.js'])
            },
            params: {mauto : null}
        })


        .state('index.3000Gconfig.other', {
            url: '/other',
            templateUrl: 'template/3000Gconfig/other.html',
            controller: "otherCtrl",
            resolve : {
                load : loadJS("3000GotherModule",['controller/3000Gconfig/otherCtrl.js'])
            },
            params: {mauto : null}
        })
       .state('index.3000Gconfig.refStatusTable', {
            url: '/refStatusTable',
            templateUrl: 'template/3000Gconfig/refStatusTable.html',
            controller: "refStatusTableCtrl",
            resolve : {
                load : loadJS("3000GrefStatusTableModule",['controller/3000Gconfig/refStatusTableCtrl.js'])
            },
            params: {mauto : null}
        })
 
        .state('index.3000Gconfig.refConfigTable', {
            url: '/refConfigTable',
            templateUrl: 'template/3000Gconfig/refConfigTable.html',
            controller: "refConfigTableCtrl",
            resolve : {
                load : loadJS("3000GrefConfigTableModule",['controller/3000Gconfig/refConfigTableCtrl.js'])
            }
        })
      
}]);
