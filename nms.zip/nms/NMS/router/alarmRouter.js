routerApp.config(['$stateProvider', '$urlRouterProvider',function($stateProvider, $urlRouterProvider) {
	$stateProvider
    .state('index.alarm', {
        url: '/alarm',
        views: {
            'center@index': {
                templateUrl: 'template/center.html'
            }
        }
    })
    .state('index.alarm.alarmNMS', {//告警
        url: '/alarmNMS',
        templateUrl: 'template/alarm/alarmNMS.html',
        controller : "alarmNMSCtrl",
        resolve: {
            load : loadJS("alarmNMSModule",['controller/alarm/alarmNMSCtrl.js'])
        }
    })
    .state('index.alarm.filter', {//告警过滤
        url: '/filter',
        templateUrl: 'template/alarm/alarmFilter.html',
        controller : "alarmFilterCtrl",
        resolve: {
            deviceInfoData:function(publicService){
                publicService.loading('start');
                return publicService.doRequest("GET", 4, {type : "two"});
            },
            load : loadJS("alarmFilterModule",['controller/alarm/alarmFilterCtrl.js'])
        }
    })
    .state('index.alarm.alarmFilterEditAdd', {//告警过滤
        url: '/alarmFilterEditAdd',
        templateUrl: 'template/alarm/alarmFilterEditAdd.html',
        controller : "alarmFilterEditAddCtrl",
        params: {mauto : null},
        resolve: {
            deviceInfoData:function(publicService){
                publicService.loading('start');
                return publicService.doRequest("GET", 4, {type : "two"});
            },
            load : loadJS("alarmFilterEditAddModule",['controller/alarm/alarmFilterEditAddCtrl.js'])
        }
    })
    .state('index.alarm.alarmRule', {//前转规则
        url: '/alarmRule',
        templateUrl: 'template/alarm/alarmRule.html',
        controller : "alarmRuleCtrl",
        resolve: {
            deviceInfoData:function(publicService){
                publicService.loading('start');
                return publicService.doRequest("GET", 4, {type : "two"});
            },
            load : loadJS("alarmRuleModule",['controller/alarm/alarmRuleCtrl.js'])
        }
    })
    .state('index.alarm.alarmRuleEditAdd', {//告警过滤
        url: '/alarmRuleEditAdd',
        templateUrl: 'template/alarm/alarmRuleEditAdd.html',
        controller : "alarmRuleEditAddCtrl",
        params: {mauto : null},
        resolve: {
            deviceInfoData:function(publicService){
                publicService.loading('start');
                return publicService.doRequest("GET", 4, {type : "two"});
            },
            load : loadJS("alarmRuleEditAddModule",['controller/alarm/alarmRuleEditAddCtrl.js'])
        }
    })
    .state('index.alarm.alarmStatistics', {//告警统计 
        url: '/alarmStatistics',
        templateUrl: 'template/alarm/alarmStatistics.html',
        controller : "alarmStatisticsCtrl",
        resolve: {
            load : loadJS("alarmStatisticsModule",['controller/alarm/alarmStatisticsCtrl.js'])
        }
    })
    .state('index.alarm.alarmTrend', {//告警趋势统计图表 
        url: '/alarmTrend',
        templateUrl: 'template/alarm/alarmTrend.html',
        controller : "alarmTrendCtrl",
        resolve: {
            load : loadJS("alarmTrendModule",['controller/alarm/alarmTrendCtrl.js'])
        }
    })
    
    .state('index.alarm.Tipfilter', {//告警过滤
        url: '/Tipfilter',
        templateUrl: 'template/alarm/alarmTipFilter.html',
        controller : "alarmTipFilterCtrl",
        resolve: {
            load : loadJS("alarmTipFilterModule",['controller/alarm/alarmTipFilterCtrl.js'])
        }
    })
    .state('index.alarm.alarmTipFilterEditAdd', {//告警过滤
        url: '/alarmTipFilterEditAdd',
        templateUrl: 'template/alarm/alarmTipFilterEditAdd.html',
        controller : "alarmTipFilterEditAddCtrl",
        params: {mauto : null},
        resolve: {
            load : loadJS("alarmTipFilterEditAddModule",['controller/alarm/alarmTipFilterEditAddCtrl.js'])
        }
    })
}]);