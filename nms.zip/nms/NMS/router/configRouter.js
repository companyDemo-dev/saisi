routerApp.config(['$stateProvider', '$urlRouterProvider', function($stateProvider, $urlRouterProvider) {
    $stateProvider
        .state('index.config', {
            url: '/config',
            views: {
                'center@index': {
                    templateUrl: 'template/center.html'
                }
            }
        })

    .state('index.config.outputCardConfig', {
        url: '/outputCardConfig',
        templateUrl: 'template/config/outputCardConfiglist.html',
        controller: "outputCardConfigCtrl",
        params: {deviceData : null},
        resolve: {
            configName: function() {
                return 'outputCard'
            },
            load : loadJS("sm2000outputCardConfigModule",['controller/config/outputCardConfigCtrl.js'])
        }
    })

    .state('index.config.outPTPconfig', {
        url: '/outPTPconfig',
        templateUrl: 'template/config/outPTPconfig.html',
        controller: "outputCardPTPConfigCtrl",
        params: {
            mauto : null,
            deviceData : null
        },
        resolve: {
            load : loadJS("sm2000outputCardPTPConfigModule",['controller/config/outputCardPTPConfigCtrl.js'])
        }
    })

    .state('index.config.outE1configtable', {
        url: '/outE1configtable',
        templateUrl: 'template/config/outE1configtable.html',
        controller: "outputCardE1PConfigtableCtrl",
        params: {
           mauto : null,
            deviceData : null
        },
        resolve: {
            load : loadJS("sm2000outputCardE1PConfigtableModule",['controller/config/outputCardE1PConfigtableCtrl.js'])
        }
    })
    .state('index.config.outE1config', {
        url: '/outE1config',
        templateUrl: 'template/config/outE1config.html',
        controller: "outputCardE1PConfigCtrl",
        params: {
           mauto : null,
            deviceData : null
        },
        resolve: {
            load : loadJS("sm2000outputCardE1PConfigModule",['controller/config/outputCardE1PConfigCtrl.js'])
        }
    })
    .state('index.config.outE1Exp1config', {
        url: '/outE1Exp1config',
        templateUrl: 'template/config/outE1Exp1config.html',
        controller: "outE1Exp1config",
        params: {
            mauto : null,
            deviceData : null
        },
        resolve: {
            load : loadJS("sm2000outE1Exp1configModule",['controller/config/outputCardE1pExp1ConfigCtrl.js'])
        }
    })
    .state('index.config.outE1Exp2config', {
        url: '/outE1Exp2config',
        templateUrl: 'template/config/outE1Exp2config.html',
        controller: "outE1Exp2config",
        params: {
            mauto : null,
            deviceData : null
        },
        resolve: {
            load : loadJS("sm2000outE1Exp2configModule",['controller/config/outputCardE1pExp2ConfigCtrl.js'])
        }
    })
    .state('index.config.outE1Exp3config', {
        url: '/outE1Exp3config',
        templateUrl: 'template/config/outE1Exp3config.html',
        controller: "outE1Exp3config",
        params: {
            mauto : null,
            deviceData : null
        },
        resolve: {
            load : loadJS("sm2000outE1Exp3configModule",['controller/config/outputCardE1pExp3ConfigCtrl.js'])
        }
    })
    .state('index.config.outE1Exp4config', {
        url: '/outE1Exp4config',
        templateUrl: 'template/config/outE1Exp4config.html',
        controller: "outE1Exp4config",
        params: {
           mauto : null,
            deviceData : null
        },
        resolve: {
            load : loadJS("sm2000outE1Exp4configModule",['controller/config/outputCardE1pExp4ConfigCtrl.js'])
        }
    })

    .state('index.config.outPPSTODconfig', {
        url: '/outPPSTODconfig',
        templateUrl: 'template/config/outPPSTODconfig.html',
        controller: "outputCardppstodConfigCtrl",
        params: {
           mauto : null,
            deviceData : null
        },
        resolve: {
            load : loadJS("sm2000outputCardppstodConfigModule",['controller/config/outputCardppstodConfigCtrl.js'])
        }
    })

    .state('index.config.outputCardFREQConfig', {
        url: '/outputCardFREQConfig',
        templateUrl: 'template/config/outputCardFREQConfig.html',
        controller: "outputCardFREQConfigCtrl",
        params: {
            devid: null,
            slot : null,
            exp  : null,
            deviceData : null
        },
        resolve: {
            load : loadJS("sm2000outputCardFREQConfigModule",['controller/config/outputCardFREQConfigCtrl.js'])
        }
    })

    .state('index.config.outputCardFREQExp1Config', {
        url: '/outputCardFREQExp1Config',
        templateUrl: 'template/config/outputCardFREQExp1Config.html',
        controller: "outputCardFREQExp1ConfigCtrl",
        params: {
            devid: null,
            slot : null,
            exp  : null,
            deviceData : null
        },
        resolve: {
            load : loadJS("sm2000outputCardFREQExp1ConfigModule",['controller/config/outputCardFREQExp1ConfigCtrl.js'])
        }
    })

    .state('index.config.outputCardFREQExp2Config', {
        url: '/outputCardFREQExp2Config',
        templateUrl: 'template/config/outputCardFREQExp2Config.html',
        controller: "outputCardFREQExp2ConfigCtrl",
        params: {
            devid: null,
            slot : null,
            exp  : null,
            deviceData : null
        },
        resolve: {
            load : loadJS("sm2000outputCardFREQExp2ConfigModule",['controller/config/outputCardFREQExp2ConfigCtrl.js'])
        }
    })

    .state('index.config.outputCardFREQExp3Config', {
        url: '/outputCardFREQExp3Config',
        templateUrl: 'template/config/outputCardFREQExp3Config.html',
        controller: "outputCardFREQExp3ConfigCtrl",
        params: {
            devid: null,
            slot : null,
            exp  : null,
            deviceData : null
        },
        resolve: {
            load : loadJS("sm2000outputCardFREQExp3ConfigModule",['controller/config/outputCardFREQExp3ConfigCtrl.js'])
        }
    })

    .state('index.config.outputCardFREQExp4Config', {
        url: '/outputCardFREQExp4Config',
        templateUrl: 'template/config/outputCardFREQExp4Config.html',
        controller: "outputCardFREQExp4ConfigCtrl",
        params: {
            devid: null,
            slot : null,
            exp  : null,
            deviceData : null
        },
        resolve: {
            load : loadJS("sm2000outputCardFREQExp4ConfigModule",['controller/config/outputCardFREQExp4ConfigCtrl.js'])
        }
    })
    .state('index.config.gnss1', {
        url: '/gnss',
        templateUrl: 'template/config/gnss1.html',
        controller: "outputCardConfigCtrl",
        resolve: {
            configName: function() {
                return 'gnss1'
            },
            load : loadJS("sm2000outputCardConfigModule",['controller/config/outputCardConfigCtrl.js'])

        }
    })
    .state('index.config.gnss2', {
        url: '/gnss2',
        templateUrl: 'template/config/gnss2.html',
        controller: "outputCardConfigCtrl",
        resolve: {
            configName: function() {
                return 'gnss2'
            },
            load : loadJS("sm2000outputCardConfigModule",['controller/config/outputCardConfigCtrl.js'])
        }
    })

    .state('index.config.ppsTod1', {
        url: '/ppsTod1',
        templateUrl: 'template/config/ppsTod1.html',
        controller: "outputCardConfigCtrl",
        resolve: {
            configName: function() {
                return 'ppsTod1'
            },
            load : loadJS("sm2000outputCardConfigModule",['controller/config/outputCardConfigCtrl.js'])
        }
    })

    .state('index.config.ppsTod2', {
        url: '/ppsTod2',
        templateUrl: 'template/config/ppsTod2.html',
        controller: "outputCardConfigCtrl",
        resolve: {
            configName: function() {
                return 'ppsTod2'
            },
            load : loadJS("sm2000outputCardConfigModule",['controller/config/outputCardConfigCtrl.js'])
        }
    })

    .state('index.config.e1', {
        url: '/e1',
        templateUrl: 'template/config/e1.html',
        controller: "outputCardConfigCtrl",
        resolve: {
            configName: function() {
                return 'e1'
            },
            load : loadJS("sm2000outputCardConfigModule",['controller/config/outputCardConfigCtrl.js'])
        }
    })

    .state('index.config.otherOutput', {
        url: '/otherOutput',
        templateUrl: 'template/config/otherOutput.html',
        controller: "outputCardConfigCtrl",
        resolve: {
            configName: function() {
                return 'otherOutput'
            },
            load : loadJS("sm2000outputCardConfigModule",['controller/config/outputCardConfigCtrl.js'])
        }
    })

    .state('index.config.ntp', {
        url: '/ntp',
        templateUrl: 'template/config/ntp.html',
        controller: "outputCardConfigCtrl",
        resolve: {
            configName: function() {
                return 'ntp'
            },
            load : loadJS("sm2000outputCardConfigModule",['controller/config/outputCardConfigCtrl.js'])
        }
    })

    .state('index.config.ntpProbe', {
        url: '/ntpProbe',
        templateUrl: 'template/config/ntpProbe.html',
        controller: "outputCardConfigCtrl",
        resolve: {
            configName: function() {
                return 'ntpProbe'
            },
            load : loadJS("sm2000outputCardConfigModule",['controller/config/outputCardConfigCtrl.js'])
        }
    })

    .state('index.config.ntpStatus', {
        url: '/ntpStatus',
        templateUrl: 'template/config/ntpStatus.html',
        controller: "outputCardConfigCtrl",
        resolve: {
            configName: function() {
                return 'ntpStatus'
            },
            load : loadJS("sm2000outputCardConfigModule",['controller/config/outputCardConfigCtrl.js'])
        }
    })

    .state('index.config.zptpCommon', {
        url: '/zptpCommon',
        templateUrl: 'template/config/zptpCommon.html',
        controller: "outputCardConfigCtrl",
        resolve: {
            configName: function() {
                return 'zptpCommon'
            },
            load : loadJS("sm2000outputCardConfigModule",['controller/config/outputCardConfigCtrl.js'])
        }
    })

    .state('index.config.zptpMulticast', {
        url: '/zptpMulticast',
        templateUrl: 'template/config/zptpMulticast.html',
        controller: "outputCardConfigCtrl",
        resolve: {
            configName: function() {
                return 'zptpMulticast'
            },
            load : loadJS("sm2000outputCardConfigModule",['controller/config/outputCardConfigCtrl.js'])
        }
    })

    .state('index.config.zUnicastClinet', {
        url: '/zUnicastClinet',
        templateUrl: 'template/config/zUnicastClinet.html',
        controller: "outputCardConfigCtrl",
        resolve: {
            configName: function() {
                return 'zUnicastClinet'
            },
            load : loadJS("sm2000outputCardConfigModule",['controller/config/outputCardConfigCtrl.js'])
        }
    })

    .state('index.config.zptpProbe', {
        url: '/zptpProbe',
        templateUrl: 'template/config/zptpProbe.html',
        controller: "outputCardConfigCtrl",
        resolve: {
            configName: function() {
                return 'zptpProbe'
            },
            load : loadJS("sm2000outputCardConfigModule",['controller/config/outputCardConfigCtrl.js'])
        }
    })

    .state('index.config.alarmModle', {
        url: '/alarmModle',
        templateUrl: 'template/config/alarmModle.html',
        controller: "outputCardConfigCtrl",
        resolve: {
            configName: function() {
                return 'alarmModle'
            },
            load : loadJS("sm2000outputCardConfigModule",['controller/config/outputCardConfigCtrl.js'])
        }
    })

    .state('index.config.alarmthreshold', {
        url: '/alarmthreshold',
        templateUrl: 'template/config/alarmthreshold.html',
        controller: "alarmthresholdCtrl",
        resolve: {
            load : loadJS("alarmthresholdModule",['controller/config/alarmthresholdCtrl.js'])
        }
    })

    .state('index.config.alarmModleSub', {
        url: '/alarmModleSub',
        templateUrl: 'template/config/alarmModleSub.html',
        controller: "outputCardConfigCtrl",
        resolve: {
            configName: function() {
                return 'alarmModleSub'
            },
            load : loadJS("sm2000outputCardConfigModule",['controller/config/outputCardConfigCtrl.js'])
        }
    })

    .state('index.config.IPETH', {
        url: '/IPETH',
        templateUrl: 'template/config/IPETH.html',
        controller: "outputCardConfigCtrl",
        resolve: {
            configName: function() {
                return 'IPETH'
            },
            load : loadJS("sm2000outputCardConfigModule",['controller/config/outputCardConfigCtrl.js'])
        }
    })

    .state('index.config.vlan', {
        url: '/vlan',
        templateUrl: 'template/config/vlan.html',
        controller: "outputCardConfigCtrl",
        resolve: {
            configName: function() {
                return 'vlan'
            },
            load : loadJS("sm2000outputCardConfigModule",['controller/config/outputCardConfigCtrl.js'])
        }
    })

    .state('index.config.vlanAddEdit', {
        url: '/vlanAddEdit',
        templateUrl: 'template/config/vlanAdd.html',
        controller: "vlanAddCtrl",
        params: {
            mauto: null
        },
        resolve: {
            load : loadJS("sm2000vlanAddModule",['controller/config/vlanAddCtrl.js'])
        }
    })
    .state('index.config.reboot', {
        url: '/reboot',
        templateUrl: 'template/config/reboot.html',
        controller: "outputCardConfigCtrl",
        resolve: {
            configName: function() {
                return 'reboot'
            },
            load : loadJS("sm2000outputCardConfigModule",['controller/config/outputCardConfigCtrl.js'])
        }
    })

    .state('index.config.zSet', {
        url: '/zSet',
        templateUrl: 'template/config/zSet.html',
        controller: "outputCardConfigCtrl",
        resolve: {
            configName: function() {
                return 'zSet'
            },
            load : loadJS("sm2000outputCardConfigModule",['controller/config/outputCardConfigCtrl.js'])
        }
    })

    .state('index.config.inventoryInfo', {
        url: '/inventoryInfo',
        templateUrl: 'template/config/inventoryInfo.html',
        controller: "outputCardConfigCtrl",
        resolve: {
            configName: function() {
                return 'inventoryInfo'
            },
            load : loadJS("sm2000outputCardConfigModule",['controller/config/outputCardConfigCtrl.js'])
        }
    })

    .state('index.config.imageInfo', { //地图管理
        url: '/imageInfo',
        templateUrl: 'template/config/imageInfo.html',
        controller: "imageInfoCtrl",
        resolve: {
            load : loadJS("sm2000imageInfoModule",['controller/config/imageInfoCtrl.js'])
        }
    })
    
    .state('index.config.backupConfig', {
        url: '/backupConfig',
        templateUrl: 'template/device/backupConfig.html',
        controller : "backupConfigCtrl",
        resolve: {
            load : loadJS("backupConfigModule",['controller/device/backupConfigCtrl.js'])
        }
    })
    .state('index.config.upgradeCmd', {
        url: '/upgradeCmd',
        templateUrl: 'template/device/upgradeCmd.html',
        controller : "upgradeCmdCtrl",
        resolve: {
            load : loadJS("upgradeCmdModule",['controller/device/upgradeCmdCtrl.js'])
        }
    })

    .state('index.config.inputPtp', {
        url: '/inputPtp',
        templateUrl: 'template/config/inputPtp/inputPtp.html',
        controller : "inputPtpCtrl",
        params: {
            devid: null,
            slot : null,
            deviceData : null
        },
        resolve: {
            load : loadJS("sm2000inputPtpModule",['controller/config/inputPtp/inputPtpCtrl.js'])
        }
    })

    .state('index.config.inputPtpInventory', {
        url: '/inputPtpInventory',
        templateUrl: 'template/config/inputPtp/inputPtpInventory.html',
        controller : "inputPtpInventoryCtrl",
        params: {
            devid: null,
            slot : null
        },
        resolve: {
            load : loadJS("sm2000inputPtpInventoryModule",['controller/config/inputPtp/inputPtpInventoryCtrl.js'])
        }
    })
    
    .state('index.config.inputPtpimage', {
        url: '/inputPtpimage',
        templateUrl: 'template/config/inputPtp/inputPtpimage.html',
        controller : "inputPtpimageCtrl",
        params: {
            devid: null,
            slot : null
        },
        resolve: {
            load : loadJS("sm2000inputPtpimageModule",['controller/config/inputPtp/inputPtpimageCtrl.js'])
        }
    })
    .state('index.config.inputPtpNetwork', {
        url: '/inputPtpNetwork',
        templateUrl: 'template/config/inputPtp/inputPtpNetwork.html',
        controller : "inputPtpNetworkCtrl",
        params: {
            devid: null,
            slot : null
        },
        resolve: {
            load : loadJS("sm2000inputPtpNetworkModule",['controller/config/inputPtp/inputPtpNetworkCtrl.js'])
        }
    })
    .state('index.config.inputPtpCommon', {
        url: '/inputPtpCommon',
        templateUrl: 'template/config/inputPtp/inputPtpCommon.html',
        controller : "inputPtpCommonCtrl",
        params: {
            devid: null,
            slot : null
        },
        resolve: {
            load : loadJS("sm2000inputPtpCommonModule",['controller/config/inputPtp/inputPtpCommonCtrl.js'])
        }
    })
    .state('index.config.inputPtpClient', {
        url: '/inputPtpClient',
        templateUrl: 'template/config/inputPtp/inputPtpClient.html',
        controller : "inputPtpClientCtrl",
        params: {
            devid: null,
            slot : null
        },
        resolve: {
            load : loadJS("sm2000inputPtpClientModule",['controller/config/inputPtp/inputPtpClientCtrl.js'])
        }
    })
    .state('index.config.inputPtpClockStatus', {
        url: '/inputPtpClockStatus',
        templateUrl: 'template/config/inputPtp/inputPtpClockStatus.html',
        controller : "inputPtpClockStatusCtrl",
        params: {
            devid: null,
            slot : null
        },
        resolve: {
            load : loadJS("sm2000inputPtpClockStatusModule",['controller/config/inputPtp/inputPtpClockStatusCtrl.js'])
        }
    })
    
    .state('index.config.inputPtpStatus', {
        url: '/inputPtpStatus',
        templateUrl: 'template/config/inputPtp/inputPtpStatus.html',
        controller : "inputPtpStatusCtrl",
        params: {
            devid: null,
            slot : null
        },
        resolve: {
            load : loadJS("sm2000inputPtpStatusModule",['controller/config/inputPtp/inputPtpStatusCtrl.js'])
        }
    })
    .state('index.config.inputPtpNetworkStartus', {
        url: '/inputPtpNetworkStartus',
        templateUrl: 'template/config/inputPtp/inputPtpNetworkStartus.html',
        controller : "inputPtpNetworkStartusCtrl",
        params: {
            devid: null,
            slot : null
        },
        resolve: {
            load : loadJS("sm2000inputPtpNetworkStartusModule",['controller/config/inputPtp/inputPtpNetworkStartusCtrl.js'])
        }
    })
    .state('index.config.inputPtpconfigManage', {
        url: '/inputPtpconfigManage',
        templateUrl: 'template/config/inputPtp/inputPtpconfigManage.html',
        controller : "inputPtpconfigManageCtrl",
        params: {
            devid: null,
            slot : null
        },
        resolve: {
            load : loadJS("sm2000inputPtpconfigManageModule",['controller/config/inputPtp/inputPtpconfigManageCtrl.js'])
        }
    })
    .state('index.config.inputPtprestart', {
        url: '/inputPtprestart',
        templateUrl: 'template/config/inputPtp/inputPtprestart.html',
        controller : "inputPtprestartCtrl",
        params: {
            devid: null,
            slot : null
        },
        resolve: {
            load : loadJS("sm2000inputPtprestartModule",['controller/config/inputPtp/inputPtprestartCtrl.js'])
        }
    })
    .state('index.config.outputNTP', {
        url: '/outputNTP',
        templateUrl: 'template/config/outputNTP/outputNTP.html',
        controller : "outputNTPCtrl",
        params: {
            devid: null,
            slot : null,
            exp  : null,
            deviceData : null
        },
        resolve: {
            load : loadJS("sm2000outputNTPModule",['controller/config/outputNTP/outputNTPCtrl.js'])
        }
    })



    .state('index.config.outputNTPAuthenticaConfig', {
        url: '/outputNTPAuthenticaConfig',
        templateUrl: 'template/config/outputNTP/outputNTPAuthenticaConfig.html',
        controller : "outputNTPAuthenticaConfigCtrl",
        params: {
            devid: null,
            slot : null,
            exp  : null
        },
        resolve: {
            load : loadJS("sm2000outputNTPAuthenticaConfigModule",['controller/config/outputNTP/outputNTPAuthenticaConfigCtrl.js'])
        }
    })
    .state('index.config.outputNTPBlacklist', {
        url: '/outputNTPBlacklist',
        templateUrl: 'template/config/outputNTP/outputNTPBlacklist.html',
        controller : "outputNTPBlacklistCtrl",
        params: {
            devid: null,
            slot : null,
            exp  : null
        },
        resolve: {
            load : loadJS("sm2000outputNTPBlacklistModule",['controller/config/outputNTP/outputNTPBlacklistCtrl.js'])
        }
    })
    .state('index.config.outputNTPboardConfig', {
        url: '/outputNTPboardConfig',
        templateUrl: 'template/config/outputNTP/outputNTPboardConfig.html',
        controller : "outputNTPboardConfigCtrl",
        params: {
            devid: null,
            slot : null,
            exp  : null
        },
        resolve: {
            load : loadJS("sm2000outputNTPboardConfigModule",['controller/config/outputNTP/outputNTPboardConfigCtrl.js'])
        }
    })
    
    .state('index.config.outputNTPbroadcastConfig', {
        url: '/outputNTPbroadcastConfig',
        templateUrl: 'template/config/outputNTP/outputNTPbroadcastConfig.html',
        controller : "outputNTPbroadcastConfigCtrl",
        params: {
            devid: null,
            slot : null,
            exp  : null
        },
        resolve: {
            load : loadJS("outputNTPbroadcastConfigModule",['controller/config/outputNTP/outputNTPbroadcastConfigCtrl.js'])
        }
    })
    .state('index.config.outputNTPimage', {
        url: '/outputNTPimage',
        templateUrl: 'template/config/outputNTP/outputNTPimage.html',
        controller : "outputNTPimageCtrl",
        params: {
            devid: null,
            slot : null,
            exp  : null
        },
        resolve: {
            load : loadJS("sm2000outputNTPimageModule",['controller/config/outputNTP/outputNTPimageCtrl.js'])
        }
    })

    
    .state('index.config.outputNTPInventory', {
        url: '/outputNTPInventory',
        templateUrl: 'template/config/outputNTP/outputNTPInventory.html',
        controller : "outputNTPInventoryCtrl",
        params: {
            devid: null,
            slot : null,
            exp  : null
        },
        resolve: {
            load : loadJS("sm2000outputNTPInventoryModule",['controller/config/outputNTP/outputNTPInventoryCtrl.js'])
        }
    })
    .state('index.config.outputNTPNetwork', {
        url: '/outputNTPNetwork',
        templateUrl: 'template/config/outputNTP/outputNTPNetwork.html',
        controller : "outputNTPNetworkCtrl",
        params: {
            devid: null,
            slot : null,
            exp  : null
        },
        resolve: {
            load : loadJS("sm2000outputNTPNetworkModule",['controller/config/outputNTP/outputNTPNetworkCtrl.js'])
        }
    })

    .state('index.config.outputNTPStatus', {
        url: '/outputNTPStatus',
        templateUrl: 'template/config/outputNTP/outputNTPStatus.html',
        controller : "outputNTPStatusCtrl",
        params: {
            devid: null,
            slot : null,
            exp  : null
        },
        resolve: {
            load : loadJS("sm2000outputNTPStatusModule",['controller/config/outputNTP/outputNTPStatusCtrl.js'])
        }
    })
    .state('index.config.outputNTPWhitelist', {
        url: '/outputNTPWhitelist',
        templateUrl: 'template/config/outputNTP/outputNTPWhitelist.html',
        controller : "outputNTPWhitelistCtrl",
        params: {
            devid: null,
            slot : null,
            exp  : null
        },
        resolve: {
            load : loadJS("sm2000outputNTPWhitelistModule",['controller/config/outputNTP/outputNTPWhitelistCtrl.js'])
        }
    })

    .state('index.config.outputNTPrestart', {
        url: '/outputNTPrestart',
        templateUrl: 'template/config/outputNTP/outputNTPrestart.html',
        controller : "outputNTPrestartCtrl",
        params: {
            devid: null,
            slot : null,
            exp  : null
        },
        resolve: {
            load : loadJS("sm2000outputNTPrestartModule",['controller/config/outputNTP/outputNTPrestartCtrl.js'])
        }
    })


    .state('index.config.irig', {
        url: '/irig',
        templateUrl: 'template/config/irig.html',
        controller : "sm2000irigCtrl",
        params: {
            devid: null,
            slot : null,
            exp  : null,
            deviceData : null
        },
        resolve: {
            load : loadJS("sm2000irigModule",['controller/config/sm2000irigCtrl.js'])
        }
    })
}]);

