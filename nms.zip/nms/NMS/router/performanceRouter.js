routerApp.config(['$stateProvider', '$urlRouterProvider', function($stateProvider, $urlRouterProvider) {
    $stateProvider
        .state('index.performance', {
            url: '/performance',
            views: {
                'center@index': {
                    templateUrl: 'template/center.html'
                }
            }
        })
        .state('index.performance.performanceTable', { //性能表单
            url: '/performanceTable',
            templateUrl: 'template/performance/performanceTable.html',
            controller: "performanceTableCtrl",
            resolve: {
                load : loadJS("performanceTableModule",['controller/performance/performanceTableCtrl.js'])
            }
        })
        .state('index.performance.performanceChart', { //性能曲线
            url: '/performanceChart',
            templateUrl: 'template/performance/performanceChart.html',
            controller: "performanceChartCtrl",
            resolve: {
                load : loadJS("performanceChartModule",['controller/performance/performanceChartCtrl.js'])
            }
        })
        .state('index.performance.performanceChartM1', { //性能实时曲线
            url: '/performanceChartM1',
            templateUrl: 'template/performance/performanceChartM1.html',
            controller: "performanceChartM1Ctrl",
            resolve: {
                load : loadJS("performanceChartM1Module",['controller/performance/performanceChartM1Ctrl.js'])
            }
        })
        .state('index.performance.performanceConfig', { //性能监测配置
            url: '/performanceConfig',
            templateUrl: 'template/performance/performanceConfig.html',
            controller: "performanceConfigCtrl",
            resolve: {
                deviceInfoData: function(publicService) {
                    publicService.loading('start');
                    return publicService.doRequest("GET", 112, {
                        page: "",
                        pageSize: 200,
                        name: "",
                        ip: "",
                        deviceStatus: "",
                        areaId: "",
                        deviceType: ""
                    })
                },
                load : loadJS("performanceConfigModule",['controller/performance/performanceConfigCtrl.js'])
            }
        })
        .state('index.performance.performanceConfigEditAdd', { //性能监测配置
            url: '/performanceConfigEditAdd',
            templateUrl: 'template/performance/performanceConfigEditAdd.html',
            controller: "performanceConfigEditAddCtrl",
            resolve: {
                deviceInfoData: function(publicService) {
                    publicService.loading('start');
                    return publicService.doRequest("GET", 112, {
                        page: "",
                        pageSize: 200,
                        name: "",
                        ip: "",
                        deviceStatus: "",
                        areaId: "",
                        deviceType: ""
                    })
                },
                load : loadJS("performanceConfigEditAddModule",['controller/performance/performanceConfigEditAddCtrl.js'])
            },
            params: {
                mauto: null
            }
        })
}]);
