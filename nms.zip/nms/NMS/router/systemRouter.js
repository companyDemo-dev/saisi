routerApp.config(['$stateProvider', '$urlRouterProvider',function($stateProvider, $urlRouterProvider) {
    $stateProvider
    .state('index.system', {
        url: '/system',
        views: {
            'center@index': {
                templateUrl: 'template/center.html'
            }
        }
    })
    .state('index.system.databaseConfig', {
        url: '/baseConfig',
        templateUrl: 'template/system/database/systemDatabaseConfig.html',
        controller : "systemDatabaseConfigCtrl",
        resolve: {
            load : loadJS("systemDatabaseConfigModule",['controller/system/database/systemDatabaseConfigCtrl.js'])
        }
    })
    .state('index.system.ConfigEdit', {
        url: '/ConfigEdit',
        templateUrl: 'template/system/database/configAddEdit.html',
        controller : "databaseConfigEditCtrl",
        params: {mauto : null},
        resolve: {
            load : loadJS("databaseConfigEditModule",['controller/system/database/databaseConfigEditCtrl.js'])
        }
    })
    .state('index.system.databaseAuto', {//自动
        url: '/auto',
        templateUrl: 'template/system/database/systemDatabaseAuto.html',
        controller : "systemDatabaseAutoCtrl",
        resolve: {
            load : loadJS("systemDatabaseAutoModule",['controller/system/database/systemDatabaseAutoCtrl.js'])
        }
    })
    .state('index.system.databaseAutoAddEdit', {//自动添加修改
        url: '/dbaddedit',
        templateUrl: 'template/system/database/addEdit.html',
        controller:"databaseAutoAddEditCtrl",
        resolve: {
            tableDate:function($http,publicService){
                return publicService.doRequest("GET", 12, {});
            },
            load : loadJS("databaseAutoAddEditModule",['controller/system/database/databaseAutoAddEditCtrl.js'])
        },
        params: {mauto : null}
    })
    .state('index.system.databaseManual', {//手动
        url: '/manual',
        templateUrl: 'template/system/database/systemDatabaseManual.html',
        controller : "systemDatabasManualCtrl",
        resolve: {
            load : loadJS("systemDatabasManualModule",['controller/system/database/systemDatabasManualCtrl.js'])
        },
        params: {mauto : null}
    })
    .state('index.system.databaseManualConfig', {//手动
        url: '/manualConfig',
        templateUrl: 'template/system/database/systemDatabaseManualConfig.html',
        controller : "systemDatabaseManualConfigCtrl",
        resolve: {
            load : loadJS("systemDatabaseManualConfigModule",['controller/system/database/systemDatabaseManualConfigCtrl.js'])
        },
        params: {mauto : null}
    })
    .state('index.system.databaseRecord', {//记录
        url: '/record',
        templateUrl: 'template/system/database/systemDatabaseRecord.html',
        controller : "systemDatabasRecordCtrl",
        resolve: {
            load : loadJS("systemDatabasRecordModule",['controller/system/database/systemDatabasRecordCtrl.js'])
        }
    })
    .state('index.system.hardVersionMessage', {// Soft and hard软硬件管理
        url: '/hard',
        templateUrl: 'template/system/softHard/hardVersionMessage.html',
        controller : "hardVersionMessageCtrl",
        resolve: {
            load : loadJS("hardVersionMessageModule",['controller/system/softHard/hardVersionMessageCtrl.js'])
        }
    })
    .state('index.system.softVersionMessage', {//软件版本
        url: '/soft',
        templateUrl: 'template/system/softHard/softVersionMessage.html'
    })
    .state('index.system.processMessage', {//软件进程
        url: '/process',
        templateUrl: 'template/system/softHard/processMessage.html',
        controller : "processMessageCtrl",
        resolve: {
            processDate:function($http,publicService){
                publicService.loading('start')
               return publicService.doRequest("GET", 16, {})
            },
            load : loadJS("processMessageModule",['controller/system/softHard/processMessageCtrl.js'])
        }
    })
    .state('index.system.map', {//地图管理
        url: '/map',
        templateUrl: 'template/system/map/map.html',
        controller : "mapCtrl",
        resolve: {
            mapDate:function($http,publicService){
               return publicService.doRequest("GET", 17, {})
            },
            load : loadJS("mapModule",['controller/system/map/mapCtrl.js'])
        }
    })
    .state('index.system.mapAdd', {//地图管理
        url: '/mapAdd',
        templateUrl: 'template/system/map/mapAdd.html',
        controller : "mapAddCtrl",
        resolve: {
            load : loadJS("mapAddModule",['controller/system/map/mapAddCtrl.js'])
        }
    })
    .state('index.help', { //STFS1000配置
        url: '/helpCofing',
        views: {
            'center@index': {
                templateUrl: 'template/center.html'
            }
        }
    })
    .state('index.help.doc', {
        url: '/helpC',
        templateUrl: 'template/system/helpC.html',
        controller: "helpCCtrl",
        resolve: {
            load : loadJS("helpCModule",['controller/system/helpCCtrl.js'])
        }
    })
    .state('index.help.abnms', {
        url: '/about',
        templateUrl: 'template/system/about.html',
        controller: "sysaboutCtrl",
        resolve: {
            load : loadJS("sysaboutModule",['controller/system/sysaboutCtrl.js'])
        }
    })
    .state('index.system.addressconfig', {
        url: '/addressconfig',
        templateUrl: 'template/system/database/addrManage.html',
        controller: "addrManageCtrl",
        resolve: {
            load : loadJS("addrManageModule",['controller/system/database/addrManageCtrl.js'])
        }
    })
    .state('index.system.syncManage', {
        url: '/syncManage',
        templateUrl: 'template/system/syncManage.html',
        controller: "syncManageCtrl",
        resolve: {
            load : loadJS("syncManageModule",['controller/system/syncManageCtrl.js'])
        }
    })
    .state('index.system.syncManageAdd', {
        url: '/syncManageAdd',
        templateUrl: 'template/system/syncManageAdd.html',
        controller: "syncManageAddCtrl",
        resolve: {
            load : loadJS("syncManageAddModule",['controller/system/syncManageAddCtrl.js'])
        }
    })
    .state('index.system.serverAlarmThreshold', {
        url: '/serverAlarmThreshold',
        templateUrl: 'template/system/serverAlarmThreshold.html',
        controller: "serverAlarmThresholdCtrl",
        resolve: {
            load : loadJS("serverAlarmThresholdModule",['controller/system/serverAlarmThresholdCtrl.js'])
        }
    })
    .state('index.system.serverAlarmThresholdAdd', {
        url: '/serverAlarmThresholdAdd',
        templateUrl: 'template/system/serverAlarmThresholdAdd.html',
        controller: "serverAlarmThresholdAddCtrl",
        resolve: {
            load : loadJS("serverAlarmThresholdAddModule",['controller/system/serverAlarmThresholdAddCtrl.js'])
        }
    })
}]);
