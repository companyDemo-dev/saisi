routerApp.config(['$stateProvider', '$urlRouterProvider', function($stateProvider, $urlRouterProvider) {
    $stateProvider
        .state('index.authority', {
            url: '/authority',
            views: {
                'center@index': {
                    templateUrl: 'template/center.html'
                }
            }
        })
        .state('index.authority.userManage', { //用户管理
            url: '/userManage',
            templateUrl: 'template/authority/userManage.html',
            controller: "userManageCtrl",
            resolve: {
                load : loadJS("userManageModule",['controller/authority/userManageCtrl.js'])
            }
        })


       .state('index.authority.userManageAddEdit', {
            url: '/userManageAddEdit',
            templateUrl: 'template/authority/userManageAddEdit.html',
            controller: "userManageAddEditCtrl",
            params: {mauto : null},
            resolve: {
                load : loadJS("userManageAddEditModule",['controller/authority/userManageAddEditCtrl.js'])
            }
        })

 

        .state('index.authority.menuManage', { //菜单管理
            url: '/menuManage',
            templateUrl: 'template/authority/menuManage.html',
            controller: "menuManageCtrl",
            cache: false,
            resolve: {
                load : loadJS("menuManageModule",['controller/authority/menuManageCtrl.js'])
            }
        })
       .state('index.authority.menuManageAdd', {
            url: '/menuManageAdd',
            templateUrl: 'template/dialog/menuManageAdd.html',
            controller: "userManageAddCtrl",
            resolve: {
                load : loadJS("userManageAddModule",['controller/authority/userManageAddCtrl.js'])
            }
        })



       .state('index.authority.roleManageAddEdit', {
            url: '/roleManageAddEdit',
            templateUrl: 'template/authority/roleManageAddEdit.html',
            controller: "roleManageAddEditCtrl",
            params: {mauto : null},
            resolve: {
                load : loadJS("roleManageAddEditModule",['controller/authority/roleManageAddEditCtrl.js'])
            }
        })
       
        .state('index.authority.roleManage', { //角色管理
            url: '/roleManage',
            templateUrl: 'template/authority/roleManage.html',
            controller: "roleManageCtrl",
            resolve: {
                load : loadJS("roleManageModule",['controller/authority/roleManageCtrl.js'])
            }
        })
        .state('index.authority.deviceManage', { //设备权限
            url: '/deviceManage',
            templateUrl: 'template/authority/deviceManage.html',
            controller: "deviceManageCtrl",
            resolve: {
                load : loadJS("deviceManageModule",['controller/authority/deviceManageCtrl.js'])
            }
        })
}]);
