routerApp.config(['$stateProvider', '$urlRouterProvider',function($stateProvider, $urlRouterProvider) {
	$stateProvider
    .state('index.log', {
        url: '/log',
        views: {
            'center@index': {
                templateUrl: 'template/center.html'
            }
        }
    })
    .state('index.log.safeLog', {//安全
        url: '/safeLog',
        templateUrl: 'template/log/safeLog.html',
        controller : "safeLogCtrl",
        resolve: {
            load : loadJS("safeLogModule",['controller/log/safeLogCtrl.js'])
        }
    })
    .state('index.log.alarmLog', {//告警
        url: '/alarmLog',
        templateUrl: 'template/log/alarmLog.html',
        controller : "alarmLogCtrl",
        resolve: {
            deviceInfoData:function(publicService){
                publicService.loading('start');
                return publicService.doRequest("GET", 4, {type : "two"});
            },
            load : loadJS("alarmLogModule",['controller/log/alarmLogCtrl.js'])
        }
    })
    
    .state('index.log.networkLog', {//网管
        url: '/networkLog',
        templateUrl: 'template/log/networkLog.html',
        controller : "networkLogCtrl",
        resolve: {
            load : loadJS("networkLogModule",['controller/log/networkLogCtrl.js'])
        }
    })
    .state('index.log.operationLog', {//操作
        url: '/operationLog',
        templateUrl: 'template/log/operationLog.html',
        controller : "operationLogCtrl",
        resolve: {
            deviceInfoData:function(publicService){
                publicService.loading('start');
                return publicService.doRequest("GET", 4, {type : "two"});
            },
            load : loadJS("operationLogModule",['controller/log/operationLogCtrl.js'])
        }
    })
    .state('index.log.performanceLog', {//性能
        url: '/performanceLog',
        templateUrl: 'template/log/performanceLog.html',
        controller : "performanceLogCtrl",
        resolve: {
            deviceInfoData:function(publicService){
                publicService.loading('start');
                return publicService.doRequest("GET", 4, {type : "two"});
            },
            load : loadJS("performanceLogModule",['controller/log/performanceLogCtrl.js'])
        }
    })
    .state('index.log.systemLog', {//系统
        url: '/systemLog',
        templateUrl: 'template/log/systemLog.html',
        controller : "systemLogCtrl",
        resolve: {
            deviceInfoData:function(publicService){
                publicService.loading('start');
                return publicService.doRequest("GET", 4, {type : "two"});
            },
            load : loadJS("systemLogModule",['controller/log/systemLogCtrl.js'])
        }
    })        
}]);
