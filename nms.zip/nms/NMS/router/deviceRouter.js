routerApp.config(['$stateProvider', '$urlRouterProvider',function($stateProvider, $urlRouterProvider) {
	$stateProvider
    .state('index.device', {
        url: '/device',
        views: {
            'center@index': {
                templateUrl: 'template/center.html'
            }
        }
    })
    .state('index.device.deviceManage', {//设备管理
        url: '/deviceManage',
        templateUrl: 'template/device/deviceManage.html',
        controller : "deviceManageCtrl",
        resolve: {
            load : loadJS("deviceManageModule",['controller/device/deviceManageCtrl.js'])
        }
    })
    .state('index.device.deviceManageEditAdd', {//设备管理添加修改
        url: '/deviceManageEditAdd',
        templateUrl: 'template/device/deviceManageEditAdd.html',
        controller : "deviceManageEditAddCtrl",
        resolve: {
            areaData:function(publicService){
                publicService.loading('start');
                return publicService.doRequest("GET", 111, {})
            },
            load : loadJS("deviceManageEditAddModule",['controller/device/deviceManageEditAddCtrl.js'])
        },
        params: {mauto : null}
    })
    .state('index.device.areaManage', {//区域管理
        url: '/areaManage',
        templateUrl: 'template/device/areaManage.html',
        controller : "areaManageCtrl",
        resolve: {
            areaData:function(publicService){
                publicService.loading('start');
                return publicService.doRequest("GET", 111, {})
            },
            load : loadJS("areaManageModule",['controller/device/areaManageCtrl.js'])
        }
    })
    .state('index.device.areaManageAdd', {
        url: '/areaManageAdd',
        templateUrl: 'template/device/areaManageAdd.html',
        controller : "areaManageAddCtrl",
        resolve: {
            load : loadJS("areaManageAddModule",['controller/device/areaManageAddCtrl.js'])
        }
    })
}]);
