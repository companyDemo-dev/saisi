
routerApp.config(['$stateProvider', '$urlRouterProvider', function($stateProvider, $urlRouterProvider) {
    $stateProvider
        .state('index.other', {
            url: '/other',
            views: {
                'center@index': {
                    templateUrl: 'template/center.html'
                }
            }
        })

    .state('lockFrame', {
        url: '/lockFrame',
        templateUrl: 'template/other/lockFrame.html',
        controller: 'otherlockFrameCtrl',
        resolve: {
            load : loadJS("otherlockFrameModule",['controller/other/otherlockFrameCtrl.js'])
        }
    })
    .state('PASDFrame', { //屏保密码
        url: '/PASDFrame',
        templateUrl: 'template/other/PASDFrame.html',
        controller: "otherlockFrameCtrl",
        resolve: {
            load : loadJS("otherlockFrameModule",['controller/other/otherlockFrameCtrl.js'])
        }
    })
    .state('index.other.lockFrameConfig', {
        url: '/lockFrameConfig',
        templateUrl: 'template/other/lockFrameConfig.html',
        controller: 'otherlockFrameConfigCtrl',
        resolve: {
            load : loadJS("otherlockFrameConfigModule",['controller/other/otherlockFrameConfigCtrl.js'])
        }
    })
    .state('index.other.sound', { //
        url: '/sound',
        templateUrl: 'template/other/otherSound.html',
        controller: "otherSoundCtrl",
        resolve: {
            load : loadJS("otherSoundModule",['controller/other/otherSoundCtrl.js'])
        }
    })
    .state('index.other.ping', { //
        url: '/ping',
        templateUrl: 'template/other/otherPing.html',
        controller: "otherPingCtrl",
        resolve: {
            load : loadJS("otherPingModule",['controller/other/otherPingCtrl.js'])
        }
    })
    .state('index.other.NetworkUpgrade', { //网管级升
        url: '/NetworkUpgrade',
        templateUrl: 'template/other/otherNetworkUpgrade.html',
        controller: "otherNetworkUpgradeCtrl",
        resolve: {
            load : loadJS("otherNetworkUpgradeModule",['controller/other/otherNetworkUpgradeCtrl.js'])
        }
    })
    .state('index.other.language', { //
        url: '/language',
        templateUrl: 'template/other/otherLanguage.html',
        controller: "otherLanguageCtrl",
        resolve: {
            load : loadJS("otherLanguageModule",['controller/other/otherLanguageCtrl.js'])
        }
    })
    .state('index.other.passwordRule', { //
        url: '/passwordRule',
        templateUrl: 'template/other/passwordRule.html',
        controller: "passwordRuleCtrl",
        resolve: {
            load : loadJS("passwordRuleModule",['controller/other/passwordRuleCtrl.js'])
        }
    })
    .state('index.other.sync', { //
        url: '/sync',
        templateUrl: 'template/other/sync.html',
        controller: "syncCtrl",
        resolve: {
            load : loadJS("syncModule",['controller/other/syncCtrl.js'])
        }
    })

    .state('index.other.portname', {
        url: '/porname',
        templateUrl: 'template/other/porname.html',
        controller: "pornameCtrl",
        resolve: {
            load : loadJS("pornameModule",['controller/other/pornameCtrl.js'])
        },
        params: {mauto : null,devID : null}
    })
    .state('index.other.pornameConfig', {
        url: '/pornameConfig',
        templateUrl: 'template/other/pornameConfig.html',
        controller: "pornameConfigCtrl",
        resolve: {
            load : loadJS("pornameConfigModule",['controller/other/pornameConfigCtrl.js'])
        },
        params: {mauto : null,devID : null}
    })
    .state('index.other.mapdata', {
        url: '/mapdata',
        templateUrl: 'template/other/mapdata.html',
        controller: "mapdataCtrl",
        resolve: {
            load : loadJS("mapdataModule",['controller/other/mapdataCtrl.js'])
        },
        params: {mauto : null,devID : null}
    })
    .state('index.other.otherTerminal', {
        url: '/otherTerminal',
        templateUrl: 'template/other/otherTerminal.html',
        controller: "otherTerminalCtrl",
        resolve: {
            load : loadJS("otherTerminalModule",['controller/other/otherTerminalCtrl.js'])
        },
        params: {mauto : null,devID : null}
    })
}]);
