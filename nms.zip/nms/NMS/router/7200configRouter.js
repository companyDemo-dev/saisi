routerApp.config(['$stateProvider', '$urlRouterProvider', function($stateProvider, $urlRouterProvider) {
    $stateProvider
        .state('index.7200config', {
            url: '/7200config',
            views: {
                'center@index': {
                    templateUrl: 'template/center.html'
                }
            }
        })
       .state('index.7200config.ntpOther', {
            url: '/ntpOther',
            templateUrl: 'template/7200config/ntpOther.html',
            controller: "ntpOtherCtrl",
            resolve : {
                load : loadJS("7200ntpOtherModule",['controller/7200config/ntpOtherCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.7200config.ntpserver', {
            url: '/ntpserver',
            templateUrl: 'template/7200config/ntpserver.html',
            controller: "ntpServerCtrl",
            resolve : {
                load : loadJS("7200ntpServerModule",['controller/7200config/ntpServerCtrl.js'])
            },
            params: {mauto : null}
        })
       .state('index.7200config.ntpserverConfig', {
            url: '/ntpserverConfig',
            templateUrl: 'template/7200config/ntpserverConfig.html',
            controller: "ntpserverConfigCtrl",
            resolve : {
                load : loadJS("7200ntpserverConfigModule",['controller/7200config/ntpserverConfigCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.7200config.ntpWhitelist', {
            url: '/ntpWhitelist',
            templateUrl: 'template/7200config/ntpWhitelist.html',
            controller: "ntpWhitelistCtrl",
            resolve : {
                load : loadJS("7200ntpWhitelistModule",['controller/7200config/ntpWhitelistCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.7200config.ntpBlacklist', {
            url: '/ntpBlacklist',
            templateUrl: 'template/7200config/ntpBlacklist.html',
            controller: "ntpBlacklistCtrl",
            resolve : {
                load : loadJS("7200ntpBlacklistModule",['controller/7200config/ntpBlacklistCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.7200config.ntpUserlist', {
            url: '/ntpUserlist',
            templateUrl: 'template/7200config/ntpUserlist.html',
            controller: "ntpUserlistCtrl",
            resolve : {
                load : loadJS("7200ntpUserlistModule",['controller/7200config/ntpUserlistCtrl.js'])
            },
            params: {mauto : null}
        })


       .state('index.7200config.ntp', {
            url: '/ntp',
            templateUrl: 'template/7200config/ntp.html',
            controller: "ntpCtrl",
            resolve : {
                load : loadJS("7200ntpModule",['controller/7200config/ntpCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.7200config.inputOutput', {
            url: '/inputOutput',
            templateUrl: 'template/7200config/inputOutput.html',
            controller: "inputOutputCtrl",
            resolve : {
                load : loadJS("7200inputOutputModule",['controller/7200config/inputOutputCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.7200config.gnss1', {
            url: '/gnss1',
            templateUrl: 'template/7200config/gnss1.html',
            controller: "gnss1Ctrl",
            resolve : {
                load : loadJS("7200gnss1Module",['controller/7200config/gnss1Ctrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.7200config.gnss1State', {
            url: '/gnss1State',
            templateUrl: 'template/7200config/gnss1State.html',
            controller: "gnss1StateCtrl",
            resolve : {
                load : loadJS("7200gnss1StateModule",['controller/7200config/gnss1StateCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.7200config.gnss1Lite', {
            url: '/gnss1Lite',
            templateUrl: 'template/7200config/gnss1Lite.html',
            controller: "gnss1LiteCtrl",
            resolve : {
                load : loadJS("7200gnss1LiteModule",['controller/7200config/gnss1LiteCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.7200config.gnss2', {
            url: '/gnss2',
            templateUrl: 'template/7200config/gnss2.html',
            controller: "gnss2Ctrl",
            resolve : {
                load : loadJS("7200gnss2Module",['controller/7200config/gnss2Ctrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.7200config.gnss2State', {
            url: '/gnss2State',
            templateUrl: 'template/7200config/gnss2State.html',
            controller: "gnss2StateCtrl",
            resolve : {
                load : loadJS("7200gnss2StateModule",['controller/7200config/gnss2StateCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.7200config.gnss2Lite', {
            url: '/gnss2Lite',
            templateUrl: 'template/7200config/gnss2Lite.html',
            controller: "gnss2LiteCtrl",
            resolve : {
                load : loadJS("7200gnss2LiteModule",['controller/7200config/gnss2LiteCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.7200config.alarmModle', {
            url: '/alarmModle',
            templateUrl: 'template/7200config/alarmConfigTable.html',
            controller: "alarmConfigTableCtrl",
            resolve : {
                load : loadJS("7200alarmConfigTableModule",['controller/7200config/alarmConfigTableCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.7200config.alarmConfigTable', {
            url: '/alarmConfigTable',
            templateUrl: 'template/7200config/alarmConfigTable.html',
            controller: "alarmConfigTableCtrl",
            resolve : {
                load : loadJS("7200alarmConfigTableModule",['controller/7200config/alarmConfigTableCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.7200config.alarmStatusTable', {
            url: '/alarmStatusTable',
            templateUrl: 'template/7200config/alarmStatusTable.html',
            controller: "alarmStatusTableCtrl",
            resolve : {
                load : loadJS("7200alarmStatusTableModule",['controller/7200config/alarmStatusTableCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.7200config.IPETH', {
            url: '/IPETH',
            templateUrl: 'template/7200config/IPETH.html',
            controller: "IPETHCtrl",
            resolve : {
                load : loadJS("7200IPETHModule",['controller/7200config/IPETHCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.7200config.inventoryGroup', {
            url: '/inventoryGroup',
            templateUrl: 'template/7200config/inventoryGroup.html',
            controller: "inventoryGroupCtrl",
            resolve : {
                load : loadJS("7200inventoryGroupModule",['controller/7200config/inventoryGroupCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.7200config.ref', {
            url: '/ref',
            templateUrl: 'template/7200config/gnss1.html',
            controller: "gnss1Ctrl",
            resolve : {
                load : loadJS("7200gnss1Module",['controller/7200config/gnss1Ctrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.7200config.boardConfig', {
            url: '/boardConfig',
            templateUrl: 'template/7200config/boardConfig.html',
            controller: "boardConfigCtrl",
            resolve : {
                load : loadJS("7200boardConfigModule",['controller/7200config/boardConfigCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.7200config.reboot', {
            url: '/reboot',
            templateUrl: 'template/7200config/reboot.html',
            controller: "rebootCtrl",
            resolve : {
                load : loadJS("7200rebootModule",['controller/7200config/rebootCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.7200config.image', {
            url: '/image',
            templateUrl: 'template/7200config/image.html',
            controller: "imageCtrl",
            resolve : {
                load : loadJS("7200imageModule",['controller/7200config/imageCtrl.js'])
            },
            params: {mauto : null}
        })

       .state('index.7200config.upgrade', {
            url: '/upgrade',
            templateUrl: 'template/7200config/upgrade.html',
            controller: "upgradeCtrl",
            resolve : {
                load : loadJS("7200upgradeModule",['controller/7200config/upgradeCtrl.js'])
            },
            params: {mauto : null}
        })




        .state('index.7200config.other', {
            url: '/other',
            templateUrl: 'template/7200config/other.html',
            controller: "otherCtrl",
            resolve : {
                load : loadJS("7200otherModule",['controller/7200config/otherCtrl.js'])
            },
            params: {mauto : null}
        })
        .state('index.7200config.other2', {
            url: '/other',
            templateUrl: 'template/7200config/other.html',
            controller: "otherCtrl",
            resolve : {
                load : loadJS("7200otherModule",['controller/7200config/otherCtrl.js'])
            },
            params: {mauto : null}
        })
       .state('index.7200config.referenceInfo', {
            url: '/referenceInfo',
            templateUrl: 'template/7200config/refOffsetHistoryTable.html',
            controller: "refOffsetHistoryTableCtrl",
            resolve : {
                load : loadJS("7200refOffsetHistoryTableModule",['controller/7200config/refOffsetHistoryTableCtrl.js'])
            },
            params: {mauto : null}
        })
 
        .state('index.7200config.refConfigTable', {
            url: '/refConfigTable',
            templateUrl: 'template/7200config/refConfigTable.html',
            controller: "refConfigTableCtrl",
            resolve : {
                load : loadJS("7200refConfigTableModule",['controller/7200config/refConfigTableCtrl.js'])
            }
        })
        .state('index.7200config.refOffsetHistoryTable', {
            url: '/refOffsetHistoryTable',
            templateUrl: 'template/7200config/refOffsetHistoryTable.html',
            controller: "refOffsetHistoryTableCtrl",
            resolve : {
                load : loadJS("7200refOffsetHistoryTableModule",['controller/7200config/refOffsetHistoryTableCtrl.js'])
            }
        })

        .state('index.7200config.snmpUserTable', {
            url: '/snmpUserTable',
            templateUrl: 'template/7200config/snmpUserTable.html',
            controller: "snmpUserTableCtrl",
            resolve : {
                load : loadJS("7200snmpUserTableModule",['controller/7200config/snmpUserTableCtrl.js'])
            }
        })
        
        .state('index.7200config.snmpManagerTable', {
            url: '/snmpManagerTable',
            templateUrl: 'template/7200config/snmpManagerTable.html',
            controller: "snmpManagerTableCtrl",
            resolve : {
                load : loadJS("7200snmpManagerTableModule",['controller/7200config/snmpManagerTableCtrl.js'])
            }
        })
        
        .state('index.7200config.snmpConfig', {
            url: '/snmpConfig',
            templateUrl: 'template/7200config/snmpConfig.html',
            controller: "snmpConfigCtrl",
            resolve : {
                load : loadJS("7200snmpsnmpConfigModule",['controller/7200config/snmpConfigCtrl.js'])
            }
        })

        .state('index.7200config.refConfigTablePriority', {
            url: '/refConfigTablePriority',
            templateUrl: 'template/7200config/refConfigTablePriority.html',
            controller: "refConfigTablePriorityCtrl",
            params: {obj : null},
            resolve : {
                load : loadJS("7200refConfigTablePriorityModule",['controller/7200config/refConfigTablePriorityCtrl.js'])
            }
        })
}]);
