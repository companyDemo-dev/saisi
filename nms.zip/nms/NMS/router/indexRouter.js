routerApp.config(['$stateProvider', '$urlRouterProvider',function($stateProvider, $urlRouterProvider) {
    $stateProvider
    .state('index', {
        url: '/index',
        views: {
            '': {
                templateUrl: 'template/index.html',
                controller : 'indexCtrl',
                resolve : {
                    load : loadJS("indexModule",['controller/indexCtrl.js'])
                }
            },
            'topbar@index': {
                templateUrl: 'template/topbar.html',
                controller:'topbarCtrl',
                resolve : {
                    load : loadJS("topbarModule",['controller/topbarCtrl.js'])
                }
            }
            ,'center@index': {
                templateUrl: 'template/tuopu.html',
                controller:'tuopuCtrl',
                resolve : {
                    load : loadJS("tuopuModule",['controller/tuopuCtrl.js'])
                }
                // templateUrl: 'template/deviceMap.html',
                // controller : "deviceMapCtrl"
            },
            'footer@index': {
                templateUrl: 'template/footer.html'
            }
        },
        params: {ExpiredFlag : null}
    })
    .state('index.tuopuDeviceAddEdit', { //拓扑图添加修改设备
        url: '/tuopuDeviceAddEdit',
        views: {
            'center@index': {
                templateUrl: 'template/device/deviceManageEditAdd.html',
                controller : "deviceManageEditAddCtrl",
                resolve: {
                    areaData:function(publicService){
                        publicService.loading('start');
                        return publicService.doRequest("GET", 111, {})
                    },
                    load : loadJS("deviceManageEditAddModule",['controller/device/deviceManageEditAddCtrl.js'])
                }
            }
        },
        params: {mauto : null}
    })
    .state('index.alwaysAlarm', { //时实告警
        url: '/alwaysAlarm?id',
        views: {
            'center@index': {
                templateUrl: 'template/alarm/alwaysAlarm.html',
                controller : "alwaysAlarm",
                resolve: {
                    load : loadJS("alwaysAlarmModule",['controller/alarm/alwaysAlarm.js'])
                }
            }
        },
        params: {id : null, deviceType:null}
    })
    .state('index.showTrimble', { //查看参考源
        url: '/showTrimble?id',
        views: {
            'center@index': {
                templateUrl: 'template/showTrimble/TrimbleList.html',
                controller : "showTrimbleCtrl",
                resolve: {
                    load : loadJS("TrimbleListModule",['controller/showTrimble/showTrimble.js'])
                }
            }
        }
    })

    .state('index.showTrimbleptp', { //查看参考源
        url: '/showTrimbleptp?id',
        views: {
            'center@index': {
                templateUrl: 'template/showTrimble/showTrimbleptp.html',
                controller : "showTrimbleptpCtrl",
                resolve: {
                    load : loadJS("showTrimbleptpListModule",['controller/showTrimble/showTrimbleptp.js'])
                }
            }
        }
    })
    .state('index.showGnss1', { //查看gnss
        url: '/showGnss1?id',
        views: {
            'center@index': {
                templateUrl: 'template/showTrimble/gnss1.html',
                controller : "gnss11Ctrl",
                resolve: {
                    load : loadJS("gnss11Module",['controller/showTrimble/gnss1.js'])
                }
            }
        }
    })
    .state('index.showGnss2', { //查看gnss
        url: '/showGnss2?id',
        views: {
            'center@index': {
                templateUrl: 'template/showTrimble/gnss2.html',
                controller : "gnss22Ctrl",
                resolve: {
                    load : loadJS("gnss22Module",['controller/showTrimble/gnss2.js'])
                }
            }
        }
    })
    .state('index.showoffset', { //查看gnss
        url: '/showoffset?id',
        views: {
            'center@index': {
                templateUrl: 'template/showTrimble/showoffset.html',
                controller : "showoffsetCtrl",
                resolve: {
                    load : loadJS("showoffsetModule",['controller/showTrimble/showoffset.js'])
                }
            }
        }
    })
    .state('index.newDeviceTopu', { 
        url: '/newDeviceTopu',
        views: {
            'center@index': {
                templateUrl: 'template/newDeviceTopu.html',
                controller : "newDeviceTopuCtrl",
                resolve: {
                    load : loadJS("newDeviceTopuModule",['controller/newDeviceTopuCtrl.js'])
                }
            }
        }
    })
}]);
