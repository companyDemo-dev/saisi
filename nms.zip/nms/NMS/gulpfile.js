// 引入 gulp
var gulp = require("gulp");
// 引入组件
var imagemin = require("gulp-imagemin");
var minifycss = require("gulp-minify-css");
var uglify = require("gulp-uglify");
var jshint = require("gulp-jshint");
var concat = require("gulp-concat");
var paths = {
    scripts: [
        "js/angular-1.3.0.js",
        "js/angular-ui-router.js",
        "js/ui-bootstrap-tpls.0.11.2.js",
        "js/angular-tree-control.js",

        "js/ngDialog.min.js",
        "js/ngTip.js",
        "js/loading-bar.js",
        "js/isteven-multi-select.js",
        "js/angular-translate.js",
        "js/DatePicker/WdatePicker.js",
        "js/ichart.latest.min.js",
        "js/pageLoading/me-pageloading.min.js",
        "js/pageLoading/snap.svg-min.js",

        "js/angular-file-upload.min.js",
        "js/angular-ui-switch.js",
        "js/macTopology.js",
        "js/topologyConfig.js",

        "js/JSPlumb/lib/jsBezier-0.7.js",
        "js/JSPlumb/lib/mottle-0.7.1.js",
        "js/JSPlumb/lib/biltong-0.2.js",
        "js/JSPlumb/lib/katavorio-0.13.0.js",
        "js/JSPlumb/util.js",
        "js/JSPlumb/browser-util.js",
        "js/JSPlumb/jsPlumb.js",
        "js/JSPlumb/dom-adapter.js",
        "js/JSPlumb/overlay-component.js",
        "js/JSPlumb/endpoint.js",
        "js/JSPlumb/connection.js",
        "js/JSPlumb/anchors.js",
        "js/JSPlumb/defaults.js",
        "js/JSPlumb/connectors-bezier.js",
        "js/JSPlumb/connectors-statemachine.js",
        "js/JSPlumb/connectors-flowchart.js",
        "js/JSPlumb/renderers-svg.js",
        "js/JSPlumb/base-library-adapter.js",
        "js/JSPlumb/dom.jsPlumb.js",

        "app.js",
        "js/language.js",
        "js/service.js",
        "js/directive.js",
        "js/verify.js",
        "router/loginRouter.js",
        "router/indexRouter.js",
        "router/authorityRouter.js",
        "router/configRouter.js",
        "router/systemRouter.js",
        "router/alarmRouter.js",
        "router/deviceRouter.js",
        "router/logRouter.js",
        "router/performanceRouter.js",
        "router/otherRouter.js",
        "router/ssuconfigRouter.js",
        "router/7200configRouter.js",
        "router/sm2000GNRouter.js",
        "router/ts3100ConfigRouter.js",

        "controller/indexCtrl.js",
        "controller/loginCtrl.js",
        "controller/tuopuCtrl.js",
        "controller/topbarCtrl.js",
        "controller/twoMenuCtrl.js",
        "controller/alarm/alarmFilterCtrl.js",
        "controller/alarm/alarmFilterEditAddCtrl.js",
        "controller/alarm/alarmRuleCtrl.js",
        "controller/alarm/alarmRuleEditAddCtrl.js",
        "controller/alarm/alwaysAlarm.js",
        "controller/showTrimble/gnss1.js",
        "controller/showTrimble/gnss2.js",
        "controller/showTrimble/showTrimble.js",

        "controller/log/safeLogCtrl.js",
        "controller/log/alarmLogCtrl.js",
        "controller/log/networkLogCtrl.js",
        "controller/log/operationLogCtrl.js",
        "controller/log/performanceLogCtrl.js",
        "controller/log/systemLogCtrl.js",

        "controller/system/database/systemDatabaseAutoCtrl.js",
        "controller/system/database/systemDatabasManualCtrl.js",
        "controller/system/database/systemDatabasRecordCtrl.js",
        "controller/system/database/databaseAutoAddEditCtrl.js",
        "controller/system/softHard/processMessageCtrl.js",
        "controller/system/map/mapCtrl.js",
        "controller/system/map/mapAddCtrl.js",

        "controller/device/deviceManageCtrl.js",
        "controller/device/deviceManageEditAddCtrl.js",
        "controller/device/areaManageCtrl.js",
        "controller/device/areaManageAddCtrl.js",
        "controller/device/backupConfigCtrl.js",
        "controller/device/upgradeCmdCtrl.js",

        "controller/authority/userManageAddEditCtrl.js",
        "controller/authority/userManageCtrl.js",
        "controller/authority/menuManageCtrl.js",
        "controller/authority/roleManageAddEditCtrl.js",
        "controller/authority/roleManageCtrl.js",
    
        "controller/7200config/ntpCtrl.js",
        "controller/7200config/ntpWhitelistCtrl.js",
        "controller/7200config/ntpBlacklistCtrl.js",
        "controller/7200config/ntpServerCtrl.js",
        "controller/7200config/ntpUserlistCtrl.js",
        "controller/7200config/inputOutputCtrl.js",
        "controller/7200config/gnss1Ctrl.js",
        "controller/7200config/gnss2Ctrl.js",
        "controller/7200config/alarmConfigTableCtrl.js",
        "controller/7200config/alarmStatusTableCtrl.js",
        "controller/7200config/IPETHCtrl.js",
    
        "controller/7200config/boardConfigCtrl.js",
        "controller/7200config/inventoryGroupCtrl.js",
        "controller/7200config/boardConfigCtrl.js",
        "controller/7200config/rebootCtrl.js",
        "controller/7200config/imageCtrl.js",
        "controller/7200config/upgradeCtrl.js",
        "controller/7200config/otherCtrl.js",
        "controller/7200config/refOffsetHistoryTableCtrl.js",
        "controller/7200config/refConfigTableCtrl.js",
        "controller/7200config/snmpUserTableCtrl.js",
        "controller/7200config/snmpManagerTableCtrl.js",
        "controller/7200config/snmpConfigCtrl.js",
        "controller/7200config/refConfigTablePriorityCtrl.js",


        "controller/sm2000GNconfig/alarmModleCtrl.js",
        "controller/sm2000GNconfig/alarmModleSubCtrl.js",
        "controller/sm2000GNconfig/IPETHCtrl.js",
        "controller/sm2000GNconfig/vlanCtrl.js",
        "controller/sm2000GNconfig/ntpconfigCtrl.js",
        "controller/sm2000GNconfig/ntpprobeCtrl.js",
        "controller/sm2000GNconfig/ntpstatusCtrl.js",
        "controller/sm2000GNconfig/ptpProbeCtrl.js",
        "controller/sm2000GNconfig/ptpMulticastCtrl.js",
        "controller/sm2000GNconfig/ptpUnicastClientCtrl.js",
        "controller/sm2000GNconfig/ptpCommonCtrl.js",
        "controller/sm2000GNconfig/ReferenceCtrl.js",
        "controller/sm2000GNconfig/gnss1Ctrl.js",
        "controller/sm2000GNconfig/gnss2Ctrl.js",
        "controller/sm2000GNconfig/ppstodCtrl.js",
        "controller/sm2000GNconfig/otherCtrl.js",
        "controller/sm2000GNconfig/inputOutputCtrl.js",
        "controller/sm2000GNconfig/rebootCtrl.js",
        "controller/sm2000GNconfig/upgradeCtrl.js",
        "controller/sm2000GNconfig/BackupCtrl.js",
        "controller/sm2000GNconfig/imageCtrl.js",
        "controller/sm2000GNconfig/OutputCardCtrl.js",
        "controller/sm2000GNconfig/inputCardCtrl.js",
        "controller/sm2000GNconfig/outputCardE1PConfigCtrl.js",
        "controller/sm2000GNconfig/outputCardppstodConfigCtrl.js",
        "controller/sm2000GNconfig/vlanAddCtrl.js",
        "controller/sm2000GNconfig/outE12048configCtrl.js",

        "controller/ssuconfig/ssucCtrl.js",
        "controller/ssuconfig/ssucCardCtrl.js",
        "controller/ssuconfig/ssucCardEditAddCtrl.js",
    

        "controller/config/outputCardConfigCtrl.js",
        "controller/config/outputCardPTPConfigCtrl.js",
        "controller/config/outputCardppstodConfigCtrl.js",
        "controller/config/outputCardE1PConfigCtrl.js",
        "controller/config/outputCardE1pExp1ConfigCtrl.js",
        "controller/config/outputCardE1pExp2ConfigCtrl.js",
        "controller/config/outputCardE1pExp3ConfigCtrl.js",
        "controller/config/outputCardE1pExp4ConfigCtrl.js",
        "controller/config/vlanAddCtrl.js",
        "controller/config/imageInfoCtrl.js",
    
        "controller/config/inputPtp/inputPtpCtrl.js",
        "controller/config/inputPtp/inputPtpInventoryCtrl.js",
        "controller/config/inputPtp/inputPtpimageCtrl.js",
        "controller/config/inputPtp/inputPtpNetworkCtrl.js",
        "controller/config/inputPtp/inputPtpCommonCtrl.js",
        "controller/config/inputPtp/inputPtpClientCtrl.js",
        "controller/config/inputPtp/inputPtpClockStatusCtrl.js",
        "controller/config/inputPtp/inputPtpStatusCtrl.js",
        "controller/config/inputPtp/inputPtpNetworkStartusCtrl.js",
        "controller/config/inputPtp/inputPtpconfigManageCtrl.js",
        "controller/config/inputPtp/inputPtprestartCtrl.js",


        "controller/config/outputNTP/outputNTPWhitelistCtrl.js",
        "controller/config/outputNTP/outputNTPStatusCtrl.js",
        "controller/config/outputNTP/outputNTPrestartCtrl.js",
        "controller/config/outputNTP/outputNTPNetworkCtrl.js",
        "controller/config/outputNTP/outputNTPInventoryCtrl.js",
        "controller/config/outputNTP/outputNTPimageCtrl.js",
        "controller/config/outputNTP/outputNTPboardConfigCtrl.js",
        "controller/config/outputNTP/outputNTPBlacklistCtrl.js",
        "controller/config/outputNTP/outputNTPAuthenticaConfigCtrl.js",
        "controller/config/outputNTP/outputNTPCtrl.js",
    
        "controller/ts3100Config/ts3100CCtrl.js",

        "controller/other/otherSoundCtrl.js",
        "controller/other/otherlockFrameCtrl.js",
        "controller/other/otherlockFrameConfigCtrl.js",
        "controller/other/otherPingCtrl.js",
        "controller/other/otherNetworkUpgradeCtrl.js",
        "controller/other/otherLanguageCtrl.js",
        "controller/other/passwordRuleCtrl.js",
        "controller/performanceCtrl.js",

        "controller/performance/performanceChartCtrl.js",
        "controller/performance/performanceChartM1Ctrl.js",
        "controller/performance/performanceTableCtrl.js",
        "controller/performance/performanceConfigCtrl.js",
        "controller/performance/performanceConfigEditAddCtrl.js"
    ],
    images: [
        "static/images/*",
        "static/css/images/*",
        "static/js/plugin/img/*",
        "static/js/plugin/treeview/images/*",
        "static/js/plugin/selectseach/images/*.png"
    ],
    css: [
        "css/bootstrap.min.css",
        "css/tree-control.css",
        "css/tree-control-attribute.css",
        "css/jsPlumbToolkit-defaults.css",
        "css/jsPlumbToolkit-demo.css",
        "css/demo.css",
        "css/ngDialog.min.css",
        "css/ngDialog-theme-default.min.css",
        "css/ngDialog-theme-plain.min.css",
        "css/ngDialog-theme-flat.css",
        "css/loading-bar.css",
        "css/angular-ui-switch.css",
        "css/isteven-multi-select.css",
        "css/index.css",
        "css/windowsLock/zzsc.css",
        "css/windowsLock/me-pageloading.min.css"
    ]
};

gulp.task("images", function(){
    return gulp.src(paths.images)
        .pipe(imagemin({ optimizationLevel: 3, progressive: true, interlaced: true }))
        .pipe(gulp.dest("v1/images"))
});
// 合并、压缩、重命名css
gulp.task("minifycss", function(){
    return gulp.src(paths.css)
        .pipe(minifycss())
        .pipe(concat("all.min.css"))
        .pipe(gulp.dest("v1/css"));
});
// 检查js
gulp.task("lint", function(){
    return gulp.src(paths.scripts)
        .pipe(jshint())
        .pipe(jshint.reporter("default"));
});
// 合并，压缩js文件
gulp.task("javascripts", function(){
    return gulp.src(paths.scripts)
        .pipe(uglify({
            //mangle: false,//类型：Boolean 默认：true 是否修改变量名
            mangle: {except: ["$timeout", "$scope", "$http", "publicService",'$rootScope']}//排除混淆关键字
        }))
        .pipe(concat("all.min.js"))
        .pipe(gulp.dest("v1/js"));
});

gulp.task("watch", function() {
  gulp.watch(paths.scripts, ["javascripts"]);
  gulp.watch(paths.css, ["minifycss"]);
});

// 默认任务
gulp.task("default", ["minifycss","javascripts", "watch"]);

// css + js
gulp.task("d", ["minifycss","javascripts",]);
