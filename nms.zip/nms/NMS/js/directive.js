routerApp.directive('tmPagination', [function() {
    return {
        restrict: 'EA',
        template: '<div class="page-list">' +
            '<ul class="pagination" ng-show="conf.totalItems > 0">' +
            '<li ng-class="{disabled: conf.currentPage == 1}" ng-click="prevPage()"><span>&laquo;</span></li>' +
            '<li ng-repeat="item in pageList track by $index" ng-class="{active: item == conf.currentPage, separate: item == \'...\'}" ' +
            'ng-click="changeCurrentPage(item)">' +
            '<span>{{ item }}</span>' +
            '</li>' +
            '<li ng-class="{disabled: conf.currentPage == conf.numberOfPages}" ng-click="nextPage()"><span>&raquo;</span></li>' +
            '</ul>' +
            '<div class="page-total" style="margin: 23px 20px;" ng-show="conf.totalItems > 0">' +
            '<select ng-model="conf.itemsPerPage" ng-options="option for option in conf.perPageOptions " ng-change="changeItemsPerPage()"></select>' +
            '<sp translate="TOTALE"></sp><strong> {{ conf.totalItems }}</strong>，' +
            '<span translate="TO_"></span><input type="text" ng-model="jumpPageNum" style="padding-left: 14px;" /><span translate="PAGE"></span><button class="btn btn-primary btn-xs" style="margin-bottom: 4px;" ng-click="jumpToPage()">GO</button>' +
            '</div>' +
            // '<div class="no-items" ng-show="conf.totalItems <= 0">暂无数据</div>' +
            '</div>',
        replace: true,
        scope: {
            conf: '='
        },
        link: function(scope, element, attrs) {
            // 变更当前页
            scope.changeCurrentPage = function(item) {
                if (item == '...') {
                    return;
                } else {
                    scope.conf.currentPage = item;
                    ax();
                }
            };

            // 定义分页的长度必须为奇数 (default:9)
            scope.conf.pagesLength = parseInt(scope.conf.pagesLength) ? parseInt(scope.conf.pagesLength) : 9;
            if (scope.conf.pagesLength % 2 === 0) {
                // 如果不是奇数的时候处理一下
                scope.conf.pagesLength = scope.conf.pagesLength - 1;
            }

            // conf.erPageOptions
            if (!scope.conf.perPageOptions) {
                scope.conf.perPageOptions = [10, 15, 20, 30, 50];
            }

            // pageList数组
            function getPagination() {
                // conf.currentPage
                scope.conf.currentPage = parseInt(scope.conf.currentPage) ? parseInt(scope.conf.currentPage) : 1;
                // conf.totalItems
                scope.conf.totalItems = parseInt(scope.conf.totalItems);

                // conf.itemsPerPage (default:15)
                // 先判断一下本地存储中有没有这个值
                if (scope.conf.rememberPerPage) {
                    // if(!parseInt(localStorage[scope.conf.rememberPerPage])){
                    //     localStorage[scope.conf.rememberPerPage] = parseInt(scope.conf.itemsPerPage) ? parseInt(scope.conf.itemsPerPage) : 15;
                    // }

                    // scope.conf.itemsPerPage = parseInt(localStorage[scope.conf.rememberPerPage]);


                } else {
                    scope.conf.itemsPerPage = parseInt(scope.conf.itemsPerPage) ? parseInt(scope.conf.itemsPerPage) : 15;
                }

                // numberOfPages
                scope.conf.numberOfPages = Math.ceil(scope.conf.totalItems / scope.conf.itemsPerPage);

                // judge currentPage > scope.numberOfPages
                if (scope.conf.currentPage < 1) {
                    scope.conf.currentPage = 1;
                }

                if (scope.conf.currentPage > scope.conf.numberOfPages) {
                    scope.conf.currentPage = scope.conf.numberOfPages;
                }

                // jumpPageNum
                scope.jumpPageNum = scope.conf.currentPage;

                // 如果itemsPerPage在不在perPageOptions数组中，就把itemsPerPage加入这个数组中
                var perPageOptionsLength = scope.conf.perPageOptions.length;
                // 定义状态
                var perPageOptionsStatus;
                for (var i = 0; i < perPageOptionsLength; i++) {
                    if (scope.conf.perPageOptions[i] == scope.conf.itemsPerPage) {
                        perPageOptionsStatus = true;
                    }
                }
                // 如果itemsPerPage在不在perPageOptions数组中，就把itemsPerPage加入这个数组中
                if (!perPageOptionsStatus) {
                    scope.conf.perPageOptions.push(scope.conf.itemsPerPage);
                }

                // 对选项进行sort
                scope.conf.perPageOptions.sort(function(a, b) {
                    return a - b
                });

                scope.pageList = [];
                if (scope.conf.numberOfPages <= scope.conf.pagesLength) {
                    // 判断总页数如果小于等于分页的长度，若小于则直接显示
                    for (i = 1; i <= scope.conf.numberOfPages; i++) {
                        scope.pageList.push(i);
                    }
                } else {
                    // 总页数大于分页长度（此时分为三种情况：1.左边没有...2.右边没有...3.左右都有...）
                    // 计算中心偏移量
                    var offset = (scope.conf.pagesLength - 1) / 2;
                    if (scope.conf.currentPage <= offset) {
                        // 左边没有...
                        for (i = 1; i <= offset + 1; i++) {
                            scope.pageList.push(i);
                        }
                        scope.pageList.push('...');
                        scope.pageList.push(scope.conf.numberOfPages);
                    } else if (scope.conf.currentPage > scope.conf.numberOfPages - offset) {
                        scope.pageList.push(1);
                        scope.pageList.push('...');
                        for (i = offset + 1; i >= 1; i--) {
                            scope.pageList.push(scope.conf.numberOfPages - i);
                        }
                        scope.pageList.push(scope.conf.numberOfPages);
                    } else {
                        // 最后一种情况，两边都有...
                        scope.pageList.push(1);
                        scope.pageList.push('...');

                        for (i = Math.ceil(offset / 2); i >= 1; i--) {
                            scope.pageList.push(scope.conf.currentPage - i);
                        }
                        scope.pageList.push(scope.conf.currentPage);
                        for (i = 1; i <= offset / 2; i++) {
                            scope.pageList.push(scope.conf.currentPage + i);
                        }

                        scope.pageList.push('...');
                        scope.pageList.push(scope.conf.numberOfPages);
                    }
                }
                scope.$parent.conf = scope.conf;
            }

            // prevPage
            scope.prevPage = function() {
                if (scope.conf.currentPage > 1) {
                    scope.conf.currentPage -= 1;
                    ax();
                }
            };
            // nextPage
            scope.nextPage = function() {
                if (scope.conf.currentPage < scope.conf.numberOfPages) {
                    scope.conf.currentPage += 1;
                    ax();
                }
            };

            // 跳转页
            scope.jumpToPage = function() {
                typeof scope.jumpPageNum === "number" && (scope.jumpPageNum += "");
                scope.jumpPageNum = scope.jumpPageNum.replace(/[^0-9]/g, '');
                if (scope.jumpPageNum > scope.conf.numberOfPages) return;
                if (scope.jumpPageNum !== '') {
                    scope.conf.currentPage = scope.jumpPageNum;
                    ax();
                }
            };

            // 修改每页显示的条数
            scope.changeItemsPerPage = function() {
                if (scope.conf.rememberPerPage) {
                    scope.conf.currentPage = 1
                    ax();
                }
            };

            scope.$watch(function() {
                var newValue = scope.conf.currentPage + ' ' + scope.conf.totalItems + ' ';
                newValue += scope.conf.itemsPerPage;
                return newValue;
            }, getPagination);

            function ax() {
                if (scope.conf.onChange) {
                    scope.conf.onChange();
                }
            }
            ax();
        }
    };
}]);

routerApp.directive('toggleClass', function() {
    return {
        restrict: 'A',
        scope: {
            toggleClass: '@'
        },
        link: function($scope, $element) {
            $element.on('click', function() {
                $element.parent().parent().find('a').removeClass("activeOneMenu");
                $element.addClass('activeOneMenu');
            });
        }
    };
});
routerApp.directive('datatogg', function() {
    return {
        restrict: 'A',
        scope: {
            dataTogg: '@'
        },
        link: function(scope, element) {
            var mapUlr = localStorage.getItem("mapUlr");
            // if (mapUlr) {
            //     angular.element(document.getElementById("canvas")).css({
            //         "background": "url(" + 'http://' + location.host + '/mapImg/' + mapUlr + ") no-repeat",
            //         'background-size': "100% 100%"
            //     })
            // }
            angular.element(document.getElementById("tuopu_canvas")).css({
                "background": mapUlr ? "url(" + 'http://' + location.host + '/mapImg/' + mapUlr + ") no-repeat" : '#c7c1c1',
                'background-size': "100% 100%"
            })
            element.on('click', function(e) {
                if (element.find('ul').hasClass('btnFlagHide')) {
                    element.find('ul').removeClass('btnFlagHide');
                    element.find('ul').addClass('btnFlagShow');
                } else if (element.find('ul').hasClass('btnFlagShow')) {
                    element.find('ul').removeClass('btnFlagShow');
                    element.find('ul').addClass('btnFlagHide');
                }
                e.stopPropagation();
            });
        }
    };
});
routerApp.directive('deviceFrame', function() {
    return {
        restrict: 'A',
        link: function(scope, element) {
            var slot = scope.$index;
                scope.$watch("frameList", function(a, b) {

                    scope.$watch("deviceType", function(c, d) {
                        var list = a;
                        var DEVICE_CUR_TYPE = c;
                        if (list && list.length > 0) {
                            for (var i = 0; i < list.length; i++) {
                                if (list[i].index == slot) {
                                    if (list[i].card !== null) {
                                        if (DEVICE_CUR_TYPE == 'SSU2000') { //判断ssu
                                            element.append(cardObj.choseCard(list[i].card.cardLed.ledList, list[i].card.type, DEVICE_CUR_TYPE));
                                        } else if (DEVICE_CUR_TYPE == 'STFS1000' || DEVICE_CUR_TYPE == 'TP1000' || DEVICE_CUR_TYPE == 'HP55400' ) {
                                            element.append(cardObj.choseCard(list[i].card.cardLed.ledList, list[i].card.type, DEVICE_CUR_TYPE));
                                        } else if (DEVICE_CUR_TYPE == 'LF7300') {
                                            element.append(cardObj.choseCard(list[i].card.cardLed.ledList, list[i].card.type, DEVICE_CUR_TYPE));
                                        } else if (DEVICE_CUR_TYPE == 'TS3000G') {
                                            element.append(cardObj.choseCard(list[i].card.cardLed.ledList,'', DEVICE_CUR_TYPE));
                                        }else {
                                            element.append(cardObj.choseCard(list[i].card.cardLed, list[i].card.type, DEVICE_CUR_TYPE));
                                        }
                                    } else {
                                        if (list.length == 12) {
                                            if (slot == 0 || slot == 1) {
                                                element.append(cardObj.cardNullcc());
                                            } else {
                                                element.append(cardObj.cardNull());
                                            }
                                        } else {
                                            element.append(cardObj.cardNull());
                                        }
                                    }
                                    break;
                                }
                            }
                        }
                    })
                })
                  scope.$last && element.css('border-right', "1px solid black");
        }
    };
});

routerApp.directive('ngRightClick', function($parse) {
    return function(scope, element, attrs) {
        var fn = $parse(attrs.ngRightClick);
        element.bind('contextmenu', function(event) {
            scope.$apply(function() {
                event.preventDefault();
                fn(scope, {
                    $event: event
                });
            });
        });
    };
});

//$scope.$on('ngRepeatFinished', function (ngRepeatFinishedEvent) {指令DOM加载后运行});
routerApp.directive('menuplug', function($timeout) {
    return {
        restrict: 'AE',
        scope: {},
        link: function(scope, element, attr) {
            scope.tog = false;
            element.children().eq(0).on('click', function(e) {
                // element.parent().children('li').removeClass('active');
                // element.addClass('active');
                if (scope.tog) {
                    element.children().eq(0).removeClass('collapsed');
                    element.children().eq(0).find("span").removeClass('glyphicon-chevron-down');
                    element.children().eq(0).find("span").addClass('glyphicon-chevron-up');
                    element.children().eq(1).removeClass('in');
                } else {
                    element.children().eq(0).addClass('collapsed');
                    element.children().eq(0).find("span").removeClass('glyphicon-chevron-up');
                    element.children().eq(0).find("span").addClass('glyphicon-chevron-down');
                    element.children().eq(1).addClass('in');
                }
                scope.tog = !scope.tog;
            });
        }
    };
});

routerApp.directive('ngThumb', ['$window', function($window) {
    var helper = {
        support: !!($window.FileReader && $window.CanvasRenderingContext2D),
        isFile: function(item) {
            return angular.isObject(item) && item instanceof $window.File;
        },
        isImage: function(file) {
            var type = '|' + file.type.slice(file.type.lastIndexOf('/') + 1) + '|';
            return '|jpg|png|jpeg|bmp|gif|'.indexOf(type) !== -1;
        }
    };

    return {
        restrict: 'A',
        template: '<canvas/>',
        link: function(scope, element, attributes) {
            if (!helper.support) return;

            var params = scope.$eval(attributes.ngThumb);

            if (!helper.isFile(params.file)) return;
            if (!helper.isImage(params.file)) return;

            var canvas = element.find('canvas');
            var reader = new FileReader();

            reader.onload = onLoadFile;
            reader.readAsDataURL(params.file);

            function onLoadFile(event) {
                var img = new Image();
                img.onload = onLoadImage;
                img.src = event.target.data;
            }

            function onLoadImage() {
                var width = params.width || this.width / this.height * params.height;
                var height = params.height || this.height / this.width * params.width;
                canvas.attr({
                    width: width,
                    height: height
                });
                canvas[0].getContext('2d').drawImage(this, 0, 0, width, height);
            }
        }
    };
}]);



    routerApp.directive('ngFile', ['$parse', function ($parse) {
        return {
            restrict: 'A',
            link: function (scope, element, attrs) {
                var model = $parse(attrs.ngFile);
                var modelSetter = model.assign;

                element.bind('change', function () {
                    scope.$apply(function () {
                        modelSetter(scope, element[0].files);
                    });
                });
            }
        };
    }]);

    routerApp.directive('ngRightClick', ['$parse', function ($parse) {
        return function (scope, element, attrs) {
            var fn = $parse(attrs.ngRightClick);
            element.bind('contextmenu', function (event) {
                scope.$apply(function () {
                    event.preventDefault();
                    fn(scope, {$event: event});
                });
            });
        };
    }]);

    //routerApp.value('extraObj', null);

    routerApp.directive("jqueryUpload", ["fileNavigator", function (fileNavigator) {
        return {
            require: '?ngModel',
            restrict: 'A',
            link: function ($scope, element, attrs, ngModel) {
                extraObj = $(element).uploadFile({
                    url: "uploadFile",
                    fileName: "file",
                    showFileSize: true,
                    showDelete: true,
                    autoSubmit: false,
                    statusBarWidth: "auto",
                    dragdropWidth: "auto",
                    dragdropHeight: 200,
                    uploadStr: "选择",
                    cancelStr: "取消",
                    "abortStr": "终止",
                    "deleteStr": "删除",
                    dynamicFormData: function () {
                        var data = {"path": $scope.fileNavigator.currentPath.join('/')};
                        return data;
                    },
                    onSuccess: function (files, data, xhr, pd) {
                        var obj = eval(data);

                        if (obj.success) {
                            $scope.fileNavigator.refresh();
                        } else {
                            pd.progressDiv.hide();
                            pd.statusbar.append("<span class='ajax-file-upload-error'>ERROR: " + obj.error + "</span>");
                        }
                    }
                });
            }
        };
    }]);

routerApp.factory('item', ['$http', '$q', '$translate', 'fileManagerConfig','$rootScope',  function ($http, $q, $translate, fileManagerConfig, $rootScope) {

        var Item = function (model, path) {
            var rawModel = {
                name: model && model.name || '',
                path: path || [],
                type: model && model.type || 'file',
                size: model && parseInt(model.size || 0),
                date: parseMySQLDate(model && model.date),
                perms: '',
                content: model && model.content || '',
                recursive: false,
                sizeKb: function () {
                    var sizeKB = Math.ceil(this.size / 1024);

                    return formatSize(sizeKB, 0);
                    //return Math.round(this.size / 1024, 1);
                },
                fullPath: function () {
                    return ('/' + this.path.join('/') + '/' + this.name).replace(/\/\//, '/');
                }
            };

            this.error = '';
            this.inprocess = false;

            this.model = angular.copy(rawModel);
            this.tempModel = angular.copy(rawModel);

            function parseMySQLDate(mysqlDate) {
                var d = (mysqlDate || '').toString().split(/[- :]/);
                return new Date(d[0], d[1] - 1, d[2], d[3], d[4], d[5]);
            }

            function formatSize(s) {
                s = s + "";
                var l = s.split("").reverse();
                var t = "";
                for (var i = 0; i < l.length; i++) {
                    t += l[i] + ((i + 1) % 3 == 0 && (i + 1) != l.length ? "," : "");
                }
                return t.split("").reverse().join("");
            }
        };

        Item.prototype.update = function () {
            angular.extend(this.model, angular.copy(this.tempModel));
        };

        Item.prototype.revert = function () {
            angular.extend(this.tempModel, angular.copy(this.model));
            this.error = '';
        };

        Item.prototype.deferredHandler = function (data, deferred, defaultMsg) {
            if (!data || typeof data !== 'object') {
                this.error = 'Bridge response error, please check the docs';
            }
            if (data.data && data.data.error) {
                this.error = data.data.error;
            }
            if (!this.error && data.error) {
                this.error = data.error.message;
            }
            if (!this.error && defaultMsg) {
                this.error = defaultMsg;
            }
            if (this.error) {
                return deferred.reject(data);
            }
            this.update();
            return deferred.resolve(data);
        };

        Item.prototype.createFolder = function () {
            var self = this;
            var deferred = $q.defer();
            var data = {
                params: {
                    mode: 'addfolder',
                    path: self.tempModel.path.join('/'),
                    name: self.tempModel.name
                }
            };

            self.inprocess = true;
            self.error = '';
            $http.post(fileManagerConfig.createFolderUrl+'?token='+ $rootScope.curLoginMsg.sessionID, data).success(function (data) {
                self.deferredHandler(data, deferred);
            }).error(function (data) {
                self.deferredHandler(data, deferred, $translate.instant('error_creating_folder'));
            })['finally'](function () {
                self.inprocess = false;
            });

            return deferred.promise;
        };

        Item.prototype.rename = function () {
            var self = this;
            var deferred = $q.defer();
            var data = {
                params: {
                    mode: 'rename',
                    path: self.model.fullPath(),
                    newPath: self.tempModel.fullPath()
                }
            };
            self.inprocess = true;
            self.error = '';
            $http.post(fileManagerConfig.renameUrl, data).success(function (data) {
                self.deferredHandler(data, deferred);
            }).error(function (data) {
                self.deferredHandler(data, deferred, $translate.instant('error_renaming'));
            })['finally'](function () {
                self.inprocess = false;
            });
            return deferred.promise;
        };

        Item.prototype.copy = function () {
            var self = this;
            var deferred = $q.defer();
            var data = {
                params: {
                    mode: 'copy',
                    path: self.model.fullPath(),
                    newPath: self.tempModel.fullPath()
                }
            };

            self.inprocess = true;
            self.error = '';
            $http.post(fileManagerConfig.copyUrl, data).success(function (data) {
                self.deferredHandler(data, deferred);
            }).error(function (data) {
                self.deferredHandler(data, deferred, $translate.instant('error_copying'));
            })['finally'](function () {
                self.inprocess = false;
            });
            return deferred.promise;
        };

        Item.prototype.compress = function () {
            var self = this;
            var deferred = $q.defer();
            var data = {
                params: {
                    mode: 'compress',
                    path: self.model.fullPath(),
                    destination: self.tempModel.fullPath()
                }
            };

            self.inprocess = true;
            self.error = '';
            $http.post(fileManagerConfig.compressUrl, data).success(function (data) {
                self.deferredHandler(data, deferred);
            }).error(function (data) {
                self.deferredHandler(data, deferred, $translate.instant('error_compressing'));
            })['finally'](function () {
                self.inprocess = false;
            });
            return deferred.promise;
        };

        Item.prototype.extract = function () {
            var self = this;
            var deferred = $q.defer();
            var data = {
                params: {
                    mode: 'extract',
                    path: self.model.fullPath(),
                    sourceFile: self.model.fullPath(),
                    destination: self.tempModel.fullPath()
                }
            };

            self.inprocess = true;
            self.error = '';
            $http.post(fileManagerConfig.extractUrl, data).success(function (data) {
                self.deferredHandler(data, deferred);
            }).error(function (data) {
                self.deferredHandler(data, deferred, $translate.instant('error_extracting'));
            })['finally'](function () {
                self.inprocess = false;
            });
            return deferred.promise;
        };

        Item.prototype.getUrl = function (preview) {
            var path = this.model.fullPath();
            var data = {
                mode: 'download',
                preview: preview,
                path: path
            };
            return path && [fileManagerConfig.downloadFileUrl, $.param(data)].join('?');
        };

        Item.prototype.download = function (preview) {
            if (this.model.type !== 'dir') {


                //console.log(this.getUrl());
                /*var path = this.model.fullPath();

                var aLink = document.createElement('a');

                var evt = document.createEvent("HTMLEvents");
                evt.initEvent("click", false, false);//initEvent 不加后两个参数在FF下会报错, 感谢 Barret Lee 的反馈
                //aLink.download = fileName;
                aLink.href = "uploadFiles" + path;
                aLink.target="_blank";
                aLink.download = "" + this.model.name;
                aLink.dispatchEvent(evt);*/

                //window.open(this.getUrl(preview), '_blank', '');



                //window.open("uploadFiles" + path, '_blank', '');

               // downloadFile(path, "uploadFiles" + path);

                //var path = this.model.fullPath();
                //downloadFile2("uploadFiles" + path);
                //window.location.assign("uploadFiles" + path);

                window.open(this.getUrl(preview), '_blank', '');


            }
        };


        function  downloadFile2(sUrl) {

            var isChrome = navigator.userAgent.toLowerCase().indexOf('chrome') > -1;
            var isSafari =  navigator.userAgent.toLowerCase().indexOf('safari') > -1;

                //If in Chrome or Safari - download via virtual link click
                if (isChrome || isSafari) {
                    //Creating new link node.
                    var link = document.createElement('a');
                    link.href = sUrl;

                    if (link.download !== undefined){
                        //Set HTML5 download attribute. This will prevent file from opening if supported.
                        var fileName = sUrl.substring(sUrl.lastIndexOf('/') + 1, sUrl.length);
                        link.download = fileName;
                    }

                    //Dispatching click event.
                    if (document.createEvent) {
                        var e = document.createEvent('MouseEvents');
                        e.initEvent('click' ,true ,true);
                        link.dispatchEvent(e);
                        return true;
                    }
                }

                // Force file download (whether supported by server).
                var query = '?download';

                window.open(sUrl + query);

        }


        function downloadFile(fileName, content){

            var aLink = document.createElement('a');
            var blob = new Blob([content]);
            var evt = document.createEvent("HTMLEvents");
            evt.initEvent("click", false, false);//initEvent 不加后两个参数在FF下会报错, 感谢 Barret Lee 的反馈
            aLink.download = fileName;
            aLink.href = URL.createObjectURL(blob);
            aLink.dispatchEvent(evt);
        }

        Item.prototype.getContent = function () {
            var self = this;
            var deferred = $q.defer();
            var data = {
                params: {
                    mode: 'editfile',
                    path: self.tempModel.fullPath()
                }
            };

            self.inprocess = true;
            self.error = '';
            $http.post(fileManagerConfig.getContentUrl, data).success(function (data) {
                self.tempModel.content = self.model.content = data.data;
                self.deferredHandler(data, deferred);
            }).error(function (data) {
                self.deferredHandler(data, deferred, $translate.instant('error_getting_content'));
            })['finally'](function () {
                self.inprocess = false;
            });
            return deferred.promise;
        };

        Item.prototype.remove = function () {
            var self = this;
            var deferred = $q.defer();
            var data = {
                params: {
                    mode: 'delete',
                    path: self.tempModel.fullPath()
                }
            };

            self.inprocess = true;
            self.error = '';
            $http.post(fileManagerConfig.removeUrl, data).success(function (data) {
                self.deferredHandler(data, deferred);
            }).error(function (data) {
                self.deferredHandler(data, deferred, $translate.instant('error_deleting'));
            })['finally'](function () {
                self.inprocess = false;
            });
            return deferred.promise;
        };

        Item.prototype.edit = function () {
            var self = this;
            var deferred = $q.defer();
            var data = {
                params: {
                    mode: 'savefile',
                    content: self.tempModel.content,
                    path: self.tempModel.fullPath()
                }
            };

            self.inprocess = true;
            self.error = '';

            $http.post(fileManagerConfig.editUrl, data).success(function (data) {
                self.deferredHandler(data, deferred);
            }).error(function (data) {
                self.deferredHandler(data, deferred, $translate.instant('error_modifying'));
            })['finally'](function () {
                self.inprocess = false;
            });
            return deferred.promise;
        };

        Item.prototype.changePermissions = function () {
            var self = this;
            var deferred = $q.defer();
            var data = {
                params: {
                    mode: 'changepermissions',
                    path: self.tempModel.fullPath(),
                    perms: self.tempModel.perms.toOctal(),
                    permsCode: self.tempModel.perms.toCode(),
                    recursive: self.tempModel.recursive
                }
            };

            self.inprocess = true;
            self.error = '';
            $http.post(fileManagerConfig.permissionsUrl, data).success(function (data) {
                self.deferredHandler(data, deferred);
            }).error(function (data) {
                self.deferredHandler(data, deferred, $translate.instant('error_changing_perms'));
            })['finally'](function () {
                self.inprocess = false;
            });
            return deferred.promise;
        };

        Item.prototype.isFolder = function () {
            return this.model.type === 'dir' || this.model.type === 'disk';
        };

        Item.prototype.isEditable = function () {
            return !this.isFolder() && fileManagerConfig.isEditableFilePattern.test(this.model.name);
        };

        Item.prototype.isImage = function () {
            return fileManagerConfig.isImageFilePattern.test(this.model.name);
        };

        Item.prototype.isCompressible = function () {
            return this.isFolder();
        };

        Item.prototype.isExtractable = function () {
            return !this.isFolder() && fileManagerConfig.isExtractableFilePattern.test(this.model.name);
        };

        return Item;
    }]);



    routerApp.filter('strLimit', ['$filter', function($filter) {
        return function(input, limit) {
            if (input.length <= limit) {
                return input;
            }
            return $filter('limitTo')(input, limit) + '...';
        };
    }]);

    routerApp.filter('formatDate', ['$filter', function() {
        return function(input) {
            return input instanceof Date ?
                input.toISOString().substring(0, 19).replace('T', ' ') :
                (input.toLocaleString || input.toString).apply(input);
        };
    }]);

   routerApp.provider('fileManagerConfig', function() {

        var values = {
            appName: 'https://github.com/joni2back/angular-filemanager',
            defaultLang: 'cn',

            sidebar: true,
            breadcrumb: true,
            allowedActions: {
                upload: true,
                rename: true,
                copy: true,
                edit: true,
                changePermissions: true,
                compress: true,
                compressChooseName: true,
                extract: true,
                download: true,
                preview: true,
                remove: true,
                qrcode:true
            },

            enablePermissionsRecursive: true,
            compressAsync: true,
            extractAsync: true,

            isEditableFilePattern: /\.(txt|html?|aspx?|ini|pl|py|md|css|js|log|htaccess|htpasswd|json|sql|xml|xslt?|sh|rb|as|bat|cmd|coffee|php[3-6]?|java|c|cbl|go|h|scala|vb)$/i,
            isImageFilePattern: /\.(jpe?g|gif|bmp|png|svg|tiff?)$/i,
            isExtractableFilePattern: /\.(gz|tar|rar|g?zip)$/i,
            tplPath: 'src/templates'
        };

        return { 
            $get: function() {
                return values;
            }, 
            set: function (constants) {
                angular.extend(values, constants);
            }
        };
    
    });
routerApp.service('fileNavigator', [
        '$http', '$q','$rootScope', 'fileManagerConfig', 'item', function ($http, $q,$rootScope, fileManagerConfig, Item) {

        $http.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';

        var FileNavigator = function() {
            this.requesting = false;
            this.fileList = [];
            this.currentPath = [];
            this.history = [];
            this.error = '';
        };

        FileNavigator.prototype.deferredHandler = function(data, deferred, defaultMsg) {
            if (!data || typeof data !== 'object') {
                this.error = 'Bridge response error, please check the docs';
            }
            if (!this.error && data.data && data.data.error) {
                this.error = data.data.error;
            }
            if (!this.error && data.error) {
                this.error = data.error.message;
            }
            if (!this.error && defaultMsg) {
                this.error = defaultMsg;
            }
            if (this.error) {
                return deferred.reject(data);
            }
            return deferred.resolve(data);
        };

        FileNavigator.prototype.list = function() {
            var self = this;
            var deferred = $q.defer();
            var path = self.currentPath.join('/');
            var data = {params: {
                mode: 'list',
                onlyFolders: false,
                path: '/' + path
            }};

            self.requesting = true;
            self.fileList = [];
            self.error = '';

            $http.post(fileManagerConfig.listUrl+'?token='+ $rootScope.curLoginMsg.sessionID, data).success(function(data) {
                self.deferredHandler(data, deferred);
            }).error(function(data) {
                self.deferredHandler(data, deferred, 'Unknown error listing, check the response');
            })['finally'](function() {
                self.requesting = false;
            });
            return deferred.promise;
        };

        FileNavigator.prototype.refresh = function() {
            var self = this;
            var path = self.currentPath.join('/');
            return self.list().then(function(data) {
                self.fileList = (data.data || []).map(function(file) {
                    return new Item(file, self.currentPath);
                });
                self.buildTree(path);
            });
        };
        
        FileNavigator.prototype.buildTree = function(path) {
            var flatNodes = [], selectedNode = {};

            function recursive(parent, item, path) {
                var absName = path ? (path + '/' + item.model.name) : item.model.name;
                if (parent.name.trim() && path.trim().indexOf(parent.name) !== 0) {
                    parent.nodes = [];
                }
                if (parent.name !== path) {
                    for (var i in parent.nodes) {
                        recursive(parent.nodes[i], item, path);
                    }
                } else {
                    for (var e in parent.nodes) {
                        if (parent.nodes[e].name === absName) {
                            return;
                        }
                    }
                    parent.nodes.push({item: item, name: absName, nodes: []});
                }
                parent.nodes = parent.nodes.sort(function(a, b) {
                    return a.name.toLowerCase() < b.name.toLowerCase() ? -1 : a.name.toLowerCase() === b.name.toLowerCase() ? 0 : 1;
                });
            }

            function flatten(node, array) {
                array.push(node);
                for (var n in node.nodes) {
                    flatten(node.nodes[n], array);
                }
            }

            function findNode(data, path) {
                return data.filter(function (n) {
                    return n.name === path;
                })[0];
            }

            !this.history.length && this.history.push({name: '', nodes: []});
            flatten(this.history[0], flatNodes);
            selectedNode = findNode(flatNodes, path);
            selectedNode.nodes = [];

            for (var o in this.fileList) {
                var item = this.fileList[o];
                item.isFolder() && recursive(this.history[0], item, path);
            }
        };

        FileNavigator.prototype.folderClick = function(item) {
            this.currentPath = [];
            if (item && item.isFolder()) {
                this.currentPath = item.model.fullPath().split('/').splice(1);
            }
            this.refresh();
        };

        FileNavigator.prototype.upDir = function() {
            if (this.currentPath[0]) {
                this.currentPath = this.currentPath.slice(0, -1);
                this.refresh();
            }
        };

        FileNavigator.prototype.goTo = function(index) {
            this.currentPath = this.currentPath.slice(0, index + 1);
            this.refresh();
        };



        return FileNavigator;
    }]);
routerApp.service('fileUploader', ['$http', '$q', 'fileManagerConfig', function ($http, $q, fileManagerConfig) {

        function deferredHandler(data, deferred, errorMessage) {
            if (!data || typeof data !== 'object') {
                return deferred.reject('Bridge response error, please check the docs');
            }
            if (data.data && data.data.error) {
                return deferred.reject(data);
            }
            if (data.error) {
                return deferred.reject(data);
            }
            if (errorMessage) {
                return deferred.reject(errorMessage);
            }
            deferred.resolve(data);
        }

        this.requesting = false;
        this.upload = function(fileList, path) {
            if (! window.FormData) {
                throw new Error('Unsupported browser version');
            }
            var self = this;
            var form = new window.FormData();
            var deferred = $q.defer();
            form.append('destination', '/' + path.join('/'));

            for (var i = 0; i < fileList.length; i++) {
                var fileObj = fileList.item(i);
                fileObj instanceof window.File && form.append('file-' + i, fileObj);
            }

            self.requesting = true;
            $http.post(fileManagerConfig.uploadUrl, form, {
                transformRequest: angular.identity,
                headers: {
                    'Content-Type': undefined
                }
            }).success(function(data) {
                deferredHandler(data, deferred);
            }).error(function(data) {
                deferredHandler(data, deferred, 'Unknown error uploading files');
            })['finally'](function() {
                self.requesting = false;
            });

            return deferred.promise;
        };
    }]);