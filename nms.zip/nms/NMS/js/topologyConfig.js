/*
拓扑图
*/
function loadTopoData(arr) {
    var topology = new Topology('container'),
        nodes = [{
            id: '主机框',
            type: 'switch',
            status: 1,
            server: true
        }],
        links = [];
    for (var i = 0; i < arr.length; i++) {
        var obj = {
                type: 'switch',
                status: 1,
                expand: true,
                id: arr[i]
            },
            os = {
                source: '主机框',
                target: arr[i]
            }
        nodes.push(obj);
        links.push(os)
    }

    topology.addNodes(nodes);
    topology.addLinks(links);
    //可展开节点的点击事件
    // topology.setNodeClickFn(function(node) {
    //     if (!node['_expanded']) {
    //         mainTemplate('macFrame','3067ed6c81ad432ea144934c55051ebe');
    //         expandNode(node.id);
    //         node['_expanded'] = true;
    //     } else {
    //         collapseNode(node.id);
    //         node['_expanded'] = false;
    //     }
    // });
    topology.update();
}

function Topology(ele) {
    typeof(ele) == 'string' && (ele = document.getElementById(ele));
    if (ele.getElementsByTagName("svg") && ele.getElementsByTagName("svg").length > 0) {
        var svg = ele.getElementsByTagName("svg");
        for (var i = 0; i < svg.length; i++) {
            if (svg[i].parentNode) {
                svg[i].parentNode.removeChild(svg[i]);
            }
        }
    }
    var w = ele.clientWidth,
        h = ele.clientHeight,
        self = this;
    this.force = d3.layout.force().gravity(.05).distance(70).charge(-800).size([w, h]);
    this.nodes = this.force.nodes();
    this.links = this.force.links();
    this.clickFn = function() {};
    this.vis = d3.select(ele).append("svg:svg")
        .attr("width", w).attr("height", h).attr("pointer-events", "all");

    this.force.on("tick", function(x) {
        self.vis.selectAll("g.node")
            .attr("transform", function(d) {
                return "translate(" + d.x + "," + d.y + ")";
            });

        self.vis.selectAll("line.link")
            .attr("x1", function(d) {
                return d.source.x;
            })
            .attr("y1", function(d) {
                return d.source.y;
            })
            .attr("x2", function(d) {
                return d.target.x;
            })
            .attr("y2", function(d) {
                return d.target.y;
            });
    });
}


Topology.prototype.doZoom = function() {
    d3.select(this).select('g').attr("transform", "translate(" + d3.event.translate + ")" + " scale(" + d3.event.scale + ")");

}


//增加节点
Topology.prototype.addNode = function(node) {
    this.nodes.push(node);
}

Topology.prototype.addNodes = function(nodes) {
    if (Object.prototype.toString.call(nodes) == '[object Array]') {
        var self = this;
        nodes.forEach(function(node) {
            self.addNode(node);
        });

    }
}

//增加连线
Topology.prototype.addLink = function(source, target) {
    this.links.push({
        source: this.findNode(source),
        target: this.findNode(target)
    });
}

//增加多个连线
Topology.prototype.addLinks = function(links) {
    if (Object.prototype.toString.call(links) == '[object Array]') {
        var self = this;
        links.forEach(function(link) {
            self.addLink(link['source'], link['target']);
        });
    }
}


//删除节点
Topology.prototype.removeNode = function(id) {
    var i = 0,
        n = this.findNode(id),
        links = this.links;
    while (i < links.length) {
        links[i]['source'] == n || links[i]['target'] == n ? links.splice(i, 1) : ++i;
    }
    this.nodes.splice(this.findNodeIndex(id), 1);
}

//删除节点下的子节点，同时清除link信息
Topology.prototype.removeChildNodes = function(id) {
    var node = this.findNode(id),
        nodes = this.nodes;
    links = this.links,
        self = this;

    var linksToDelete = [],
        childNodes = [];

    links.forEach(function(link, index) {
        link['source'] == node && linksToDelete.push(index) && childNodes.push(link['target']);
    });

    linksToDelete.reverse().forEach(function(index) {
        links.splice(index, 1);
    });

    var remove = function(node) {
        var length = links.length;
        for (var i = length - 1; i >= 0; i--) {
            if (links[i]['source'] == node) {
                var target = links[i]['target'];
                links.splice(i, 1);
                nodes.splice(self.findNodeIndex(node.id), 1);
                remove(target);

            }
        }
    }

    childNodes.forEach(function(node) {
        remove(node);
    });

    //清除没有连线的节点
    for (var i = nodes.length - 1; i >= 0; i--) {
        var haveFoundNode = false;
        for (var j = 0, l = links.length; j < l; j++) {
            (links[j]['source'] == nodes[i] || links[j]['target'] == nodes[i]) && (haveFoundNode = true)
        }!haveFoundNode && nodes.splice(i, 1);
    }
}



//查找节点
Topology.prototype.findNode = function(id) {
    var nodes = this.nodes;
    for (var i in nodes) {
        if (nodes[i]['id'] == id) return nodes[i];
    }
    return null;
}


//查找节点所在索引号
Topology.prototype.findNodeIndex = function(id) {
    var nodes = this.nodes;
    for (var i in nodes) {
        if (nodes[i]['id'] == id) return i;
    }
    return -1;
}

//节点点击事件
Topology.prototype.setNodeClickFn = function(callback) {
    this.clickFn = callback;
}

//更新拓扑图状态信息
Topology.prototype.update = function() {
    var link = this.vis.selectAll("line.link")
        .data(this.links, function(d) {
            return d.source.id + "-" + d.target.id;
        })
        .attr("class", function(d) {
            return d['source']['status'] && d['target']['status'] ? 'link' : 'link link_error';
        });

    link.enter().insert("svg:line", "g.node")
        .attr("class", function(d) {
            return d['source']['status'] && d['target']['status'] ? 'link' : 'link link_error';
        });

    link.exit().remove();

    var node = this.vis.selectAll("g.node")
        .data(this.nodes, function(d) {
            return d.id;
        });

    var nodeEnter = node.enter().append("svg:g")
        .attr("class", "node")
        .call(this.force.drag);

    //增加图片，可以根据需要来修改
    var self = this;
    nodeEnter.append("svg:image")
        .attr("class", "circle")
        .attr("xlink:href", function(d) {
            //根据类型来使用图片
            if (d.server) {
                return "images/sm.png";
            } else if (d.expand) {
                return "images/mac.png";
            } else if (d.alarm) {
                return "images/alarm.png";
            } else if (d.alarm2) {
                return "images/alarm2.png";
            } else {
                return "images/site.png";
            }
        })
        .attr("x", "-32px")
        .attr("y", "-32px")
        .attr("width", "54px")
        .attr("height", "54px")
        .on('click', function(d) {
            d.expand && self.clickFn(d);
            d.expand2 && self.clickFn(d);
            d.alarm && self.clickFn(d);
            d.alarm2 && self.clickFn(d);
            // showTopoTemplate("topu");
        })

    nodeEnter.append("svg:text")
        .attr("class", "nodetext")
        .attr("style", "color:#fff")
        .attr("dx", 15)
        .attr("dy", -25)
        .text(function(d) {
            return d.id
        });


    node.exit().remove();

    this.force.start();
}



function expandNode(id) {
    topology.addLinks(childLinks);
    topology.update();
}

function collapseNode(id) {
    topology.removeChildNodes(id);
    topology.update();
}

/*卡*/
var cardObj = {
    imgX: function(i) {
        var str = "";
        if (i == '0') {
            str = '<img style="width:15px;" src="images/gery.png" alt="" />';
        } else if (i == '1') {
            str = '<img style="width:15px;" src="images/green.PNG" alt="" />';
        } else if (i == '2') {
            str = '<img style="width:15px;" src="images/red.PNG" alt="" />';
        } else if (i == '3') {
            str = '<img style="width:15px;" src="images/yellow.png" alt="" />';
        } else if (i == '4') {
            str = '<img style="width:15px;" src="images/greent.gif" alt="" />';
        } else if (i == '5') {
            str = '<img style="width:15px;" src="images/redt.gif" alt="" />';
        } else if (i == '6') {
            str = '<img style="width:15px;" src="images/yellow.gif" alt="" />';
        }
        return str;
    },
    imgX10: function(i) {
        var str = "";
        if (i == '0') {
            str = '<img style="width:10px;" src="images/gery.png" alt="" />';
        } else if (i == '1') {
            str = '<img style="width:10px;" src="images/green.PNG" alt="" />';
        } else if (i == '2') {
            str = '<img style="width:10px;" src="images/red.PNG" alt="" />';
        } else if (i == '3') {
            str = '<img style="width:10px;" src="images/yellow.png" alt="" />';
        } else if (i == '4') {
            str = '<img style="width:10px;" src="images/greent.gif" alt="" />';
        } else if (i == '5') {
            str = '<img style="width:10px;" src="images/redt.gif" alt="" />';
        } else if (i == '6') {
            str = '<img style="width:10px;" src="images/yellow.gif" alt="" />';
        }
        return str;
    },
    imgX3000g1: function(i) {
        var str = "";
        if (i == '0') {
            str = '<img style="width:10px;" src="images/gery.png" alt="" />';
        } else if (i == '1') {
            str = '<img style="width:10px;" src="images/red.PNG" alt="" />';
        }
        return str;
    },
    imgX3000g2: function(i) {
        var str = "";
        if (i == '0') {
            str = '<img style="width:10px;" src="images/gery.png" alt="" />';
        } else if (i == '1') {
            str = '<img style="width:10px;" src="images/yellow.png" alt="" />';
        }
        return str;
    },
    imgX1: function(i) {
        var str = "";
        if (i == '0') {
            str = '<img style="width:15px;" src="images/gery.png" alt="" />';
        } else if (i == '1') {
            str = '<img style="width:15px;" src="images/red.PNG" alt="" />';
        } else if (i == '2') {
            str = '<img style="width:15px;" src="images/green.PNG" alt="" />';
        } else if (i == '3') {
            str = '<img style="width:15px;" src="images/greent.gif" alt="" />';
        } else if (i == '4') {
            str = '<img style="width:15px;" src="images/yellow.png" alt="" />';
        } else if (i == '5') {
            str = '<img style="width:15px;" src="images/redt.gif" alt="" />';
        } else if (i == '6') {
            str = '<img style="width:15px;" src="images/yellow.gif" alt="" />';
        }
        return str;
    },
    imgX2: function(i) {
        var str = "";
        if (i == 'OFF') {
            str = '<img style="width:15px;" src="images/gery.png" alt="" />';
        } else if (i == 'GRN') {
            str = '<img style="width:15px;" src="images/green.PNG" alt="" />';
        } else if (i == 'AMB') {
            str = '<img style="width:15px;" src="images/yellow.png" alt="" />';
        } else if (i == 'RED') {
            str = '<img style="width:15px;" src="images/red.PNG" alt="" />';
        } else if (i == 'BLK') {
            str = '<img style="width:15px;" src="images/greent.gif" alt="" />';
        }
        return str;
    },
    imgXSys: function(i) {
        var str = "";
        if (i == '0') {
            str = '<img style="width:15px;" src="images/gery.png" alt="" />';
        } else if (i == '1') {
            str = '<img style="width:15px;" src="images/green.PNG" alt="" />';
        } else if (i == '3') {
            str = '<img style="width:15px;" src="images/greent.gif" alt="" />';
        }
        return str;
    },
    cardNull: function() {
        var str = '';
        str += '<div class="fCenter-box-1" >'
        str += '<div class="fCenter-box1">'
        str += '<img src="images/zcard.PNG" alt="" />'
        str += '<div style=""></div>'
        str += '</div>'
        str += '</div>'
        str += '<div class="fCenter-box-2">'
        str += '</div>'
        str += '<div class="fCenter-box-3">'
        str += '<img src="images/zcardb.PNG" alt=""/>'
        str += '</div>';
        return str;
    },
    cardNullcc: function() {
        var str = '';
        str += '<div class="fCenter-box-1cc" >'
        str += '<div class="fCenter-box1">'
        str += '<img src="images/zcard.PNG" alt="" />'
        str += '<div style=""></div>'
        str += '</div>'
        str += '</div>'
        str += '<div class="fCenter-box-2cc">'
        str += '</div>'
        str += '<div class="fCenter-box-3cc">'
        str += '<img src="images/zcardb.PNG" alt=""/>'
        str += '</div>';
        return str;
    },
    cardCC: function(freeRun, active, lock, alarm, type) { //钟卡 每种灯的范围0-6;
        var str = '';
        str += '<div class="fCenter-box-1cc" >'
        str += '<div class="fCenter-box1">'
        str += '<img src="images/zcard.PNG" alt="" />'
        str += '<div translate="CLOCK_CARD" style="">钟卡</div>'
        str += '</div>'
        str += '</div>'
        str += '<div class="fCenter-box-2cc" style="padding-left: 30px;">'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 0%;">freeRun</div>'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 col-sm-offset-2">'
        str += this.imgX(freeRun);
        // '<img src="images/gery.gif" style="width: 15px;" alt="">'+
        str += '</div>'
        str += '</div>'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 0%;">active</div>'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 col-sm-offset-2">'
        str += this.imgX(active);
        // '<img src="images/gery.gif" style="width: 15px;" alt="">'+
        str += '</div>'
        str += '</div>'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 0%;">lock</div>'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 col-sm-offset-2">'
        str += this.imgX(lock);
        // '<img src="images/gery.gif" style="width: 15px;" alt="">'+
        str += '</div>'
        str += '</div>'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 0%;">alarm</div>'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 col-sm-offset-2">'
        str += this.imgX(alarm);
        // '<img src="images/gery.gif" style="width: 15px;" alt="">'+
        str += '</div>'
        str += '</div>'
        str += '<div class="fc-conPtp">'
        str += '<div class="col-lg-5 col-md-5 col-sm-5 col-xs-5">PTP1</div>'
        str += '<div class="col-lg-5 col-md-5 col-sm-5 col-xs-5">'
        str += '<img src="images/ptp.PNG" alt="" style="width: 25px;vertical-align:middle;">'
        str += '</div>'
        str += '</div>'
        str += '<div class="fc-conPtp">'
        str += '<div class="col-lg-5 col-md-5 col-sm-5 col-xs-5">PTP2</div>'
        str += '<div class="col-lg-5 col-md-5 col-sm-5 col-xs-5">'
        str += '<img src="images/ptp.PNG" alt="" style="width: 25px;vertical-align:middle;">'
        str += '</div>'
        str += '</div>'

        if (type === "SM2000_GN") {
            str += '<div class="fc-conPtp" style="margin-top: 49px;">'
            str += '    <div class="col-lg-5 col-md-5 col-sm-5 col-xs-5 ">'
            str += '        <div  style="width:30px;height:30px;border-radius:100%;background:#ccc;"></div>';
            str += '    </div>'
            str += '    <div class="col-lg-5 col-md-5 col-sm-5 col-xs-5" style="position: relative;top:-80%;">GNSS</div>'
            str += '</div>'
        }

        str += '</div>'
        str += '<div class="fCenter-box-3cc">'
        str += '<img src="images/zcardb.PNG" alt=""/>'
        str += '</div>';
        return str;
    },
    cardMC: function(pwrA, pwrB, system, alarm) { //管理卡 每种灯的范围范围 0-1 
        var str = '';
        str += '<div class="fCenter-box-1" >'
        str += '<div class="fCenter-box1">'
        str += '<img src="images/zcard.PNG" alt="" />'
        str += '<div translate="MANAGEMENT_CARD"  style="">管理卡</div>'
        str += '</div>'
        str += '</div>'
        str += '<div class="fCenter-box-2">'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        str += this.imgX(pwrA);
        str += '</div>'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">pwrA</div>'
        str += '</div>'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        str += this.imgX(pwrB);
        str += '</div>'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">pwrB</div>'
        str += '</div>'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        if (this.deviceType === "SM2000") {
            str += this.imgXSys(system);
        } else if (this.deviceType === "SM2000_GN") {
            str += this.imgX(system);
        }
        str += '</div>'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">sys</div>'
        str += '</div>'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        str += this.imgX1(alarm);
        str += '</div>'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">alarm</div>'
        str += '</div>'
        str += '<div class="fc-conMC">'
        str += '<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="text-align: center;"><img src="images/managecard.PNG" alt="" style="width: 25px;vertical-align:middle;"><span style="position: absolute;right: -5%;top: 20%;width: 30px;line-height: 20px;">管理网口</span></div>'

        str += '</div>'
        str += '<div class="fc-conMC1">'
        str += '<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="text-align: center;"><img src="images/craft.PNG" alt="" style="width: 25px;vertical-align:middle;"><span style="position: absolute;right: -5%;top:40%;width: 30px;line-height: 20px;">Craft</span></div>'

        str += '</div>'
        str += '</div>'
        str += '<div class="fCenter-box-3">'
        str += '<img src="images/zcardb.PNG" alt=""/>'
        str += '</div>';
        return str;
    },
    cardGnssE1TOD: function(obj, type) { //GNSS+4E1 每种灯的范围范围 0-3 
        var str = '',
            sys = obj.sys,
            port1 = obj.port1,
            port2 = obj.port2,
            port3 = obj.port3,
            port4 = obj.port4;
        if (this.deviceType === 'SM2000') {
            var gnss = obj.gnss;
        }
        str += '<div class="fCenter-box-1" >'
        str += '<div class="fCenter-box1">'
        str += '<img src="images/zcard.PNG" alt="" />'
        str += '<div style="">T1-TOD</div>'
        str += '</div>'
        str += '</div>'
        str += '<div class="fCenter-box-2">'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        str += this.imgX1(sys);
        str += '</div>'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">Sys</div>'
        str += '</div>'
        if (this.deviceType === "SM2000") {
            str += '<div class="fc-con">'
            str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
            str += this.imgX1(gnss);
            str += '</div>'
            str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">GNSS</div>'
            str += '</div>'
        }
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        str += this.imgX1(port1);
        str += '</div>'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">Input1</div>'
        str += '</div>'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        str += this.imgX1(port2);
        str += '</div>'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">Input2</div>'
        str += '</div>'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        str += this.imgX1(port3);
        str += '</div>'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">Input3</div>'
        str += '</div>'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        str += this.imgX1(port4);
        str += '</div>'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">Input4</div>'
        str += '</div>'

        if (type === "SM2000") {
            str += '<div class="fc-conPtp" style="margin-top: 49px;">'
            str += '    <div class="col-lg-5 col-md-5 col-sm-5 col-xs-5 ">'
            str += '        <div  style="width:30px;height:30px;border-radius:100%;background:#ccc;"></div>';
            str += '    </div>'
            str += '    <div class="col-lg-5 col-md-5 col-sm-5 col-xs-5" style="position: relative;top:-80%;">GNSS</div>'
            str += '</div>'
        }

        str += '</div>'
        str += '<div class="fCenter-box-3">'
        str += '<img src="images/zcardb.PNG" alt=""/>'
        str += '</div>';
        return str;
    },
    cardGnss4E1: function(obj, type) { //GNSS+4E1 每种灯的范围范围 0-3 
        var str = '',
            sys = obj.sys,
            port1 = obj.port1,
            port2 = obj.port2,
            port3 = obj.port3,
            port4 = obj.port4;
        if (this.deviceType === 'SM2000') {
            var gnss = obj.gnss;
        }
        str += '<div class="fCenter-box-1" >'
        str += '<div class="fCenter-box1">'
        str += '<img src="images/zcard.PNG" alt="" />'
        str += '<div style="">GNSS+4E1</div>'
        str += '</div>'
        str += '</div>'
        str += '<div class="fCenter-box-2">'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        str += this.imgX1(sys);
        str += '</div>'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">Sys</div>'
        str += '</div>'
        if (this.deviceType === "SM2000") {
            str += '<div class="fc-con">'
            str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
            str += this.imgX1(gnss);
            str += '</div>'
            str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">GNSS</div>'
            str += '</div>'
        }
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        str += this.imgX1(port1);
        str += '</div>'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">Input1</div>'
        str += '</div>'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        str += this.imgX1(port2);
        str += '</div>'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">Input2</div>'
        str += '</div>'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        str += this.imgX1(port3);
        str += '</div>'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">Input3</div>'
        str += '</div>'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        str += this.imgX1(port4);
        str += '</div>'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">Input4</div>'
        str += '</div>'

        if (type === "SM2000") {
            str += '<div class="fc-conPtp" style="margin-top: 49px;">'
            str += '    <div class="col-lg-5 col-md-5 col-sm-5 col-xs-5 ">'
            str += '        <div  style="width:30px;height:30px;border-radius:100%;background:#ccc;"></div>';
            str += '    </div>'
            str += '    <div class="col-lg-5 col-md-5 col-sm-5 col-xs-5" style="position: relative;top:-80%;">GNSS</div>'
            str += '</div>'
        }

        str += '</div>'
        str += '<div class="fCenter-box-3">'
        str += '<img src="images/zcardb.PNG" alt=""/>'
        str += '</div>';
        return str;
    },
    cardBuffer: function(pwrA, pwrB, system, Active) { //Buffer 每种灯的范围范围 0-3
        var str = '';
        str += '<div class="fCenter-box-1" >'
        str += '<div class="fCenter-box1">'
        str += '<img src="images/zcard.PNG" alt="" />'
        str += '<div style="">Buffer</div>'
        str += '</div>'
        str += '</div>'
        str += '<div class="fCenter-box-2">'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        str += this.imgX1(pwrA);
        str += '</div>'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">pwrA</div>'
        str += '</div>'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        str += this.imgX1(pwrB);
        str += '</div>'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">pwrB</div>'
        str += '</div>'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        str += this.imgX1(system);
        str += '</div>'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">Sys</div>'
        str += '</div>'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        str += this.imgX1(Active);
        str += '</div>'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">Active</div>'
        str += '</div>'
        str += '</div>'
        str += '<div class="fCenter-box-3">'
        str += '<img src="images/zcardb.PNG" alt=""/>'
        str += '</div>';
        return str;
    },
    cardPtp: function(obj) { //PTP输出卡 每种灯的范围范围 0-1
        var PWR = obj.pwr,
            Sys = "";
        if (Object.keys(obj).length === 2) {
            Sys = obj.enable
        } else {
            Sys = obj.sys
        }
        var str = '';
        str += '<div class="fCenter-box-1" >'
        str += '<div class="fCenter-box1">'
        str += '<img src="images/zcard.PNG" alt="" />'
        str += '<div  translate="" style="">PTP输出卡</div>'
        str += '</div>'
        str += '</div>'
        str += '<div class="fCenter-box-2">'
        str += '<div class="fc-con">'

        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">'
        str += this.imgX(PWR);
        str += '</div>'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">PWR</div>'

        str += '</div>'

        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">'
        if (Sys == '1') {
            str += '               <img style="width:15px;" src="images/greent.gif" alt="" />';
        } else if (Sys == '0') {
            str += '               <img style="width:15px;" src="images/gery.png" alt="" />';
        }
        // '<img src="images/gery.gif" style="width: 15px;" alt="">'+
        str += '</div>'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">Sys</div>'

        str += '</div>'
        if (Object.keys(obj).length === 2) {
            str += '<div class="fc-conPtp">'
            str += '<div class="col-lg-5 col-md-5 col-sm-5 col-xs-5">PTP1</div>'
            str += '<div class="col-lg-5 col-md-5 col-sm-5 col-xs-5">'
            str += '<img src="images/ptp.PNG" alt="" style="width: 15px;vertical-align:middle;">'
            str += '</div>'
            str += '</div>'
            str += '<div class="fc-conPtp">'
            str += '<div class="col-lg-5 col-md-5 col-sm-5 col-xs-5">PTP2</div>'
            str += '<div class="col-lg-5 col-md-5 col-sm-5 col-xs-5">'
            str += '<img src="images/ptp.PNG" alt="" style="width: 15px;vertical-align:middle;">'
            str += '</div>'
            str += '</div>'
            str += '<div class="fc-conPtp">'
            str += '<div class="col-lg-5 col-md-5 col-sm-5 col-xs-5">PTP3</div>'
            str += '<div class="col-lg-5 col-md-5 col-sm-5 col-xs-5">'
            str += '<img src="images/ptp.PNG" alt="" style="width: 15px;vertical-align:middle;">'
            str += '</div>'
            str += '</div>'
            str += '<div class="fc-conPtp">'
            str += '<div class="col-lg-5 col-md-5 col-sm-5 col-xs-5">PTP4</div>'
            str += '<div class="col-lg-5 col-md-5 col-sm-5 col-xs-5">'
            str += '<img src="images/ptp.PNG" alt="" style="width: 15px;vertical-align:middle;">'
            str += '</div>'
            str += '</div>'
            str += '</div>'
            str += '<div class="fCenter-box-3">'
            str += '<img src="images/zcardb.PNG" alt=""/>'
            str += '</div>';
        } else {

            str += '<img src="images/ptp.PNG" alt="" style="width: 25px;vertical-align:middle;width: 25px;vertical-align:middle;position: absolute;left: 12%;top: 20%;">'
            str += '<img src="images/ptp.PNG" alt="" style="width: 25px;vertical-align:middle;width: 25px;vertical-align:middle;position: absolute;left: 12%;top: 35%;">'
            str += '<img src="images/ptp.PNG" alt="" style="width: 25px;vertical-align:middle;width: 25px;vertical-align:middle;position: absolute;left: 12%;top: 50%;">'
            str += '<img src="images/ptp.PNG" alt="" style="width: 25px;vertical-align:middle;width: 25px;vertical-align:middle;position: absolute;left: 12%;top: 65%;">'
            str += '<div class="fc-con" style="position: absolute;top: 18%;right: -30%;">'
            str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">'
            if (obj.ptp1 === 1) {
                str += '               <img style="width:8px;" src="images/green.PNG" alt="" />';
            } else {
                str += '               <img style="width:8px;" src="images/gery.png" alt="" />';
            }
            str += '</div>'
            str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 20%;top: 5%;">ACT</div>'
            str += '</div>'


            str += '<div class="fc-con" style="position: absolute;top: 22%;right: -30%;">'
            str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">'
            if (obj.ptp1 === 1) {
                str += '               <img style="width:8px;" src="images/greent.gif" alt="" />';
            } else {
                str += '               <img style="width:8px;" src="images/gery.png" alt="" />';
            }
            str += '</div>'
            str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 20%;top: 5%;">LNK</div>'
            str += '</div>'



            str += '<div class="fc-con" style="position: absolute;top: 33%;right: -30%;">'
            str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">'
            if (obj.ptp2 === 1) {
                str += '               <img style="width:8px;" src="images/green.PNG" alt="" />';
            } else {
                str += '               <img style="width:8px;" src="images/gery.png" alt="" />';
            }
            str += '</div>'
            str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 20%;top: 5%;">ACT</div>'
            str += '</div>'


            str += '<div class="fc-con" style="position: absolute;top: 37%;right: -30%;">'
            str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">'
            if (obj.ptp2 === 1) {
                str += '               <img style="width:8px;" src="images/greent.gif" alt="" />';
            } else {
                str += '               <img style="width:8px;" src="images/gery.png" alt="" />';
            }
            str += '</div>'
            str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 20%;top: 5%;">LNK</div>'
            str += '</div>'


            str += '<div class="fc-con" style="position: absolute;top: 48%;right: -30%;">'
            str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">'
            if (obj.ptp3 === 1) {
                str += '               <img style="width:8px;" src="images/green.PNG" alt="" />';
            } else {
                str += '               <img style="width:8px;" src="images/gery.png" alt="" />';
            }
            str += '</div>'
            str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 20%;top: 5%;">ACT</div>'
            str += '</div>'


            str += '<div class="fc-con" style="position: absolute;top: 52%;right: -30%;">'
            str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">'
            if (obj.ptp3 === 1) {
                str += '               <img style="width:8px;" src="images/greent.gif" alt="" />';
            } else {
                str += '               <img style="width:8px;" src="images/gery.png" alt="" />';
            }
            str += '</div>'
            str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 20%;top: 5%;">LNK</div>'
            str += '</div>'


            str += '<div class="fc-con" style="position: absolute;top: 63%;right: -30%;">'
            str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">'
            if (obj.ptp4 === 1) {
                str += '               <img style="width:8px;" src="images/green.PNG" alt="" />';
            } else {
                str += '               <img style="width:8px;" src="images/gery.png" alt="" />';
            }
            str += '</div>'
            str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 20%;top: 5%;">ACT</div>'
            str += '</div>'


            str += '<div class="fc-con" style="position: absolute;top: 67%;right: -30%;">'
            str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">'
            if (obj.ptp4 === 1) {
                str += '               <img style="width:8px;" src="images/greent.gif" alt="" />';
            } else {
                str += '               <img style="width:8px;" src="images/gery.png" alt="" />';
            }
            str += '</div>'
            str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 20%;top: 5%;">LNK</div>'
            str += '</div>'
            str += '</div>'
            str += '<div class="fCenter-box-3">'
            str += '<img src="images/zcardb.PNG" alt=""/>'
            str += '</div>';
        }

        return str;
    },
    cardNtp: function(obj) { //PTP输出卡 每种灯的范围范围 0-1
        var PWR = obj.pwr,
            Sys = obj.sys;
        var str = '';
        str += '<div class="fCenter-box-1" >'
        str += '<div class="fCenter-box1">'
        str += '<img src="images/zcard.PNG" alt="" />'
        str += '<div  translate="" style="">NTP输出卡</div>'
        str += '</div>'
        str += '</div>'
        str += '<div class="fCenter-box-2">'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        str += this.imgX(PWR);
        // '<img src="images/gery.gif" style="width: 15px;" alt="">'+
        str += '</div>'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">PWR</div>'
        str += '</div>'

        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        if (Sys == '1') {
            str += '               <img style="width:15px;" src="images/greent.gif" alt="" />';
        } else if (Sys == '0') {
            str += '               <img style="width:15px;" src="images/gery.png" alt="" />';
        } else if (Sys == '2 ') {
            str += '               <img style="width:15px;" src="images/green.PNG" alt="" />';
        }
        // '<img src="images/gery.gif" style="width: 15px;" alt="">'+
        str += '</div>'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">Sys</div>'
        str += '</div>'



        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        str += this.imgX(obj.ntp1);
        str += '</div>'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">NTP1</div>'
        str += '</div>'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        str += this.imgX(obj.ntp2);
        str += '</div>'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">NTP2</div>'
        str += '</div>'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        str += this.imgX(obj.ntp3);
        str += '</div>'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">NTP3</div>'
        str += '</div>'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        str += this.imgX(obj.ntp4);
        str += '</div>'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">NTP4</div>'
        str += '</div>'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        str += this.imgX(obj.ntp5);
        str += '</div>'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">NTP5</div>'
        str += '</div>'
        str += '</div>';
        str += '<div class="fCenter-box-3">'
        str += '<img src="images/zcardb.PNG" alt=""/>'
        str += '</div>';
        return str;
    },
    cardE1T1: function(pwr, enable) { //E1-T1 每种灯的范围范围 0-1
        var str = '';
        str += '<div class="fCenter-box-1" >'
        str += '<div class="fCenter-box1">'
        str += '<img src="images/zcard.PNG" alt="" />'
        str += '<div translate=""  style="">E1输出卡</div>'
        str += '</div>'
        str += '</div>'
        str += '<div class="fCenter-box-2">'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        str += this.imgX(pwr);
        str += '</div>'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">PWR</div>'
        str += '</div>'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        if (enable == '0') {
            str += '<img style="width:15px;" src="images/gery.png" alt="" />';
        } else {
            str += '<img style="width:15px;" src="images/greent.gif" alt="" />';
        }
        /*else if (enable == '1') {
                    str += '<img style="width:15px;" src="images/greent.gif" alt="" />';
                } else if (enable == '2') {
                    str += '<img style="width:15px;" src="images/green.PNG" alt="" />';
                }*/
        str += '</div>'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">Enable</div>'
        str += '</div>'
        str += '</div>'
        str += '</div>'
        str += '<div class="fCenter-box-3">'
        str += '<img src="images/zcardb.PNG" alt=""/>'
        str += '</div>';
        return str;
    },
    cardIrigAndPpsToD: function(pwr, enable) { //IRIG  PPS-TOD pwr 0-1 enable 0-2
        var str = '';
        str += '<div class="fCenter-box-1" >'
        str += '<div class="fCenter-box1">'
        str += '<img src="images/zcard.PNG" alt="" />'
        str += '<div translate=""   style="">PPS-TOD</div>'
        str += '</div>'
        str += '</div>'
        str += '<div class="fCenter-box-2">'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        if (pwr == '1') {
            str += '               <img style="width:15px;" src="images/green.PNG" alt="" />';
        } else if (pwr == '0') {
            str += '               <img style="width:15px;" src="images/gery.png" alt="" />';
        }
        str += '</div>'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">PWR</div>'
        str += '</div>'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        if (enable == '1') {
            str += '               <img style="width:15px;" src="images/greent.gif" alt="" />';
        } else if (enable == '0') {
            str += '               <img style="width:15px;" src="images/gery.png" alt="" />';
        } else if (enable == '2') {
            str += '               <img style="width:15px;" src="images/green.PNG" alt="" />';
        }


        str += '</div>'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">Enable</div>'
        str += '</div>'
        str += '</div>'
        str += '<div class="fCenter-box-3">'
        str += '<img src="images/zcardb.PNG" alt=""/>'
        str += '</div>';
        return str;
    },
    cardGeneral: function(obj, type) { //IRIG  PPS-TOD pwr 0-1 enable 0-2
        var str = '';
        str += '<div class="fCenter-box-1" >'
        str += '<div class="fCenter-box1">'
        str += '<img src="images/zcard.PNG" alt="" />'
        str += '<div style="">' + type + '</div>'
        str += '</div>'
        str += '</div>'
        str += '<div class="fCenter-box-2">'
        for (var i = 0; i < obj.length; i++) {
            str += '<div class="fc-con">'
            str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
            str += this.imgX2(obj[i].cardLedValue);
            str += '</div>'
            str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">' + obj[i].cardLedLable + '</div>'
            str += '</div>'
        }
        str += '</div>'
        str += '<div class="fCenter-box-3">'
        str += '<img src="images/zcardb.PNG" alt=""/>'
        str += '</div>';
        return str;
    },
    cardSTFS1000: function(obj, type) { //IRIG  PPS-TOD pwr 0-1 enable 0-2
        var str = '';
        str += '<div class="fCenter-box-1" >';
        str += '<div class="fCenter-box1">';
        str += '<img src="images/zcard.PNG" alt="" />';
        str += '<div style="">' + type + '</div>';
        str += '</div>';
        str += '</div>';

        if (type == 'MCP') {
            str += '<div class="fCenter-box-2">';
            for (var i = 0; i < obj.length; i++) {
                str += '<div class="fc-con">';
                str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 col-sm-offset-2">';
                str += this.imgX(obj[i].cardLedValue);
                str += '</div>'
                str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">' + obj[i].cardLedLable + '</div>';
                str += '</div>';
            }
            str += '</div>';
            str += '<div class="fc-conMC">';
            str += '<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="text-align: center;"><img src="images/managecard.PNG" alt="" style="width: 15px;vertical-align:middle;"></div>';

            str += '</div>';
            str += '<div class="fc-conMC1">';
            str += '<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="text-align: center;"><img src="images/craft.PNG" alt="" style="width: 15px;vertical-align:middle;"></div>';

            str += '</div>';
        } else if (type == 'TEST') {
            str += '<div class="fCenter-box-2">'
            for (var i = 0; i < obj.length; i++) {
                str += '<div class="fc-con">';
                str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 col-sm-offset-2">';
                str += this.imgX(obj[i].cardLedValue);
                str += '</div>'
                str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">' + obj[i].cardLedLable + '</div>';
                str += '</div>';
            }
            str += '</div>'
            str += '<div class="fc-conMC1">';
            str += '<img src="images/craft.PNG" alt="" style="width: 15px;vertical-align:middle;">';
            str += '&nbsp;&nbsp;&nbsp;<span>Craft</span>';
            str += '</div>';
        } else if (type.indexOf('RB') > -1) {
            str += '<div class="fCenter-box-2">'
            for (var i = 0; i < obj.length; i++) {
                str += '<div class="fc-con">';
                str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">';
                if (obj[i].cardLedLable != 'REF') {
                    str += this.imgX(obj[i].cardLedValue);
                    str += '</div>';
                    str += '<div class="">' + obj[i].cardLedLable + '</div>';
                    str += '</div>';
                } else {
                    if (obj[i].cardLedValue == '9' || obj[i].cardLedValue == '10') {
                        str += '<div  style="text-align:center;"><img style="width: 30px;z-index: 100;position: relative;border: 1px solid #aba3a3;" src="images/Rb.gif" alt="" /><p id="fontss" style="color:#63ea2f;z-index: 10;" class="rbLED">' + parseInt(obj[i].cardLedValue - 8) + '</p></div>';
                    } else {
                        str += '<div  style="text-align:center;"><img style="width: 30px;position: relative;border: 1px solid #aba3a3;" src="images/Rb.png" alt="" /><p id="fontss" style="color:#63ea2f;z-index: 100;" class="rbLED">' + obj[i].cardLedValue; + '</p></div>';
                    }
                    str += '</div>';
                    str += ' <div class="">' + obj[i].cardLedLable + '</div>';
                    str += '</div>';
                }
            }
            str += '</div>';
        } else {
            str += '<div class="fCenter-box-2">';
            for (var i = 0; i < obj.length; i++) {
                str += '<div class="fc-con">';
                str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 col-sm-offset-2">';
                str += this.imgX(obj[i].cardLedValue);
                str += '</div>';
                str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">' + obj[i].cardLedLable + '</div>';
                str += '</div>';
            }
            str += '</div>';
        }
        str += '<div class="fCenter-box-3">';
        str += '<img src="images/zcardb.PNG" alt=""/>';
        str += '</div>';
        return str;
    },
    cardTP1000: function(obj, type) { //IRIG  PPS-TOD pwr 0-1 enable 0-2
        var str = '';
        if (type == 'IOC1') {
            var num = '090-58022-01';
            var info = 'Rubidium Input/Output Card';
        } else if (type == 'IMC') {
            var num = '090-58031-01';
            var info = 'Information Management Card';
        } else if (type == 'IOC2') {
            var num = '090-58021-01';
            var info = 'Input/Output Card';
        }
        str += '<div class="fCenter-tp1000-1" >';
        str += '<div style="float: right;text-align: right;padding: 10px;"><span>' + info + '</span></br></br><span style="padding-top: 3px;">' + num + '</span>';
        str += '</div>';
        str += '</div>';

        if (type != 'IMC') {
            str += '<div class="fCenter-tp1000-2">';
            str += '<div class=""><div style="position: relative;right: -60%;top: -10%;">Q-Qualified</div> <div style="position:relative;right: -60%;margin-top: 10px;">|&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;A-Active</div>';
            str += '</div>';
            str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">';
            for (var i = 0; i < obj.length; i++) {
                if (obj[i].cardLedLable == 'POWER') {
                    str += '<div class="fc-contp1000">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX(obj[i].cardLedValue);
                    str += '</div>';
                    str += '<div class="">Power</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'FAIL') {
                    str += '<div class="fc-contp1000">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX(obj[i].cardLedValue);
                    str += '</div>';
                    str += '<div class="">Fail</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'ALARM') {
                    str += '<div class="fc-contp1000">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX(obj[i].cardLedValue);
                    str += '</div>';
                    str += '<div class="">Alarm</div>';
                    str += '</div>';
                }
            }
            str += '</div>';
            str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">';
            for (var i = 0; i < obj.length; i++) {
                if (obj[i].cardLedLable == 'GPS') {
                    str += '<div class="fc-contp1000">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX(obj[i].cardLedValue);
                    str += '</div>';
                    str += '<div class="">' + obj[i].cardLedLable + '</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'HOLDOVER') {
                    str += '<div class="fc-contp1000">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX(obj[i].cardLedValue);
                    str += '</div>';
                    str += '<div class="">Holdover</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'ACTIVE') {
                    str += '<div class="fc-contp1000">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX(obj[i].cardLedValue);
                    str += '</div>';
                    str += '<div class="">Active</div>';
                    str += '</div>';
                }
            }
            str += '</div>';
            str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">';
            for (var i = 0; i < obj.length; i++) {
                if (obj[i].cardLedLable == 'PRS-Q') {
                    str += '<div class="fc-contp1000">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'INP1-Q') {
                    str += '<div class="fc-contp1000">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'INP2-Q') {
                    str += '<div class="fc-contp1000">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
            }
            str += '</div>';
            str += '<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">';
            for (var i = 0; i < obj.length; i++) {
                if (obj[i].cardLedLable == 'PRS-A') {
                    str += '<div class="fc-contp1000">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX(obj[i].cardLedValue);
                    str += '</div>';
                    str += '<div class="">PRS</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'INP1-A') {
                    str += '<div class="fc-contp1000">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX(obj[i].cardLedValue);
                    str += '</div>';
                    str += '<div class="">Input 1</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'INP2-A') {
                    str += '<div class="fc-contp1000">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX(obj[i].cardLedValue);
                    str += '</div>';
                    str += '<div class="">Input 2</div>';
                    str += '</div>';
                }
            }
            str += '</div>';
            str += '</div>';
        } else if (type == 'IMC') {
            str += '<div class="fCenter-tp1000-2" style="padding-top: 70px;">';
            str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">';
            for (var i = 0; i < obj.length; i++) {
                if (obj[i].cardLedLable == 'POWER') {
                    str += '<div class="fc-contp1000">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX(obj[i].cardLedValue);
                    str += '</div>';
                    str += '<div class="">Power</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'FAIL') {
                    str += '<div class="fc-contp1000">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX(obj[i].cardLedValue);
                    str += '</div>';
                    str += '<div class="">Fail</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'ALARM') {
                    str += '<div class="fc-contp1000">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX(obj[i].cardLedValue);
                    str += '</div>';
                    str += '<div class="">Alarm</div>';
                    str += '</div>';
                }
            }
            str += '</div>';
            str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">';
            for (var i = 0; i < obj.length; i++) {
                if (obj[i].cardLedLable == 'CRITICAL') {
                    str += '<div class="fc-contp1000">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX(obj[i].cardLedValue);
                    str += '</div>';
                    str += '<div class="">Critical</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'MAJOR') {
                    str += '<div class="fc-contp1000">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX(obj[i].cardLedValue);
                    str += '</div>';
                    str += '<div class="">Major</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'MINOR') {
                    str += '<div class="fc-contp1000">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX(obj[i].cardLedValue);
                    str += '</div>';
                    str += '<div class="">Minor</div>';
                    str += '</div>';
                }
            }
            str += '</div>';

            str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">';
            str += '<div class="fc-contp1000"></div><div class="fc-contp1000"></div>';
            for (var i = 0; i < obj.length; i++) {
                if (obj[i].cardLedLable == 'ACO') {
                    str += '<div class="fc-contp1000">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX(obj[i].cardLedValue);
                    str += '</div>';
                    str += '<div class="">ACO</div>';
                    str += '</div>';
                }
            }
            str += '</div>';
            str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">';
            str += '<div class="fc-contp1000"></div><div class="fc-contp1000"></div><img src="images/craft2.PNG" alt="" style="width: 65px;vertical-align:middle;">';
            str += '</div>';
            str += '</div>';

        }
        str += '<div class="fCenter-tp1000-3 t-middle">';
        str += '<div style="">' + type + '</div>';
        str += '</div>';
        return str;
    },
    cardHP55400: function(obj, type) { //IRIG  PPS-TOD pwr 0-1 enable 0-2
        var str = '';
        str += '<div class="fCenter-HP55400-1" >';
               str += '<div class="fCenter-box1">'
        str += '<img src="images/zcard.PNG" alt="" />'
        str += '<div  translate="" style="">'+type+'</div>'
        str += '</div>'
        str += '</div>';
        str += '</div>';
        if (type == 'IMC') {
            str += '<div class="fCenter-HP55400-2" style="padding-top: 5px;position: relative;top: -30px;">';
            str += '<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="padding: 0px;">';
            str += '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2" style="padding: 0px;">';
            for (var i = 0; i < obj.length; i++) {
                if (obj[i].cardLedLable == 'Power') {
                   str += '<div class="" style="padding-bottom: 15px;">Power</div>';
                   str += '<div class="" style="padding-left: 18px;">|</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == '48V Fail A') {
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                   str += '<div class="" style="padding-left: 18px;">|</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += 'A';
                    str += '</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'Fuse') {
                    str += '<div class="fc-conHP55400" >';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding-bottom: 15px;">';
                    str += 'Fuse';
                    str += '</div>';
                    str += '</div>';
                   str += '<div class="" style="padding-left: 18px;">|</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'Alarm Critical') {
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                   str += '<div class="" style="padding-left: 18px;">|</div>';
                    str += '<div class="fc-conHP55400" >';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding-bottom: 15px;position: relative;right: 15px;">';
                    str += 'Alarm Critical';
                    str += '</div>';
                    str += '</div>';
                }
            }

            str += '</div>';

            str += '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2" style="padding: 0px;height: 160px;">';
            for (var i = 0; i < obj.length; i++) {
                if (obj[i].cardLedLable == 'Diagnostics') {
                   str += '<div class="" style="padding-top: 15px;padding-left: 10px;">Diagnostics</div>';
                    
                   str += '<div class="" style="padding-left: 18px;">|</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == '48V Fail B') {
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                   str += '<div class="" style="padding-left: 18px;">|</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += 'B';
                    str += '</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'Alarm') {
                    str += '<div class="fc-conHP55400" style="padding-top: 15px;">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += 'Alarm';
                    str += '</div>';
                    str += '</div>';
                   str += '<div class="" style="padding-left: 18px;">|</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'Alarm Major') {
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                   str += '<div class="" style="padding-left: 18px;">|</div>';
                    str += '<div class="fc-conHP55400" >';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding-bottom: 15px;position: relative;left: 3px;">';
                    str += 'Alarm Major';
                    str += '</div>';
                    str += '</div>';
                }
            }
            str += '</div>';
             str += '<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8" style="padding: 0px;">';

            str += '<div class="fc-conHP55400">';
            str += '<div style="padding-top: 60px;text-align: center;">- 48V Fail</div>';
            str += '</div>';
            str += '<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6" style="padding: 0px;">';

           str += '<div class="fc-conHP55400" style="padding-top: 157px;">';
            for (var i = 0; i < obj.length; i++) {
                if (obj[i].cardLedLable == 'Alarm Minor') {
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                }
            }
            str += '</div>';

            str += '</div>';

            str += '<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6" style="padding: 0px;">';
            str += '<div class="fc-conHP55400">';
            str += '<div class="" style="padding-top: 160px;">Alarm Minor</div>';
            str += '</div>';

            str += '</div>';
            str += '</div>';
            str += '</div>';

        //分层
            str += '<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"  style="padding: 0px;">';
            str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="padding: 0px;">';
            for (var i = 0; i < obj.length; i++) {
                if (obj[i].cardLedLable == 'Alarm Cutoff') {
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
            }
            str += '</div>';

            str += '<div class="col-lg-9 col-md-9 col-sm-9 col-xs-9" style="padding: 0px;">';
            str += '<div class="fc-conHP55400">';
            str += '<div class="" style="">Alarm Cutoff</div>';
            str += '</div>';
            str += '</div>';
            str += '<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">';
            str += '</div>';
            str += '</div>';


        //分层
        //
            str += '<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"  style="padding: 0px;">';
            str += '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2"  style="padding: 0px;">';
            for (var i = 0; i < obj.length; i++) {
                if (obj[i].cardLedLable == 'Local') {
                    str += '<div class="fc-conHP55400" >';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding-bottom: 15px;">';
                    str += 'Local';
                    str += '</div>';
                    str += '</div>';
                   str += '<div class="" style="padding-left: 18px;">|</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
            }
            str += '</div>';
            str += '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2"  style="padding: 0px;">';
            for (var i = 0; i < obj.length; i++) {
                if (obj[i].cardLedLable == 'Remote') {
                    str += '<div class="fc-conHP55400" style="padding-top: 15px;">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += 'Remote';
                    str += '</div>';
                    str += '</div>';
                   str += '<div class="" style="padding-left: 18px;">|</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
            }
            str += '</div>';
            str += '<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">';
            str += '</div>';
            str += '</div>';

        //分层
            str += '<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"  style="padding: 0px;">';
            str += '<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="text-align: center;">';
            str += '<img src="images/managecard.PNG" alt="" style="width: 25px;vertical-align:middle;"><span style="position: absolute;right: 15%;top: 20%;width: 30px;line-height: 20px;">LAN</span></div>'
            str += '</div>';
      
        //分层
        //
            str += '<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"  style="padding: 0px;">';
            str += '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2"  style="padding: 0px;">';
            for (var i = 0; i < obj.length; i++) {
                if (obj[i].cardLedLable == 'Link') {
                    str += '<div class="fc-conHP55400" >';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding-bottom: 15px;">';
                    str += 'Link';
                    str += '</div>';
                    str += '</div>';
                   str += '<div class="" style="padding-left: 18px;">|</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
            }
            str += '</div>';
            str += '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2"  style="padding: 0px;">';
            for (var i = 0; i < obj.length; i++) {
                if (obj[i].cardLedLable == 'Data Xmit') {
                    str += '<div class="fc-conHP55400" style="padding-top: 15px;">';
                    str += '<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 ">';
                    str += 'DataXmit';
                    str += '</div>';
                    str += '</div>';
                   str += '<div class="" style="padding-left: 18px;">|</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
            }
            str += '</div>';
            str += '<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">';
            str += '</div>';
            str += '</div>';

        //分层
            str += '<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"  style="padding: 0px;">';

            str += '<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">';
            str += ' <img src="images/craft.PNG" alt="" style="width: 20px;vertical-align:middle;"><span style="position: absolute;right: -5%;top:40%;width: 30px;line-height: 20px;">Rack Alarms</span></div>';
            str += '</div>';
            str += '<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"  style="padding: 0px;margin-top: 10px;">';

            str += '<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">';
            str += ' <img src="images/craft.PNG" alt="" style="width: 20px;vertical-align:middle;"><span style="position: absolute;right: -5%;top:40%;width: 30px;line-height: 20px;">Local</span></div>';
            str += '</div>';
      
        //分层
            str += '</div>';
        }
          if (type.includes('ITH')) {
            str += '<div class="fCenter-HP55400-2" style="padding-top: 5px;position: relative;top: -30px;">';
            str += '<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="padding: 0px;">';

             str += '<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4" style="padding: 0px;">';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;position: relative;right: -15px;">';
                    str += '<div class="" style="">Power</div>';
                    str += '</div>';
                    str += '</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;position: relative;right: -3px;">';
                    str += '<div class="" style="">Tracking</div>';
                    str += '</div>';
                    str += '</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;position: relative;right:0px;">';
                    str += '<div class="" style="">Holdover</div>';
                    str += '</div>';
                    str += '</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;position: relative;right: -25px;">';
                    str += '<div class="" style="">Fuse</div>';
                    str += '</div>';
                    str += '</div>';
            str += '</div>';



            str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1" style="padding: 0px;">';
            for (var i = 0; i < obj.length; i++) {
                if (obj[i].cardLedLable == 'Power') {
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'Tracking') {
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'Holdover') {
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'Fuse') {
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
            }

            str += '</div>';

            str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1" style="padding: 0px;">';
                for (var i = 0; i < obj.length; i++) {
                if (obj[i].cardLedLable == 'Diagnostics') {
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'Warmup') {
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'Freerun') {
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'Alarm') {
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
            }
            str += '</div>';
              str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="padding: 0px;">';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += '<div class="" style="">Diagnostics</div>';
                    str += '</div>';
                    str += '</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += '<div class="" style="">Warmup</div>';
                    str += '</div>';
                    str += '</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += '<div class="" style="">Freerun</div>';
                    str += '</div>';
                    str += '</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += '<div class="" style="">Alarm</div>';
                    str += '</div>';
                    str += '</div>';
            str += '</div>';
            str += '</div>';

        //分层
             str += '<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="padding: 0px;margin-top: 30px;">';

             str += '<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4" style="padding: 0px;position: relative;right: -45px;">';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += '<div class="" style=""> </div>';
                    str += '</div>';
                    str += '</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;position: relative;right: 18px;">';
                    str += '<div class="" style="">PRC</div>';
                    str += '</div>';
                    str += '</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += '<div class="" style="">1</div>';
                    str += '</div>';
                    str += '</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += '<div class="" style="">2</div>';
                    str += '</div>';
                    str += '</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += '<div class="" style="">3</div>';
                    str += '</div>';
                    str += '</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += '<div class="" style="">4</div>';
                    str += '</div>';
                    str += '</div>';
            str += '</div>';



            str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1" style="padding: 0px;">';
            for (var i = 0; i < obj.length; i++) {
                if (obj[i].cardLedLable == 'QPRC') {
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += 'Q';
                    str += '</div>';
                    str += '</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'Q1') {
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'Q2') {
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'Q3') {
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'Q4') {
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
            }

            str += '</div>';

            str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1" style="padding: 0px;">';
                for (var i = 0; i < obj.length; i++) {
                if (obj[i].cardLedLable == 'APRC') {
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += 'A';
                    str += '</div>';
                    str += '</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'A1') {
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'A2') {
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'A3') {
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'A4') {
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
            }
            str += '</div>';
              str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="padding: 0px;">';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += '<div class="" style=""> </div>';
                    str += '</div>';
                    str += '</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += '<div class="" style=""></div>';
                    str += '</div>';
                    str += '</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += '<div class="" style=""></div>';
                    str += '</div>';
                    str += '</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += '<div class="" style=""></div>';
                    str += '</div>';
                    str += '</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += '<div class="" style=""></div>';
                    str += '</div>';
                    str += '</div>';
            str += '</div>';
            str += '</div>';


        //分层
            str += '<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="padding: 0px;margin-top: 90px;">';

             str += '<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4" style="padding: 0px;position: relative;right: -20px;">';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += '<div class="" style="">Active</div>';
                    str += '</div>';
                    str += '</div>';
            str += '</div>';



            str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1" style="padding: 0px;">';
            for (var i = 0; i < obj.length; i++) {
                if (obj[i].cardLedLable == 'Active') {
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }

                if (obj[i].cardLedLable == 'Force Active') {
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += '<div class="" style="">Force Active</div>';
                    str += '</div>';
                    str += '</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 5px;">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                 }
    
            }

            str += '</div>';

            str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1" style="padding: 0px;">';
                for (var i = 0; i < obj.length; i++) {
                if (obj[i].cardLedLable == 'Standby') {
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
          
            }
            str += '</div>';
              str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="padding: 0px;">';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += '<div class="" style="">Standby</div>';
                    str += '</div>';
                    str += '</div>';
            str += '</div>';
            str += '</div>';

     
            str += '</div>';
        }

       if (type.includes('OUT')) {
           str += '<div class="fCenter-HP55400-2" style="padding-top: 5px;position: relative;top: -30px;left: 12px;">';
              str += '<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="padding: 0px;">';
            str += '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2" style="padding: 0px;">';
            for (var i = 0; i < obj.length; i++) {
                if (obj[i].cardLedLable == 'Power') {
                   str += '<div class="" style="padding-bottom: 15px;">Power</div>';
                   str += '<div class="" style="padding-left: 18px;">|</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
            }

            str += '</div>';

            str += '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2" style="padding: 0px;height: 70px;">';
            for (var i = 0; i < obj.length; i++) {
                if (obj[i].cardLedLable == 'Diag') {
                   str += '<div class="" style="padding-top: 15px;padding-left: 10px;">Diag</div>';
                    
                   str += '<div class="" style="padding-left: 18px;">|</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
            }
            str += '</div>';
             str += '<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8" style="padding: 0px;">';
             
            str += '</div>';
            str += '</div>';


        //分层

            str += '<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="padding: 0px;">';
            str += '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2" style="padding: 0px;">';
            for (var i = 0; i < obj.length; i++) {
                if (obj[i].cardLedLable == 'Fuse') {
                   str += '<div class="" style="padding-bottom: 15px;">Fuse</div>';
                   str += '<div class="" style="padding-left: 18px;">|</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'Output Loss') {
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                   str += '<div class="" style="padding-left: 18px;">|</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="position: relative;left: -29px;">';
                    str += 'Output Loss';
                    str += '</div>';
                    str += '</div>';
                }
            }

            str += '</div>';

            str += '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2" style="padding: 0px;height: 130px;">';
            for (var i = 0; i < obj.length; i++) {
                if (obj[i].cardLedLable == 'Alarm') {
                   str += '<div class="" style="padding-top: 15px;padding-left: 10px;">Alarm</div>';
                    
                   str += '<div class="" style="padding-left: 18px;">|</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'OOL') {
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                   str += '<div class="" style="padding-left: 18px;">|</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += 'OOL';
                    str += '</div>';
                    str += '</div>';
                }
            }
            str += '</div>';
             str += '<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8" style="padding: 0px;">';

            str += '</div>';
            str += '</div>';

     
        //分层
            str += '<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="padding: 0px;">';
            str += '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2" style="padding: 0px;">';
            for (var i = 0; i < obj.length; i++) {
                if (obj[i].cardLedLable == 'ITH1') {
                   str += '<div class="" style="padding-bottom: 15px;">ITH1</div>';
                   str += '<div class="" style="padding-left: 18px;">|</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
            }

            str += '</div>';

            str += '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2" style="padding: 0px;height: 60px;">';
            for (var i = 0; i < obj.length; i++) {
                if (obj[i].cardLedLable == 'ITH2') {
                   str += '<div class="" style="padding-bottom: 15px;padding-left: 15px;">ITH2</div>';
                   str += '<div class="" style="padding-left: 18px;">|</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
            }
            str += '</div>';
             str += '<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8" style="padding: 0px;">';
             
            str += '</div>';
            str += '</div>';

        //分层
            str += '<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="padding: 0px;margin-top: 50px;">';
            str += '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2" style="padding: 0px;">';
            for (var i = 0; i < obj.length; i++) {
                if (obj[i].cardLedLable == 'Active') {
                   str += '<div class="" style="padding-bottom: 15px;">Actie</div>';
                   str += '<div class="" style="padding-left: 18px;">|</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }

                if (obj[i].cardLedLable == 'Force Active') {
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 0px;">';
                    str += '<div class="" style="">Force Active</div>';
                    str += '</div>';
                    str += '</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 " style="padding: 5px;">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                 }
            }

            str += '</div>';

            str += '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2" style="padding: 0px;">';
            for (var i = 0; i < obj.length; i++) {
                if (obj[i].cardLedLable == 'Standby') {
                   str += '<div class="" style="padding-top: 15px;padding-left: 10px;">Standby</div>';
                    
                   str += '<div class="" style="padding-left: 18px;">|</div>';
                    str += '<div class="fc-conHP55400">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '</div>';
                }
            }
            str += '</div>';
             str += '<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8" style="padding: 0px;">';
             
            str += '</div>';
            str += '</div>';

        //分层
            str += '</div>';
        }
        str += '<div class="fCenter-HP55400-3 t-middle">';
        str += '<img src="images/zcardb.PNG" alt=""/>'
        str += '</div>';
        return str;
    },
    cardLF7300: function(obj, type) { //IRIG  PPS-TOD pwr 0-1 enable 0-2
          var str = '';
            str += '<div class="fCenter-LF7300-2">';
            str += '<div class="">';
            str += '</div>';
            str += '</div>';
            str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">';
                    str += '<div class="fc-conLF7300LCD">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += '</div>';
                    str += '<div style="position:relative;top:30%;left: -5%;">Warmup GNSS</div>';
                    str += '<div style="position:relative;top:15%;left: 85%;">UTC</div>';
                    str += '<div style="position:relative;top:35%;left: 6%;">2017-09-22 06:43:39</div>';
                    str += '</div>';
            str += '</div>';
            str += '</div>';

            str += '<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">';
                    str += '<div style="margin: 60px 0px 60px 160px;">';
          for (var i = 0; i < obj.length; i++) { 
                if (obj[i].cardLedLable == 'PWR') {
                    str += '<div class="fc-conLF7300">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '<div style="position: absolute;top: 65%;left: 32%;">PWR</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'BDC') {
                    str += '<div class="fc-conLF7300">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '<div style="position: absolute; top: 65%;left: 40%;">BDC</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'GPS/BD') {
                    str += '<div class="fc-conLF7300">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '<div style="position: absolute; top: 65%;left: 45%;">GPS/BD</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'Lock') {
                    str += '<div class="fc-conLF7300">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '<div style="position: absolute; top: 65%;left: 54%;">Lock</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'Holdover') {
                    str += '<div class="fc-conLF7300">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '<div style="position: absolute; top: 65%;left: 60%;">Holdover</div>';
                    str += '</div>';
                }
            }
            str += '</div>';
            str += '</div>';
             str += '<div style="position:relative;top:70%;left: -10%;font-size: 20px;">LF7300</div>';
            str += '</div>';

        return str;
    },
    cardTS3000G: function(obj, type) { //IRIG  PPS-TOD pwr 0-1 enable 0-2
        var str = '';
        str += '<div class="fCenter-TS3000G-1" >';
        str += '<div style="float: right;text-align: right;padding: 10px;"><span></span></br></br><span style="padding-top: 3px;"></span>';
        str += '</div>';
        str += '</div>';
            str += '<div class="fCenter-TS3000G-2">';
            str += '<div class="">';
            str += '</div>';
             str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">';
            str += '</div>';
            str += '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">';
          for (var i = 0; i < obj.length; i++) { 
                if (obj[i].cardLedLable == '运行') {
                    str += '<div class="fc-conTS3000G">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '<div class="">运行</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == '故障') {
                    str += '<div class="fc-conTS3000G">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX3000g1(obj[i].cardLedValue);
                    str += '</div>';
                    str += '<div class="">故障</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == '同步') {
                    str += '<div class="fc-conTS3000G">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '<div class="">同步</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'BD') {
                    str += '<div class="fc-conTS3000G">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '<div class="">BD</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'IRIG-B1') {
                    str += '<div class="fc-conTS3000G">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '<div class="">IRIG-B1</div>';
                    str += '</div>';
                }
            }
            str += '</div>';
            str += '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">';

          for (var i = 0; i < obj.length; i++) { 
                if (obj[i].cardLedLable == '状态监测') {
                    str += '<div class="fc-conTS3000G">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '<div class="">状态监测</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == '告警') {
                    str += '<div class="fc-conTS3000G">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX3000g2(obj[i].cardLedValue);
                    str += '</div>';
                    str += '<div class="">告警</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == '秒脉冲') {
                    str += '<div class="fc-conTS3000G">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '<div class="">秒脉冲</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'GPS') {
                    str += '<div class="fc-conTS3000G">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '<div class="">GPS</div>';
                    str += '</div>';
                }
                if (obj[i].cardLedLable == 'IRIG-B2') {
                    str += '<div class="fc-conTS3000G">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += this.imgX10(obj[i].cardLedValue);
                    str += '</div>';
                    str += '<div class="">IRIG-B2</div>';
                    str += '</div>';
                }
            }
            str += '</div>';
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">';
                    str += '<div class="fc-conTS3000GLCD">';
                    str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">';
                    str += '</div>';
                    str += '<div style="position:relative;top:30%;left: 10%;">2017-09-22 06:43:39</div>';
                    str += '</div>';
            str += '</div>';
            str += '</div>';

        str += '<div class="fCenter-TS3000G-3 t-middle">';
        str += '<div style=""></div>';
        str += '</div>';
        return str;
    },
    cardSM2000FREQ: function(obj, type) {
        var PWR = obj.pwr,
            Enable = obj.enable;
        var str = '';
        str += '<div class="fCenter-box-1" >'
        str += '<div class="fCenter-box1">'
        str += '<img src="images/zcard.PNG" alt="" />'
        str += '<div  translate="" style="">频率合成卡</div>'
        str += '</div>'
        str += '</div>'
        str += '<div class="fCenter-box-2">'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">PWR</div>'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 col-sm-offset-2">'
        str += this.imgX(PWR);
        str += '</div>'
        str += '</div>'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">Enable</div>'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 col-sm-offset-2">'
            //str += this.imgX1(Enable);
        if (Enable == '0') {
            str += '<img style="width:15px;" src="images/gery.png" alt="" />';
        } else if (Enable == '1') {
            str += '<img style="width:15px;" src="images/greent.gif" alt="" />';
        } else if (Enable == '2') {
            str += '<img style="width:15px;" src="images/green.PNG" alt="" />';
        }
        str += '</div>'
        str += '</div>'
        str += '</div>';
        str += '<div class="fCenter-box-3">';
        str += '<img src="images/zcardb.PNG" alt=""/>';
        str += '</div>';
        return str;
    },
    cardSM2000_GN: function(obj, type) {
        var PWR = obj.pwr,
            Enable = obj.enable;
        var str = '';
        str += '<div class="fCenter-box-1" >'
        str += '<div class="fCenter-box1">'
        str += '<img src="images/zcard.PNG" alt="" />'
        str += '<div  translate="" style="">' + type + '</div>'
        str += '</div>'
        str += '</div>'
        str += '<div class="fCenter-box-2">'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">PWR</div>'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 col-sm-offset-2">'
        str += this.imgX(PWR);
        str += '</div>'
        str += '</div>'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="position: relative;right: 9%;">Enable</div>'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 col-sm-offset-2">'
            //str += this.imgX1(Enable);
        if (Enable == '0') {
            str += '<img style="width:15px;" src="images/gery.png" alt="" />';
        } else if (Enable == '1') {
            str += '<img style="width:15px;" src="images/greent.gif" alt="" />';
        } else if (Enable == '2') {
            str += '<img style="width:15px;" src="images/green.PNG" alt="" />';
        }
        str += '</div>'
        str += '</div>'
        str += '</div>';
        str += '<div class="fCenter-box-3">';
        str += '<img src="images/zcardb.PNG" alt=""/>';
        str += '</div>';
        return str;
    },
    cardinputPtp: function(obj, type) {
        var str = '',
            sys = obj.sys,
            alarm = obj.alarm,
            ptp = obj.ptp,
            e1_1 = obj.e1_1,
            e1_2 = obj.e1_2,
            ppss_tod = obj.ppss_tod;
        str += '<div class="fCenter-box-1" >'
        str += '<div class="fCenter-box1">'
        str += '<img src="images/zcard.PNG" alt="" />'
        str += '<div style="">PTP输入卡</div>'
        str += '</div>'
        str += '</div>'
        str += '<div class="fCenter-box-2" style="width:100px;">'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        str += this.imgX1(sys);
        str += '</div>'
        str += '<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6" style="position: relative;right: 9%;">Sys</div>'
        str += '</div>'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        str += this.imgX1(alarm);
        str += '</div>'
        str += '<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6" style="position: relative;right: 9%;">Alarm</div>'
        str += '</div>'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        str += this.imgX1(ptp);
        str += '</div>'
        str += '<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6" style="position: relative;right: 9%;">PTP</div>'
        str += '</div>'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        str += this.imgX1(e1_1);
        str += '</div>'
        str += '<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8" style="position: relative;right: 9%;">E1-1</div>'
        str += '</div>'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        str += this.imgX1(e1_2);
        str += '</div>'
        str += '<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8" style="position: relative;right: 9%;">E1-2</div>'
        str += '</div>'
        str += '<div class="fc-con">'
        str += '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">'
        str += this.imgX1(ppss_tod);
        str += '</div>'
        str += '<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6" style="position: relative;right: 9%;">TOD+PPS</div>'
        str += '</div>'
        str += '</div>'
        str += '<div class="fCenter-box-3">'
        str += '<img src="images/zcardb.PNG" alt=""/>'
        str += '</div>';
        return str;
    },
    choseCard: function(obj, type, deviceType) {
        var self = this;
        self.deviceType = deviceType;
        if (deviceType === "SM2000" || deviceType === "SM2000_GN") {
            if (type === "CC") {
                return self.cardCC(obj.freeRun, obj.active, obj.lock, obj.alarm, deviceType);
            } else if (type === "MC") {
                return self.cardMC(obj.pwrA, obj.pwrB, obj.system, obj.alarm);
            } else if (type === "4-E1") { //输入卡。
                return self.cardGnss4E1(obj, deviceType);
            } else if (type === "E1-TOD") { //输入卡。
                return self.cardGnssE1TOD(obj, deviceType);
            } else if (type === "PPS-TOD" || type === "IRIG") {
                return self.cardIrigAndPpsToD(obj.pwr, obj.enable);
            } else if (type === "E1-T1") {
                return self.cardE1T1(obj.pwr, obj.enable);
            } else if (type === "Buffer") {
                return self.cardBuffer(obj.powerA, obj.powerB, obj.sys, obj.active);
            } else if (type === "PTP") {
                return self.cardPtp(obj);
            } else if (type === "NTP") {
                return self.cardNtp(obj);
            } else if (type === "input-PTP") {
                return self.cardinputPtp(obj);
            } else if (type === "FREQ") {
                return self.cardSM2000FREQ(obj, type);
            } else { //SM2000_GN
                return self.cardSM2000_GN(obj, type)
            }
        } else if (deviceType === "SSU2000") {
            return self.cardGeneral(obj, type);
        } else if (deviceType === "STFS1000") {
            return self.cardSTFS1000(obj, type);
        } else if (deviceType === "TP1000") {
            return self.cardTP1000(obj, type);
        } else if (deviceType === "HP55400") {
            return self.cardHP55400(obj, type);
        } else if (deviceType === "LF7300") {
            return self.cardLF7300(obj, type);
        } else if (deviceType === "TS3000G") {
            return self.cardTS3000G(obj, type);
        }
    }
}