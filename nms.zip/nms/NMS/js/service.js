routerApp.factory('publicService', ["$http", "$rootScope",'$translate', "ngDialog", "ngTip", "cfpLoadingBar", function($http, $rootScope,$translate, ngDialog, ngTip, cfpLoadingBar) {
    var req = function(method, flag, data, scope,asyncdata) {
        var url = {
                /*"1": "data/menu.json", //菜单*/
                "1": "/nms/spring/user/getMenu", //菜单
                "2": "/nms/spring/user/login", //登录
                "3": "/nms/spring/log/secuLog", //安全日志GET
                "4": "/nms/spring/device/parents", //设备树GET
                "5": "/nms/spring/viewData", //拓扑设备图位置连绑存GET POST
                "6": "/nms/spring/alarm/activeAlarm/fliter", //告警日志
                "7": "/nms/spring/log/nmsLog", //网管日志
                "8": "/nms/spring/log/cmdLog", //操作日志
                "9": "/nms/spring/log/eventLog", //系统日志
                "10": "/nms/spring/performances/page", // 性能日志            
                "11": "/nms/spring/databaseBackup/getConfigParamByFilter", //数据库自动备份列表
                "12": "/nms/spring/systemManage/findBybackupObectConfig", //数据库表名下拉框数据
                "13": "/nms/spring/databaseBackup/updateConfigParam", //数据库自动备份归档策略 添加修改POST
                "14": "/nms/spring/databaseBackup/getBackupLogByFilter", // 归档/备份记录GET
                "16": "/nms/spring/systemManage/softwareProcessInfo", //软件进程信息\
                "17": "/nms/spring/files/getImageMapInfo", // 地图管理GET
                /*        "18" : "/nms/spring/devices/parents/0", //区域列表GET
                        "19" : "/nms/spring/devices/parents/1", //未分配设备列表GET
                        "20" : "/nms/spring/devices", //添加设备
                        "21" : "/nms/spring/devices/update", //修改设备*/
                "22": "/nms/spring/alarm/activeAlarmFilterConfig/page", //告警过滤GET
                "23": "/nms/spring/alarm/activeAlarmFilterConfig", //告警过滤 post 添加修改
                "24": "/nms/spring/alarm/alarmForwardRule/page", //前传规则GET
                "25": "/nms/spring/alarm/alarmForwardRule", //前传规则 添加修 改
                "27": "/nms/spring/performances/pMP/page", //性能监测配置
                "28": "/nms/spring/performances/performanceMonitorParam", //性能监测配置添加修改\
                "29": "/nms/spring/user/logout", //登录退出

                "30": "/nms/spring/device/getDeviceByType", //ssu设备查询
                "31": "/nms/spring/deviceConfig/ssu2000/getAllRetrieveCommands", //获取SSU2000设备TL1主命令
                "32": "/nms/spring/deviceConfig/ts3100/getAllRetrieveCommands", 
                "33": "/nms/spring/deviceConfig/ts3000/getAllRetrieveCommands", 
                "34": "/nms/spring/deviceConfig/hp55400/getAllRetrieveCommands", 
                "35": "/nms/spring/deviceConfig/stfs1000/getAllRetrieveCommands", 
                "36": "/nms/spring/report/alarm",
                "37": "/nms/spring/report/deviceSupplier",

                "100": "/nms/spring/user/page", //用户读取
                "101": "/nms/spring/user", //用户添加
                "102": "/nms/spring/menu/page", //菜单读取
                "103": "/nms/spring/role/page", //角色读取
                "104": "/nms/spring/user", //用户编辑
                "105": "/nms/spring/role", //角色添加
                "106": "/nms/spring/role", //角色编辑
                "107": "/nms/spring/role/getRole", //用户分配角色
                "108": "/nms/spring/menu/getMenu", //角色分配菜单
                "109": "/nms/spring/device/getDevice", //角色分配设备
                "110": "/nms/spring/menu", //菜单添加
                "111": "/nms/spring/device/area", //区域列表GET
                "112": "/nms/spring/device/page", //设备下拉列表GET
                "113": "/nms/spring/device/area", //添加区域
                "114": "/nms/spring/device", //添加设备
                "115": "/nms/spring/performances/getForChart", //性能表单
                "116": "/nms/spring/device/forManager", //设备列表GET
                "117": "/nms/spring/device/cardLedConfig", //SSU板卡配置添加
                "118": "/nms/spring/device/cardLedConfig/page", //SSU板卡配置列表
                "119": "/nms/spring/systemManage/getPasswordRule",//密码规则GET
                "120": "/nms/spring/systemManage/updatePasswordRule"//密码规则SET
            },
            s = typeof flag === "number" ? url[flag] : flag,
            f = (method === "POST" || method === "DELETE" || method === "PUT") ? "data" : "params",
            o = {};
        o.method = method;
        if(asyncdata =='false'){
        o.async = false;
        }
        if(flag == 4){
            var par = document.getElementById('popover');
            if(par){
                angular.element(par).addClass('popoverS');
            }
            cfpLoadingBar.complete();
        }
        if ($rootScope.curLoginMsg) {
            if (s.indexOf("?") > -1){
            o.url = s + '&token=' + $rootScope.curLoginMsg.sessionID;
            }else{
            o.url = s + '?token=' + $rootScope.curLoginMsg.sessionID;
            }
        } else {
            o.url = s;
        }
        o[f] = data;
        o.headers = {
            'Content-Type': 'application/json;charset=UTF-8'
        };
        return $http(o).error(function(e, l, s) {
            if (l == 401) {
                var t = $translate.use() === "ch" ? '请重新登录网管系统！':'please log on to the network management system!';
                ngTip.tip(t, "danger");
                delete $rootScope.curLoginMsg;
                $rootScope.STATE.go('login');
            };
            /*      ngTip.tip("error:    " + l, "danger");*/
         var par = document.getElementById('popover');
            if(par){
                angular.element(par).addClass('popoverS');
            }
            cfpLoadingBar.complete();
            typeof scope !== "undefined" && (scope.disabledFlag = false);
        })
    }
    return {
        doRequest: function(method, flag, data, scope,asyncdata) {
            return req(method, flag, data, scope,asyncdata);
        },
        loads: function(fn) { //angular 数据加载完执行
            angular.element(document).ready(function() {
                fn();
            });
        },
        loading: function(r,flag) { //进度条加载
       /*     if(flag != 4){
            r === "start" ? (cfpLoadingBar.start()) : (cfpLoadingBar.complete());
            }*/
        },
        ngAlert: function(title, type) {
            ngTip.tip(title, type) //type类型有success warning danger
        },
        ngDialog: function(width, url, scope, fn, closeFn) {
            ngDialog.open({
                width: width,
                template: url,
                className: 'ngdialog-theme-default ngdialog-theme-custom',
                //className: 'ngdialog-theme-flat ngdialog-theme-custom',//className: 'ngdialog-theme-plain',
                scope: scope, //将scope传给test.html,以便显示地址详细信息
                controller: function($scope) {
                        fn();
                    }
                    // ,preCloseCallback : function($scope){closeFn();} 
            });
        }
    };
}]);