/*var $lang={
errAlertMsg: "Invalid date or the date out of range,redo or not?",
aWeekStr: ["wk", "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
aLongWeekStr:["wk","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"],
aMonStr: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
aLongMonStr: ["January","February","March","April","May","June","July","August","September","October","November","December"],
clearStr: "Clear",
todayStr: "Today",
okStr: "OK",
updateStr: "OK",
timeStr: "Time",
quickStr: "Quick Selection",
err_1: 'MinDate Cannot be bigger than MaxDate!'
}
*/
var $lang={
errAlertMsg: "无效日期或者日期超出范围?",
aWeekStr: ["日", "一", "二", "三", "四", "五", "六", "七"],
aLongWeekStr:["周日", "周一", "周二", "周三", "周四", "周五", "周六", "周日"],
aMonStr: ["一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"],
aLongMonStr: ["一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"],
clearStr: "清除",
todayStr: "今天",
okStr: "确定",
updateStr: "确定",
timeStr: "时间",
quickStr: "快速选择",
err_1: '最小日期不能大于最大日期!'
}