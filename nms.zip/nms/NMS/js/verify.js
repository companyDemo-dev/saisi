;
(function() {
	window.verify = {
		nullFun: function(t) {
			return (t.use() === 'ch' ? 　"不能为空！" : " can not be empty!");
		},
		formatErrorFun: function(t) {
			return (t.use() === 'ch' ? 　"格式错误！" : " wrong format!");
		},
		fe: function(m, a, b) {
			return (m + "只能为" + (a + "") + " ~ " + (b + '') + "之间的数字！");
		},
		inputPTPClient: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t);
			if (!m || verifyFun.isNull(m["inputPTPClientConfigGM1addr"])) {
				y.ngAlert("GM1addr" + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["inputPTPClientConfigGM1addr"])) {
				y.ngAlert("GM1addr" + err, "warning")
				return false;
			}
			if (!m || verifyFun.isNull(m["inputPTPClientConfigGM2addr"])) {
				y.ngAlert("GM2addr" + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["inputPTPClientConfigGM2addr"])) {
				y.ngAlert("GM2addr" + err, "warning")
				return false;
			}

			if (verifyFun.isNull(m["inputPTPClientConfigDomain"])) {
				y.ngAlert("Domain" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["inputPTPClientConfigDomain"]) || !verifyFun.between(m["inputPTPClientConfigDomain"], 0, 255)) {
				y.ngAlert(this.fe("Domain", 0, 255), "warning")
				return false;
			}
			if (verifyFun.isNull(m["inputPTPClientConfigAnnounceIntv"])) {
				y.ngAlert("AnnounceIntv" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["inputPTPClientConfigAnnounceIntv"]) || !verifyFun.between(m["inputPTPClientConfigAnnounceIntv"], 0, 3)) {
				y.ngAlert(this.fe("AnnounceIntv", 0, 3), "warning")
				return false;
			}
			if (verifyFun.isNull(m["inputPTPClientConfigSyncIntv"])) {
				y.ngAlert("SyncIntv" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["inputPTPClientConfigSyncIntv"]) || !verifyFun.between(m["inputPTPClientConfigSyncIntv"], -7, -3)) {
				y.ngAlert(this.fe("SyncIntv", -7, -3), "warning")
				return false;
			}
			if (verifyFun.isNull(m["inputPTPClientConfigDelayIntv"])) {
				y.ngAlert("DelayIntv" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["inputPTPClientConfigDelayIntv"]) || !verifyFun.between(m["inputPTPClientConfigDelayIntv"], -7, 0)) {
				y.ngAlert(this.fe("DelayIntv", -7, 0), "warning")
				return false;
			}
			return true;
		},
		inputPTPNetwork: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t);
			if (!m || verifyFun.isNull(m["address"])) {
				y.ngAlert("address" + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["address"])) {
				y.ngAlert("address" + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m["netmask"])) {
				y.ngAlert("netmask" + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["netmask"])) {
				y.ngAlert("netmask" + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m["gateway"])) {
				y.ngAlert("gateway" + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["gateway"])) {
				y.ngAlert("gateway" + err, "warning")
				return false;
			}
			return true;
		},
		passEdit: function(m, y, t) {
			var str = this.nullFun(t);
			if (verifyFun.isNull(m) || verifyFun.isNull(m.password)) {
				y.ngAlert(t.instant("NEW_PASSWORD") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m) || verifyFun.isNull(m.npassword)) {
				y.ngAlert(t.instant("CONFIRM_N_PAS") + str, "warning")
				return false;
			}
			if (m.npassword !== m.password) {
				ss = t.use() === 'ch' ? "密码不一致" : "Passwords are not consistent";
				y.ngAlert(ss, "warning");
				return false;
			}
			return true
		},
		login: function(m, y, t) {
			var str = this.nullFun(t),
				regex = new RegExp('(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[^a-zA-Z0-9]).{8,30}');
			if (verifyFun.isNull(m.userName)) {
				y.ngAlert(t.instant("USERNAME") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.password)) {
				y.ngAlert(t.instant("PASSWORD") + str, "warning")
				return false;
			}
			// if(!regex.test(m.password)){
			// 	y.ngAlert("密码中必须包含字母、数字、特称字符，至少8个字符，最多30个字符。", "warning")
			// 	return false;
			// }
			return true;
		},
		userManageAddEdit: function(m, y, t) {
			var str = this.nullFun(t),
				regex = /^(?=.*[a-zA-Z])(?=.*\d)(?=.*[~!@#$%^&*()_+`\-={}:";'<>?,.\/]).{8,30}$/,
				regexU = /^(.){5,15}$/;
			if (!m) m = {};
			if (verifyFun.isNull(m.userName)) {
				y.ngAlert(t.instant("USERNAME") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.password)) {
				y.ngAlert(t.instant("PASSWORD") + str, "warning")
				return false;
			}
			/*	if(!regexU.test(m.userName)){
					y.ngAlert("用户名不能少于5个字符，最多15个字符。", "warning")
					return false;
				}
				if(!regex.test(m.password)){
					y.ngAlert("密码中必须包含字母、数字、特称字符，至少8个字符，最多30个字符。", "warning")
					return false;
				}*/
			return true;
		},
		ip_vlan: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";
			return true;
		},
		IPETH: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";
			if (verifyFun.isNull(m["ipAddress"])) {
				y.ngAlert("IP_ADDRESS" + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["ipAddress"])) {
				y.ngAlert("IP_ADDRESS" + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m.ipPortState)) {
				y.ngAlert(s + t.instant("IP_PORT_STATE"), "warning");
				return false;
			}
			if (verifyFun.isNull(m["maskAddress"])) {
				y.ngAlert("MASK" + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["maskAddress"])) {
				y.ngAlert("MASK" + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m.ipMCMode)) {
				y.ngAlert(s + t.instant("IP_MODE"), "warning");
				return false;
			}
			if (verifyFun.isNull(m["gatewayAddress"])) {
				y.ngAlert("GATEWAY" + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["gatewayAddress"])) {
				y.ngAlert("GATEWAY" + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m.firewallState)) {
				y.ngAlert(s + t.instant("FIREWALL_State"), "warning");
				return false;
			}
			return true;
		},
		ptp_probe: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";
			if (verifyFun.isNull(m["ptpActiveProbeGMIpAddr"])) {
				y.ngAlert("Grandmaster IP" + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["ptpActiveProbeGMIpAddr"])) {
				y.ngAlert("Grandmaster IP" + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m["ptpActiveProbeVlanID"])) {
				y.ngAlert("VLAN ID" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ptpActiveProbeVlanID"]) || !verifyFun.between(m["ptpActiveProbeVlanID"], 1, 4094)) {
				y.ngAlert(this.fe("VLAN ID", 1, 4094), "warning")
				return false;
			}
			if (verifyFun.isNull(m["ptpActiveProbeGMClockID"])) {
				y.ngAlert("Grandmaster Clock ID" + str, "warning");
				return false;
			}

			if (verifyFun.isNull(m["ptpActiveProbeInterval"])) {
				y.ngAlert("Interval" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ptpActiveProbeInterval"]) || !verifyFun.between(m["ptpActiveProbeInterval"], -6, 7)) {
				y.ngAlert(this.fe("Interval", -6, 7), "warning")
				return false;
			}
			if (verifyFun.isNull(m["ptpActiveProbeDuration"])) {
				y.ngAlert("Lease Duration" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ptpActiveProbeDuration"]) || !verifyFun.between(m["ptpActiveProbeDuration"], 10, 1000)) {
				y.ngAlert(this.fe("Lease Duration", 10, 1000), "warning")
				return false;
			}
			if (verifyFun.isNull(m.ptpActiveProbeProfile)) {
				y.ngAlert(s + "Profile", "warning");
				return false;
			}
			return true;
		},
		common: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";
			if (verifyFun.isNull(m.ptpCommonState)) {
				y.ngAlert(s + t.instant("PORT_ENABLE"), "warning");
				return false;
			}
			if (verifyFun.isNull(m.ptpCommonTimescale)) {
				y.ngAlert(s + "Time Scale", "warning");
				return false;
			}

			if (verifyFun.isNull(m["ptpCommonMaxClient"])) {
				y.ngAlert(t.instant("MAX_CLIENT") + str, "warning");
				return false;
			}
			if (!verifyFun.isNumber(m["ptpCommonMaxClient"]) || !verifyFun.between(m["ptpCommonMaxClient"], 1, 1000)) {
				y.ngAlert(this.fe(t.instant("MAX_CLIENT"), 1, 1000), "warning");
				return false;
			}
			if (verifyFun.isNull(m["ptpCommonPriority1"])) {
				y.ngAlert(t.instant("PRIORITY") + '1' + str, "warning");
				return false;
			}
			if (!verifyFun.isNumber(m["ptpCommonPriority1"]) || !verifyFun.between(m["ptpCommonPriority1"], 0, 255)) {
				y.ngAlert(this.fe(t.instant("PRIORITY") + '1', 0, 255), "warning");
				return false;
			}

			if (verifyFun.isNull(m.ptpCommonProfile)) {
				y.ngAlert(s + "Profile", "warning");
				return false;
			}
			if (verifyFun.isNull(m["ptpCommonPriority2"])) {
				y.ngAlert(t.instant("PRIORITY") + '2' + str, "warning");
				return false;
			}
			if (!verifyFun.isNumber(m["ptpCommonPriority2"]) || !verifyFun.between(m["ptpCommonPriority2"], 0, 255)) {
				y.ngAlert(this.fe(t.instant("PRIORITY") + '2', 0, 255), "warning");
				return false;
			}
			if (verifyFun.isNull(m["ptpCommonClockID"])) {
				y.ngAlert("Clock ID" + str, "warning");
				return false;
			}
			if (!verifyFun.isMac(m["ptpCommonClockID"])) {
				y.ngAlert("Clock ID" + err, "warning");
				return false;
			}
			if (verifyFun.isNull(m["ptpCommonDSCP"])) {
				y.ngAlert("DSCP" + str, "warning");
				return false;
			}
			if (!verifyFun.isNumber(m["ptpCommonDSCP"]) || !verifyFun.between(m["ptpCommonDSCP"], 0, 63)) {
				y.ngAlert(this.fe("DSCP", 0, 63), "warning");
				return false;
			}
			if (verifyFun.isNull(m["ptpCommonDomain"])) {
				y.ngAlert("Domain" + str, "warning");
				return false;
			}
			if (!verifyFun.isNumber(m["ptpCommonDomain"]) || !verifyFun.between(m["ptpCommonDomain"], 0, 255)) {
				y.ngAlert(this.fe("Domain", 0, 255), "warning");
				return false;
			}
			if (verifyFun.isNull(m.ptpCommonDSCPState)) {
				y.ngAlert(s + "DSCP" + t.instant("GNSS1_ENABLE"), "warning");
				return false;
			}
			if (verifyFun.isNull(m["ptpCommonSyncLimit"])) {
				y.ngAlert("Delay Limit" + str, "warning");
				return false;
			}
			if (!verifyFun.isNumber(m["ptpCommonSyncLimit"]) || !verifyFun.between(m["ptpCommonSyncLimit"], -7, 7)) {
				y.ngAlert(this.fe("Sync Limit", -7, 7), "warning");
				return false
			}
			if (verifyFun.isNull(m["ptpCommonDelayLimit"])) {
				y.ngAlert("Delay Limit" + str, "warning");
				return false;
			}
			if (!verifyFun.isNumber(m["ptpCommonDelayLimit"]) || !verifyFun.between(m["ptpCommonDelayLimit"], -7, 7)) {
				y.ngAlert(this.fe("Delay Limit", -7, 7), "warning");
				return false
			}
			if (verifyFun.isNull(m.ptpCommonDither)) {
				y.ngAlert(s + "Dither", "warning");
				return false;
			}
			if (verifyFun.isNull(m.ptpCommonTwoStep)) {
				y.ngAlert(s + "Two Step", "warning");
				return false;
			}
			if (verifyFun.isNull(m["ptpCommonTTL"])) {
				y.ngAlert("TTL" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ptpCommonTTL"]) || !verifyFun.between(m["ptpCommonTTL"], 1, 255)) {
				y.ngAlert(this.fe("TTL", 1, 255), "warning")
			}
			if (verifyFun.isNull(m.ptpCommonMgmtAddrMode)) {
				y.ngAlert(s + t.instant("MANAGED_ADDRESS_MODE"), "warning");
				return false;
			}
			if (verifyFun.isNull(m.ptpCommonAlternateMaster)) {
				y.ngAlert(s + "Alternate Master", "warning");
				return false;
			}
			if (verifyFun.isNull(m.ptpUnicastNegotiate)) {
				y.ngAlert(s + "Unicast Negotiation", "warning");
				return false;
			}

			if (verifyFun.isNull(m["ptpUnicastLeaseDuration"])) {
				y.ngAlert("Unicast Lease Duration" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ptpUnicastLeaseDuration"]) || !verifyFun.between(m["ptpUnicastLeaseDuration"], 10, 1000)) {
				y.ngAlert(this.fe("Unicast Lease Duration:", 10, 1000), "warning")
			}
			return true;
		},
		Unicast_clinet: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";
			if (verifyFun.isNull(m.ptpUnicastClientState)) {
				y.ngAlert(s + t.instant("GNSS1_ENABLE"), "warning")
				return false;
			}
			if (verifyFun.isNull(m["ptpUnicastClientAddr"])) {
				y.ngAlert(t.instant("ADDRESS") + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["ptpUnicastClientAddr"])) {
				y.ngAlert(t.instant("ADDRESS") + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m["ptpUnicastClientVlanID"])) {
				y.ngAlert("VLAN ID" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ptpUnicastClientVlanID"]) || !verifyFun.between(m["ptpUnicastClientVlanID"], 1, 4094)) {
				y.ngAlert(this.fe("VLAN ID", 1, 4094), "warning")
				return false;
			}
			if (verifyFun.isNull(m["ptpUnicastClientClockID"])) {
				y.ngAlert("Clock ID" + str, "warning");
				return false;
			}
			if (!verifyFun.isMac(m["ptpUnicastClientClockID"])) {
				y.ngAlert("Clock ID" + err, "warning");
				return false;
			}

			if (verifyFun.isNull(m["ptpUnicastClientSync"])) {
				y.ngAlert("Sync" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ptpUnicastClientSync"]) || !verifyFun.between(m["ptpUnicastClientSync"], -7, 7)) {
				y.ngAlert(this.fe("Sync", -7, 7), "warning")
				return false;
			}
			if (verifyFun.isNull(m["ptpUnicastClientDelay"])) {
				y.ngAlert("Delay" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ptpUnicastClientDelay"]) || !verifyFun.between(m["ptpUnicastClientDelay"], -7, 7)) {
				y.ngAlert(this.fe("Delay", -7, 7), "warning")
				return false;
			}
			if (verifyFun.isNull(m["ptpUnicastClientAnnounce"])) {
				y.ngAlert("通知" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ptpUnicastClientAnnounce"]) || !verifyFun.between(m["ptpUnicastClientAnnounce"], -4, 4)) {
				y.ngAlert(this.fe("通知", -4, 4), "warning")
				return false;
			}
			return true;
		},
		multicast: function(m, y, t) {
			var str = this.nullFun(t);
			if (verifyFun.isNull(m["ptpMulticastVlanID"])) {
				y.ngAlert("VLAN ID" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ptpMulticastVlanID"]) || !verifyFun.between(m["ptpMulticastVlanID"], 0, 4094)) {
				y.ngAlert(this.fe("VLAN ID", 0, 4094), "warning")
				return false;
			}
			if (verifyFun.isNull(m["ptpMulticastAnnounceIntv"])) {
				y.ngAlert("Announce Interval" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ptpMulticastAnnounceIntv"]) || !verifyFun.between(m["ptpMulticastAnnounceIntv"], -4, 4)) {
				y.ngAlert(this.fe("Announce Interval", -4, 4), "warning")
				return false;
			}
			if (verifyFun.isNull(m["ptpMulticastDelayIntv"])) {
				y.ngAlert("Delay Interval" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ptpMulticastDelayIntv"]) || !verifyFun.between(m["ptpMulticastDelayIntv"], -7, 7)) {
				y.ngAlert(this.fe("Delay Interval", -7, 7), "warning")
				return false;
			}

			if (verifyFun.isNull(m["ptpMulticastAnnounceTimeout"])) {
				y.ngAlert("Announce Timeout" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ptpMulticastAnnounceTimeout"]) || !verifyFun.between(m["ptpMulticastAnnounceTimeout"], 2, 10)) {
				y.ngAlert(this.fe("Announce Timeout", 2, 10), "warning")
				return false;
			}

			if (verifyFun.isNull(m["ptpMulticastClientTimeout"])) {
				y.ngAlert("Client Timeout" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ptpMulticastClientTimeout"]) || !verifyFun.between(m["ptpMulticastClientTimeout"], 10, 3600)) {
				y.ngAlert(this.fe("Client Timeout", 10, 3600), "warning")
				return false;
			}
			return true;
		},
		ntp: function(m, y, t) {
			var str = this.nullFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";
			if (verifyFun.isNull(m.ntpState)) {
				y.ngAlert(s + "NTP" + t.instant("GNSS1_ENABLE"), "warning")
				return false;
			}
			if (verifyFun.isNull(m.ntpDSCPState)) {
				y.ngAlert(s + "DSCP" + t.instant("GNSS1_ENABLE"), "warning")
				return false;
			}
			if (verifyFun.isNull(m["ntpDSCP"])) {
				y.ngAlert("DSCP" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ntpDSCP"]) || !verifyFun.between(m["ntpDSCP"], 0, 63)) {
				y.ngAlert(this.fe("DSCP", 0, 63), "warning")
				return false;
			}
			if (verifyFun.isNull(m["ntpTTL"])) {
				y.ngAlert("TTL" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ntpTTL"]) || !verifyFun.between(m["ntpTTL"], 1, 255)) {
				y.ngAlert(this.fe("TTL", 1, 255), "warning")
				return false;
			}
			if (verifyFun.isNull(m["ntpVlanID"])) {
				y.ngAlert("VLAN ID" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ntpVlanID"]) || !verifyFun.between(m["ntpVlanID"], 1, 4094)) {
				y.ngAlert(this.fe("VLAN ID", 1, 4094), "warning")
				return false;
			}
			return true;
		},
		ntp_probe: function(m, y, t) {
			var str = this.nullFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ",
				err = this.formatErrorFun(t);
			if (verifyFun.isNull(m["ntpProbeServerIP"])) {
				y.ngAlert("Server IP" + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m.ntpProbeServerIP)) {
				y.ngAlert("Server IP" + err, "warning")
				return false;
			}

			if (verifyFun.isNull(m["ntpProbeInterval"])) {
				y.ngAlert("Interval" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ntpProbeInterval"]) || !verifyFun.between(m["ntpProbeInterval"], -6, 7)) {
				y.ngAlert(this.fe("Interval", -6, 7), "warning")
				return false;
			}

			if (verifyFun.isNull(m["ntpProbeVlanID"])) {
				y.ngAlert("VLAN ID" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ntpProbeVlanID"]) || !verifyFun.between(m["ntpProbeVlanID"], 1, 4094)) {
				y.ngAlert(this.fe("VLAN ID", 1, 4094), "warning")
				return false;
			}
			// if(verifyFun.isNull(m.ntpProbeDataFormat)){
			// 	y.ngAlert(s + "DSCP" + t.instant("DATA_FORMAT"), "warning")
			// 	return false;
			// }

			// if(verifyFun.isNull(m["ttl"])){
			// 	y.ngAlert("TTL" + str, "warning")
			// 	return false;
			// }
			// if(!verifyFun.isNumber(m["ttl"]) || !verifyFun.between(m["ttl"], 1, 4094)){
			// 	y.ngAlert(this.fe("TTL", 1, 4094), "warning")
			// 	return false;
			// }
			return true;
		},
		outputPTPCommon: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";
			if (verifyFun.isNull(m.outputPTPCommonConfigPTPstate)) {
				y.ngAlert(s + t.instant("PORT_ENABLE"), "warning");
				return false;
			}
			if (verifyFun.isNull(m.outputPTPCommonOtherConfigTimaScale)) {
				y.ngAlert(s + "Time Scale", "warning");
				return false;
			}

			if (verifyFun.isNull(m["outputPTPCommonConfigMaxClients"])) {
				y.ngAlert(t.instant("MAX_CLIENT") + str, "warning");
				return false;
			}
			if (!verifyFun.isNumber(m["outputPTPCommonConfigMaxClients"]) || !verifyFun.between(m["outputPTPCommonConfigMaxClients"], 1, 500)) {
				y.ngAlert(this.fe(t.instant("MAX_CLIENT"), 1, 500), "warning");
				return false;
			}
			if (verifyFun.isNull(m["outputPTPCommonConfigPriority1"])) {
				y.ngAlert(t.instant("PRIORITY") + '1' + str, "warning");
				return false;
			}
			if (!verifyFun.isNumber(m["outputPTPCommonConfigPriority1"]) || !verifyFun.between(m["outputPTPCommonConfigPriority1"], 0, 255)) {
				y.ngAlert(this.fe(t.instant("PRIORITY") + '1', 0, 255), "warning");
				return false;
			}

			if (verifyFun.isNull(m.outputPTPCommonConfigProfile)) {
				y.ngAlert(s + "Profile", "warning");
				return false;
			}
			if (verifyFun.isNull(m["outputPTPCommonConfigPriority2"])) {
				y.ngAlert(t.instant("PRIORITY") + '2' + str, "warning");
				return false;
			}
			if (!verifyFun.isNumber(m["outputPTPCommonConfigPriority2"]) || !verifyFun.between(m["outputPTPCommonConfigPriority2"], 0, 255)) {
				y.ngAlert(this.fe(t.instant("PRIORITY") + '2', 0, 255), "warning");
				return false;
			}
			if (verifyFun.isNull(m["outputPTPCommonConfigClockID"])) {
				y.ngAlert("Clock ID" + str, "warning");
				return false;
			}
			if (!verifyFun.isMac(m["outputPTPCommonConfigClockID"])) {
				y.ngAlert("Clock ID" + err, "warning");
				return false;
			}
			if (verifyFun.isNull(m["outputPTPCommonConfigDSCP"])) {
				y.ngAlert("DSCP" + str, "warning");
				return false;
			}
			if (!verifyFun.isNumber(m["outputPTPCommonConfigDSCP"]) || !verifyFun.between(m["outputPTPCommonConfigDSCP"], 0, 63)) {
				y.ngAlert(this.fe("DSCP", 0, 63), "warning");
				return false;
			}
			if (verifyFun.isNull(m["outputPTPCommonConfigDomain"])) {
				y.ngAlert("Domain" + str, "warning");
				return false;
			}
			if (!verifyFun.isNumber(m["outputPTPCommonConfigDomain"]) || !verifyFun.between(m["outputPTPCommonConfigDomain"], 0, 255)) {
				y.ngAlert(this.fe("Domain", 0, 255), "warning");
				return false;
			}
			if (verifyFun.isNull(m.outputPTPCommonConfigDSCPstate)) {
				y.ngAlert(s + "DSCP" + t.instant("GNSS1_ENABLE"), "warning");
				return false;
			}
			if (verifyFun.isNull(m["outputPTPCommonConfigDelayLimit"])) {
				y.ngAlert("Delay Limit" + str, "warning");
				return false;
			}
			if (!verifyFun.isNumber(m["outputPTPCommonConfigDelayLimit"]) || !verifyFun.between(m["outputPTPCommonConfigDelayLimit"], -7, 7)) {
				y.ngAlert(this.fe("Delay Limit", -7, 7), "warning");
				return false
			}
			if (verifyFun.isNull(m.outputPTPCommonConfigDither)) {
				y.ngAlert(s + "Dither", "warning");
				return false;
			}
			if (verifyFun.isNull(m.outputPTPCommonConfigTwoStep)) {
				y.ngAlert(s + "Two Step", "warning");
				return false;
			}
			if (verifyFun.isNull(m["outputPTPCommonConfigTTL"])) {
				y.ngAlert("TTL" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["outputPTPCommonConfigTTL"]) || !verifyFun.between(m["outputPTPCommonConfigTTL"], 1, 255)) {
				y.ngAlert(this.fe("TTL", 1, 255), "warning")
			}
			if (verifyFun.isNull(m.outputPTPCommonConfigMgmtAddrMode)) {
				y.ngAlert(s + t.instant("MANAGED_ADDRESS_MODE"), "warning");
				return false;
			}
			if (verifyFun.isNull(m.outputPTPCommonConfigAlternateMaster)) {
				y.ngAlert(s + "Alternate Master", "warning");
				return false;
			}
			if (verifyFun.isNull(m.outputPTPCommonConfigUnicastNegotiate)) {
				y.ngAlert(s + "Unicast Negotiation", "warning");
				return false;
			}

			if (verifyFun.isNull(m["outputPTPCommonConfigUnicastLeaseDuration"])) {
				y.ngAlert("Unicast Lease Duration" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["outputPTPCommonConfigUnicastLeaseDuration"]) || !verifyFun.between(m["outputPTPCommonConfigUnicastLeaseDuration"], 10, 1000)) {
				y.ngAlert(this.fe("Unicast Lease Duration:", 10, 1000), "warning")
			}
			return true;
		},
		outputPTPMulticast: function(m, y, t) {
			var str = this.nullFun(t);
			if (verifyFun.isNull(m["outputPTPMulticastVlanID"])) {
				y.ngAlert("VLAN ID" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["outputPTPMulticastVlanID"]) || !verifyFun.between(m["outputPTPMulticastVlanID"], 0, 4094)) {
				y.ngAlert(this.fe("VLAN ID", 0, 4094), "warning")
				return false;
			}
			if (verifyFun.isNull(m["outputPTPMulticastAnnounceIntv"])) {
				y.ngAlert("Announce Interval" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["outputPTPMulticastAnnounceIntv"]) || !verifyFun.between(m["outputPTPMulticastAnnounceIntv"], -4, 4)) {
				y.ngAlert(this.fe("Announce Interval", -4, 4), "warning")
				return false;
			}
			if (verifyFun.isNull(m["outputPTPMulticastDelayIntv"])) {
				y.ngAlert("Delay Interval" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["outputPTPMulticastDelayIntv"]) || !verifyFun.between(m["outputPTPMulticastDelayIntv"], -7, 7)) {
				y.ngAlert(this.fe("Delay Interval", -7, 7), "warning")
				return false;
			}

			if (verifyFun.isNull(m["outputPTPMulticastAnnounceTimeout"])) {
				y.ngAlert("Announce Timeout" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["outputPTPMulticastAnnounceTimeout"]) || !verifyFun.between(m["outputPTPMulticastAnnounceTimeout"], 2, 10)) {
				y.ngAlert(this.fe("Announce Timeout", 2, 10), "warning")
				return false;
			}

			if (verifyFun.isNull(m["outputPTPMulticastClientTimeout"])) {
				y.ngAlert("Client Timeout" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["outputPTPMulticastClientTimeout"]) || !verifyFun.between(m["outputPTPMulticastClientTimeout"], 10, 3600)) {
				y.ngAlert(this.fe("Client Timeout", 10, 3600), "warning")
				return false;
			}
			return true;
		},
		outputPTPNetwork: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";
			if (verifyFun.isNull(m["ipAddress"])) {
				y.ngAlert("IP_ADDRESS" + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["ipAddress"])) {
				y.ngAlert("IP_ADDRESS" + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m.outputPTPNetworkConfigIpState)) {
				y.ngAlert(s + t.instant("IP_PORT_STATE"), "warning");
				return false;
			}
			if (verifyFun.isNull(m["maskAddress"])) {
				y.ngAlert("MASK" + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["maskAddress"])) {
				y.ngAlert("MASK" + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m["gatewayAddress"])) {
				y.ngAlert("GATEWAY" + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["gatewayAddress"])) {
				y.ngAlert("GATEWAY" + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m.outputPTPNetworkConfigVlanMode)) {
				y.ngAlert(s + t.instant("IP_VlanMode"), "warning");
				return false;
			}
			if (verifyFun.isNull(m.outputPTPNetworkConfigAutoNegState)) {
				y.ngAlert(s + t.instant("AutoNeg_State"), "warning");
				return false;
			}
			if (verifyFun.isNull(m.outputPTPNetworkConfigDuplex)) {
				y.ngAlert(s + t.instant("Duplex"), "warning");
				return false;
			}
			if (verifyFun.isNull(m.outputPTPNetworkConfigSpeed)) {
				y.ngAlert(s + t.instant("Speed"), "warning");
				return false;
			}
			return true;
		},
		outputPTPntpAuthenticaKeys: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";
			if (verifyFun.isNull(m.outputPTPntpAuthenticaConfigMD5State)) {
				y.ngAlert(s + t.instant("MD5_State"), "warning");
				return false;
			}
			if (verifyFun.isNull(m.outputPTPntpAuthenticaConfigAutokeyState)) {
				y.ngAlert(s + t.instant("Autokey_State"), "warning");
				return false;
			}
			return true;
		},
		outputPTPntpListState: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";
			if (verifyFun.isNull(m.outputPTPntpListState)) {
				y.ngAlert(s + t.instant("PTPntpList_State"), "warning");
				return false;
			}
			return true;
		},
		ntpWhitelistIP: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";
			if (verifyFun.isNull(m.outputPTPntpWhitelistAddr)) {
				y.ngAlert(t.instant("NE_IP") + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m.outputPTPntpWhitelistAddr)) {
				y.ngAlert(t.instant("NE_IP") + err, "warning")
				return false;
			}

			if (!verifyFun.isNull(m.outputPTPntpWhitelistAddr2)) {
				if (!verifyFun.isIp(m.outputPTPntpWhitelistAddr2)) {
					y.ngAlert(t.instant("NE_IP") + err, "warning")
					return false;
				}
			}

			return true;
		},
		otherOutPut: function(m, y, t) {
			var str = this.nullFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";
			if (verifyFun.isNull(m.refModeConfig)) {
				y.ngAlert(s + "Reference Mode", "warning")
				return false;
			}
			if (verifyFun.isNull(m.refCriteriaConfig)) {
				y.ngAlert(s + "Reference Criteria", "warning")
				return false;
			}
			return true;
		},
		ppsTod: function(m, y, t) {
			var str = this.nullFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";
			if (verifyFun.isNull(m.ppsTODState)) {
				y.ngAlert(s + t.instant("PORT_ENABLE"), "warning")
				return false;
			}
			if (verifyFun.isNull(m["ppsTODPriority"])) {
				y.ngAlert("优先级" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ppsTODPriority"]) || !verifyFun.between(m["ppsTODPriority"], 0, 16)) {
				y.ngAlert(this.fe("优先级", 0, 16), "warning")
				return false;
			}

			if (verifyFun.isNull(m["ppsTODCableDelay"])) {
				y.ngAlert("Cable Delay" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ppsTODCableDelay"]) || !verifyFun.between(m["ppsTODCableDelay"], 0, 200000)) {
				y.ngAlert(this.fe("Cable Delay", 0, 200000), "warning")
				return false;
			}

			if (verifyFun.isNull(m["ppsTODPQL"])) {
				y.ngAlert(t.instant("PQL_VALUE") + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ppsTODPQL"]) || !verifyFun.between(m["ppsTODPQL"], 1, 3)) {
				y.ngAlert(this.fe(t.instant("PQL_VALUE"), 1, 3), "warning")
				return false;
			}
			return true;
		},
		IRIG: function(m, y, t) {
			var str = this.nullFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";
			if (verifyFun.isNull(m.irigState)) {
				y.ngAlert(s + t.instant("PORT_ENABLE"), "warning")
				return false;
			}
			if (verifyFun.isNull(m["irigPriority"])) {
				y.ngAlert("优先级" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["irigPriority"]) || !verifyFun.between(m["irigPriority"], 0, 16)) {
				y.ngAlert(this.fe("优先级", 0, 16), "warning")
				return false;
			}

			if (verifyFun.isNull(m["irigCableDelay"])) {
				y.ngAlert("Cable Delay" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["irigCableDelay"]) || !verifyFun.between(m["irigCableDelay"], 0, 200000)) {
				y.ngAlert(this.fe("Cable Delay", 0, 200000), "warning")
				return false;
			}

			if (verifyFun.isNull(m["irigPQL"])) {
				y.ngAlert(t.instant("PQL_VALUE") + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["irigPQL"]) || !verifyFun.between(m["irigPQL"], 1, 3)) {
				y.ngAlert(this.fe(t.instant("PQL_VALUE"), 1, 3), "warning")
				return false;
			}
			return true;
		},
		outputNTPbroadcast: function(m, y, t) {
			var str = this.nullFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ",
				err = this.formatErrorFun(t);
			if (!verifyFun.isIp(m.outputNTPbroadcastIP)) {
				if (m.outputNTPbroadcastIP == undefined) {
					return true;
				}
				y.ngAlert(t.instant("NE_IP") + err, "warning")
				return false;
			}
			if (!verifyFun.betweenN(m["outputNTPbroadcastInterval"], 3, 17)) {
				if (m["outputNTPbroadcastInterval"] == undefined) {
					return true;
				}
				y.ngAlert(this.fe("Interval", 3, 17), "warning")
				return false;
			}
			return true;
		},
		e1tod: function(m, y, t) {
			var str = this.nullFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";
			if (verifyFun.isNull(m.inputE1State)) {
				y.ngAlert(s + t.instant("PORT_ENABLE"), "warning")
				return false;
			}
			if (verifyFun.isNull(m["inputE1Priority"])) {
				y.ngAlert(t.instant("PRIORITY") + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["inputE1Priority"]) || !verifyFun.between(m["inputE1Priority"], 1, 16)) {
				y.ngAlert(this.fe(t.instant("PRIORITY"), 1, 16), "warning")
				return false;
			}

			if (verifyFun.isNull(m.inputE1FrameType)) {
				y.ngAlert(s + t.instant("FRAME_TYPE"), "warning")
				return false;
			}
			if (verifyFun.isNull(m.inputE1CRCState)) {
				y.ngAlert(s + t.instant("CRC_STATE"), "warning")
				return false;
			}
			if (verifyFun.isNull(m.inputE1SSMState)) {
				y.ngAlert(s + t.instant("SSM_STATE"), "warning")
				return false;
			}
			if (verifyFun.isNull(m["inputE1SSMState"])) {
				y.ngAlert("SSM Bit" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["inputE1SSMBit"]) || !verifyFun.between(m["inputE1SSMBit"], 4, 8)) {
				y.ngAlert(this.fe("SSM Bit", 4, 8), "warning")
				return false;
			}
			if (verifyFun.isNull(m.inputE1QL)) {
				y.ngAlert(s + t.instant("QUALITY_GRADE"), "warning")
				return false;
			}
			return true;
		},
		e1: function(m, y, t) {
			var str = this.nullFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";
			if (verifyFun.isNull(m.inputCardState)) {
				y.ngAlert(s + t.instant("PORT_ENABLE"), "warning")
				return false;
			}
			if (verifyFun.isNull(m["inputCardPriority"])) {
				y.ngAlert(t.instant("PRIORITY") + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["inputCardPriority"]) || !verifyFun.between(m["inputCardPriority"], 0, 16)) {
				y.ngAlert(this.fe(t.instant("PRIORITY"), 0, 16), "warning")
				return false;
			}

			if (verifyFun.isNull(m.inputCardFrameType)) {
				y.ngAlert(s + t.instant("FRAME_TYPE"), "warning")
				return false;
			}
			if (verifyFun.isNull(m.inputCardCRCState)) {
				y.ngAlert(s + t.instant("CRC_STATE"), "warning")
				return false;
			}
			if (verifyFun.isNull(m.inputCardSSMState)) {
				y.ngAlert(s + t.instant("SSM_STATE"), "warning")
				return false;
			}
			if (verifyFun.isNull(m["inputCardSSMBit"])) {
				y.ngAlert("SSM Bit" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["inputCardSSMBit"]) || !verifyFun.between(m["inputCardSSMBit"], 4, 8)) {
				y.ngAlert(this.fe("SSM Bit", 4, 8), "warning")
				return false;
			}
			if (verifyFun.isNull(m.inputCardPQL)) {
				y.ngAlert(s + t.instant("QUALITY_GRADE"), "warning")
				return false;
			}
			return true;
		},
		gnss: function(m, y, t, n) {
			var str = this.nullFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";
			if (verifyFun.isNull(m["gnss" + n + "State"])) {
				y.ngAlert(s + "Gnss" + n + t.instant("GNSS1_ENABLE"), "warning")
				return false;
			}
			if (verifyFun.isNull(m["gnss" + n + "Mode"])) {
				y.ngAlert(s + "Gnss" + n + t.instant("GNSS1_PATTERN"), "warning")
				return false;
			}
			if (verifyFun.isNull(m["gnss" + n + "Priority"])) {
				y.ngAlert("优先级" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["gnss" + n + "Priority"]) || !verifyFun.between(m["gnss" + n + "Priority"], 1, 16)) {
				y.ngAlert(this.fe("优先级", 1, 16), "warning")
				return false;
			}
			if (verifyFun.isNull(m["gnss" + n + "TrackMode"])) {
				y.ngAlert(s + t.instant("TRACKING_MODE"), "warning")
				return false;
			}
			if (verifyFun.isNull(m["gnss" + n + "Mask"])) {
				y.ngAlert("Mask" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["gnss" + n + "Mask"]) || !verifyFun.between(m["gnss" + n + "Mask"], 5, 45)) {
				y.ngAlert(this.fe("Mask", 5, 45), "warning")
				return false;
			}

			if (verifyFun.isNull(m["gnss" + n + "CableDelay"])) {
				y.ngAlert(t.instant("ANTENNA_DELAY") + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["gnss" + n + "CableDelay"]) || !verifyFun.between(m["gnss" + n + "CableDelay"], 0, 65485)) {
				y.ngAlert(this.fe(t.instant("ANTENNA_DELAY"), 0, 65485), "warning")
				return false;
			}

			if (verifyFun.isNull(m["gnss" + n + "PQLState"])) {
				y.ngAlert(s + t.instant("PQL_STATE"), "warning")
				return false;
			}

			if (verifyFun.isNull(m["gnss" + n + "PQL"])) {
				y.ngAlert(t.instant("PQL_VALUE") + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["gnss" + n + "PQL"]) || !verifyFun.between(m["gnss" + n + "PQL"], 1, 3)) {
				y.ngAlert(this.fe(t.instant("PQL_VALUE"), 1, 3), "warning")
				return false;
			}

			if (verifyFun.isNull(m["gnss" + n + "CurrentPositionJ"])) {
				y.ngAlert(t.instant("LONGITUDE") + str, "warning")
				return false;
			}

			if (verifyFun.isNull(m["gnss" + n + "CurrentPositionW"])) {
				y.ngAlert(t.instant("LATITUDE") + str, "warning")
				return false;
			}

			if (verifyFun.isNull(m["gnss" + n + "CurrentPositionH"])) {
				y.ngAlert(t.instant("HEIGHT") + str, "warning")
				return false;
			}
			return true;
		},
		deviceManageEditAdd: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t);
			if (verifyFun.isNull(m.area) || verifyFun.isNull(m.area.id)) {
				y.ngAlert(t.instant("ARER") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.name)) {
				y.ngAlert(t.instant("NE_NAME") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.ip)) {
				y.ngAlert(t.instant("NE_IP") + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m.ip)) {
				y.ngAlert(t.instant("NE_IP") + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m.description)) {
				y.ngAlert(t.instant("NE_DESCRIBE") + str, "warning")
				return false;
			}
			return true;
		},
		roleManageEditAdd: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t);
			if (verifyFun.isNull(m.roleName)) {
				y.ngAlert(t.instant("ARER") + str, "warning")
				return false;
			}
			return true;
		},
		performanceConfigEditAdd: function(m, y, t) {
			var str = this.nullFun(t);
			if (verifyFun.isNull(m.device)) {
				y.ngAlert(t.instant("DEVICE") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.monitorPeriod)) {
				y.ngAlert(t.instant("MONITORING_PERIOD") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.port)) {
				y.ngAlert(t.instant("PORT") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.monitorStartTime)) {
				y.ngAlert(t.instant("MONITORING_BEGIN_TIME") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.monitorEndTime)) {
				y.ngAlert(t.instant("MONITORING_END_TIME") + str, "warning")
				return false;
			}
			return true;
		},
		syncManageAdd: function(m, y, t) {
			var str = this.nullFun(t);

			if (verifyFun.isNull(m.timeZone)) {
				y.ngAlert("timeZone " + str, "warning")
				return false;
			}

			if (!verifyFun.isNumber(m["timeZone"]) || !verifyFun.between(m["timeZone"], -12, 12)) {
				y.ngAlert(this.fe("timeZone", -12, 12), "warning")
				return false;
			}

			return true;
		},
		alarmFilterAdd: function(m, y, t) {
			var str = this.nullFun(t);

			if (verifyFun.isNull(m.threshold)) {
				y.ngAlert("threshold " + str, "warning")
				return false;
			}

			if (!verifyFun.isNumber(m["threshold"]) || !verifyFun.between(m["threshold"], 0, 100)) {
				y.ngAlert(this.fe("threshold", 0, 100), "warning")
				return false;
			}

			return true;
		},
		areaManageAdd: function(m, y, t) {
			var str = this.nullFun(t);
			if (verifyFun.isNull(m)) {
				y.ngAlert(t.instant("AREA_NAME") + str, "warning")
				return false;
			}
			return true;
		},
		alarmFilterEditAdd: function(m, y, t) {
			var str = this.nullFun(t);
			if (verifyFun.isNull(m.activeAlarmId)) {
				y.ngAlert(t.instant("activeAlarmId") + str, "warning")
				return false;
			}

			if (verifyFun.isNull(m.activeAlarmLevel)) {
				y.ngAlert(t.instant("activeAlarmLevel") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.enable)) {
				y.ngAlert(t.instant("MAIL") + str, "warning")
				return false;
			}

			return true;
		},
		alarmRuleEditAdd: function(m, y, t) {
			var str = this.nullFun(t);
			if (verifyFun.isNull(m.activeAlarmId)) {
				y.ngAlert(t.instant("activeAlarmId") + str, "warning")
				return false;
			}

			if (verifyFun.isNull(m.activeAlarmLevel)) {
				y.ngAlert(t.instant("activeAlarmLevel") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.sendFlag)) {
				y.ngAlert(t.instant("MAIL") + str, "warning")
				return false;
			}
			return true;
		},
		alarmConfig: function(m, y, t) {
			var str = this.nullFun(t);
			if (verifyFun.isNull(m.alarmState)) {
				y.ngAlert(t.instant("alarmState") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.alarmLevel)) {
				y.ngAlert(t.instant("alarmLevel") + str, "warning")
				return false;
			}
			return true;
		},
		alarmthreshold: function(m, y, t) {
			var str = this.nullFun(t);
			if (verifyFun.isNull(m)) {
				y.ngAlert(t.instant("value") + str, "warning")
				return false;
			}

			if (!verifyFun.isNumber(m["value"]) || !verifyFun.between(m["value"], -1000000, 1000000)) {
				y.ngAlert(this.fe("Interval", -1000000, 1000000), "warning")
				return false;
			}
			return true;
		},
		inputOutput: function(m, y, t) {
			var str = this.nullFun(t);
			if (verifyFun.isNull(m.outputSquelchState)) {
				y.ngAlert(t.instant("outputSquelchState") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.outputPPSState)) {
				y.ngAlert(t.instant("outputPPSState") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.output10MState)) {
				y.ngAlert(t.instant("output10MState") + str, "warning")
				return false;
			}
			return true;
		},
		ntpServer: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t);
			if (verifyFun.isNull(m.ntpServerAutoKeyEnable)) {
				y.ngAlert(t.instant("ntpServerAutoKeyEnable") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.ntpServerMd5Enable)) {
				y.ngAlert(t.instant("ntpServerMd5Enable") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.ntpServerBroadcastEnable)) {
				y.ngAlert(t.instant("ntpServerBroadcastEnable") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.ntpServerManycastEnable)) {
				y.ngAlert(t.instant("ntpServerManycastEnable") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.ntpServerBroadcastAddr)) {
				y.ngAlert(t.instant("ntpServerBroadcastAddr") + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["ntpServerBroadcastAddr"])) {
				y.ngAlert("IP_ADDRESS" + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m.ntpServerManycastAddr)) {
				y.ngAlert(t.instant("ntpServerManycastAddr") + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["ntpServerManycastAddr"])) {
				y.ngAlert("IP_ADDRESS" + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m.ntpServerBroadcastInterval)) {
				y.ngAlert(t.instant("ntpServerBroadcastInterval") + str, "warning")
				return false;
			}

			if (!verifyFun.isNumber(m["ntpServerBroadcastInterval"]) || !verifyFun.between(m["ntpServerBroadcastInterval"], -6, 7)) {
				y.ngAlert(this.fe("Interval", -6, 7), "warning")
				return false;
			}
			if (verifyFun.isNull(m.ntpServerManycastInterval)) {
				y.ngAlert(t.instant("ntpServerManycastInterval") + str, "warning")
				return false;
			}

			if (!verifyFun.isNumber(m["ntpServerManycastInterval"]) || !verifyFun.between(m["ntpServerManycastInterval"], -6, 7)) {
				y.ngAlert(this.fe("Interval", -6, 7), "warning")
				return false;
			}
			if (verifyFun.isNull(m.ipAddress)) {
				y.ngAlert(t.instant("ipAddress") + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["ipAddress"])) {
				y.ngAlert("IP_ADDRESS" + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m["maskAddress"])) {
				y.ngAlert("MASK" + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["maskAddress"])) {
				y.ngAlert("MASK" + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m["gatewayAddress"])) {
				y.ngAlert("GATEWAY" + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["gatewayAddress"])) {
				y.ngAlert("GATEWAY" + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m.ntpServerConfigPortState)) {
				y.ngAlert(t.instant("ntpServerConfigPortState") + str, "warning")
				return false;
			}
			return true;
		},
		ntp7200: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t);
			if (verifyFun.isNull(m.ntpAutokeyState)) {
				y.ngAlert(t.instant("ntpAutokeyState") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.ntpMD5State)) {
				y.ngAlert(t.instant("ntpMD5State") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.ntpInputAddress)) {
				y.ngAlert(t.instant("ntpInputAddress") + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["ntpInputAddress"])) {
				y.ngAlert("IP_ADDRESS" + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m.ntpInterval)) {
				y.ngAlert(t.instant("ntpInterval") + str, "warning")
				return false;
			}

			if (!verifyFun.isNumber(m["ntpInterval"]) || !verifyFun.between(m["ntpInterval"], -6, 7)) {
				y.ngAlert(this.fe("Interval", -6, 7), "warning")
				return false;
			}

			return true;
		},
		refOffsetHistoryTableSET: function(m, y, t) {
			var str = this.nullFun(t);
			if (verifyFun.isNull(m.refOffsetHistoryShowFlag)) {
				y.ngAlert(t.instant("refOffsetHistoryShowFlag") + str, "warning")
				return false;
			}

			if (verifyFun.isNull(m.refOffsetHistoryShowNumber)) {
				y.ngAlert(t.instant("refOffsetHistoryShowNumber") + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["refOffsetHistoryShowNumber"]) || !verifyFun.between(m["refOffsetHistoryShowNumber"], 1, 10)) {
				y.ngAlert(this.fe("refOffsetHistoryShowNumber", 1, 10), "warning")
				return false;
			}
			return true;
		},
		gnss27200: function(m, y, t) {
			var str = this.nullFun(t);
			if (verifyFun.isNull(m.gnssConfigMode)) {
				y.ngAlert(t.instant("gnssConfigMode") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.gnssConfigElevMask)) {
				y.ngAlert(t.instant("gnssConfigElevMask") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.gnssConfigCableDelay)) {
				y.ngAlert(t.instant("gnssConfigCableDelay") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.gnssConfigTrackMode)) {
				y.ngAlert(t.instant("gnssConfigTrackMode") + str, "warning")
				return false;
			}

			if (verifyFun.isNull(m["gnss2CurrentPositionJ"])) {
				y.ngAlert(t.instant("LONGITUDE") + str, "warning")
				return false;
			}

			if (verifyFun.isNull(m["gnss2CurrentPositionW"])) {
				y.ngAlert(t.instant("LATITUDE") + str, "warning")
				return false;
			}

			if (verifyFun.isNull(m["gnss2CurrentPositionH"])) {
				y.ngAlert(t.instant("HEIGHT") + str, "warning")
				return false;
			}
			return true;
		},
		gnss17200: function(m, y, t) {
			var str = this.nullFun(t);
			if (verifyFun.isNull(m.gpsConfigMode)) {
				y.ngAlert(t.instant("gpsConfigMode") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.gpsConfigElevMask)) {
				y.ngAlert(t.instant("gpsConfigElevMask") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.gpsConfigCableDelay)) {
				y.ngAlert(t.instant("gpsConfigCableDelay") + str, "warning")
				return false;
			}

			if (verifyFun.isNull(m["gnss1CurrentPositionJ"])) {
				y.ngAlert(t.instant("LONGITUDE") + str, "warning")
				return false;
			}

			if (verifyFun.isNull(m["gnss1CurrentPositionW"])) {
				y.ngAlert(t.instant("LATITUDE") + str, "warning")
				return false;
			}

			if (verifyFun.isNull(m["gnss1CurrentPositionH"])) {
				y.ngAlert(t.instant("HEIGHT") + str, "warning")
				return false;
			}
			return true;
		},
		network7200: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";
			if (verifyFun.isNull(m["ipAddress"])) {
				y.ngAlert("IP_ADDRESS" + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["ipAddress"])) {
				y.ngAlert("IP_ADDRESS" + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m.ethConfigPortState)) {
				y.ngAlert(s + t.instant("IP_PORT_STATE"), "warning");
				return false;
			}
			if (verifyFun.isNull(m["maskAddress"])) {
				y.ngAlert("MASK" + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["maskAddress"])) {
				y.ngAlert("MASK" + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m["gatewayAddress"])) {
				y.ngAlert("GATEWAY" + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["gatewayAddress"])) {
				y.ngAlert("GATEWAY" + err, "warning")
				return false;
			}
			return true;
		},
		boardConfig: function(m, y, t) {
			var str = this.nullFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";
			if (verifyFun.isNull(m.chs)) {
				y.ngAlert(s + "boardConfig", "warning")
				return false;
			}
			if (verifyFun.isNull(m.con)) {
				y.ngAlert(s + t.instant("OPERATION"), "warning")
				return false;
			}

			return true;
		},
		reboot: function(m, y, t) {
			var str = this.nullFun(t);
			if (verifyFun.isNull(m.systemReboot)) {
				y.ngAlert(t.instant("systemReboot") + str, "warning")
				return false;
			}
			return true;
		},
		upgrade: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t);
			if (verifyFun.isNull(m.fileName)) {
				y.ngAlert("fileName " + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.ip)) {
				y.ngAlert("ip " + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m.ip)) {
				y.ngAlert("ip" + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m.userName)) {
				y.ngAlert("userName " + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.password)) {
				y.ngAlert("password " + str, "warning")
				return false;
			}
			// if (verifyFun.isNull(m.upgradeCmd)) {
			// 	y.ngAlert(t.instant("upgradeCmd") + str, "warning")
			// 	return false;
			// }
			// if (verifyFun.isNull(m.upgradeStatus)) {
			// 	y.ngAlert(t.instant("upgradeStatus") + str, "warning")
			// 	return false;
			// }
			return true;
		},
		other7200: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t);
			if (verifyFun.isNull(m.tftpServerAddress)) {
				y.ngAlert(t.instant("tftpServerAddress") + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["tftpServerAddress"])) {
				y.ngAlert("IP_ADDRESS" + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m.todSource)) {
				y.ngAlert(t.instant("todSource") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.lcdTimeZone)) {
				y.ngAlert(t.instant("lcdTimeZone") + str, "warning")
				return false;
			}
			return true;
		},
		outputNTPWhitelistIP: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";
			if (verifyFun.isNull(m.outputNTPWhitelistAddr)) {
				y.ngAlert(t.instant("NE_IP") + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m.outputNTPWhitelistAddr)) {
				y.ngAlert(t.instant("NE_IP") + err, "warning")
				return false;
			}

			if (!verifyFun.isNull(m.outputNTPWhitelistAddr2)) {
				if (!verifyFun.isIp(m.outputNTPWhitelistAddr2)) {
					y.ngAlert(t.instant("NE_IP") + err, "warning")
					return false;
				}
			}

			return true;
		},
		outputNTPNetworkConfig: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";
			if (verifyFun.isNull(m["address"])) {
				y.ngAlert("IP_ADDRESS" + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["address"])) {
				y.ngAlert("IP_ADDRESS" + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m.outputNTPNetworkConfigIpState)) {
				y.ngAlert(s + t.instant("IP_PORT_STATE"), "warning");
				return false;
			}
			if (verifyFun.isNull(m["netmask"])) {
				y.ngAlert("MASK" + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["netmask"])) {
				y.ngAlert("MASK" + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m["gateway"])) {
				y.ngAlert("GATEWAY" + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["gateway"])) {
				y.ngAlert("GATEWAY" + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m.outputNTPNetworkConfigAutoNegState)) {
				y.ngAlert(s + "AutoNegState", "warning")
				return false;
			}
			if (verifyFun.isNull(m.outputNTPNetworkConfigSpeed)) {
				y.ngAlert(s + "Speed", "warning")
				return false;
			}
			if (verifyFun.isNull(m.outputNTPNetworkConfigDuplex)) {
				y.ngAlert(s + "Duplex", "warning")
				return false;
			}
			return true;
		},
		tp1000ccCard: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";
			if (verifyFun.isNull(m.iocstate)) {
				y.ngAlert("iocstate " + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.iocmode)) {
				y.ngAlert("iocmode " + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.clktype)) {
				y.ngAlert("clktype " + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.clkmode)) {
				y.ngAlert("clkmode " + str, "warning")
				return false;
			}
			return true;
		},
		tp1000e422: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";

			if (verifyFun.isNull(m.outstatus)) {
				y.ngAlert("outstatus " + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.outstate)) {
				y.ngAlert("outstate " + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.frmtype)) {
				y.ngAlert("frmtype " + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.freeflt)) {
				y.ngAlert("freeflt " + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.holdflt)) {
				y.ngAlert("holdflt " + str, "warning")
				return false;
			}
			return true;
		},
		tp1000gps: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";

			if (verifyFun.isNull(m.qlevel)) {
				y.ngAlert("qlevel " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["qlevel"]) || !verifyFun.between(m["qlevel"], 1, 9)) {
				y.ngAlert(this.fe("qlevel", 1, 9), "warning")
				return false;
			}
			if (verifyFun.isNull(m.priority)) {
				y.ngAlert("优先级 " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["priority"]) || !verifyFun.between(m["priority"], 1, 4)) {
				y.ngAlert(this.fe("优先级", 1, 4), "warning")
				return false;
			}
			if (verifyFun.isNull(m.utc)) {
				y.ngAlert("utc " + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.pos)) {
				y.ngAlert("pos " + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.elevmask)) {
				y.ngAlert("elevmask " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["elevmask"]) || !verifyFun.between(m["elevmask"], 5, 45)) {
				y.ngAlert(this.fe("elevmask", 5, 45), "warning")
				return false;
			}
			return true;
		},
		tp1000inputList: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";

			if (verifyFun.isNull(m.qlevel)) {
				y.ngAlert("qlevel " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["qlevel"]) || !verifyFun.between(m["qlevel"], 1, 9)) {
				y.ngAlert(this.fe("qlevel", 1, 9), "warning")
				return false;
			}
			if (verifyFun.isNull(m.priority)) {
				y.ngAlert("优先级 " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["priority"]) || !verifyFun.between(m["priority"], 1, 4)) {
				y.ngAlert(this.fe("优先级", 1, 4), "warning")
				return false;
			}
			if (verifyFun.isNull(m.rqlevel)) {
				y.ngAlert("rqlevel " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["rqlevel"]) || !verifyFun.between(m["rqlevel"], 1, 10)) {
				y.ngAlert(this.fe("rqlevel", 1, 10), "warning")
				return false;
			}
			if (verifyFun.isNull(m.ssmbit)) {
				y.ngAlert("ssmbit " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ssmbit"]) || !verifyFun.between(m["ssmbit"], 4, 8)) {
				y.ngAlert(this.fe("ssmbit",4, 8), "warning")
				return false;
			}
			return true;
		},
		tp1000mcCard(m, y, t, z) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";
			if (z == '1' || z == '2' || z == '3') {
				if (verifyFun.isNull(m.baud)) {
					y.ngAlert("baud " + str, "warning")
					return false;
				}
				if (verifyFun.isNull(m.flow)) {
					y.ngAlert("flow " + str, "warning")
					return false;
				}
			} else if (z == '4') {
				if (verifyFun.isNull(m["ipaddr"])) {
					y.ngAlert("IP_ADDRESS" + str, "warning")
					return false;
				}
				if (!verifyFun.isIp(m["ipaddr"])) {
					y.ngAlert("IP_ADDRESS" + err, "warning")
					return false;
				}
				if (verifyFun.isNull(m["ipsubnet"])) {
					y.ngAlert("MASK" + str, "warning")
					return false;
				}
				if (!verifyFun.isIp(m["ipsubnet"])) {
					y.ngAlert("MASK" + err, "warning")
					return false;
				}
				if (verifyFun.isNull(m["ipgate"])) {
					y.ngAlert("GATEWAY" + str, "warning")
					return false;
				}
				if (!verifyFun.isIp(m["ipgate"])) {
					y.ngAlert("GATEWAY" + err, "warning")
					return false;
				}

			}
			return true;
		},
		tp1000outa(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";

			if (verifyFun.isNull(m.outstate)) {
				y.ngAlert("outstate " + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.frmtype)) {
				y.ngAlert("frmtype " + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.freeflt)) {
				y.ngAlert("freeflt " + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.holdflt)) {
				y.ngAlert("holdflt " + str, "warning")
				return false;
			}
			return true;
		},
		tp1000prs(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";

			if (verifyFun.isNull(m.qlevel)) {
				y.ngAlert("qlevel " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["qlevel"]) || !verifyFun.between(m["qlevel"], 1, 9)) {
				y.ngAlert(this.fe("qlevel", 1, 9), "warning")
				return false;
			}
			if (verifyFun.isNull(m.priority)) {
				y.ngAlert("优先级 " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["priority"]) || !verifyFun.between(m["priority"], 1, 4)) {
				y.ngAlert(this.fe("优先级", 1, 4), "warning")
				return false;
			}
			return true;
		},
		tp1000rtma(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";

			if (verifyFun.isNull(m.rtmlbo)) {
				y.ngAlert("rtmlbo " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["rtmlbo"]) || !verifyFun.between(m["rtmlbo"], 0, 4)) {
				y.ngAlert(this.fe("rtmlbo", 0, 4), "warning")
				return false;
			}
			if (verifyFun.isNull(m.rtmslip)) {
				y.ngAlert("rtmslip " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["rtmslip"]) || !verifyFun.between(m["rtmslip"], 0, 255)) {
				y.ngAlert(this.fe("rtmslip", 0, 255), "warning")
				return false;
			}
			return true;
		},
		tp1000ntp(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";

			if (verifyFun.isNull(m.keyid)) {
				y.ngAlert("keyid " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["keyid"]) || !verifyFun.between(m["keyid"], 0, 32768)) {
				y.ngAlert(this.fe("keyid", 0, 32768), "warning")
				return false;
			}
			return true;
		},
		hp55400mcCard(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";

			if (verifyFun.isNull(m.inacttime)) {
				y.ngAlert("inacttime " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["inacttime"]) || !verifyFun.between(m["inacttime"], 0, 10000)) {
				y.ngAlert(this.fe("inacttime", 0, 10000), "warning")
				return false;
			}
			return true;
		},
		hp55400ccCard(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";


			if (verifyFun.isNull(m.thr)) {
				y.ngAlert("thr " + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.hslimit)) {
				y.ngAlert("hslimit " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["hslimit"]) || !verifyFun.between(m["hslimit"], 10, 20000)) {
				y.ngAlert(this.fe("hslimit", 10, 20000), "warning")
				return false;
			}
			if (verifyFun.isNull(m.bldlmt)) {
				y.ngAlert("bldlmt " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["bldlmt"]) || !verifyFun.between(m["bldlmt"], 50, 20000)) {
				y.ngAlert(this.fe("bldlmt", 50, 20000), "warning")
				return false;
			}
			if (verifyFun.isNull(m.dsctime)) {
				y.ngAlert("dsctime " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["dsctime"]) || !verifyFun.between(m["dsctime"], 1, 15)) {
				y.ngAlert(this.fe("dsctime", 1, 15), "warning")
				return false;
			}
			if (verifyFun.isNull(m.hfqlevl)) {
				y.ngAlert("hfqlevl " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["hfqlevl"]) || !verifyFun.between(m["hfqlevl"], 0, 15)) {
				y.ngAlert(this.fe("hfqlevl", 0, 15), "warning")
				return false;
			}
			if (verifyFun.isNull(m.hfqlevlsec)) {
				y.ngAlert("hfqlevlsec " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["hfqlevlsec"]) || !verifyFun.between(m["hfqlevlsec"], 0, 15)) {
				y.ngAlert(this.fe("hfqlevlsec", 0, 15), "warning")
				return false;
			}
			if (verifyFun.isNull(m.mxccn)) {
				y.ngAlert("mxccn " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["mxccn"]) || !verifyFun.between(m["mxccn"], 1, 9)) {
				y.ngAlert(this.fe("mxccn", 1, 9), "warning")
				return false;
			}
			if (verifyFun.isNull(m.manchan)) {
				y.ngAlert("manchan " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["manchan"]) || !verifyFun.between(m["manchan"], 0, 8)) {
				y.ngAlert(this.fe("manchan", 0, 8), "warning")
				return false;
			}

			if (verifyFun.isNull(m.pirange)) {
				y.ngAlert("pirange " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["pirange"]) || !verifyFun.between(m["pirange"], 10, 10000)) {
				y.ngAlert(this.fe("pirange", 10, 10000), "warning")
				return false;
			}

			if (verifyFun.isNull(m.pirangesec)) {
				y.ngAlert("pirangesec " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["pirangesec"]) || !verifyFun.between(m["pirangesec"], 10, 10000)) {
				y.ngAlert(this.fe("pirangesec", 10, 10000), "warning")
				return false;
			}

			if (verifyFun.isNull(m.wtrss)) {
				y.ngAlert("wtrss " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["wtrss"]) || !verifyFun.between(m["wtrss"], 0, 1000)) {
				y.ngAlert(this.fe("wtrss", 0, 1000), "warning")
				return false;
			}
			return true;
		},
		hp55400outa(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";

			if (verifyFun.isNull(m.sabits)) {
				y.ngAlert("sabits " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["sabits"]) || !verifyFun.between(m["sabits"], 0, 255)) {
				y.ngAlert(this.fe("sabits", 0, 255), "warning")
				return false;
			}

			if (verifyFun.isNull(m.traffic)) {
				y.ngAlert("traffic " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["traffic"]) || !verifyFun.between(m["traffic"], 0, 255)) {
				y.ngAlert(this.fe("traffic", 0, 255), "warning")
				return false;
			}
			return true;
		},
		hp55400ithport(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";

			if (verifyFun.isNull(m.good)) {
				y.ngAlert("good " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["good"]) || !verifyFun.between(m["good"], 1, 15)) {
				y.ngAlert(this.fe("good", 1, 15), "warning")
				return false;
			}
			if (verifyFun.isNull(m.thr)) {
				y.ngAlert("thr " + str, "warning")
				return false;
			}

			if (verifyFun.isNull(m.currssm)) {
				y.ngAlert("currssm " + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.tconstsec)) {
				y.ngAlert("tconstsec " + str, "warning")
				return false;
			}

			if (!verifyFun.isNumber(m["tconstsec"]) || !verifyFun.between(m["tconstsec"], 192, 49152)) {
				y.ngAlert(this.fe("tconstsec", 192, 49152), "warning")
				return false;
			}

			if (verifyFun.isNull(m.measdly)) {
				y.ngAlert("measdly " + str, "warning")
				return false;
			}

			if (!verifyFun.isNumber(m["measdly"]) || !verifyFun.between(m["measdly"], 0, 1800)) {
				y.ngAlert(this.fe("measdly", 0, 1800), "warning")
				return false;
			}

			if (verifyFun.isNull(m.priority)) {
				y.ngAlert("priority " + str, "warning")
				return false;
			}

			if (!verifyFun.isNumber(m["priority"]) || !verifyFun.between(m["priority"], 0, 9)) {
				y.ngAlert(this.fe("priority", 0, 9), "warning")
				return false;
			}


			if (verifyFun.isNull(m.qcutoff)) {
				y.ngAlert("qcutoff " + str, "warning")
				return false;
			}

			if (!verifyFun.isNumber(m["qcutoff"]) || !verifyFun.between(m["qcutoff"], 0, 15)) {
				y.ngAlert(this.fe("qcutoff", 0, 15), "warning")
				return false;
			}


			if (verifyFun.isNull(m.qlevel)) {
				y.ngAlert("qlevel " + str, "warning")
				return false;
			}

			if (!verifyFun.isNumber(m["qlevel"]) || !verifyFun.between(m["qlevel"], 0, 15)) {
				y.ngAlert(this.fe("qlevel", 0, 15), "warning")
				return false;
			}
			if (verifyFun.isNull(m.ssmpri)) {
				y.ngAlert("ssmpri " + str, "warning")
				return false;
			}

			if (!verifyFun.isNumber(m["ssmpri"]) || !verifyFun.between(m["ssmpri"], 0, 8)) {
				y.ngAlert(this.fe("ssmpri", 0, 8), "warning")
				return false;
			}

			return true;
		},

		pornameConfig(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";

			if (verifyFun.isNull(m.port)) {
				y.ngAlert("port " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["port"])) {
				y.ngAlert('port必须是纯数字', "warning")
				return false;
			}
			return true;
		},
		SSU20002048Card(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";

			if (verifyFun.isNull(m.squelch)) {
				y.ngAlert("squelch " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["squelch"]) || !verifyFun.between(m["squelch"], 0, 16)) {
				y.ngAlert(this.fe("squelch", 0, 16), "warning")
				return false;
			}

			if (verifyFun.isNull(m.mode)) {
				y.ngAlert("mode " + str, "warning")
				return false;
			}
			return true;
		},
		SSU2000inputCard(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";

			if (verifyFun.isNull(m.pri)) {
				y.ngAlert("pri " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["pri"]) || !verifyFun.between(m["pri"], 0, 16)) {
				y.ngAlert(this.fe("pri", 0, 16), "warning")
				return false;
			}

			if (verifyFun.isNull(m.pql)) {
				y.ngAlert("pql " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["pql"]) || !verifyFun.between(m["pql"], 0, 16)) {
				y.ngAlert(this.fe("pql", 0, 16), "warning")
				return false;
			}
			if (verifyFun.isNull(m.bit)) {
				y.ngAlert("bit " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["bit"]) || !verifyFun.between(m["bit"], 4, 8)) {
				y.ngAlert(this.fe("bit", 4, 8), "warning")
				return false;
			}
			return true;
		},
		SSU2000gpsCard(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";

			if (verifyFun.isNull(m.pri)) {
				y.ngAlert("pri " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["pri"]) || !verifyFun.between(m["pri"], 0, 10)) {
				y.ngAlert(this.fe("pri", 0, 10), "warning")
				return false;
			}

			if (verifyFun.isNull(m.pql)) {
				y.ngAlert("pql " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["pql"]) || !verifyFun.between(m["pql"], 1, 16)) {
				y.ngAlert(this.fe("pql", 1, 16), "warning")
				return false;
			}

			if (verifyFun.isNull(m.sifma)) {
				y.ngAlert("sifma " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["sifma"]) || !verifyFun.between(m["sifma"], 10, 1000)) {
				y.ngAlert(this.fe("sifma", 10, 1000), "warning")
				return false;
			}
			if (verifyFun.isNull(m.posel)) {
				y.ngAlert("posel " + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.timel)) {
				y.ngAlert("timel " + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.pdop)) {
				y.ngAlert("pdop " + str, "warning")
				return false;
			}
			return true;
		},
		SSU2000inputSineCard(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";

			if (verifyFun.isNull(m.port)) {
				y.ngAlert("port " + str, "warning")
				return false;
			}

			if (verifyFun.isNull(m.pri)) {
				y.ngAlert("pri " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["pri"]) || !verifyFun.between(m["pri"], 1, 10)) {
				y.ngAlert(this.fe("pri", 1, 10), "warning")
				return false;
			}
			if (verifyFun.isNull(m.pql)) {
				y.ngAlert("pql " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["pql"]) || !verifyFun.between(m["pql"], 1, 16)) {
				y.ngAlert(this.fe("pql", 1, 16), "warning")
				return false;
			}
			return true;
		},
		SSU2000ccCard(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";

			if (verifyFun.isNull(m.warmup)) {
				y.ngAlert("warmup " + str, "warning")
				return false;
			}

			if (verifyFun.isNull(m.mintau)) {
				y.ngAlert("mintau " + str, "warning")
				return false;
			}

			if (verifyFun.isNull(m.maxtau)) {
				y.ngAlert("maxtau " + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.mintaulimit)) {
				y.ngAlert("mintaulimit " + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.maxtaulimit)) {
				y.ngAlert("maxtaulimit " + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.tod_timeout)) {
				y.ngAlert("tod_timeout " + str, "warning")
				return false;
			}
			return true;
		},
		ts3100mcCard: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t);
			if (!m || verifyFun.isNull(m["ipem1"])) {
				y.ngAlert("ipem1" + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["ipem1"])) {
				y.ngAlert("ipem1" + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m.ipem1PORT)) {
				y.ngAlert("ipem1PORT " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ipem1PORT"]) || !verifyFun.between(m["ipem1PORT"], 0, 65535)) {
				y.ngAlert(this.fe("ipem1PORT", 0, 65535), "warning")
				return false;
			}
			if (!m || verifyFun.isNull(m["ipem2"])) {
				y.ngAlert("ipem2" + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["ipem2"])) {
				y.ngAlert("ipem2" + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m.ipem2PORT)) {
				y.ngAlert("ipem2PORT " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ipem2PORT"]) || !verifyFun.between(m["ipem2PORT"], 0, 65535)) {
				y.ngAlert(this.fe("ipem2PORT", 0, 65535), "warning")
				return false;
			}
			if (verifyFun.isNull(m["ipgate"])) {
				y.ngAlert("ipgate" + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["ipgate"])) {
				y.ngAlert("ipgate" + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m.ipinact)) {
				y.ngAlert("ipinact " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ipinact"]) || !verifyFun.between(m["ipinact"], 0, 10000)) {
				y.ngAlert(this.fe("ipinact", 0, 10000), "warning")
				return false;
			}
			if (verifyFun.isNull(m["ipne"])) {
				y.ngAlert("ipne" + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["ipne"])) {
				y.ngAlert("ipne" + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m["ipsubnet"])) {
				y.ngAlert("ipsubnet" + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["ipsubnet"])) {
				y.ngAlert("ipsubnet" + err, "warning")
				return false;
			}
			return true;
		},
		ts3100GPSCard(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";
			if (verifyFun.isNull(m.antcbldly)) {
				y.ngAlert("antcbldly " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["antcbldly"]) || !verifyFun.between(m["antcbldly"], 0, 330)) {
				y.ngAlert(this.fe("antcbldly", 0, 330), "warning")
				return false;
			}
			if (verifyFun.isNull(m.antelevmask)) {
				y.ngAlert("antelevmask " + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["antelevmask"]) || !verifyFun.between(m["antelevmask"], 0, 45)) {
				y.ngAlert(this.fe("antelevmask", 0, 45), "warning")
				return false;
			}
			return true;
		},
		ts3100spanCard(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";
			if (verifyFun.isNull(m.alarm)) {
				y.ngAlert("alarm " + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.ensembler)) {
				y.ngAlert("ensembler " + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.time)) {
				y.ngAlert("time " + str, "warning")
				return false;
			}
			return true;
		},

		alarmConfig3000G: function(m, y, t) {
			var str = this.nullFun(t);
			if (verifyFun.isNull(m.alarmState)) {
				y.ngAlert(t.instant("alarmState") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.alarmLevel)) {
				y.ngAlert(t.instant("alarmLevel") + str, "warning")
				return false;
			}
			return true;
		},
		refConfig3000G: function(m, y, t) {
			var str = this.nullFun(t);
			if (verifyFun.isNull(m.refConfigFP)) {
				y.ngAlert(t.instant("refConfigFP") + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["refConfigFP"]) || !verifyFun.between(m["refConfigFP"], 1, 5)) {
				y.ngAlert(this.fe("refConfigFP", 1, 5), "warning")
				return false;
			}
			return true;
		},
		output3000G: function(m, y, t) {
			var str = this.nullFun(t);

			if (verifyFun.isNull(m.outputIrigbAcRatio)) {
				y.ngAlert(t.instant("outputIrigbAcRatio") + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["outputIrigbAcRatio"]) || !verifyFun.between(m["outputIrigbAcRatio"], 2, 6)) {
				y.ngAlert(this.fe("outputIrigbAcRatio", 2, 6), "warning")
				return false;
			}
			if (verifyFun.isNull(m.outputIrigbOffset)) {
				y.ngAlert(t.instant("outputIrigbOffset") + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["outputIrigbOffset"]) || !verifyFun.between(m["outputIrigbOffset"], -20,20)) {
				y.ngAlert(this.fe("outputIrigbOffset", -20, 20), "warning")
				return false;
			}
			return true;
		},
		ntpslot3000G: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t);
			if (verifyFun.isNull(m.ntpSlotAlarm)) {
				y.ngAlert(t.instant("ntpSlotAlarm") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.ntpSlotCpuMem)) {
				y.ngAlert(t.instant("ntpSlotCpuMem") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.ntpSlotHWVersion)) {
				y.ngAlert(t.instant("ntpSlotHWVersion") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.ntpSlotImage)) {
				y.ngAlert(t.instant("ntpSlotImage") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.ntpSlotLinkStatus)) {
				y.ngAlert(t.instant("ntpSlotLinkStatus") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.ntpSlotMacInfo)) {
				y.ngAlert(t.instant("ntpSlotMacInfo") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.ntpSlotTrackStatus)) {
				y.ngAlert(t.instant("ntpSlotTrackStatus") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.ntpSlotVersionInfo)) {
				y.ngAlert(t.instant("ntpSlotVersionInfo") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.ntpSlotBackup)) {
				y.ngAlert(t.instant("ntpSlotBackup") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.ntpSlotReboot)) {
				y.ngAlert(t.instant("ntpSlotReboot") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.ntpSlotRestore)) {
				y.ngAlert(t.instant("ntpSlotRestore") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.ntpSlotReboot)) {
				y.ngAlert(t.instant("ntpSlotReboot") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.ntpSlotReboot)) {
				y.ngAlert(t.instant("ntpSlotReboot") + str, "warning")
				return false;
			}
			return true;
		},
		ntpport3000G: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t);
			if (verifyFun.isNull(m.ntpPortBroadcastAddr)) {
				y.ngAlert(t.instant("ntpPortBroadcastAddr") + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["ntpPortBroadcastAddr"])) {
				y.ngAlert("IP_ADDRESS" + err, "warning")
				return false;
			}

			if (verifyFun.isNull(m.ntpPortBroadcastTimeInterval)) {
				y.ngAlert(t.instant("ntpPortBroadcastTimeInterval") + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ntpPortBroadcastTimeInterval"]) || !verifyFun.between(m["ntpPortBroadcastTimeInterval"], 3, 17)) {
				y.ngAlert(this.fe("ntpPortBroadcastTimeInterval", 3, 17), "warning")
				return false;
			}

			return true;
		},
		ref3000G: function(m, y, t) {
			var str = this.nullFun(t);
			if (verifyFun.isNull(m.refOffsetHistoryShowFlag)) {
				y.ngAlert(t.instant("refOffsetHistoryShowFlag") + str, "warning")
				return false;
			}

			if (verifyFun.isNull(m.refOffsetHistoryShowNumber)) {
				y.ngAlert(t.instant("refOffsetHistoryShowNumber") + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["refOffsetHistoryShowNumber"]) || !verifyFun.between(m["refOffsetHistoryShowNumber"], 1, 10)) {
				y.ngAlert(this.fe("refOffsetHistoryShowNumber", 1, 10), "warning")
				return false;
			}
			return true;
		},
		gnss23000G: function(m, y, t) {
			var str = this.nullFun(t);
			if (verifyFun.isNull(m.gnssConfigMode)) {
				y.ngAlert(t.instant("gnssConfigMode") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.gnssConfigElevMask)) {
				y.ngAlert(t.instant("gnssConfigElevMask") + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["gpsConfigElevMask"]) || !verifyFun.between(m["gpsConfigElevMask"], 5, 40)) {
				y.ngAlert(this.fe("gpsConfigElevMask", 5, 40), "warning")
				return false;
			}
			if (verifyFun.isNull(m.gnssConfigCableDelay)) {
				y.ngAlert(t.instant("gnssConfigCableDelay") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.gnssConfigTrackMode)) {
				y.ngAlert(t.instant("gnssConfigTrackMode") + str, "warning")
				return false;
			}

			if (verifyFun.isNull(m["gnss2CurrentPositionJ"])) {
				y.ngAlert(t.instant("LONGITUDE") + str, "warning")
				return false;
			}

			if (verifyFun.isNull(m["gnss2CurrentPositionW"])) {
				y.ngAlert(t.instant("LATITUDE") + str, "warning")
				return false;
			}

			if (verifyFun.isNull(m["gnss2CurrentPositionH"])) {
				y.ngAlert(t.instant("HEIGHT") + str, "warning")
				return false;
			}
			return true;
		},
		gnss13000G: function(m, y, t) {
			var str = this.nullFun(t);
			if (verifyFun.isNull(m.gpsConfigMode)) {
				y.ngAlert(t.instant("gpsConfigMode") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.gpsConfigElevMask)) {
				y.ngAlert(t.instant("gpsConfigElevMask") + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["gpsConfigElevMask"]) || !verifyFun.between(m["gpsConfigElevMask"], 5, 40)) {
				y.ngAlert(this.fe("gpsConfigElevMask", 5, 40), "warning")
				return false;
			}
			if (verifyFun.isNull(m.gpsConfigCableDelay)) {
				y.ngAlert(t.instant("gpsConfigCableDelay") + str, "warning")
				return false;
			}

			if (verifyFun.isNull(m["gnss1CurrentPositionJ"])) {
				y.ngAlert(t.instant("LONGITUDE") + str, "warning")
				return false;
			}

			if (verifyFun.isNull(m["gnss1CurrentPositionW"])) {
				y.ngAlert(t.instant("LATITUDE") + str, "warning")
				return false;
			}

			if (verifyFun.isNull(m["gnss1CurrentPositionH"])) {
				y.ngAlert(t.instant("HEIGHT") + str, "warning")
				return false;
			}
			return true;
		},
		network3000G: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";
			if (verifyFun.isNull(m["ipAddress"])) {
				y.ngAlert("IP_ADDRESS" + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["ipAddress"])) {
				y.ngAlert("IP_ADDRESS" + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m.ethConfigPortState)) {
				y.ngAlert(s + t.instant("IP_PORT_STATE"), "warning");
				return false;
			}
			if (verifyFun.isNull(m["maskAddress"])) {
				y.ngAlert("MASK" + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["maskAddress"])) {
				y.ngAlert("MASK" + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m["gatewayAddress"])) {
				y.ngAlert("GATEWAY" + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["gatewayAddress"])) {
				y.ngAlert("GATEWAY" + err, "warning")
				return false;
			}
			return true;
		},
		boardConfig3000G: function(m, y, t) {
			var str = this.nullFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";
			if (verifyFun.isNull(m.chs)) {
				y.ngAlert(s + "boardConfig", "warning")
				return false;
			}
			if (verifyFun.isNull(m.con)) {
				y.ngAlert(s + t.instant("OPERATION"), "warning")
				return false;
			}

			return true;
		},
		other3000G: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t);
			if (verifyFun.isNull(m.tftpServerAddress)) {
				y.ngAlert(t.instant("tftpServerAddress") + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["tftpServerAddress"])) {
				y.ngAlert("IP_ADDRESS" + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m.todSource)) {
				y.ngAlert(t.instant("todSource") + str, "warning")
				return false;
			}
			if (verifyFun.isNull(m.lcdTimeZone)) {
				y.ngAlert(t.instant("lcdTimeZone") + str, "warning")
				return false;
			}
			return true;
		},
		gnss_7300: function(m, y, t, n) {
			var str = this.nullFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";
			if (verifyFun.isNull(m["gnssState"])) {
				y.ngAlert(s + "gnssState" + t.instant("GNSS_ENABLE"), "warning")
				return false;
			}
			if (verifyFun.isNull(m["gnssMode"])) {
				y.ngAlert(s + "gnssMode" + t.instant("GNSS_PATTERN"), "warning")
				return false;
			}
			if (verifyFun.isNull(m["gnssPriority"])) {
				y.ngAlert("优先级" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["gnssPriority"]) || !verifyFun.between(m["gnssPriority"], 1, 16)) {
				y.ngAlert(this.fe("优先级", 1, 16), "warning")
				return false;
			}
			if (verifyFun.isNull(m["gnssTrackMode"])) {
				y.ngAlert(s + t.instant("TRACKING_MODE"), "warning")
				return false;
			}
			if (verifyFun.isNull(m["gnssElevMask"])) {
				y.ngAlert("Mask" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["gnssElevMask"]) || !verifyFun.between(m["gnssElevMask"], 5, 45)) {
				y.ngAlert(this.fe("Mask", 5, 45), "warning")
				return false;
			}

			if (verifyFun.isNull(m["gnssCableDelay"])) {
				y.ngAlert(t.instant("ANTENNA_DELAY") + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["gnssCableDelay"]) || !verifyFun.between(m["gnssCableDelay"], 0, 65485)) {
				y.ngAlert(this.fe(t.instant("ANTENNA_DELAY"), 0, 65485), "warning")
				return false;
			}

			if (verifyFun.isNull(m["gnssPQLState"])) {
				y.ngAlert(s + t.instant("PQL_STATE"), "warning")
				return false;
			}

			if (verifyFun.isNull(m["gnssPQL"])) {
				y.ngAlert(t.instant("PQL_VALUE") + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["gnssPQL"]) || !verifyFun.between(m["gnssPQL"], 1, 3)) {
				y.ngAlert(this.fe(t.instant("PQL_VALUE"), 1, 3), "warning")
				return false;
			}

			if (verifyFun.isNull(m["gnssCurrentPositionJ"])) {
				y.ngAlert(t.instant("LONGITUDE") + str, "warning")
				return false;
			}

			if (verifyFun.isNull(m["gnssCurrentPositionW"])) {
				y.ngAlert(t.instant("LATITUDE") + str, "warning")
				return false;
			}

			if (verifyFun.isNull(m["gnssCurrentPositionH"])) {
				y.ngAlert(t.instant("HEIGHT") + str, "warning")
				return false;
			}
			return true;
		},
		common_7300: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";
			if (verifyFun.isNull(m.ptpCommonState)) {
				y.ngAlert(s + t.instant("PORT_ENABLE"), "warning");
				return false;
			}
			if (verifyFun.isNull(m.ptpCommonTimescale)) {
				y.ngAlert(s + "Time Scale", "warning");
				return false;
			}

			if (verifyFun.isNull(m["ptpCommonMaxClient"])) {
				y.ngAlert(t.instant("MAX_CLIENT") + str, "warning");
				return false;
			}
			if (!verifyFun.isNumber(m["ptpCommonMaxClient"]) || !verifyFun.between(m["ptpCommonMaxClient"], 1, 1000)) {
				y.ngAlert(this.fe(t.instant("MAX_CLIENT"), 1, 1000), "warning");
				return false;
			}
			if (verifyFun.isNull(m["ptpCommonPriority1"])) {
				y.ngAlert(t.instant("PRIORITY") + '1' + str, "warning");
				return false;
			}
			if (!verifyFun.isNumber(m["ptpCommonPriority1"]) || !verifyFun.between(m["ptpCommonPriority1"], 0, 255)) {
				y.ngAlert(this.fe(t.instant("PRIORITY") + '1', 0, 255), "warning");
				return false;
			}

			if (verifyFun.isNull(m.ptpCommonProfile)) {
				y.ngAlert(s + "Profile", "warning");
				return false;
			}
			if (verifyFun.isNull(m["ptpCommonPriority2"])) {
				y.ngAlert(t.instant("PRIORITY") + '2' + str, "warning");
				return false;
			}
			if (!verifyFun.isNumber(m["ptpCommonPriority2"]) || !verifyFun.between(m["ptpCommonPriority2"], 0, 255)) {
				y.ngAlert(this.fe(t.instant("PRIORITY") + '2', 0, 255), "warning");
				return false;
			}
			if (verifyFun.isNull(m["ptpCommonClockID"])) {
				y.ngAlert("Clock ID" + str, "warning");
				return false;
			}
			if (!verifyFun.isMac(m["ptpCommonClockID"])) {
				y.ngAlert("Clock ID" + err, "warning");
				return false;
			}
			if (verifyFun.isNull(m["ptpCommonDSCP"])) {
				y.ngAlert("DSCP" + str, "warning");
				return false;
			}
			if (!verifyFun.isNumber(m["ptpCommonDSCP"]) || !verifyFun.between(m["ptpCommonDSCP"], 0, 63)) {
				y.ngAlert(this.fe("DSCP", 0, 63), "warning");
				return false;
			}
			if (verifyFun.isNull(m["ptpCommonDomain"])) {
				y.ngAlert("Domain" + str, "warning");
				return false;
			}
			if (!verifyFun.isNumber(m["ptpCommonDomain"]) || !verifyFun.between(m["ptpCommonDomain"], 0, 255)) {
				y.ngAlert(this.fe("Domain", 0, 255), "warning");
				return false;
			}
			if (verifyFun.isNull(m.ptpCommonDSCPState)) {
				y.ngAlert(s + "DSCP" + t.instant("GNSS1_ENABLE"), "warning");
				return false;
			}
			if (verifyFun.isNull(m["ptpCommonSyncLimit"])) {
				y.ngAlert("Delay Limit" + str, "warning");
				return false;
			}
			if (!verifyFun.isNumber(m["ptpCommonSyncLimit"]) || !verifyFun.between(m["ptpCommonSyncLimit"], -7, 7)) {
				y.ngAlert(this.fe("Sync Limit", -7, 7), "warning");
				return false
			}
			if (verifyFun.isNull(m["ptpCommonDelayLimit"])) {
				y.ngAlert("Delay Limit" + str, "warning");
				return false;
			}
			if (!verifyFun.isNumber(m["ptpCommonDelayLimit"]) || !verifyFun.between(m["ptpCommonDelayLimit"], -7, 7)) {
				y.ngAlert(this.fe("Delay Limit", -7, 7), "warning");
				return false
			}
			if (verifyFun.isNull(m.ptpCommonDither)) {
				y.ngAlert(s + "Dither", "warning");
				return false;
			}
			if (verifyFun.isNull(m.ptpCommonTwoStep)) {
				y.ngAlert(s + "Two Step", "warning");
				return false;
			}
			if (verifyFun.isNull(m["ptpCommonTTL"])) {
				y.ngAlert("TTL" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ptpCommonTTL"]) || !verifyFun.between(m["ptpCommonTTL"], 1, 255)) {
				y.ngAlert(this.fe("TTL", 1, 255), "warning")
			}
			if (verifyFun.isNull(m.ptpCommonMgmtAddrMode)) {
				y.ngAlert(s + t.instant("MANAGED_ADDRESS_MODE"), "warning");
				return false;
			}
			if (verifyFun.isNull(m.ptpCommonAlternateMaster)) {
				y.ngAlert(s + "Alternate Master", "warning");
				return false;
			}
			return true;
		},
		Unicast_clinet_7300: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";
			if (verifyFun.isNull(m.ptpUnicastClientState)) {
				y.ngAlert(s + t.instant("GNSS1_ENABLE"), "warning")
				return false;
			}
			if (verifyFun.isNull(m["ptpUnicastClientAddr"])) {
				y.ngAlert(t.instant("ADDRESS") + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["ptpUnicastClientAddr"])) {
				y.ngAlert(t.instant("ADDRESS") + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m["ptpUnicastClientVlanID"])) {
				y.ngAlert("VLAN ID" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ptpUnicastClientVlanID"]) || !verifyFun.between(m["ptpUnicastClientVlanID"], 1, 4094)) {
				y.ngAlert(this.fe("VLAN ID", 1, 4094), "warning")
				return false;
			}
			if (verifyFun.isNull(m["ptpUnicastClientClockID"])) {
				y.ngAlert("Clock ID" + str, "warning");
				return false;
			}
			if (!verifyFun.isMac(m["ptpUnicastClientClockID"])) {
				y.ngAlert("Clock ID" + err, "warning");
				return false;
			}

			if (verifyFun.isNull(m["ptpUnicastClientSync"])) {
				y.ngAlert("Sync" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ptpUnicastClientSync"]) || !verifyFun.between(m["ptpUnicastClientSync"], -7, 7)) {
				y.ngAlert(this.fe("Sync", -7, 7), "warning")
				return false;
			}
			if (verifyFun.isNull(m["ptpUnicastClientDelay"])) {
				y.ngAlert("Delay" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ptpUnicastClientDelay"]) || !verifyFun.between(m["ptpUnicastClientDelay"], -7, 7)) {
				y.ngAlert(this.fe("Delay", -7, 7), "warning")
				return false;
			}
			if (verifyFun.isNull(m["ptpUnicastClientAnnounce"])) {
				y.ngAlert("通知" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ptpUnicastClientAnnounce"]) || !verifyFun.between(m["ptpUnicastClientAnnounce"], -4, 4)) {
				y.ngAlert(this.fe("通知", -4, 4), "warning")
				return false;
			}
			return true;
		},
		multicast_7300: function(m, y, t) {
			var str = this.nullFun(t);
			if (verifyFun.isNull(m["ptpMulticastVlanID"])) {
				y.ngAlert("VLAN ID" + str , "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ptpMulticastVlanID"]) || !verifyFun.between(m["ptpMulticastVlanID"], 0, 4094)) {
				y.ngAlert(this.fe("VLAN ID", 0, 4094), "warning")
				return false;
			}
			if (verifyFun.isNull(m["ptpMulticastAnnounceIntv"])) {
				y.ngAlert("Announce Interval" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ptpMulticastAnnounceIntv"]) || !verifyFun.between(m["ptpMulticastAnnounceIntv"], -4, 4)) {
				y.ngAlert(this.fe("Announce Interval", -4, 4), "warning")
				return false;
			}
			if (verifyFun.isNull(m["ptpMulticastDelayIntv"])) {
				y.ngAlert("Delay Interval" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ptpMulticastDelayIntv"]) || !verifyFun.between(m["ptpMulticastDelayIntv"], -7, 7)) {
				y.ngAlert(this.fe("Delay Interval", -7, 7), "warning")
				return false;
			}

			if (verifyFun.isNull(m["ptpMulticastAnnounceTimeout"])) {
				y.ngAlert("Announce Timeout" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ptpMulticastAnnounceTimeout"]) || !verifyFun.between(m["ptpMulticastAnnounceTimeout"], 2, 10)) {
				y.ngAlert(this.fe("Announce Timeout", 2, 10), "warning")
				return false;
			}

			if (verifyFun.isNull(m["ptpMulticastClientTimeout"])) {
				y.ngAlert("Client Timeout" + str, "warning")
				return false;
			}
			if (!verifyFun.isNumber(m["ptpMulticastClientTimeout"]) || !verifyFun.between(m["ptpMulticastClientTimeout"], 10, 3600)) {
				y.ngAlert(this.fe("Client Timeout", 10, 3600), "warning")
				return false;
			}
			return true;
		},
		network7300: function(m, y, t) {
			var str = this.nullFun(t),
				err = this.formatErrorFun(t),
				s = t.use() === 'ch' ? 　"请选择" : "Please select ";
			if (verifyFun.isNull(m["ipAddress"])) {
				y.ngAlert("IP_ADDRESS" + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["ipAddress"])) {
				y.ngAlert("IP_ADDRESS" + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m["maskAddress"])) {
				y.ngAlert("MASK" + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["maskAddress"])) {
				y.ngAlert("MASK" + err, "warning")
				return false;
			}
			if (verifyFun.isNull(m["gatewayAddress"])) {
				y.ngAlert("GATEWAY" + str, "warning")
				return false;
			}
			if (!verifyFun.isIp(m["gatewayAddress"])) {
				y.ngAlert("GATEWAY" + err, "warning")
				return false;
			}
			return true;
		},
	}
	window.verifyFun = {
		isIp: function(s) {
			var y = /^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])$/;
			return y.test(s) ? true : false;
		},
		isMac: function(s) {
			var y = /^[A-F\d]{2}:[A-F\d]{2}:[A-F\d]{2}:[A-F\d]{2}:[A-F\d]{2}:[A-F\d]{2}:[A-F\d]{2}:[A-F\d]{2}$/;
			return y.test(s) ? true : false;
		},
		isNull: function(a) {
			return (a === "" || a === null || a === undefined ? true : false);
		},
		isNumber: function(a) {
			return !this.isNull(a) && !isNaN(a) ? true : false;
		},
		between: function(a, b, c) {
			return (!this.isNull(a) && !this.isNull(b) && !this.isNull(c) && this.isNumber(a) && this.isNumber(b) && this.isNumber(c) && b <= a && c >= a) ? true : false;
		},
		betweenN: function(a, b, c) {
			return (this.isNumberN(a) && this.isNumberN(b) && this.isNumberN(c) && b <= a && c >= a) ? true : false;
		},
		isNumberN: function(a) {
			return !isNaN(a) ? true : false;
		},
	}

	// window.$ = function (s){
	// 	if(typeof s === 'undefined') s = "";
	//     return document.getElementById(s);
	// }
	window.$q = function(s) {
		if (typeof s === 'undefined') s = "";
		return document.querySelectorAll(s);
	}
	Array.prototype.unique = function() {
		var res = [],
			json = {};
		for (var i = 0; i < this.length; i++) {
			if (!json[this[i]]) {
				res.push(this[i]);
				json[this[i]] = 1;
			}
		}
		return res;
	}
})();
