var routerApp = angular.module('myApp', ["isteven-multi-select",'ui.router', "oc.lazyLoad", "treeControl", 'ngDialog', "ngTip", 'chieffancypants.loadingBar', "angularFileUpload", "uiSwitch", "pascalprecht.translate",'pascalprecht.translate']);
var loadJS = function(moduleName, files){
    return ['$ocLazyLoad', function ($ocLazyLoad) {
        return $ocLazyLoad.load(
            {
                name: moduleName,  //module name is "store"
                files: files
            }
        )
    }]
}
routerApp.config(['$stateProvider', '$urlRouterProvider', "$translateProvider", "cfpLoadingBarProvider",function($stateProvider, $urlRouterProvider, $translateProvider, cfpLoadingBarProvider) {
    $urlRouterProvider.otherwise('/login');
    cfpLoadingBarProvider.includeSpinner = true; // LOADING加载用的参数
    //$urlRouterProvider.when("", "/login");
}]);
routerApp.config(['fileManagerConfigProvider', function (config) {
    var defaults = config.$get();
    config.set({
        appName: '文件管理',
        listUrl: 'spring/databaseBackup/getBackupSrc',
        renameUrl: "renameFile",
        removeUrl: 'removeFile',
        getContentUrl: 'getContent',
        editUrl: 'saveFile',
        downloadFileUrl: 'previewFile',
        createFolderUrl: 'spring/databaseBackup/getBackupSrc',
        allowedActions: angular.extend(defaults.allowedActions, {
            copy : false,
            edit : true,
            changePermissions: false,
            compress: false,
            compressChooseName : false,
            extract: false
        })
    });
}]);

/* routerApp.service('chmod', function () {

        var Chmod = function(initValue) {
            this.owner = this.getRwxObj();
            this.group = this.getRwxObj();
            this.others = this.getRwxObj();

            if (initValue) {
                var codes = isNaN(initValue) ?
                    this.convertfromCode(initValue):
                    this.convertfromOctal(initValue);

                if (! codes) {
                    throw new Error('Invalid chmod input data');
                }

                this.owner = codes.owner;
                this.group = codes.group;
                this.others = codes.others;
            }
        };

        Chmod.prototype.toOctal = function(prepend, append) {
            var props = ['owner', 'group', 'others'];
            var result = [];
            for (var i in props) {
                var key = props[i];
                result[i]  = this[key].read  && this.octalValues.read  || 0;
                result[i] += this[key].write && this.octalValues.write || 0;
                result[i] += this[key].exec  && this.octalValues.exec  || 0;
            }
            return (prepend||'') + result.join('') + (append||'');
        };

        Chmod.prototype.toCode = function(prepend, append) {
            var props = ['owner', 'group', 'others'];
            var result = [];
            for (var i in props) {
                var key = props[i];
                result[i]  = this[key].read  && this.codeValues.read  || '-';
                result[i] += this[key].write && this.codeValues.write || '-';
                result[i] += this[key].exec  && this.codeValues.exec  || '-';
            }
            return (prepend||'') + result.join('') + (append||'');
        };

        Chmod.prototype.getRwxObj = function() {
            return {
                read: false,
                write: false,
                exec: false
            };
        };

        Chmod.prototype.octalValues = {
            read: 4, write: 2, exec: 1
        };

        Chmod.prototype.codeValues = {
            read: 'r', write: 'w', exec: 'x'
        };

        Chmod.prototype.convertfromCode = function (str) {
            str = ('' + str).replace(/\s/g, '');
            str = str.length === 10 ? str.substr(1) : str;
            if (! /^[-rwxt]{9}$/.test(str)) {
                return;
            }

            var result = [], vals = str.match(/.{1,3}/g);
            for (var i in vals) {
                var rwxObj = this.getRwxObj();
                rwxObj.read  = /r/.test(vals[i]);
                rwxObj.write = /w/.test(vals[i]);
                rwxObj.exec  = /x|t/.test(vals[i]);
                result.push(rwxObj);
            }

            return {
                owner : result[0],
                group : result[1],
                others: result[2]
            };
        };

        Chmod.prototype.convertfromOctal = function (str) {
            str = ('' + str).replace(/\s/g, '');
            str = str.length === 4 ? str.substr(1) : str;
            if (! /^[0-7]{3}$/.test(str)) {
                return;
            }

            var result = [], vals = str.match(/.{1}/g);
            for (var i in vals) {
                var rwxObj = this.getRwxObj();
                rwxObj.read  = /[4567]/.test(vals[i]);
                rwxObj.write = /[2367]/.test(vals[i]);
                rwxObj.exec  = /[1357]/.test(vals[i]);
                result.push(rwxObj);
            }

            return {
                owner : result[0],
                group : result[1],
                others: result[2]
            };
        };

        return Chmod;
    });
*/
routerApp.run(['$rootScope','$window','$state',  "$location",'$log',"$templateCache", '$timeout',function($rootScope,$window, $state,$location, $log, $templateCache,$timeout){
    $rootScope.isLogin = false;
    $rootScope.alarmLevelArray = [];
    $rootScope.STATE = $state;
    $rootScope.$on('$stateChangeSuccess', function(event, toState, toParams, fromState, fromParams){
        if(toState.url.indexOf("/login") > -1){
            $templateCache.removeAll();
            var template =
                '<span class="multiSelect inlineBlock">' +
                    // main button
                    '<button id="{{directiveId}}" type="button"' +
                        'ng-click="toggleCheckboxes( $event ); refreshSelectedItems(); refreshButton(); prepareGrouping; prepareIndex();"' +
                        'ng-bind-html="varButtonLabel"' +
                        'ng-disabled="disable-button"' +
                    '>' +
                    '</button>' +
                    // overlay layer
                    '<div class="checkboxLayer">' +
                        // container of the helper elements
                        '<div class="helperContainer" ng-if="helperStatus.filter || helperStatus.all || helperStatus.none || helperStatus.reset ">' +
                            // container of the first 3 buttons, select all, none and reset
                            '<div class="line" ng-if="helperStatus.all || helperStatus.none || helperStatus.reset ">' +
                                // select all
                                '<button type="button" class="helperButton"' +
                                    'ng-disabled="isDisabled"' +
                                    'ng-if="helperStatus.all"' +
                                    'ng-click="select( \'all\', $event );"' +
                                    'ng-bind-html="lang.selectAll">' +
                                '</button>'+
                                // select none
                                '<button type="button" class="helperButton"' +
                                    'ng-disabled="isDisabled"' +
                                    'ng-if="helperStatus.none"' +
                                    'ng-click="select( \'none\', $event );"' +
                                    'ng-bind-html="lang.selectNone">' +
                                '</button>'+
                                // reset
                                '<button type="button" class="helperButton reset"' +
                                    'ng-disabled="isDisabled"' +
                                    'ng-if="helperStatus.reset"' +
                                    'ng-click="select( \'reset\', $event );"' +
                                    'ng-bind-html="lang.reset">'+
                                '</button>' +
                            '</div>' +
                            // the search box
                            '<div class="line" style="position:relative" ng-if="helperStatus.filter">'+
                                // textfield
                                '<input placeholder="{{lang.search}}" type="text"' +
                                    'ng-click="select( \'filter\', $event )" '+
                                    'ng-model="inputLabel.labelFilter" '+
                                    'ng-change="searchChanged()" class="inputFilter"'+
                                    '/>'+
                                // clear button
                                '<button type="button" class="clearButton" ng-click="clearClicked( $event )" >×</button> '+
                            '</div> '+
                        '</div> '+
                        // selection items
                        '<div class="checkBoxContainer">'+
                            '<div '+
                                'ng-repeat="item in filteredModel | filter:removeGroupEndMarker" class="multiSelectItem"'+
                                'ng-class="{selected: item[ tickProperty ], horizontal: orientationH, vertical: orientationV, multiSelectGroup:item[ groupProperty ], disabled:itemIsDisabled( item )}"'+
                                'ng-click="syncItems( item, $event, $index );" '+
                                'ng-mouseleave="removeFocusStyle( tabIndex );"> '+
                                // this is the spacing for grouped items
                                '<div class="acol" ng-if="item[ spacingProperty ] > 0" ng-repeat="i in numberToArray( item[ spacingProperty ] ) track by $index">'+
                            '</div>  '+
                            '<div class="acol">'+
                                '<label>'+
                                    // input, so that it can accept focus on keyboard click
                                    '<input class="checkbox focusable" type="checkbox" '+
                                        'ng-disabled="itemIsDisabled( item )" '+
                                        'ng-checked="item[ tickProperty ]" '+
                                        'ng-click="syncItems( item, $event, $index )" />'+
                                    // item label using ng-bind-hteml
                                    '<span '+
                                        'ng-class="{disabled:itemIsDisabled( item )}" '+
                                        'ng-bind-html="writeLabel( item, \'itemLabel\' )">'+
                                    '</span>'+
                                '</label>'+
                            '</div>'+
                            // the tick/check mark
                            '<span class="tickMark" ng-if="item[ groupProperty ] !== true && item[ tickProperty ] === true" ng-bind-html="icon.tickMark"></span>'+
                        '</div>'+
                    '</div>'+
                '</div>'+
            '</span>';
            $templateCache.put( 'isteven-multi-select.htm' , template );
        }
    });


    $rootScope.PRINTCOUNT = 0;
    var removePrintArea = function(id) {
        //$("iframe#" + id).remove();
        angular.element(document.getElementById('iframe' + id)).remove()
    };
    $rootScope.PRINTANG = function(dom){
        var ele = angular.element(document.getElementById(dom));
        var idPrefix = "printArea_";
        removePrintArea(idPrefix + $rootScope.PRINTCOUNT);
        $rootScope.PRINTCOUNT++;
        var iframeId = idPrefix + $rootScope.PRINTCOUNT;
        var iframeStyle = 'position:absolute;width:0px;height:0px;left:-500px;top:-500px;';
        iframe = document.createElement('IFRAME');
        angular.element(iframe).attr({
            style: iframeStyle,
            id: iframeId
        });
        angular.forEach(ele.find('input'), function(data,index,array){
            var domsInt = angular.element(data)
            if(domsInt.attr("type") === 'text'){
                domsInt.attr('value', domsInt.val());
            }
        });
        document.body.appendChild(iframe);
        var doc = iframe.contentWindow.document;

        angular.forEach( angular.element(document).find("link"), function(data,index,array){
            angular.element(data).attr("rel").toLowerCase() == "stylesheet"
        });

        angular.forEach( angular.element(document).find("link"), function(data,index,array){
            doc.write('<link type="text/css" rel="stylesheet" href="' + angular.element(data).attr("href") + '" >');
        });


        doc.write('<div class="' + ele.attr("class") + '">' + ele.html() + '</div>');
        doc.close();
        var frameWindow = iframe.contentWindow;
        frameWindow.close();
        frameWindow.focus();

        setTimeout(function(){
           frameWindow.print();
        },1000)
    }

    function typeELe(ele){
        var str = ""
        if(ele.tagName === "INPUT"){
            str = ele.value;
        }else if(ele.tagName === "SELECT"){
            str = $(ele).find("option:selected").text()
        }else{
            str =  $(ele).text();
        }
        return str ;
    }
    $rootScope.excel_tableFun = function(t){
        var _table = $("#excel_daochu"),
            _excel = $(".excel");
        if(_excel[0].tagName !== "TABLE"){
            var key = $('.excel_key'),
                value = $('.excel_value'),
                _th = "",
                _tr = "";
            for (var i = 0; i < key.length; i++) {
                _th += "<th>"+typeELe(key[i])+"</th>";
                _tr += "<td>"+typeELe(value[i])+"</td>";
            }
            _table.append("<thead>"+_th+"</thead>"+"<tr>"+_tr+"</tr>")
            _table.tableExport({ type: 'excel', escape: 'false' ,fileName : t});
        }else{
            _table.append(_excel.html());
            _table.tableExport({ type: 'excel', escape: 'false' ,fileName : t});
        }
        _table.html("");
    }

    $rootScope.excel_tableFun2 = function(t){
        var _table = $("#excel_daochu"),
            _excel = $(".excel");
            _table.append(_excel.html());
            _table.tableExport({ type: 'excel', escape: 'false' ,fileName : t});
        _table.html("");
        $rootScope.excel_tableFun2D('告警门限_TDEV_FREQ');
    }
    $rootScope.excel_tableFun2D = function(t){
        var _table = $("#excel_daochu"),
            _excel2 = $(".excel2");
            _table.append(_excel2.html());
            _table.tableExport({ type: 'excel', escape: 'false' ,fileName : t});
        _table.html("");
    }


    $rootScope.excel_tableFunPTP = function(t,num){
        var _table = $("#excel_daochu"),
            _excel = $("#excelPTP"+num);
        if(_excel[0].tagName !== "TABLE"){
            var key = $('.excel_key'+num),
                value = $('.excel_value'+num),
                _th = "",
                _tr = "";
            for (var i = 0; i < key.length; i++) {
                _th += "<th>"+typeELe(key[i])+"</th>";
                _tr += "<td>"+typeELe(value[i])+"</td>";
            }
            _table.append("<thead>"+_th+"</thead>"+"<tr>"+_tr+"</tr>")
            _table.tableExport({ type: 'excel', escape: 'false' ,fileName : t});
        }else{
            _table.append(_excel.html());
            _table.tableExport({ type: 'excel', escape: 'false' ,fileName : t});
        }
        _table.html("");
    }
    $rootScope.$on('$stateChangeStart', function(event, toState, toParams, fromState, fromParams){
        if(!fromState.name){
            return $location.path("/login");
        }
    });

    $(window.document).on('shown.bs.modal', '.modal', function() {
        window.setTimeout(function() {
            $('[autofocus]', this).focus();
        }.bind(this), 100);
    });

    $(window.document).on('click', function() {
        $('#context-menu').hide();
    });

    $(window.document).on('contextmenu', '.main-navigation .table-files td:first-child, .iconset a.thumbnail', function(e) {
        $('#context-menu').hide().css({
            left: e.pageX,
            top: e.pageY
        }).show();
        e.preventDefault();
    });
}]);
